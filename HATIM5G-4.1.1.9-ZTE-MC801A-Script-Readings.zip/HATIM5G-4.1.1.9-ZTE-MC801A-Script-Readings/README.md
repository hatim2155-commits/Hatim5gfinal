# Hua4GMon — наведение LTE/5G-антенн для роутеров Huawei

![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20Android-blue)
[![Release](https://img.shields.io/github/v/release/Sp0Xik/Hua4GMon)](https://github.com/Sp0Xik/Hua4GMon/releases)
[![CI](https://github.com/Sp0Xik/Hua4GMon/actions/workflows/build.yml/badge.svg)](https://github.com/Sp0Xik/Hua4GMon/actions/workflows/build.yml)
[![Android APK](https://github.com/Sp0Xik/Hua4GMon/actions/workflows/build-android.yml/badge.svg?event=push)](https://github.com/Sp0Xik/Hua4GMon/actions/workflows/build-android.yml)
![Python](https://img.shields.io/badge/python-3.11%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)

Бесплатный инструмент для **монтажников антенн** и всех, кто сам ставит
внешнюю MIMO-антенну к роутеру или модему Huawei (B315, B525, B535, B628,
B636, B818, E3372 и совместимых). Показывает в реальном времени, как
меняется сигнал при повороте антенны, к какой вышке и соте вы
подключены, и помогает зафиксировать лучший результат.

Один репозиторий — **две платформы**:

| Платформа | Технологии | Точка входа |
| :-------- | :--------- | :---------- |
| Windows 10/11 | Tkinter + PyInstaller (один .exe) | `main.py` |
| Android 7–16 | Kivy + Buildozer | `android_main.py` |

Вся логика (опрос роутера, разбор данных, оценка сигнала, Band Lock,
переводы) — в общем пакете `core/`, одинаковом для обеих версий.

> **English.** Hua4GMon is a free antenna-alignment monitor for Huawei
> LTE/5G routers and modems (HiLink API via
> [huawei-lte-api](https://github.com/Salamek/huawei-lte-api)): live
> RSRP/SINR/RSRQ with session peak and "Δ to peak", trend arrow, audio
> "parking sensor", serving cell / eNodeB / band / carrier aggregation info,
> safe Band Lock with read-back and one-click restore, antenna switching,
> mobile-data reattach and a demo mode without a router. Portable Windows
> `.exe` and Android APK are on the
> [Releases](https://github.com/Sp0Xik/Hua4GMon/releases) page; the
> interface is available in Russian and English.

## Возможности

**Наведение антенны**
- Крупные RSRP / SINR / RSRQ / RSSI с оценкой, пиком сессии и
  **«Δ до пика»** — сколько дБ не хватает до лучшего положения.
- **Стрелка тенденции** (↑ / → / ↓) по выбранной метрике (по умолчанию
  SINR) — со сглаживанием и гистерезисом, не «мигает» от шума.
- **Звук-парктроник**: чем ближе к пику, тем выше тон (Windows) или
  чаще сигнал (Android) — можно крутить антенну, не глядя на экран.
- График с автомасштабом и линией пика; признак «нет свежих данных»,
  если роутер перестал отвечать.
- Советы по текущим метрикам: помехи, слабый сигнал, загруженная сота,
  работает один поток MIMO, модем передаёт на пределе мощности.
- **Крышный режим** (Windows, F11) и режим **«Солнце»** с высоким
  контрастом (Android).

**Вышка и сота**
- Оператор, технология (LTE / LTE+ CA / 5G NSA / 5G SA), бэнд и
  **частота DL по EARFCN**, PCI, eNodeB и сектор, TAC, ширина канала.
- Агрегация несущих по данным роутера, 5G NR-метрики.
- **События смены соты** и таблица **лучших сот за сессию**.
- CQI и состояние потоков MIMO, модуляция DL/UL, мощность передатчика.

**Настройка роутера** (всё — через официальный веб-API роутера)
- **Band Lock** по списку бэндов, которые поддерживает ваш модем;
  бэнды, замеченные в эфире, — первыми; «Отметить текущие» одной кнопкой.
- Перед записью программа читает текущие настройки и меняет **только
  LTE-бэнды**; после записи перечитывает и сверяет. Кнопка **«Вернуть как
  было»** восстанавливает настройки, прочитанные при подключении.
- Предупреждение, если выбор отключит текущий бэнд или агрегацию.
- Переключение антенн (авто / внутренняя / внешняя / смешанная).
- **Переподключение мобильной связи** без перезагрузки — модем заново
  выбирает лучшую соту. Перезагрузка роутера с автоматическим
  переподключением программы.

**Сервис**
- **Автопоиск роутера** по типовым адресам.
- **Тестовый режим** на обеих платформах: симулятор модема (вращение
  антенны, смена сот, CA, 5G, Band Lock, перезагрузка) — можно освоить
  программу без роутера.
- Экспорт сессии в **CSV для Excel** (Windows).
- **Диагностика** для отчёта об ошибке: сырые ответы API в JSON; IMEI,
  IMSI, ICCID, номер и серийный номер замаскированы, MAC-адреса (в том
  числе Wi-Fi), IP и DNS скрыты полностью. Номер соты и оператор остаются —
  без них диагностика бесполезна; по ним можно определить район вышки.
- Проверка режима **«белых списков»** оператора (РФ): TLS-рукопожатие с
  SNI, различает блокировку по IP и по имени сайта.
- Два языка: русский и английский.

## Установка

### Windows

Скачайте `Hua4GMon-vX.Y.Z.exe` из [Releases] и запустите — установка не
нужна, это один файл (можно носить на флешке). Программа не сохраняет ни
настроек, ни паролей. При каждом запуске .exe распаковывается во временную
папку Windows (и удаляет её при выходе), а антивирус проверяет
распакованные файлы — поэтому время запуска зависит от компьютера и
антивируса. Всё это время видна заставка с ходом запуска: распаковка,
загрузка программы, построение окна.

При первом запуске неподписанного .exe Windows SmartScreen может
предупредить «Неизвестный издатель» — нажмите «Подробнее» →
«Выполнить в любом случае». Если файл не открывается, в PowerShell:
`Unblock-File .\Hua4GMon-vX.Y.Z.exe`.

**Если браузер или антивирус блокирует файл.** Hua4GMon не подписан
цифровой подписью, а упаковщиком PyInstaller пользуются и авторы
вредоносных программ, поэтому Chrome («Заблокировано скачивание опасного
файла»), SmartScreen или антивирус иногда принимают новую сборку за
опасную. Это ложное срабатывание: каждая сборка — новый файл, и его
репутация начинается с нуля. Скачивайте программу только со страницы
[Releases] и сверяйте SHA256 с указанным в релизе — в PowerShell:
`Get-FileHash .\Hua4GMon-vX.Y.Z.exe`. В Chrome заблокированный файл можно
сохранить из списка загрузок: стрелка «>» справа от файла.

Проверка программы без роутера (для обращения в поддержку):
`Hua4GMon-vX.Y.Z.exe --self-test отчёт.txt` — в файле отчёта версия и
результаты проверки библиотеки роутера и окна, в последней строке `OK`
или `FAIL`.

### Android

Скачайте `Hua4GMon-vX.Y.Z.apk` из [Releases] и установите (понадобится
разрешить установку из этого источника). Android 7.0–16.

> **Обновление с 1.3.0 и старше:** начиная с 1.4.0 APK подписывается
> постоянным ключом. Старую версию нужно один раз удалить, дальше
> обновления ставятся поверх.

[Releases]: https://github.com/Sp0Xik/Hua4GMon/releases

## Как пользоваться

1. Подключите компьютер или телефон к Wi-Fi (или USB) роутера. Нажмите
   **«Найти роутер»** или введите IP (обычно `192.168.8.1`), введите
   пароль с наклейки и подключитесь. Без роутера — **«Тестовый режим»**.
2. На мониторе крутите антенну по стрелке и «Δ до пика». Удобнее всего —
   по SINR: он лучше всего показывает, насколько чисто антенна «видит»
   нужную вышку. Включите звук, чтобы не смотреть на экран.
3. Найдя лучшее положение, на экране **«Сеть»** нажмите «Отметить
   текущие» → «Применить Band Lock», если нужно закрепиться на бэнде.
   Если что-то пошло не так — «Вернуть как было».
4. «Переподключить связь» помогает модему заново выбрать соту после
   поворота антенны.

Горячие клавиши Windows: **F11** — крышный режим, **Ctrl+R** — сбросить
пики, **Ctrl+M** — звук (работают и в русской раскладке). Параметры
командной строки: `--ip`, `--password` (автоподключение), `--demo`,
`--self-test`. У .exe нет консоли, поэтому `--verbose` (подробный лог) и
`--version` выводят текст только при запуске из исходников
(`python main.py`).

## Поддерживаемые устройства

Hua4GMon работает поверх библиотеки
[huawei-lte-api](https://github.com/Salamek/huawei-lte-api) 2.x и
совместим с теми же устройствами в сетевом режиме HiLink:

```
B310s-22, B311-221, B315s-22, B525s-23a, B525s-65a, B715s-23c, B528s,
B535-232, B628-265, B612-233, B818-263, E5180s-22, E5186s-22a,
E5576-320, E5577Cs-321, E8231, E5573s-320, SoyeaLink B535-333, E3131,
E8372h-608, E3372, E3531, E5530As-2, 5G CPE Pro 2 (H122-373),
5G CPE Pro (H112-372), 5G CPE6 (H165-383)
```

Предыдущие версии Hua4GMon проверялись на Huawei B636-336. Функции 1.4.0,
которые требуют подтверждения на реальном оборудовании (5G, коды
агрегации, переподключение связи и др.), перечислены в
[HARDWARE_VALIDATION.md](HARDWARE_VALIDATION.md) — результаты проверки на
вашей модели очень помогут проекту.

## Для разработчиков

```bash
git clone https://github.com/Sp0Xik/Hua4GMon
cd Hua4GMon
pip install -r requirements-dev.txt
python main.py --demo          # Windows-версия в тестовом режиме
pytest                         # тесты (UI-тесты — при наличии дисплея)
ruff check .
mypy                           # типы core/ и tools/ (настройки — в pyproject.toml)
```

UI-тесты в Linux запускаются под Xvfb: `xvfb-run -a pytest`. Тесты
Android-интерфейса требуют `pip install kivy==2.3.0`.

Структура `core/`:

| Модуль | Назначение |
| :----- | :--------- |
| `router.py` | сессия с роутером и фоновый опрос — **единственный** модуль, импортирующий huawei-lte-api |
| `models.py` | типизированный снимок состояния модема (`Snapshot`) |
| `state.py` | пики, тренд, соты, лог сессии, устаревание данных |
| `band_lock.py` | безопасное планирование Band Lock (чтение → изменение → запись → проверка) |
| `rf.py`, `signal_analysis.py` | RF-аналитика и оценка качества |
| `parsers.py`, `constants.py` | разбор ответов роутера, таблица LTE-бэндов 3GPP |
| `errors.py` | классификация ошибок и понятные сообщения |
| `demo.py` | симулятор модема для тестового режима |
| `discovery.py`, `whitelist.py`, `export.py`, `i18n.py` | автопоиск, белые списки, CSV/диагностика, переводы |

**Сборка.** CI (`.github/workflows/`) проверяет код на Python 3.11–3.14,
гоняет тесты и на Windows, и собирает обе платформы; на теге `vX.Y.Z`
выпускает релиз. Windows: `pip install -r requirements-build.txt`, затем
`pyinstaller --noconfirm packaging/windows.spec` — получится один
`dist/Hua4GMon.exe` (VERSIONINFO берётся из `core/__init__.py`,
неиспользуемые файлы отсекает `tools/bundle_filter.py`, заставка —
`packaging/splash.png`). CI запускает собранный .exe с `--self-test`.
Загрузчик PyInstaller в CI собирается из исходников
(`PYINSTALLER_COMPILE_BOOTLOADER`), а `tools/bootloader_check.py` проверяет,
что он не совпадает с готовым из PyPI: так браузеры и антивирусы реже
принимают .exe за опасный. Надёжно убирает такие срабатывания только
подпись кода (например, бесплатная для open source программа SignPath
Foundation); о ложном срабатывании можно сообщить
[Google](https://safebrowsing.google.com/safebrowsing/report_error/) и
[Microsoft](https://www.microsoft.com/en-us/wdsi/filesubmission).
Android: стек Buildozer 1.5.0 + python-for-android
v2024.01.21 + NDK 25b закреплён намеренно (новый p4a тянет Python 3.14,
где ломается pyjnius); еженедельная задача «canary» проверяет Buildozer
1.6.0 и на релиз не влияет. Известные ограничения стека: сборка идёт на
раннере `ubuntu-22.04` (нужен пакет `libtinfo5`), который GitHub удаляет
17.04.2027 (а 23.03, 30.03, 6.04 и 13.04.2027 с 14:00 до 24:00 UTC
намеренно роняет задачи на нём), — до этого сборку нужно перенести на
ubuntu-24.04; NDK 25b
собирает библиотеки для страниц памяти 4 КБ, поэтому на устройствах со
страницами 16 КБ (часть Android 15+) APK может не запуститься.

**Релиз.** Тег `vX.Y.Z` (равный `__version__`) создаёт **черновик** релиза:
к нему прикрепляют .exe и APK два разных workflow. Опубликуйте черновик
вручную (Releases → Edit → Publish), когда в нём есть оба файла, их SHA256
и лицензии, и поставьте в CHANGELOG дату релиза. После обновления
зависимостей перегенерируйте `LICENSES/THIRD-PARTY-NOTICES.txt` (команда —
в начале файла).

**Подпись APK.** Релизный APK подписывается ключом из секретов
репозитория (Settings → Secrets and variables → Actions):
`ANDROID_KEYSTORE_BASE64` (keystore в base64), `ANDROID_KEYSTORE_PASSWORD`,
`ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`. Без них в обычных сборках
получается debug-APK, а сборка по тегу останавливается.

## Благодарности

Отдельный **респект [Adam Schubert (Salamek)][salamek]** и контрибьюторам
библиотеки [huawei-lte-api][hla-repo] — без их работы по разбору веб-API
роутеров Huawei этот проект был бы невозможен.

[salamek]: https://github.com/Salamek
[hla-repo]: https://github.com/Salamek/huawei-lte-api

## Лицензия

Код Hua4GMon — MIT, см. [LICENSE](LICENSE). Сборки включают сторонние
компоненты под их собственными лицензиями (huawei-lte-api — LGPL-3.0,
шрифт DejaVu и др.); список и тексты — в [LICENSE](LICENSE) и папке
[LICENSES](LICENSES/).

## Вклад

Issue и pull request приветствуются — порядок работы описан в
[CONTRIBUTING.md](CONTRIBUTING.md). Особенно ценны результаты проверки на
разных моделях Huawei (см. [HARDWARE_VALIDATION.md](HARDWARE_VALIDATION.md),
для них есть отдельный шаблон issue) и диагностика из программы при
ошибках — шаблон issue подскажет, что приложить. Об уязвимостях —
не в открытом issue, а как описано в [SECURITY.md](SECURITY.md).


## ZTE MC801A (read-only initial integration)

This build adds automatic detection of the ZTE `/goform/goform_get_cmd_process`
API and a read-only MC801A session. It uses the router's LD challenge and the
community-documented double-SHA256 password flow, then polls signal fields such
as LTE RSRP/RSRQ/RSSI/SNR, PCI/EARFCN, active LTE band, and 5G RSRP/RSRQ/SINR,
PCI/NR channel/bandwidth when exposed by the firmware.

Band locking, antenna changes, reboot, and reconnect commands are intentionally
not implemented for ZTE yet. Those controls remain Huawei-specific until the
MC801A firmware's write API is separately verified. Missing fields remain
unavailable rather than being filled with sample values. Hardware testing on
the user's exact MC801A firmware is still required.
