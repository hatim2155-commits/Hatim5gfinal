from core.zte_router import normalize_zte_data


def test_normalize_mc801a_lte_fields():
    data = normalize_zte_data({
        "lte_rsrp": "-83",
        "lte_rsrq": "-10",
        "lte_rssi": "-58",
        "lte_snr": "17",
        "lte_pci": "65",
        "lte_earfcn": "1300",
        "lte_ca_pcell_band": "B3",
        "lte_ca_pcell_bandwidth": "20",
        "cell_id": "123456",
        "rmcc": "420",
        "rmnc": "01",
        "network_provider": "STC",
    })
    assert data["rsrp"] == -83
    assert data["rsrq"] == -10
    assert data["rssi"] == -58
    assert data["sinr"] == 17
    assert data["pci"] == 101
    assert data["earfcn"] == 1300
    assert data["band"] == "B3"
    assert data["dlbandwidth"] == "20"
    assert data["Numeric"] == "42001"
    assert data["FullName"] == "STC"


def test_normalize_mc801a_5g_fields():
    data = normalize_zte_data({
        "Z5g_rsrp": "-92",
        "Z5g_SINR": "21",
        "Z5g_RSRQ": "-8",
        "nr5g_pci": "141",
        "nr5g_action_channel": "640000",
        "nr5g_action_band": "n78",
        "nrdlbandwidth": "100MHz",
    })
    assert data["nr_rsrp"] == -92
    assert data["nr_sinr"] == 21
    assert data["nr_rsrq"] == -8
    assert data["nr_pci"] == 321
    assert data["nr_arfcn"] == 640000
    assert data["nr_band"] == "78"
    assert data["nr_bandwidth"] == "100MHz"


def test_missing_values_are_not_fabricated():
    data = normalize_zte_data({})
    assert data["rsrp"] is None
    assert data["nr_rsrp"] is None
    assert data["pci"] is None


def test_zte_normalized_payload_builds_common_snapshot():
    from core.models import build_snapshot

    raw = normalize_zte_data({
        "lte_rsrp": "-82",
        "lte_rsrq": "-9",
        "lte_snr": "18",
        "lte_pci": "5B",
        "lte_earfcn": "1300",
        "lte_ca_pcell_band": "B3",
        "Z5g_rsrp": "-94",
        "Z5g_SINR": "17",
        "Z5g_RSRQ": "-10",
        "nr5g_pci": "191",
        "nr5g_action_channel": "640000",
        "nr5g_action_band": "n78",
        "nrdlbandwidth": "100",
    })
    snap = build_snapshot(raw)
    assert snap.rsrp == -82
    assert snap.rsrq == -9
    assert snap.sinr == 18
    assert snap.band_label.startswith("B3")
    assert snap.nr_rsrp == -94
    assert snap.nr_sinr == 17
    assert snap.nr_rsrq == -10
    assert snap.nr_pci == 401
    assert snap.nr_arfcn == 640000
    assert snap.nr_band_label.lower() == "n78"


def test_supplied_script_hex_pci_and_ca_records():
    data = normalize_zte_data({
        "lte_pci": "65",  # ZTE URL.txt uses parseInt(lte_pci, 16) => 101
        "nr5g_pci": "141",  # => 321
        "lte_ca_pcell_band": "3",
        "lte_multi_ca_scell_info": "x,101,1800,1,1300,20;",
        "Z5g_rsrp": "-91",
        "Z5g_SINR": "19",
        "nr5g_action_band": "n78",
    })
    assert data["pci"] == 101
    assert data["nr_pci"] == 321
    assert data["ca_bands"] == ["B3", "B1"]
    assert data["ca_summary"] == "B3+B1"
    assert data["nr_band"] == "78"
