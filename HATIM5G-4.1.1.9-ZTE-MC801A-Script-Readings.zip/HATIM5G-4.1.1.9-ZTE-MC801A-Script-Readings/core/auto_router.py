"""Router selection facade: detect ZTE MC801A API, otherwise use Huawei adapter."""
from __future__ import annotations

from typing import Any

from core.router import RouterSession, RouterConfig
from core.zte_router import ZteMC801ASession, is_zte_mc801a_api


class AutoRouterSession:
    """SessionWorker-compatible facade with read-only ZTE support and Huawei fallback."""

    def __init__(self, ip: str, password: str, *, timeout: float = 4.0):
        self.ip = ip
        self.password = password
        self.timeout = timeout
        self._delegate: Any = None
        self.router_type = "unknown"

    def open(self) -> dict[str, Any]:
        if self._delegate is None:
            if is_zte_mc801a_api(self.ip, timeout=min(self.timeout, 1.5)):
                self._delegate = ZteMC801ASession(self.ip, self.password, timeout=self.timeout)
                self.router_type = "zte"
            else:
                self._delegate = RouterSession(self.ip, self.password, timeout=self.timeout)
                self.router_type = "huawei"
        try:
            return self._delegate.open()
        except Exception:
            # Do not silently retry with another router API after an auth failure.
            # A ZTE password failure should be shown as such, not disguised as Huawei failure.
            raise

    def close(self) -> None:
        if self._delegate is not None:
            self._delegate.close()

    def __getattr__(self, name: str) -> Any:
        delegate = object.__getattribute__(self, "_delegate")
        if delegate is None:
            raise AttributeError(name)
        return getattr(delegate, name)
