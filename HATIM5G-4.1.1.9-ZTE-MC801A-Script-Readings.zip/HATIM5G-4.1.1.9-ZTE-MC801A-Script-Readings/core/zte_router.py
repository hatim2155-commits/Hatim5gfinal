"""Read-only signal adapter for ZTE MC801A / compatible ZTE goform routers.

The ZTE web API is undocumented and firmware-dependent. This module only
reads signal/status fields; it deliberately does not send band-lock, antenna,
reboot, or network-mode write commands.
"""
from __future__ import annotations

import hashlib
import logging
import re
import threading
from typing import Any
from urllib.parse import urljoin

import requests

from core.router import RouterConfig

logger = logging.getLogger("HATIM5G.zte")


class ZteLoginError(Exception):
    """Invalid router admin password or unsuccessful ZTE login."""
    code = 108002


DEFAULT_TIMEOUT = 4.0

# Fields seen on ZTE MC801A firmware/community API implementations.
SIGNAL_FIELDS = (
    # Exact read fields used by the supplied ZTE URL.txt script.
    "lte_pci,lte_pci_lock,lte_earfcn_lock,wan_ipaddr,wan_apn,pm_sensor_mdm,"
    "pm_modem_5g,nr5g_pci,nr5g_action_channel,nr5g_action_band,Z5g_SINR,"
    "Z5g_rsrp,wan_active_band,wan_active_channel,wan_lte_ca,"
    "lte_multi_ca_scell_info,cell_id,dns_mode,prefer_dns_manual,"
    "standby_dns_manual,network_type,rmcc,rmnc,lte_rsrq,lte_rssi,lte_rsrp,"
    "lte_snr,lte_ca_pcell_band,lte_ca_pcell_bandwidth,lte_ca_scell_band,"
    "lte_ca_scell_bandwidth,lte_ca_pcell_arfcn,lte_ca_scell_arfcn,"
    "opms_wan_mode,opms_wan_auto_mode,ppp_status,loginfo,wa_inner_version,"
    "cr_version,RD,LD,modem_main_state,network_provider,Z5g_RSRQ,"
    "nr5g_rsrp,nr5g_rsrq,nr5g_sinr,nrdlbandwidth,signalbar"
)


def _clean(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text.lower() in {"", "null", "undefined", "unknown", "n/a", "--"}:
        return ""
    return text


def _number(value: Any) -> Any:
    """Keep a real numeric string; leave missing/invalid values unavailable."""
    text = _clean(value)
    if not text:
        return None
    text = text.replace("dBm", "").replace("dB", "").strip()
    try:
        if re.fullmatch(r"[-+]?\d+", text):
            return int(text)
        return float(text)
    except (TypeError, ValueError):
        return value


def _zte_hex_int(value: Any) -> int | None:
    """Decode ZTE's PCI/cell identifiers as hexadecimal, as the supplied JS does."""
    text = _clean(value)
    if not text:
        return None
    try:
        if text.lower().startswith("0x"):
            return int(text, 16)
        # These fields are explicitly parsed with parseInt(value, 16) by ZTE URL.txt.
        return int(text, 16)
    except (TypeError, ValueError):
        return None


def _parse_ca_cells(value: Any) -> list[dict[str, Any]]:
    """Parse lte_multi_ca_scell_info records (semicolon/comma delimited)."""
    text = _clean(value)
    if not text:
        return []
    cells: list[dict[str, Any]] = []
    for record in text.rstrip(";").split(";"):
        fields = record.split(",")
        # Supplied script reads fields[3] as band, [4] as PCI, [5] as bandwidth,
        # while its INFO display reads [1] as PCI and [4] as EARFCN on some firmware.
        if len(fields) < 4:
            continue
        band = _clean(fields[3])
        if not band:
            continue
        pci = _clean(fields[1]) if len(fields) > 1 else ""
        earfcn = _clean(fields[4]) if len(fields) > 4 else ""
        bandwidth = _clean(fields[5]) if len(fields) > 5 else ""
        cells.append({"band": _band_number(band, "B") or band,
                      "pci_raw": pci, "earfcn": earfcn,
                      "bandwidth_mhz": bandwidth})
    return cells


def _first(data: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        value = data.get(key)
        if _clean(value):
            return value
    return None


def _band_number(value: Any, prefix: str) -> str:
    text = _clean(value)
    if not text:
        return ""
    # Preserve explicit B3/N78 or find a band number in labels such as "LTE BAND 3".
    match = re.search(rf"(?i)(?:{prefix}\s*)?(\d{{1,3}})", text)
    return f"{prefix.upper()}{match.group(1)}" if match else ""


def normalize_zte_data(data: dict[str, Any]) -> dict[str, Any]:
    """Map observed MC801A field names into HATIM5G's common Snapshot schema."""
    raw = dict(data)

    lte_band = _band_number(
        _first(data, "lte_ca_pcell_band", "wan_active_band", "band"),
        "B",
    )
    nr_band = _band_number(
        _first(data, "nr5g_action_band", "nr_band", "nrband"),
        "N",
    )

    # Some firmware reports the NR band in a text field with extra words.
    if nr_band and nr_band.startswith("N"):
        nr_band = nr_band[1:]

    lte_rsrp = _number(_first(data, "lte_rsrp", "rsrp"))
    lte_rsrq = _number(_first(data, "lte_rsrq", "rsrq"))
    lte_rssi = _number(_first(data, "lte_rssi", "rssi"))
    lte_sinr = _number(_first(data, "lte_snr", "lte_sinr", "sinr", "Z_SINR"))

    nr_rsrp = _number(_first(data, "Z5g_rsrp", "nr5g_rsrp", "nr_rsrp", "nrrsrp"))
    nr_rsrq = _number(_first(data, "Z5g_RSRQ", "nr5g_rsrq", "nr_rsrq", "nrrsrq"))
    nr_sinr = _number(_first(data, "Z5g_SINR", "nr5g_sinr", "nr_sinr", "nrsinr"))

    # Keep both normalized values and original response fields for diagnostics.
    ca_cells = _parse_ca_cells(data.get("lte_multi_ca_scell_info"))
    ca_bands = [cell["band"] for cell in ca_cells if cell.get("band")]
    if lte_band and lte_band not in ca_bands:
        ca_bands.insert(0, lte_band)
    # The supplied page's INFO button decodes LTE/NR PCI as hexadecimal.
    lte_pci = _zte_hex_int(_first(data, "lte_pci", "pci"))
    nr_pci = _zte_hex_int(_first(data, "nr5g_pci", "nrpci", "nr_pci"))
    cell_id_raw = _clean(_first(data, "cell_id", "lte_cell_id"))
    cell_id_decoded = _zte_hex_int(cell_id_raw) if cell_id_raw else None

    raw.update({
        "rsrp": lte_rsrp,
        "rsrq": lte_rsrq,
        "rssi": lte_rssi,
        "sinr": lte_sinr,
        "nr_rsrp": nr_rsrp,
        "nr_rsrq": nr_rsrq,
        "nr_sinr": nr_sinr,
        "pci": lte_pci,
        "earfcn": _number(_first(data, "lte_earfcn", "earfcn", "wan_active_channel")),
        "band": "+".join(ca_bands) if ca_bands else (lte_band or _clean(_first(data, "wan_active_band", "band"))),
        "nr_band": nr_band,
        "nr_arfcn": _number(_first(data, "nr5g_action_channel", "nrarfcn", "nr_arfcn")),
        "nr_pci": nr_pci,
        "nr_bandwidth": _clean(_first(data, "nrdlbandwidth", "nr_bandwidth")),
        "dlbandwidth": _clean(_first(data, "lte_ca_pcell_bandwidth", "dlbandwidth")),
        "cell_id": str(cell_id_decoded) if cell_id_decoded is not None else cell_id_raw,
        "cell_id_hex": cell_id_raw,
        "enbid": cell_id_decoded // 256 if cell_id_decoded is not None else None,
        "lte_ca_cells": ca_cells,
        "ca_bands": ca_bands,
        "ca_summary": "+".join(ca_bands),
        "lte_pci_lock": _clean(data.get("lte_pci_lock")),
        "lte_earfcn_lock": _clean(data.get("lte_earfcn_lock")),
        "lte_ca_pcell_arfcn": _clean(data.get("lte_ca_pcell_arfcn")),
        "lte_ca_scell_arfcn": _clean(data.get("lte_ca_scell_arfcn")),
        "temperature_lte": _clean(data.get("pm_sensor_mdm")),
        "temperature_5g": _clean(data.get("pm_modem_5g")),
        "network_type": _clean(_first(data, "network_type")),
        "Numeric": _clean(_first(data, "plmn", "hplmn")) or (
            _clean(data.get("rmcc")) + _clean(data.get("rmnc"))
        ),
        "FullName": _clean(_first(data, "network_provider", "spn_name_data", "operator")),
        "bandInfo": lte_band,
        "wan_lte_ca": _clean(data.get("wan_lte_ca")),
        "lte_multi_ca_scell_info": _clean(data.get("lte_multi_ca_scell_info")),
    })
    return raw


class ZteMC801ASession:
    """Read-only polling session for ZTE MC801A; implements SessionWorker's API."""

    supports_band_lock = False
    supports_antenna_control = False
    supports_reboot = False
    supports_reattach = False

    def __init__(self, ip: str, password: str, *, timeout: float = DEFAULT_TIMEOUT):
        self.ip = ip.strip()
        self.url = f"http://{self.ip}/"
        self.password = password
        self.timeout = timeout
        self._http = requests.Session()
        self._lock = threading.RLock()
        self._open = False
        self._tick = 0
        self.device_info: dict[str, Any] = {}
        self.supported_bands: list[int] = []
        self.access_modes: list[str] = ["LTE", "5G"]
        self.caps_known = False
        self.original_net_mode = None

    @property
    def is_open(self) -> bool:
        return self._open

    @property
    def supports_5g(self) -> bool:
        return True

    @property
    def locks_lte_only(self) -> bool:
        return False

    def _get_json(self, params: dict[str, Any]) -> dict[str, Any]:
        response = self._http.get(
            urljoin(self.url, "goform/goform_get_cmd_process"),
            params=params,
            headers={"Referer": self.url, "X-Requested-With": "XMLHttpRequest"},
            timeout=self.timeout,
        )
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, dict):
            raise ConnectionError("ZTE returned an unexpected response")
        return data

    def _login(self) -> None:
        # MC801A community API: SHA256(password), then SHA256(uppercase hash + LD).
        challenge = self._get_json({
            "isTest": "false",
            "cmd": "LD",
        })
        ld = _clean(challenge.get("LD"))
        if not ld:
            raise ConnectionError("ZTE login challenge LD was not returned")
        first = hashlib.sha256(self.password.encode("utf-8")).hexdigest().upper()
        hashed_password = hashlib.sha256(f"{first}{ld}".encode("utf-8")).hexdigest().upper()
        response = self._http.get(
            urljoin(self.url, "goform/goform_set_cmd_process"),
            params={"isTest": "false", "goformId": "LOGIN", "password": hashed_password},
            cookies={"stok": ""},
            headers={"Referer": self.url, "X-Requested-With": "XMLHttpRequest"},
            timeout=self.timeout,
        )
        response.raise_for_status()
        result = response.json()
        if str(result.get("result", "")) != "0":
            raise ZteLoginError("ZTE login failed: check the router admin password")
        # requests.Session normally stores the response cookie automatically.
        self._open = True

    def open(self) -> dict[str, Any]:
        with self._lock:
            self.close()
            # Fetch a fresh session challenge before each login.
            self._http.cookies.clear()
            self._login()
            try:
                data = self._get_json({
                    "isTest": "false",
                    "cmd": "wa_inner_version,cr_version,modem_main_state,network_type",
                    "multi_data": "1",
                })
            except Exception:
                data = {}
            model = _clean(_first(data, "wa_inner_version", "cr_version")) or "ZTE MC801A"
            self.device_info = {
                "DeviceName": "ZTE MC801A",
                "Model": model,
                "SoftwareVersion": _clean(data.get("cr_version")),
                "network_type": _clean(data.get("network_type")),
                "RouterType": "ZTE",
            }
            self._tick = 0
            return dict(self.device_info)

    def fetch(self) -> dict[str, Any]:
        with self._lock:
            if not self._open:
                raise ConnectionError("ZTE session is not open")
            data = self._get_json({
                "isTest": "false",
                "cmd": SIGNAL_FIELDS,
                "multi_data": "1",
            })
            normalized = normalize_zte_data(data)
            # Empty responses usually indicate an expired login or API mismatch.
            if not any(normalized.get(k) is not None for k in ("rsrp", "nr_rsrp", "sinr", "nr_sinr")):
                # Do not fabricate readings; return actual fields for UI diagnostics.
                logger.info("ZTE returned no recognized signal fields; keys=%s", sorted(data.keys()))
            self._tick += 1
            return normalized

    def close(self) -> None:
        with self._lock:
            try:
                self._http.close()
            except Exception:
                pass
            self._http = requests.Session()
            self._open = False

    def read_config(self) -> RouterConfig:
        # No writes/settings API is enabled in this read-only integration.
        return RouterConfig(net_mode=None, locked=None, antenna=None)

    def collect_diagnostics(self) -> tuple[dict[str, Any], dict[str, str]]:
        with self._lock:
            data = self._get_json({
                "isTest": "false",
                "cmd": SIGNAL_FIELDS,
                "multi_data": "1",
            })
            # Do not include password, cookies or authentication challenge.
            return {"zte_signal": normalize_zte_data(data)}, {}

    def _read_only(self, *_args: Any, **_kwargs: Any) -> Any:
        raise NotImplementedError(
            "ZTE MC801A support currently reads signal data only; router settings are not changed."
        )

    plan_band_lock = _read_only
    plan_all_bands = _read_only
    plan_restore_original = _read_only
    apply_plan = _read_only
    set_antenna = _read_only
    read_antenna = lambda self: None
    reboot = _read_only
    reattach = _read_only


def is_zte_mc801a_api(ip: str, timeout: float = 1.5) -> bool:
    """Detect ZTE goform API without logging in or changing router settings."""
    try:
        response = requests.get(
            f"http://{ip.strip()}/goform/goform_get_cmd_process",
            params={"isTest": "false", "cmd": "LD"},
            headers={"Referer": f"http://{ip.strip()}/"},
            timeout=timeout,
        )
        if response.status_code != 200:
            return False
        data = response.json()
        return isinstance(data, dict) and "LD" in data
    except Exception:
        return False
