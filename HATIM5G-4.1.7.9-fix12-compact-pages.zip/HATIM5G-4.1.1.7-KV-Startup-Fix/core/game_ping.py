"""Ping page data: game publisher endpoints and regional reference points.

Every number is a measured TCP connect time (see ``core.game_test``). These are
reachability proxies for the publisher / cloud region, NOT the in-match game-server
ping, and the UI says so. Nothing here is invented: a host that does not answer is
reported as unavailable.
"""
from __future__ import annotations

import statistics
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Callable, Sequence

from .game_test import GameProbe, probe_game_endpoint

# key, display name, one-letter badge, publisher host
GAMES: tuple[tuple[str, str, str, str], ...] = (
    ('pubg', 'PUBG Mobile', 'P', 'pubgmobile.com'),
    ('freefire', 'Free Fire', 'F', 'ff.garena.com'),
    ('codm', 'Call of Duty Mobile', 'C', 'callofduty.com'),
    ('mlbb', 'Mobile Legends', 'M', 'mobilelegends.com'),
    ('supercell', 'Brawl Stars · Clash Royale', 'S', 'supercell.com'),
    ('fortnite', 'Fortnite', 'F', 'fortnite.com'),
    ('roblox', 'Roblox', 'R', 'roblox.com'),
    ('fc', 'EA FC Mobile', 'E', 'ea.com'),
    ('genshin', 'Genshin Impact', 'G', 'hoyoverse.com'),
    ('valorant', 'Valorant', 'V', 'playvalorant.com'),
    ('lol', 'League of Legends · Wild Rift', 'L', 'leagueoflegends.com'),
    ('steam', 'Steam · CS2 · Dota 2', 'S', 'steampowered.com'),
    ('epic', 'Epic Games · Rocket League', 'E', 'epicgames.com'),
    ('minecraft', 'Minecraft', 'M', 'minecraft.net'),
    ('battlenet', 'Battle.net · Overwatch', 'B', 'battle.net'),
    ('ubisoft', 'Ubisoft · Rainbow Six', 'U', 'ubisoft.com'),
    ('psn', 'PlayStation Network', 'P', 'playstation.com'),
    ('xbox', 'Xbox Live', 'X', 'xbox.com'),
)

# Public cloud regional endpoints, as reference points for where game servers are hosted.
REGIONS: tuple[tuple[str, str, str, str], ...] = (
    ('bahrain', 'الشرق الأوسط · البحرين', 'B', 'ec2.me-south-1.amazonaws.com'),
    ('uae', 'الشرق الأوسط · الإمارات', 'U', 'ec2.me-central-1.amazonaws.com'),
    ('frankfurt', 'أوروبا · فرانكفورت', 'E', 'ec2.eu-central-1.amazonaws.com'),
    ('mumbai', 'آسيا · مومباي', 'A', 'ec2.ap-south-1.amazonaws.com'),
)

QUALITY_EXCELLENT, QUALITY_GOOD, QUALITY_FAIR, QUALITY_POOR, QUALITY_NONE = (
    'excellent', 'good', 'fair', 'poor', 'none')


def quality(ms: float | None) -> str:
    """Quality class of a ping. Same thresholds as the scale bar on the ping page."""
    if ms is None:
        return QUALITY_NONE
    if ms < 40:
        return QUALITY_EXCELLENT
    if ms < 80:
        return QUALITY_GOOD
    if ms < 150:
        return QUALITY_FAIR
    return QUALITY_POOR


@dataclass(frozen=True, slots=True)
class PingResult:
    key: str
    name: str
    badge: str
    host: str
    ping_ms: float | None
    jitter_ms: float | None
    failures: int
    attempts: int
    error: str = ''


@dataclass(frozen=True, slots=True)
class PingSummary:
    ping_ms: float | None
    jitter_ms: float | None
    loss_pct: float | None
    best_ms: float | None


def _result(entry: tuple[str, str, str, str], probe: GameProbe) -> PingResult:
    return PingResult(entry[0], entry[1], entry[2], entry[3], probe.ping_ms, probe.jitter_ms,
                      probe.failures, probe.attempts, probe.error)


def sort_by_ping(results: Sequence[PingResult]) -> list[PingResult]:
    """Lowest ping first; hosts that did not answer go last."""
    return sorted(results, key=lambda r: (r.ping_ms is None, r.ping_ms or 0.0))


def summarize(results: Sequence[PingResult]) -> PingSummary:
    """Median ping and jitter over the hosts that answered, overall loss, best ping."""
    pings = [r.ping_ms for r in results if r.ping_ms is not None]
    jitters = [r.jitter_ms for r in results if r.jitter_ms is not None]
    attempts = sum(r.attempts for r in results)
    failures = sum(r.failures for r in results)
    return PingSummary(
        ping_ms=statistics.median(pings) if pings else None,
        jitter_ms=statistics.median(jitters) if jitters else None,
        loss_pct=(failures / attempts * 100.0) if attempts else None,
        best_ms=min(pings) if pings else None)


def run_ping_suite(attempts: int = 5, timeout: float = 2.5,
                   games: Sequence[tuple[str, str, str, str]] = GAMES,
                   regions: Sequence[tuple[str, str, str, str]] = REGIONS,
                   probe=probe_game_endpoint,
                   progress: Callable[[int, int], None] | None = None
                   ) -> tuple[list[PingResult], list[PingResult]]:
    """Probe every game host and every regional point in parallel.

    progress(done, total) is called from worker threads each time one host finishes."""
    entries = list(games) + list(regions)
    total = len(entries)
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(probe, e[3], attempts, timeout) for e in entries]
        if progress is not None:
            for done, _f in enumerate(as_completed(futures), 1):
                try:
                    progress(done, total)
                except Exception:       # a UI callback must never break the measurement
                    pass
        probes = [f.result() for f in futures]
    results = [_result(e, p) for e, p in zip(entries, probes)]
    return results[:len(games)], results[len(games):]
