"""Connection-quality probes for mobile games.

Measures repeated TCP+TLS handshake latency to publisher-owned public HTTPS
endpoints. These are reachability proxies, NOT the in-match game-server ping.
"""
from __future__ import annotations

import socket
import ssl
import statistics
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Sequence


@dataclass(frozen=True, slots=True)
class GameProbe:
    host: str
    samples_ms: tuple[float, ...]
    failures: int
    attempts: int
    error: str = ""

    @property
    def packet_loss_pct(self) -> float:
        return (self.failures / self.attempts * 100.0) if self.attempts else 100.0

    @property
    def average_ms(self) -> float | None:
        return statistics.mean(self.samples_ms) if self.samples_ms else None

    @property
    def min_ms(self) -> float | None:
        return min(self.samples_ms) if self.samples_ms else None

    @property
    def max_ms(self) -> float | None:
        return max(self.samples_ms) if self.samples_ms else None

    @property
    def jitter_ms(self) -> float | None:
        if len(self.samples_ms) < 2:
            return None
        # Mean absolute difference between consecutive successful probes.
        return statistics.mean(abs(b - a) for a, b in zip(self.samples_ms, self.samples_ms[1:]))


_CTX: ssl.SSLContext | None = None


def _tls_context() -> ssl.SSLContext:
    """Verified TLS context. Android's Python has no system CA store, so the
    bundled certifi CA list is used; verification is never turned off."""
    global _CTX
    if _CTX is None:
        try:
            import certifi
            _CTX = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            _CTX = ssl.create_default_context()
    return _CTX


def _one_probe(host: str, timeout: float) -> tuple[float | None, str]:
    started = time.perf_counter()
    try:
        with socket.create_connection((host, 443), timeout=timeout) as raw:
            ctx = _tls_context()
            with ctx.wrap_socket(raw, server_hostname=host):
                return (time.perf_counter() - started) * 1000.0, ""
    except (OSError, ssl.SSLError, TimeoutError) as exc:
        if isinstance(exc, socket.gaierror):
            return None, "DNS lookup failed"
        if isinstance(exc, TimeoutError) or isinstance(exc, socket.timeout):
            return None, "Timed out"
        if isinstance(exc, ssl.SSLCertVerificationError):
            return None, 'TLS certificate verification failed (check bundled CA certificates/date/time)'
        return None, type(exc).__name__


def probe_game_endpoint(host: str, attempts: int = 8, timeout: float = 2.5) -> GameProbe:
    attempts = max(3, min(int(attempts), 20))
    samples: list[float] = []
    failures = 0
    errors: list[str] = []
    for _ in range(attempts):
        elapsed, error = _one_probe(host, timeout)
        if elapsed is None:
            failures += 1
            if error:
                errors.append(error)
        else:
            samples.append(elapsed)
    return GameProbe(host, tuple(samples), failures, attempts,
                     errors[0] if errors and not samples else "")


@dataclass(frozen=True, slots=True)
class GameConnectionReport:
    pubg: GameProbe
    fc_mobile: GameProbe
    note: str = ("Measures TCP/TLS latency to public publisher endpoints; "
                 "not the live match server ping.")


def run_game_connection_test(attempts: int = 8, timeout: float = 2.5) -> GameConnectionReport:
    """Test PUBG Mobile and EA/FC Mobile publisher endpoints in parallel."""
    targets: Sequence[tuple[str, str]] = (
        ("pubg", "pubgmobile.com"),
        ("fc", "ea.com"),
    )
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = {key: pool.submit(probe_game_endpoint, host, attempts, timeout)
                   for key, host in targets}
        return GameConnectionReport(pubg=futures["pubg"].result(),
                                    fc_mobile=futures["fc"].result())
