"""Lock the router to one specific cell (NSA: one LTE cell + one NR cell).

Separate from ``core.band_lock`` (4G band masks), which is not touched.
Request layout is taken from the router's own frequency-lock call
(``POST api/net/lock-freq``, ``lock_mode`` 2 = band + channel + PCI)::

    <request>
      <lte_info><lock_mode>2</lock_mode>
        <freq_infos><freq_info><band>28</band><freq>9310</freq><pci>311</pci></freq_info></freq_infos>
        <all_bands>28</all_bands></lte_info>
      <nr_info> ... same shape with the NR band / NR-ARFCN / PCI ... </nr_info>
    </request>

Band is the plain number ("28", "78"), freq is the EARFCN / NR-ARFCN.
Nothing is guessed: a target with a missing field is refused.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

LOCK_ENDPOINT = 'net/lock-freq'
LOCK_MODE_CELL = 2


@dataclass(frozen=True)
class CellTarget:
    band: int
    freq: int
    pci: int


def band_number(text: Any) -> int | None:
    """'B28' / 'n78' / '28' -> 28 / 78 / 28; None if there is no number."""
    match = re.search(r'\d+', str(text or ''))
    return int(match.group(0)) if match else None


def make_target(band: Any, freq: Any, pci: Any) -> CellTarget | None:
    b = band_number(band)
    try:
        f = int(float(freq))
        p = int(float(pci))
    except (TypeError, ValueError):
        return None
    if b is None or f < 0 or p < 0:
        return None
    return CellTarget(b, f, p)


def _tech(target: CellTarget) -> dict[str, Any]:
    return {
        'lock_mode': LOCK_MODE_CELL,
        'freq_infos': {'freq_info': {'band': target.band, 'freq': target.freq,
                                     'pci': target.pci}},
        'all_bands': target.band,
    }


def build_request(lte: CellTarget, nr: CellTarget) -> dict[str, Any]:
    """Nested dict in the order the router expects (serialised to XML by the API client)."""
    return {'lte_info': _tech(lte), 'nr_info': _tech(nr)}


def to_xml(data: dict[str, Any]) -> str:
    """Plain XML rendering of ``build_request`` (used by tests and diagnostics)."""
    def render(node: Any) -> str:
        if isinstance(node, dict):
            return ''.join(f'<{k}>{render(v)}</{k}>' for k, v in node.items())
        return str(node)
    return '<?xml version="1.0" encoding="UTF-8"?><request>' + render(data) + '</request>'


def locked_on(snap: Any, lte: CellTarget) -> bool:
    """Is the router now served by the requested LTE cell? (read-back check)"""
    if snap is None:
        return False
    return getattr(snap, 'pci', None) == lte.pci and getattr(snap, 'earfcn', None) == lte.freq
