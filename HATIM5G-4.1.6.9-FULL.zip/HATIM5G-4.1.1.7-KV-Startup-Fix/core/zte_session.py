"""Read-only session for ZTE routers (tested on MC801A, firmware BD_SASTCMC801A).

Same interface as ``RouterSession`` for what the app reads, so the existing
pages work unchanged: ``fetch()`` returns a dict that uses the Huawei field
names ``build_snapshot`` already understands. Only GET requests are made after
the one login request. Nothing here writes a setting or sends a lock command:
every control method raises ``ZteReadOnly`` with a plain message.

Field meaning (confirmed against the router's own web script and a real reply):
  * ``lte_pci`` / ``nr5g_pci`` / ``cell_id`` are HEX strings ("135" = PCI 309).
  * ``ngbr_cell_info``: ``EARFCN,PCI,RSRQ,RSRP,RSSI;...`` (PCI decimal).
  * ``lte_multi_ca_scell_info``: ``;``-separated cells, fields
    [1]=PCI, [3]=band, [4]=EARFCN, [5]=bandwidth MHz (as in the web script).
Anything the router leaves empty stays empty; the UI then shows it unavailable.
"""
from __future__ import annotations

import base64
import hashlib
import logging
import re
import threading
import time
from dataclasses import dataclass
from typing import Any

import requests

logger = logging.getLogger(__name__)

_GET = '/goform/goform_get_cmd_process'
_SET = '/goform/goform_set_cmd_process'

SIGNAL_CMDS = (
    'lte_rsrp', 'lte_rsrq', 'lte_snr', 'lte_rssi', 'lte_pci', 'lte_band',
    'wan_active_band', 'wan_active_channel', 'wan_lte_ca', 'lte_ca_pcell_band',
    'lte_ca_pcell_bandwidth', 'lte_ca_pcell_arfcn', 'lte_multi_ca_scell_info',
    'lte_multi_ca_scell_sig_info', 'cell_id', 'rmcc', 'rmnc', 'network_type',
    'network_provider', 'ppp_status', 'nr5g_pci', 'nr5g_action_band',
    'nr5g_action_channel', 'nr5g_rsrp', 'nr5g_rsrq', 'nr5g_snr', 'Z5g_rsrp',
    'Z5g_SINR', 'Z5g_rsrq', 'nr5g_bandwidth', 'nr_ca_pcell_bandwidth',
    'nr_multi_ca_scell_info', 'nr_multi_ca_scell_sig_info', 'pm_sensor_mdm',
    'pm_modem_5g', 'loginfo',
)

# LTE band mask that means "all bands" on this ZTE family (taken from the router's own
# web script and confirmed by `lte_band_lock` of a router with no lock set).
ZTE_ALL_LTE_MASK = 0xA3E2AB0908DF


def mask_to_bands(mask: int) -> list[int]:
    return [b for b in range(1, 64) if mask >> (b - 1) & 1]


@dataclass(frozen=True)
class ZteBandPlan:
    """What will be written: the LTE band mask (bit n-1 = band n)."""
    mask: int

    @property
    def lteband(self) -> str:
        return f'0x{self.mask:x}'


@dataclass(frozen=True)
class ZteConfig:
    net_mode: None
    locked: list[int] | None
    antenna: int | None


class ZteCommandError(Exception):
    """The router refused or did not accept a command."""


READ_ONLY_MESSAGE = ("راوترات ZTE مدعومة للقراءة فقط حاليًا؛ لم يُرسل أي أمر "
                     "للراوتر.")


class ZteReadOnly(Exception):
    """A control action was requested; ZTE support is read-only for now."""


class ZteLoginError(Exception):
    """Login refused. ``code`` 108006 = wrong login/password (stops retries)."""
    code = 108006


def is_zte(ip: str, timeout: float = 3.0) -> bool:
    """True if the address answers ZTE's goform status request (GET only)."""
    try:
        reply = requests.get(f'http://{ip}{_GET}?isTest=false&cmd=wa_inner_version',
                             timeout=timeout)
        return 'wa_inner_version' in reply.json()
    except Exception:
        return False


# ---------- pure mapping helpers (unit-tested without a router) ----------

def _s(value: Any) -> str:
    return '' if value is None else str(value).strip()


def hex_to_dec(value: Any) -> str:
    """'135' -> '309'. Empty or non-hex stays empty (never guessed)."""
    text = _s(value)
    if not text:
        return ''
    try:
        return str(int(text, 16))
    except ValueError:
        return ''


def _digits(value: Any) -> str:
    match = re.search(r'\d+', _s(value))
    return match.group(0) if match else ''


def _width(value: Any) -> str:
    match = re.search(r'\d+(?:\.\d+)?', _s(value))
    return match.group(0) if match else ''


def _tokens(entries: list[tuple[str, str, str, str]]) -> str:
    """entries: (prefix, band, width, channel). The app reads either
    ``20MHz@1650(B3)`` for every carrier or plain ``(B3)`` for every carrier;
    mixing the two would hide some carriers, so width/channel are used only
    when the router gave them for all."""
    entries = [e for e in entries if e[1]]
    full = bool(entries) and all(e[2] and e[3] for e in entries)
    return ' '.join(f'{w}MHz@{ch}({p}{b})' if full else f'({p}{b})'
                    for p, b, w, ch in entries)


def parse_scells(info: str) -> list[dict[str, str]]:
    cells = []
    for entry in _s(info).split(';'):
        fields = [f.strip() for f in entry.split(',')]
        if len(fields) < 5 or not _digits(fields[3]):
            continue
        cells.append({'pci': fields[1], 'band': _digits(fields[3]),
                      'earfcn': _digits(fields[4]),
                      'width': _width(fields[5]) if len(fields) > 5 else ''})
    return cells


def to_huawei_style(z: dict[str, Any]) -> dict[str, Any]:
    """ZTE reply -> dict with the field names build_snapshot() reads."""
    out: dict[str, Any] = {}
    out['rsrp'], out['rsrq'] = _s(z.get('lte_rsrp')), _s(z.get('lte_rsrq'))
    out['sinr'], out['rssi'] = _s(z.get('lte_snr')), _s(z.get('lte_rssi'))
    out['pci'] = hex_to_dec(z.get('lte_pci'))
    channel = _digits(z.get('wan_active_channel')) or _digits(z.get('lte_ca_pcell_arfcn'))
    out['earfcn'] = channel
    cid = hex_to_dec(z.get('cell_id'))
    if cid:
        out['cell_id'] = cid

    scells = parse_scells(z.get('lte_multi_ca_scell_info'))
    pband = (_digits(z.get('lte_band')) or _digits(z.get('lte_ca_pcell_band'))
             or _digits(z.get('wan_active_band')))
    pwidth = _width(z.get('lte_ca_pcell_bandwidth'))
    entries = [('B', pband, pwidth, channel)]
    entries += [('B', c['band'], c['width'], c['earfcn']) for c in scells]
    if pwidth:
        out['dlbandwidth'] = f'{pwidth}MHz'

    nr_band = _s(z.get('nr5g_action_band'))
    nr_digits = _digits(nr_band)
    nr_channel = _digits(z.get('nr5g_action_channel'))
    nr_width = _width(z.get('nr_ca_pcell_bandwidth')) or _width(z.get('nr5g_bandwidth'))
    if nr_digits:
        entries.append(('N', nr_digits, nr_width, nr_channel))
        out['nrband'] = f'n{nr_digits}'
        if nr_width:
            out['nrdlbandwidth'] = f'{nr_width}MHz'
    out['band'] = _tokens(entries)
    out['nrearfcn'] = nr_channel
    out['nrpci'] = hex_to_dec(z.get('nr5g_pci'))
    out['nrrsrp'] = _s(z.get('Z5g_rsrp')) or _s(z.get('nr5g_rsrp'))
    out['nrsinr'] = _s(z.get('Z5g_SINR')) or _s(z.get('nr5g_snr'))
    out['nrrsrq'] = _s(z.get('Z5g_rsrq')) or _s(z.get('nr5g_rsrq'))

    if scells or _s(z.get('wan_lte_ca')) == 'ca_activated':
        out['CurrentNetworkTypeEx'] = 1011
    elif out['rsrp']:
        out['CurrentNetworkTypeEx'] = 101
    mcc, mnc = _s(z.get('rmcc')), _s(z.get('rmnc'))
    if mcc and mnc:
        out['Numeric'] = f'{mcc}{mnc.zfill(2)}'      # the router drops the leading zero (03 -> 3)
    if _s(z.get('network_provider')):
        out['FullName'] = _s(z.get('network_provider')).upper()
    temps = [_s(z.get('pm_sensor_mdm')), _s(z.get('pm_modem_5g'))]
    if any(temps):
        out['Temperature'] = ' / '.join(f'{x}°' for x in temps if x)
    out['zte_network_type'] = _s(z.get('network_type'))
    out['zte_scell_info'] = _s(z.get('lte_multi_ca_scell_info'))
    out['zte_scell_sig'] = _s(z.get('lte_multi_ca_scell_sig_info'))
    return {k: v for k, v in out.items() if v != ''}


def neighbors_to_huawei_text(info: Any) -> str:
    """'500,309,-13,-101,-67;...' -> 'EARFCN,Band,PCI,RSRP,RSRQ,RSSI,SINR;...'
    (band and SINR are not reported by ZTE: '--')."""
    rows = []
    for entry in _s(info).split(';'):
        f = [x.strip() for x in entry.split(',')]
        if len(f) < 5 or not _digits(f[0]):
            continue
        earfcn, pci, rsrq, rsrp, rssi = f[:5]
        rows.append(f'{earfcn},--,{pci},{rsrp},{rsrq},{rssi},--')
    return ';'.join(rows)


# ---------- session ----------

class ZteSession:
    """Read-only; duck-types RouterSession for what the app reads."""

    def __init__(self, ip: str, password: str, *, username: str = 'admin',
                 timeout: float = 6.0, **_ignored: Any) -> None:
        self.ip = ip
        self.url = f'http://{ip}'
        self.username = username
        self.password = password
        self.timeout = timeout
        self._lock = threading.RLock()
        self._http: requests.Session | None = None
        self._last_relogin = 0.0
        self.device_info: dict[str, Any] = {}
        self.supported_bands: list[int] = mask_to_bands(ZTE_ALL_LTE_MASK)
        self.access_modes: list[str] = []
        self.caps_known = True
        self.original_net_mode = None
        self.original_lte_mask: int | None = None
        self.is_zte = True

    @property
    def is_open(self) -> bool:
        return self._http is not None

    @property
    def supports_5g(self) -> bool:
        return True

    @property
    def locks_lte_only(self) -> bool:
        return False

    def _headers(self) -> dict[str, str]:
        return {'Referer': f'{self.url}/index.html', 'X-Requested-With': 'XMLHttpRequest'}

    def _get(self, cmds: tuple[str, ...] | list[str]) -> dict[str, Any]:
        http = self._http
        if http is None:
            raise ConnectionError('Нет сессии с роутером')
        reply = http.get(f'{self.url}{_GET}', timeout=self.timeout, headers=self._headers(),
                         params={'isTest': 'false', 'multi_data': '1', 'cmd': ','.join(cmds)})
        data = reply.json()
        if not isinstance(data, dict):
            raise ValueError('Unexpected ZTE reply')
        return data

    def _login_locked(self) -> None:
        http = requests.Session()
        headers = self._headers()
        ld = ''
        try:
            ld = _s(http.get(f'{self.url}{_GET}', timeout=self.timeout, headers=headers,
                             params={'isTest': 'false', 'cmd': 'LD'}).json().get('LD'))
        except Exception:
            ld = ''
        if ld:
            inner = hashlib.sha256(self.password.encode()).hexdigest().upper()
            secret = hashlib.sha256((inner + ld).encode()).hexdigest().upper()
        else:
            secret = base64.b64encode(self.password.encode()).decode()
        reply = http.post(f'{self.url}{_SET}', timeout=self.timeout, headers=headers,
                          data={'isTest': 'false', 'goformId': 'LOGIN', 'password': secret})
        try:
            result = _s(reply.json().get('result'))
        except ValueError:
            result = ''
        if result != '0':
            raise ZteLoginError('Неверный пароль.')
        self._http = http

    def open(self) -> dict[str, Any]:
        with self._lock:
            self._http = None
            self._login_locked()
            info = self._get(('hardware_version', 'web_version', 'wa_inner_version', 'imei'))
            version = _s(info.get('wa_inner_version'))
            model = 'ZTE MC801A' if 'MC801A' in version.upper() else 'ZTE'
            self.device_info = {k: v for k, v in {
                'DeviceName': model, 'SoftwareVersion': version,
                'Imei': _s(info.get('imei'))}.items() if v}
            try:
                self.original_lte_mask = self._read_lte_mask()
            except Exception:
                logger.debug("Could not read the LTE band lock at login", exc_info=True)
            return self.device_info

    def close(self) -> None:
        with self._lock:
            self._http = None

    def fetch(self) -> dict[str, Any]:
        with self._lock:
            data = self._get(SIGNAL_CMDS)
            if (data.get('loginfo') in ('', 'no') and not _s(data.get('lte_rsrp'))
                    and not _s(data.get('lte_band'))
                    and time.monotonic() - self._last_relogin > 10):
                # Anonymous-looking reply: the router dropped our session.
                self._last_relogin = time.monotonic()
                self._login_locked()
                data = self._get(SIGNAL_CMDS)
            return to_huawei_style(data)

    # ---- read-only helpers used by the cells pages ----

    def read_neighbor_cells_raw(self) -> dict[str, str]:
        with self._lock:
            data = self._get(('ngbr_cell_info',))
        return {'nbrcell_ltelist': neighbors_to_huawei_text(data.get('ngbr_cell_info'))}

    def read_cell_info(self) -> dict[str, Any]:
        return {}

    def read_net_mode(self) -> None:
        return None

    def collect_diagnostics(self) -> tuple[dict[str, Any], dict[str, str]]:
        from core.zte_probe import PROBE_GROUPS
        dumps: dict[str, Any] = {}
        errors: dict[str, str] = {}
        with self._lock:
            for name, cmds in {'signal': list(SIGNAL_CMDS), **PROBE_GROUPS}.items():
                try:
                    dumps[f'zte_{name}'] = self._get(cmds)
                except Exception as exc:
                    errors[f'zte_{name}'] = f'{type(exc).__name__}: {exc}'
        return dumps, errors

    # ---- LTE band lock (the router's own BAND_SELECT command) ----

    def _read_lte_mask(self) -> int | None:
        data = self._get(('lte_band_lock',))
        text = _s(data.get('lte_band_lock'))
        try:
            return int(text, 16) if text else None
        except ValueError:
            return None

    def read_config(self) -> ZteConfig:
        with self._lock:
            mask = self._read_lte_mask()
        if mask is None:
            return ZteConfig(None, None, None)
        if mask & ZTE_ALL_LTE_MASK == ZTE_ALL_LTE_MASK:
            return ZteConfig(None, [], None)            # AUTO: every band allowed
        return ZteConfig(None, mask_to_bands(mask & ZTE_ALL_LTE_MASK), None)

    def plan_band_lock(self, bands: Any) -> ZteBandPlan:
        mask = 0
        for band in bands:
            mask |= 1 << (int(band) - 1)
        if mask == 0:
            raise ValueError('لم يُختر أي باند')
        if mask & ~ZTE_ALL_LTE_MASK:
            raise ValueError('باند غير مدعوم في هذا الراوتر')
        return ZteBandPlan(mask)

    def plan_all_bands(self) -> ZteBandPlan:
        return ZteBandPlan(ZTE_ALL_LTE_MASK)

    def plan_restore_original(self) -> ZteBandPlan | None:
        return None if not self.original_lte_mask else ZteBandPlan(self.original_lte_mask)

    def apply_plan(self, plan: ZteBandPlan) -> bool:
        """Sends BAND_SELECT with the router's request signature, then reads the lock
        back. True = the router now reports exactly this mask."""
        with self._lock:
            http = self._http
            if http is None:
                raise ConnectionError('Нет сессии с роутером')
            info = self._get(('wa_inner_version', 'cr_version', 'RD'))
            token = _s(info.get('RD'))
            if not token:
                raise ZteCommandError('لم يعطِ الراوتر رمز التوقيع؛ لم يُرسل الأمر.')
            inner = hashlib.md5((_s(info.get('wa_inner_version'))
                                 + _s(info.get('cr_version'))).encode()).hexdigest()
            signature = hashlib.md5((inner + token).encode()).hexdigest()
            reply = http.post(f'{self.url}{_SET}', timeout=self.timeout, headers=self._headers(),
                              data={'isTest': 'false', 'goformId': 'BAND_SELECT',
                                    'is_gw_band': '0', 'gw_band_mask': '0',
                                    'is_lte_band': '1', 'lte_band_mask': plan.lteband,
                                    'AD': signature})
            try:
                result = _s(reply.json().get('result'))
            except ValueError:
                result = ''
            if result != 'success':
                raise ZteCommandError('رفض الراوتر أمر قفل الباندات.')
        for wait in (1.5, 2.5):
            time.sleep(wait)
            try:
                with self._lock:
                    if self._read_lte_mask() == plan.mask:
                        return True
            except Exception:
                logger.debug("Band lock read-back failed", exc_info=True)
        return False

    # ---- everything else stays read-only ----

    def _refuse(self, *_a: Any, **_k: Any) -> Any:
        raise ZteReadOnly(READ_ONLY_MESSAGE)

    read_antenna = set_antenna = reboot = reattach = lock_cells = _refuse
