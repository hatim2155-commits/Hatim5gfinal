"""Cells seen by the PHONE's own modem (Android TelephonyManager), read-only.

Separate from router readings: the phone talks to towers by itself, so these
numbers are shown on their own with a clear label and never mixed with the
router's. Values Android reports as unavailable (Integer.MAX_VALUE) become
``None`` and the UI shows them as unavailable. Nothing is sent anywhere.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from core.neighbor_cells import band_from_earfcn

_UNAVAILABLE = 2147483647

# 3GPP TS 38.104 NR-ARFCN ranges (downlink) for the bands used locally.
_NR_ARFCN_BANDS: tuple[tuple[int, int, int], ...] = (
    (422000, 434000, 1), (361000, 376000, 3), (524000, 538000, 7),
    (185000, 192000, 8), (158200, 164200, 20), (151600, 160600, 28),
    (514000, 524000, 38), (460000, 480000, 40), (499200, 537999, 41),
    (620000, 653333, 78), (653334, 680000, 77), (693334, 733333, 79),
)


@dataclass(frozen=True)
class PhoneCell:
    tech: str                 # 'LTE' or 'NR'
    band: str | None
    pci: int | None
    arfcn: int | None
    rsrp: float | None
    rsrq: float | None
    sinr: float | None
    registered: bool


def clean(value: Any) -> float | None:
    """Android 'unavailable' markers -> None."""
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if abs(number) >= _UNAVAILABLE - 1:
        return None
    return number


def nr_band_from_arfcn(arfcn: int | None) -> str | None:
    if arfcn is None:
        return None
    for low, high, band in _NR_ARFCN_BANDS:
        if low <= arfcn <= high:
            return f'N{band}'
    return None


def _int(value: Any) -> int | None:
    number = clean(value)
    return None if number is None else int(number)


def build_cell(tech: str, *, pci: Any, arfcn: Any, rsrp: Any, rsrq: Any, sinr: Any,
               registered: bool, bands: Any = None) -> PhoneCell:
    arfcn_i = _int(arfcn)
    band = None
    try:
        first = next(iter(bands), None) if bands is not None else None
    except TypeError:
        first = None
    if first is not None:
        band = f"{'N' if tech == 'NR' else 'B'}{int(first)}"
    if band is None:
        band = nr_band_from_arfcn(arfcn_i) if tech == 'NR' else band_from_earfcn(arfcn_i)
    return PhoneCell(tech, band, _int(pci), arfcn_i, clean(rsrp), clean(rsrq),
                     clean(sinr), bool(registered))


def tidy_cells(cells: list[PhoneCell]) -> list[PhoneCell]:
    """Drop duplicate entries Android may report for the same cell and blank the
    SINR of neighbour cells (modems only measure RSRP/RSRQ on neighbours; a 0
    there is a filler value, not a reading)."""
    best: dict[tuple, PhoneCell] = {}
    for c in cells:
        key = (c.tech, c.pci, c.arfcn, c.registered)
        old = best.get(key)
        if old is None:
            best[key] = c
            continue
        score = lambda x: sum(v is not None and v != 0 for v in (x.rsrp, x.rsrq, x.sinr))
        if score(c) > score(old):
            best[key] = c
    out = []
    for c in best.values():
        if not c.registered and c.sinr is not None:
            c = PhoneCell(c.tech, c.band, c.pci, c.arfcn, c.rsrp, c.rsrq, None, False)
        out.append(c)
    return out


def cell_kind(description: Any) -> str | None:
    """'CellInfoLte' / 'CellInfoNr' from a CellInfo's toString() or class name."""
    text = str(description or '')
    for kind in ('CellInfoLte', 'CellInfoNr'):
        if text.startswith(kind) or text.endswith(kind) or f'.{kind}' in text[:80]:
            return kind
    return None


def read_phone_cells() -> list[PhoneCell]:
    """Android only (pyjnius). Raises on any failure; the caller shows the reason."""
    from jnius import autoclass, cast  # type: ignore[import-not-found]
    activity = autoclass('org.kivy.android.PythonActivity').mActivity
    context = autoclass('android.content.Context')
    manager = activity.getSystemService(context.TELEPHONY_SERVICE)
    infos = manager.getAllCellInfo()
    if infos is None:
        return []
    cells: list[PhoneCell] = []
    for i in range(infos.size()):
        info = infos.get(i)
        # toString() is "CellInfoLte:{...}" / "CellInfoNr:{...}" (pyjnius' Class proxy
        # does not expose getSimpleName).
        kind = cell_kind(info.toString())
        if kind is None:
            try:
                kind = cell_kind(info.getClass().getName())
            except Exception:
                kind = None
        try:
            if kind == 'CellInfoLte':
                obj = cast('android.telephony.CellInfoLte', info)
                ident, sig = obj.getCellIdentity(), obj.getCellSignalStrength()
                bands = list(ident.getBands()) if hasattr(ident, 'getBands') else None
                cells.append(build_cell(
                    'LTE', pci=ident.getPci(), arfcn=ident.getEarfcn(), rsrp=sig.getRsrp(),
                    rsrq=sig.getRsrq(), sinr=sig.getRssnr(), registered=obj.isRegistered(),
                    bands=bands))
            elif kind == 'CellInfoNr':
                obj = cast('android.telephony.CellInfoNr', info)
                ident = cast('android.telephony.CellIdentityNr', obj.getCellIdentity())
                sig = cast('android.telephony.CellSignalStrengthNr', obj.getCellSignalStrength())
                bands = list(ident.getBands()) if hasattr(ident, 'getBands') else None
                cells.append(build_cell(
                    'NR', pci=ident.getPci(), arfcn=ident.getNrarfcn(), rsrp=sig.getSsRsrp(),
                    rsrq=sig.getSsRsrq(), sinr=sig.getSsSinr(), registered=obj.isRegistered(),
                    bands=bands))
        except Exception:  # one odd cell must not hide the others
            continue
    return tidy_cells(cells)
