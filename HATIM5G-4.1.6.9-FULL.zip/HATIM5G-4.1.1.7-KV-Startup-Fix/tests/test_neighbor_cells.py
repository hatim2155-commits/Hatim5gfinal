from core.neighbor_cells import band_from_earfcn, parse_cell_info


def test_parses_only_entries_with_pci():
    data = {'CellInfo': {'Cell': [
        {'PCI': '301', 'EARFCN': '1300', 'RSRP': '-89dBm', 'RSRQ': '-11dB', 'SINR': '9dB'},
        {'phy_cell_id': 112, 'dlearfcn': 100, 'rsrp': '-97'},
    ]}}
    cells = parse_cell_info(data)
    assert len(cells) == 2
    assert (cells[0].band, cells[0].pci, cells[0].rsrp) == ('B3', 301, -89.0)
    assert cells[1].band == 'B1' and cells[1].rsrq is None


def test_unrecognised_or_empty_response_gives_no_cells():
    assert parse_cell_info({'a': 1}) == []
    assert parse_cell_info(None) == []
    assert band_from_earfcn(9999) is None


def test_parse_nbrcell_response_router_format():
    from core.neighbor_cells import parse_nbrcell_response
    cells = parse_nbrcell_response(
        {'nbrcell_ltelist': '500,1,461,-93dBm,-15dB;500,1,162,-93dBm,-16dB'})
    assert [(c.pci, c.arfcn, c.rsrp, c.rsrq, c.sinr) for c in cells] == [
        (461, 500, -93.0, -15.0, None), (162, 500, -93.0, -16.0, None)]
    assert parse_nbrcell_response({'nbrcell_ltelist': '--'}) == []
    assert parse_nbrcell_response(None) == []


def test_parse_nbrcell_response_real_router_sample():
    from core.neighbor_cells import parse_nbrcell_response
    cells = parse_nbrcell_response({
        'nbrcell_ltelist': '9310,B28,311,-82dBm,-9dB,-53dBm,--;1450,B3,310,-100dBm,-18dB,-59dBm,12dB;',
        'nbrcell_nrlist': None})
    assert [(c.band, c.arfcn, c.pci, c.rsrp, c.rsrq, c.sinr) for c in cells] == [
        ('B28', 9310, 311, -82.0, -9.0, None), ('B3', 1450, 310, -100.0, -18.0, 12.0)]
