from core.cell_lock import (CellTarget, band_number, build_request, locked_on,
                            make_target, to_xml)


def test_band_number_and_target():
    assert band_number('B28') == 28 and band_number('n78') == 78 and band_number(None) is None
    assert make_target('B28', 9310, 311) == CellTarget(28, 9310, 311)
    assert make_target('B28', None, 311) is None
    assert make_target('', 9310, 311) is None


def test_request_matches_router_layout():
    xml = to_xml(build_request(CellTarget(28, 9310, 311), CellTarget(78, 640776, 313)))
    assert xml == (
        '<?xml version="1.0" encoding="UTF-8"?><request>'
        '<lte_info><lock_mode>2</lock_mode><freq_infos><freq_info><band>28</band>'
        '<freq>9310</freq><pci>311</pci></freq_info></freq_infos><all_bands>28</all_bands></lte_info>'
        '<nr_info><lock_mode>2</lock_mode><freq_infos><freq_info><band>78</band>'
        '<freq>640776</freq><pci>313</pci></freq_info></freq_infos><all_bands>78</all_bands></nr_info>'
        '</request>')


def test_locked_on():
    class S: pci = 311; earfcn = 9310
    assert locked_on(S, CellTarget(28, 9310, 311))
    assert not locked_on(S, CellTarget(28, 1450, 309))
    assert not locked_on(None, CellTarget(28, 9310, 311))


def test_lte_only_request_and_unlock():
    from core.cell_lock import build_unlock
    xml = to_xml(build_request(CellTarget(28, 9310, 311)))
    assert '<nr_info>' not in xml and '<lte_info><lock_mode>2</lock_mode>' in xml
    assert to_xml(build_unlock(False)).endswith('<lte_info><lock_mode>0</lock_mode></lte_info></request>')
    assert '<nr_info><lock_mode>0</lock_mode></nr_info>' in to_xml(build_unlock(True))
