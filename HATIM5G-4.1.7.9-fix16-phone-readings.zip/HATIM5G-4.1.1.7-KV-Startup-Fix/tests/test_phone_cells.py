from core.phone_cells import build_cell, clean, nr_band_from_arfcn


def test_unavailable_values_become_none():
    assert clean(2147483647) is None and clean(None) is None and clean('x') is None
    assert clean(-93) == -93.0


def test_build_cell_bands():
    nr = build_cell('NR', pci=313, arfcn=640776, rsrp=-96, rsrq=-9, sinr=2147483647, registered=False)
    assert (nr.band, nr.sinr) == ('N78', None)
    lte = build_cell('LTE', pci=311, arfcn=1450, rsrp=-93, rsrq=-10, sinr=14, registered=True)
    assert lte.band == 'B3' and lte.registered
    assert build_cell('LTE', pci=1, arfcn=1, rsrp=0, rsrq=0, sinr=0, registered=False, bands=[28]).band == 'B28'
    assert nr_band_from_arfcn(462270) == 'N40' and nr_band_from_arfcn(None) is None


def test_cell_kind_from_tostring_or_name():
    from core.phone_cells import cell_kind
    assert cell_kind('CellInfoLte:{mRegistered=YES mTimeStamp=1}') == 'CellInfoLte'
    assert cell_kind('CellInfoNr:{mRegistered=NO}') == 'CellInfoNr'
    assert cell_kind('android.telephony.CellInfoNr') == 'CellInfoNr'
    assert cell_kind('CellInfoGsm:{}') is None and cell_kind(None) is None


def test_signal_level_thresholds():
    from core.phone_cells import signal_level
    assert signal_level(None) is None
    assert signal_level(-85) == 'excellent'
    assert signal_level(-95) == 'good'
    assert signal_level(-105) == 'fair'
    assert signal_level(-115) == 'poor'


def test_main_cells_registered_lte_first():
    from core.phone_cells import PhoneCell, main_cells
    lte = PhoneCell('LTE', 'B3', 1, 1300, -95.0, -10.0, 8.0, True)
    nr = PhoneCell('NR', 'N78', 2, 640000, -90.0, -11.0, 12.0, True)
    nb = PhoneCell('LTE', 'B1', 3, 100, -80.0, -9.0, None, False)
    assert main_cells([nb, nr, lte]) == [lte, nr]
