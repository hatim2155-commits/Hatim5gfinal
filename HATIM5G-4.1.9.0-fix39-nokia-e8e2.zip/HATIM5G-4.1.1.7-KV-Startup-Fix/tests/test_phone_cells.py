from core.phone_cells import build_cell, clean, nr_band_from_arfcn


def test_unavailable_values_become_none():
    assert clean(2147483647) is None and clean(None) is None and clean('x') is None
    assert clean(-93) == -93.0


def test_build_cell_bands():
    nr = build_cell('NR', pci=313, arfcn=640776, rsrp=-96, rsrq=-9, sinr=2147483647, registered=False)
    assert (nr.band, nr.sinr) == ('N78', None)
    lte = build_cell('LTE', pci=311, arfcn=1450, rsrp=-93, rsrq=-10, sinr=14, registered=True)
    assert lte.band == 'B3' and lte.registered
    assert build_cell('LTE', pci=1, arfcn=1, rsrp=0, rsrq=0, sinr=0, registered=False, bands=[28]).band == 'B28'
    assert nr_band_from_arfcn(462270) == 'N40' and nr_band_from_arfcn(None) is None


def test_cell_kind_from_tostring_or_name():
    from core.phone_cells import cell_kind
    assert cell_kind('CellInfoLte:{mRegistered=YES mTimeStamp=1}') == 'CellInfoLte'
    assert cell_kind('CellInfoNr:{mRegistered=NO}') == 'CellInfoNr'
    assert cell_kind('android.telephony.CellInfoNr') == 'CellInfoNr'
    assert cell_kind('CellInfoGsm:{}') is None and cell_kind(None) is None


def test_signal_level_thresholds():
    from core.phone_cells import signal_level
    assert signal_level(None) is None
    assert signal_level(-85) == 'excellent'
    assert signal_level(-95) == 'good'
    assert signal_level(-105) == 'fair'
    assert signal_level(-115) == 'poor'


def test_main_cells_registered_lte_first():
    from core.phone_cells import PhoneCell, main_cells
    lte = PhoneCell('LTE', 'B3', 1, 1300, -95.0, -10.0, 8.0, True)
    nr = PhoneCell('NR', 'N78', 2, 640000, -90.0, -11.0, 12.0, True)
    nb = PhoneCell('LTE', 'B1', 3, 100, -80.0, -9.0, None, False)
    assert main_cells([nb, nr, lte]) == [lte, nr]


def test_signal_only_cell_detection():
    from core.phone_cells import PhoneCell, is_signal_only
    assert is_signal_only(PhoneCell('LTE', None, None, None, -95.0, -10.0, 8.0, True))
    assert not is_signal_only(PhoneCell('LTE', 'B3', 1, 1300, -95.0, -10.0, 8.0, True))


def test_nsa_5g_added_from_signal_strength_only_when_missing():
    from core.phone_cells import PhoneCell, add_missing_nr
    lte = PhoneCell('LTE', 'B8', 474, 3700, -101.0, -12.0, 6.6, True)
    nr_sig = PhoneCell('NR', None, None, None, -103.0, None, 19.0, True)
    lte_sig = PhoneCell('LTE', None, None, None, -100.0, -11.0, 6.0, True)
    out = add_missing_nr([lte], [lte_sig, nr_sig])
    assert out == [lte, nr_sig]                      # only the NR entry is added
    full_nr = PhoneCell('NR', 'N78', 5, 640000, -90.0, -10.0, 15.0, True)
    assert add_missing_nr([lte, full_nr], [nr_sig]) == [lte, full_nr]
    assert add_missing_nr([lte], []) == [lte]


def test_nr_frequency_range_parsing():
    from core.phone_cells import nr_range_label, parse_nr_frequency_range
    assert parse_nr_frequency_range("{mVoice=0, mNrFrequencyRange=3, mNrState=CONNECTED}") == 3
    assert parse_nr_frequency_range("nrFrequencyRange=2") == 2
    assert parse_nr_frequency_range("mNrFrequencyRange=0") is None
    assert parse_nr_frequency_range("no such field") is None
    assert parse_nr_frequency_range(None) is None
    assert nr_range_label(3) == '3-6 GHz' and nr_range_label(None) is None


def test_estimate_nr_band_by_operator_and_range():
    from core.phone_cells import estimate_nr_band
    assert estimate_nr_band('42001', 3) == 'N78/N77'
    assert estimate_nr_band('42001', 2) == 'N40'
    assert estimate_nr_band('42003', 3) == 'N77'
    assert estimate_nr_band('42003', 2) == 'N41'
    assert estimate_nr_band('42004', 3) == 'N78'
    assert estimate_nr_band('42004', 2) == 'N41'
    assert estimate_nr_band(None, 3, 'STC') == 'N78/N77'
    assert estimate_nr_band('', 2, 'Mobily') == 'N41'
    assert estimate_nr_band(None, 3, 'زين') == 'N78'
    assert estimate_nr_band('99999', 3) == 'N78/N77'
    assert estimate_nr_band('99999', 2) is None
    assert estimate_nr_band('42001', None) == 'N78/N77'
    assert estimate_nr_band('42003', None) == 'N77'
    assert estimate_nr_band(None, None, 'Zain KSA') == 'N78'
    assert estimate_nr_band('99999', None) is None
    assert estimate_nr_band(None, None, 'stc ksa') == 'N78/N77'
    assert estimate_nr_band('42001', 1) is None


def test_arfcn_from_servicemode_is_n78():
    from core.phone_cells import nr_band_from_arfcn
    assert nr_band_from_arfcn(640776) == 'N78'
