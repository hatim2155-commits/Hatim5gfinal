"""Read-only session for Nokia FastMile 5G gateways (confirmed on the E8E2 /
"5GGW2-OMNI-1", firmware 1.2103.00.0338, STC — captured via a real HTTP trace
of the router's own web_whw Angular app).

Unlike Huawei and ZTE, every status endpoint used here (``dashboard_device_info_
status_web_app.cgi``, ``device_info_get_web_app.cgi``, ``fastmile_radio_status_
web_app.cgi``, ``fastmile_statistics_status_web_app.cgi``,
``dashboard_device_status_web_app.cgi``) answered with real signal/SIM/device
data to a plain unauthenticated GET in the captured trace — no login was needed
to read them. The router's web UI does log in before showing its dashboard (a
real RSA + SHA-256 challenge-response flow, ``login_web_app.cgi``), but since
reading works without it, HATIM5G does not implement that login here: doing so
from a written description risks getting a subtle detail of the real
crypto wrong, and the one thing it would unlock (nothing — reads already work)
isn't worth that risk. If a future capture shows writes (band lock) or a
login-gated endpoint are genuinely possible, that can be added the same way
this file was: from a real captured trace, never guessed.

Field meaning (confirmed against the router's own real JSON reply):
  * ``cell_LTE_stats_cfg[0].stat``: RSSICurrent, SNRCurrent, RSRPCurrent,
    PhysicalCellID (already decimal), DownlinkEarfcn, Band ("B3", already
    letter-prefixed), RSRQCurrent.
  * ``cell_5G_stats_cfg[0].stat``: SNRCurrent, RSRPCurrent, PhysicalCellID
    (decimal), Downlink_NR_ARFCN, Band ("n40", already "n"-prefixed), RSRQCurrent.
  * ``cell_CA_stats_cfg[0]``: *CarrierAggregationNumberOfEntries + ca4GDL/ca4GUL
    — seen only ever empty (0 entries) in the capture, so their populated shape
    is not known yet and is not parsed; CA stays "not detected" until a real
    reply with active carriers is captured.
Anything the router did not provide in the capture stays unset; the UI then
shows it as unavailable rather than a guessed value.
"""
from __future__ import annotations

import logging
import re
import threading
from typing import Any

import requests

logger = logging.getLogger(__name__)

_STATUS_PATHS = (
    'dashboard_device_info_status_web_app.cgi',
    'device_info_get_web_app.cgi',
    'fastmile_radio_status_web_app.cgi',
    'fastmile_statistics_status_web_app.cgi',
    'dashboard_device_status_web_app.cgi',
)


def _s(value: Any) -> str:
    return '' if value is None else str(value).strip()


def _digits(value: Any) -> str:
    match = re.search(r'\d+', _s(value))
    return match.group(0) if match else ''


class NokiaReadOnly(Exception):
    """A control action was requested; Nokia support is read-only for now (no
    band-lock command has been captured from a real device yet)."""


READ_ONLY_MESSAGE = ("راوترات نوكيا مدعومة للقراءة فقط حاليًا؛ لم يُرسل أي أمر "
                     "للراوتر.")


def is_nokia(ip: str, timeout: float = 3.0) -> bool:
    """True if the address answers the Nokia FastMile status page (GET only,
    no login — confirmed from a real capture)."""
    try:
        reply = requests.get(f'http://{ip}/dashboard_device_info_status_web_app.cgi',
                             timeout=timeout)
        data = reply.json()
        apps = data.get('device_app_status')
        desc = _s(apps[0].get('Description')) if apps else ''
        return 'nokia' in desc.lower()
    except Exception:
        return False


def _get_json(url: str, timeout: float) -> dict[str, Any]:
    reply = requests.get(url, timeout=timeout,
                         headers={'Accept': 'application/json, text/plain, */*'})
    data = reply.json()
    return data if isinstance(data, dict) else {}


def nokia_to_huawei_style(radio: dict[str, Any]) -> dict[str, Any]:
    """Nokia fastmile_radio_status_web_app.cgi reply -> the field names
    build_snapshot() reads (same target shape as ZTE's to_huawei_style)."""
    out: dict[str, Any] = {}

    lte_list = radio.get('cell_LTE_stats_cfg') or []
    lte = (lte_list[0] or {}).get('stat', {}) if lte_list else {}
    if lte:
        out['rsrp'] = _s(lte.get('RSRPCurrent'))
        out['rsrq'] = _s(lte.get('RSRQCurrent'))
        out['sinr'] = _s(lte.get('SNRCurrent'))
        out['rssi'] = _s(lte.get('RSSICurrent'))
        out['pci'] = _digits(lte.get('PhysicalCellID'))
        out['earfcn'] = _digits(lte.get('DownlinkEarfcn'))
        band = _s(lte.get('Band'))                    # already "B3"
        if band:
            out['band'] = f'({band})'

    nr_list = radio.get('cell_5G_stats_cfg') or []
    nr = (nr_list[0] or {}).get('stat', {}) if nr_list else {}
    if nr:
        nr_band = _s(nr.get('Band'))                  # already "n40"
        if nr_band:
            out['nrband'] = nr_band
        out['nrpci'] = _digits(nr.get('PhysicalCellID'))
        out['nrearfcn'] = _digits(nr.get('Downlink_NR_ARFCN'))
        out['nrrsrp'] = _s(nr.get('RSRPCurrent'))
        out['nrrsrq'] = _s(nr.get('RSRQCurrent'))
        out['nrsinr'] = _s(nr.get('SNRCurrent'))

    ca_list = radio.get('cell_CA_stats_cfg') or []
    ca = ca_list[0] if ca_list else {}
    dl_ca = int(_digits(ca.get('X_ALU_COM_DLCarrierAggregationNumberOfEntries')) or 0)
    if dl_ca > 0:
        # Seen only as 0 in the capture; once a real reply with active carriers
        # is captured, ca4GDL's per-cell fields can be parsed here for real.
        out['CurrentNetworkTypeEx'] = 1011
    elif out.get('rsrp'):
        out['CurrentNetworkTypeEx'] = 101

    apn = (radio.get('apn_cfg') or [{}])[0]
    if _s(apn.get('APN')):
        pass  # APN itself isn't shown anywhere in the app today; nothing to map.

    return {k: v for k, v in out.items() if v != ''}


class NokiaSession:
    """Read-only; duck-types RouterSession for what the app reads."""

    def __init__(self, ip: str, password: str, *, username: str = 'admin',
                 timeout: float = 6.0, **_ignored: Any) -> None:
        self.ip = ip
        self.url = f'http://{ip}'
        self.username = username
        self.password = password
        self.timeout = timeout
        self._lock = threading.RLock()
        self._opened = False
        self.device_info: dict[str, Any] = {}
        self.supported_bands: list[int] = []
        self.original_net_mode = None
        self.original_lte_mask: int | None = None
        self.is_nokia = True

    @property
    def is_open(self) -> bool:
        return self._opened

    @property
    def supports_5g(self) -> bool:
        return True

    def open(self) -> dict[str, Any]:
        with self._lock:
            data = _get_json(f'{self.url}/dashboard_device_info_status_web_app.cgi',
                             self.timeout)
            apps = data.get('device_app_status') or [{}]
            info = apps[0] if apps else {}
            desc = _s(info.get('Description'))
            product = _s(info.get('ProductClass'))
            model = f'Nokia {product}' if product else (desc or 'Nokia FastMile')
            self.device_info = {k: v for k, v in {
                'DeviceName': model,
                'SoftwareVersion': _s(info.get('SoftwareVersion')),
                'SerialNumber': _s(info.get('SerialNumber')),
            }.items() if v}
            self._opened = True
            return self.device_info

    def close(self) -> None:
        with self._lock:
            self._opened = False

    def fetch(self) -> dict[str, Any]:
        radio = _get_json(f'{self.url}/fastmile_radio_status_web_app.cgi', self.timeout)
        if not radio:
            raise ConnectionError('Нет ответа от роутера')
        return nokia_to_huawei_style(radio)

    # ---- read-only helpers used elsewhere in the app ----

    def read_cell_info(self) -> dict[str, Any]:
        return {}

    def read_neighbor_cells_raw(self) -> dict[str, Any]:
        return {}

    def read_net_mode(self) -> None:
        return None

    def collect_diagnostics(self) -> tuple[dict[str, Any], dict[str, str]]:
        dumps: dict[str, Any] = {}
        errors: dict[str, str] = {}
        for path in _STATUS_PATHS:
            name = path.split('_web_app.cgi')[0]
            try:
                dumps[f'nokia_{name}'] = _get_json(f'{self.url}/{path}', self.timeout)
            except Exception as exc:
                errors[name] = str(exc)
        return dumps, errors

    # ---- no write command has been captured from a real device yet ----

    def _refuse(self, *_a: Any, **_k: Any) -> Any:
        raise NokiaReadOnly(READ_ONLY_MESSAGE)

    apply_plan = plan_band_lock = plan_all_bands = _refuse
    apply_network_plan = plan_network_mode = _refuse
    apply_nr_plan = plan_nr_band_lock = _refuse
    read_antenna = set_antenna = reboot = reattach = lock_cells = _refuse

    def plan_restore_original(self) -> None:
        return None            # nothing to restore; never raises (called synchronously)
