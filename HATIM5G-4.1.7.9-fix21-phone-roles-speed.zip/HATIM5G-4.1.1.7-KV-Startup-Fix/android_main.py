"""
Hua4GMon — Android-версия (Kivy).

Использует тот же пакет ``core/``, что и Windows-версия (main.py):
сессия с роутером (RouterSession/SessionWorker), разбор данных
(Snapshot), состояние (SignalState), Band Lock, RF-аналитика, переводы.
Здесь только UI-слой на Kivy.

Экраны:
    * Подключение — автопоиск роутера, пароль, язык, подсказка, тестовый режим;
    * Монитор — крупная выбранная метрика со стрелкой и «Δ до пика»,
      RSRP/SINR/RSRQ/RSSI, строка вышки, события смены соты, советы,
      график; нижняя панель: звук-парктроник, сброс пиков, меню;
    * Информация — вышка, лучшие соты сессии, SIM/устройство, состояние
      (обновляется в реальном времени);
    * Сеть — Band Lock, антенна, перезагрузка, переподключение связи,
      диагностика и اختبار اتصال الألعاب.

Жизненный цикл: на паузе опрос приостанавливается, экран не гаснет
только во время мониторинга, «Назад» ведёт к монитору.
Сборка APK — Buildozer (buildozer.spec).
"""
from __future__ import annotations

import datetime
import importlib
import importlib.abc
import importlib.util
import logging
import os
import platform as py_platform
import re
import sys
import threading
import time
import uuid
from collections.abc import Callable
from typing import Any

# --- Android crypto-совместимость (ДО первого обращения к huawei_lte_api) ---
# huawei-lte-api требует pycryptodomex (неймспейс Cryptodome), но у него
# нет рецепта python-for-android, и его нативные .so не грузятся на
# Android. Зато pycryptodome (неймспейс Crypto) рецепт имеет. Код пакетов
# идентичен — перенаправляем Cryptodome.* -> Crypto.*. На десктопе, где
# настоящий Cryptodome есть, алиас не включается.


class _CryptodomeAliasFinder(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    PREFIX = 'Cryptodome'

    def find_spec(self, fullname, path=None, target=None):
        if fullname == self.PREFIX or fullname.startswith(self.PREFIX + '.'):
            return importlib.util.spec_from_loader(fullname, self)
        return None

    def create_module(self, spec):
        real_name = 'Crypto' + spec.name[len(self.PREFIX):]
        module = importlib.import_module(real_name)
        sys.modules[spec.name] = module
        return module

    def exec_module(self, module):
        pass


try:
    import Cryptodome  # noqa: F401  (есть на десктопе — pycryptodomex)
except ImportError:
    sys.meta_path.insert(0, _CryptodomeAliasFinder())

from kivy.app import App
from kivy.clock import Clock
from kivy.core.text import LabelBase
from kivy.event import EventDispatcher
from kivy.factory import Factory
from kivy.lang import Builder
from kivy.metrics import dp, sp
from kivy.properties import BooleanProperty, ListProperty, NumericProperty, ObjectProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.modalview import ModalView
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.uix.widget import Widget
from kivy.storage.jsonstore import JsonStore
from kivy.utils import escape_markup, platform

from core.neighbor_cells import (NeighborCell, band_from_earfcn, parse_cell_info, parse_nbrcell_response,
                                 parse_seccell_response)
from core import (
    ANTENNA_MODES,
    DISCOVERY_CANDIDATES,
    GRAPH_HISTORY,
    GRAPH_MIN_SPAN,
    LANGUAGES,
    MIMO_LABELS,
    PARAM_RANGES,
    RAT_LABELS,
    REGION_BANDS,
    TREND_DOWN,
    TREND_FLAT,
    TREND_UP,
    UPLINK_LABELS,
    DemoModem,
    RouterSession,
    SessionWorker,
    SignalState,
    Snapshot,
    __version__,
    advice,
    build_diagnostics,
    calculate_overall_health,
    configure_library_logging,
    current_language,
    demo_angle_hint,
    demo_factory,
    diagnostics_json,
    discover_router,
    evaluate_signal,
    format_bytes_mb,
    format_mimo,
    format_modulation,
    format_rate_mbps,
    humanize_error,
    is_valid_ip,
    library_version,
    lock_warnings,
    lockable_bands,
    lte_band_label,
    mimo_status,
    parse_antenna_value,
    run_game_connection_test,
    set_language,
    t as _translate,
    uplink_status,
)

APP_NAME = "HATIM5G"


def Window_width() -> int:
    from kivy.core.window import Window
    return int(Window.width - dp(20))


def _make_widget(name: str, props: dict[str, Any]) -> Any:
    """Create a KV-defined widget, then assign its KV-declared properties.

    Setting them after creation (the same pattern as MetricCard.m_value)
    avoids depending on how constructor kwargs interact with KV rules."""
    widget = getattr(Factory, name)()
    for key, value in props.items():
        setattr(widget, key, value)
    return widget


def _to_float(value: Any) -> float | None:
    try:
        return float(str(value).replace('dBm', '').replace('dB', '').strip())
    except (TypeError, ValueError):
        return None


class _LocalizedText(str):
    """Text translated for the UI; format placeholders before Arabic shaping."""
    def format(self, *args: Any, **kwargs: Any) -> str:
        return _shape_arabic(super().format(*args, **kwargs))


def _shape_arabic(value: str) -> str:
    """Shape Arabic glyphs and apply Unicode bidi for Kivy's SDL text renderer."""
    if current_language() != 'ar' or not any('\u0600' <= ch <= '\u06ff' for ch in value):
        return value
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(value))
    except Exception:
        # Keep the app usable if a platform build lacks optional shaping modules.
        logger.exception("Arabic text shaping unavailable")
        return value


def _shape_arabic_display(value: str) -> str:
    """Shape Arabic display names even when the selected UI language is English."""
    if not any('\u0600' <= ch <= '\u06ff' for ch in value):
        return value
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(value))
    except Exception:
        return value


def t(text: str) -> str:
    """Translate UI text and shape Arabic for correct glyph order in Kivy."""
    translated = _translate(text)
    if current_language() == 'ar' and '{' in translated and '}' in translated:
        return _LocalizedText(translated)
    return _shape_arabic(translated)

# Логи видны в logcat (adb logcat | grep python).
logging.basicConfig(level=logging.INFO, format="%(name)s [%(levelname)s] %(message)s")
configure_library_logging()
logger = logging.getLogger(APP_NAME)

LTE_PARAMS = ['sinr', 'rsrp', 'rsrq', 'rssi']
NR_PARAMS = ['nr_sinr', 'nr_rsrp']
PARAM_TITLES = {'rsrp': 'RSRP', 'rssi': 'RSSI', 'sinr': 'SINR', 'rsrq': 'RSRQ',
                'nr_rsrp': 'NR RSRP', 'nr_sinr': 'NR SINR', 'nr_rsrq': 'NR RSRQ'}
TREND_GLYPHS = {TREND_UP: "↑", TREND_DOWN: "↓", TREND_FLAT: "→"}

# Шрифт со стрелками (↑→↓), ⚠, Δ: встроенный Roboto в Kivy их не содержит.
# Kivy не подменяет недостающие символы другим шрифтом, а цветных эмодзи
# (🔊 🧪 ✅ …) в DejaVu Sans нет — они рисуются квадратом. Все подписи
# Android используют только символы этого шрифта; это проверяет
# tests/test_project.py::test_android_text_fits_bundled_font.
_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets')
_FONT_PATH = os.path.join(_ASSETS, 'DejaVuSans.ttf')
_MOHANAD_PATH = os.path.join(_ASSETS, 'AL-Mohanad.ttf')
_ARABIC_READINGS_FONT_PATH = os.path.join(_ASSETS, 'Al-Mohanad-Long-Kaf.ttf')
_UNIFIED_PATH = os.path.join(_ASSETS, 'Hatim-Unified.ttf')
_UNIFIED_BOLD_PATH = os.path.join(_ASSETS, 'Hatim-Unified-Bold.ttf')
# Жирное начертание — для крупных значений и заголовков (читаемость на солнце).
_FONT_BOLD_PATH = os.path.join(_ASSETS, 'DejaVuSans-Bold.ttf')
_MOHANAD_BOLD_PATH = os.path.join(_ASSETS, 'Al-Mohanad-Extra-Bold.ttf')

THEMES: dict[str, dict[str, list[float]]] = {
    'dark': {
        'c_bg': [0.07, 0.09, 0.12, 1], 'c_card': [0.12, 0.14, 0.18, 1],
        'c_text': [0.92, 0.94, 0.96, 1], 'c_sub': [0.62, 0.67, 0.72, 1],
        'c_accent': [0.04, 0.47, 0.84, 1], 'c_button2': [0.2, 0.24, 0.3, 1],
        'c_graph_bg': [0.1, 0.12, 0.16, 1], 'c_grid': [0.2, 0.23, 0.27, 1],
    },
    # «Солнце»: максимальный контраст для экрана под прямым солнцем.
    'sun': {
        'c_bg': [1, 1, 1, 1], 'c_card': [0.92, 0.93, 0.94, 1],
        'c_text': [0, 0, 0, 1], 'c_sub': [0.2, 0.2, 0.2, 1],
        'c_accent': [0.0, 0.3, 0.7, 1], 'c_button2': [0.8, 0.82, 0.85, 1],
        'c_graph_bg': [1, 1, 1, 1], 'c_grid': [0.8, 0.8, 0.8, 1],
    },
}


def unit_of(param: str) -> str:
    return "dBm" if param.endswith(('rsrp', 'rssi')) else "dB"


def fmt_num(value: float | None) -> str:
    """Число для подписи: целые — как есть (eNB 1048575, а не 1.04858e+06)."""
    if value is None:
        return "-"
    return str(value) if isinstance(value, int) else f"{value:g}"


def hex_to_rgba(color: str, sun: bool = False) -> list[float]:
    """'#00b894' или 'gray' → RGBA. В режиме «Солнце» цвета темнее."""
    named = {'gray': '#808080', 'green': '#33cc66', 'orange': '#e68033', 'red': '#d93333'}
    h = named.get(color, color).lstrip('#')
    try:
        rgb = [int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)]
    except (ValueError, IndexError):
        rgb = [0.5, 0.5, 0.5]
    if sun:
        rgb = [c * 0.7 for c in rgb]
    return [*rgb, 1.0]


def beep_interval(delta: float | None) -> float:
    """Пауза между сигналами парктроника: у пика — часто, далеко — редко."""
    if delta is None:
        return 1.5
    return 0.12 + min(1.3, abs(delta) * 0.12)


# =========================================================
# Платформенные сервисы Android (pyjnius)
# =========================================================

def set_keep_screen_on(on: bool) -> None:
    """Экран не гаснет, пока идёт мониторинг (FLAG_KEEP_SCREEN_ON).

    Флаг окна не требует разрешения WAKE_LOCK и снимается системой, когда
    приложение уходит в фон. Hardware validation required.
    """
    if platform != 'android':
        return
    try:
        from android.runnable import run_on_ui_thread
        from jnius import autoclass
    except ImportError:
        logger.warning("pyjnius/android недоступны — keep-screen-on пропущен")
        return

    @run_on_ui_thread
    def apply() -> None:
        activity = autoclass('org.kivy.android.PythonActivity').mActivity
        flag = autoclass('android.view.WindowManager$LayoutParams').FLAG_KEEP_SCREEN_ON
        window = activity.getWindow()
        if on:
            window.addFlags(flag)
        else:
            window.clearFlags(flag)
    apply()


class ToneBeeper:
    """Короткие сигналы через android.media.ToneGenerator.

    Hardware validation required: громкость и задержка на устройстве.
    """

    def __init__(self) -> None:
        self._tone: Any = None
        self._tone_id = 0
        if platform != 'android':
            return
        try:
            from jnius import autoclass
            tone_cls = autoclass('android.media.ToneGenerator')
            audio = autoclass('android.media.AudioManager')
            self._tone = tone_cls(audio.STREAM_MUSIC, 80)
            self._tone_id = tone_cls.TONE_PROP_BEEP
        except Exception:
            logger.warning("ToneGenerator недоступен", exc_info=True)

    @property
    def available(self) -> bool:
        return self._tone is not None

    def beep(self, ms: int = 60) -> None:
        if self._tone is not None:
            self._tone.startTone(self._tone_id, ms)

    def release(self) -> None:
        if self._tone is not None:
            self._tone.release()
            self._tone = None


# =========================================================
# График на Kivy canvas
# =========================================================

class SignalGraph(Widget):
    """Линейный график: автомасштаб, линия пика, признак устаревания.

    Размеры — в dp/sp; текстуры подписей кэшируются (подписи оси почти
    не меняются, а создание текстуры — самая дорогая часть отрисовки).
    """

    _TEX_CACHE_MAX = 96

    def __init__(self, **kw: Any) -> None:
        super().__init__(**kw)
        self._values: list[float] = []
        self._peak: float | None = None
        self._param = 'sinr'
        self._stale = False
        self._tex: dict[tuple, Any] = {}
        self.bind(pos=lambda *a: self._redraw(), size=lambda *a: self._redraw())

    def set_data(self, values: list[float], param: str, peak: float | None,
                 stale: bool) -> None:
        self._values = list(values)
        self._param = param
        self._peak = peak
        self._stale = stale
        self._redraw()

    def _texture(self, text: str, size: float, color: tuple, bold: bool = False) -> Any:
        key = (text, size, color, bold)
        tex = self._tex.get(key)
        if tex is None:
            from kivy.core.text import Label as CoreLabel
            lbl = CoreLabel(text=text, font_size=size, bold=bold, color=color)
            lbl.refresh()
            tex = lbl.texture
            if len(self._tex) >= self._TEX_CACHE_MAX:
                self._tex.clear()
            self._tex[key] = tex
        return tex

    def _y_range(self) -> tuple[float, float]:
        base = self._param.replace('nr_', '')
        lo_lim, hi_lim = PARAM_RANGES.get(base, (-140, 40))
        pts = self._values + ([self._peak] if self._peak is not None else [])
        if not pts:
            return float(lo_lim), float(hi_lim)
        lo, hi = min(pts), max(pts)
        span = GRAPH_MIN_SPAN.get(base, 10.0)
        if hi - lo < span:
            mid = (hi + lo) / 2
            lo, hi = mid - span / 2, mid + span / 2
        lo = max(lo_lim, 5 * ((lo - 1) // 5))
        hi = min(hi_lim, 5 * -((-(hi + 1)) // 5))
        return float(lo), float(max(hi, lo + 1))

    def _redraw(self) -> None:
        from kivy.graphics import Color, Ellipse, Line, Rectangle
        app = App.get_running_app()
        theme = THEMES[app.theme_name] if app else THEMES['dark']
        text_col = tuple(theme['c_sub'])
        self.canvas.clear()
        w, h = self.width, self.height
        pl, pr, pt, pb = dp(44), dp(10), dp(22), dp(20)
        plot_w, plot_h = w - pl - pr, h - pt - pb
        if plot_w <= dp(20) or plot_h <= dp(20):
            return
        x0, y0 = self.x + pl, self.y + pb
        y_min, y_max = self._y_range()
        rng = y_max - y_min

        def y_of(v: float) -> float:
            return y0 + plot_h * (max(y_min, min(y_max, v)) - y_min) / rng

        with self.canvas:
            Color(*theme['c_graph_bg'])
            Rectangle(pos=self.pos, size=self.size)
            for i in range(5):
                gy = y0 + plot_h * i / 4
                Color(*theme['c_grid'])
                Line(points=[x0, gy, x0 + plot_w, gy], width=1)
                tex = self._texture(f"{y_min + rng * i / 4:.0f}", sp(11), text_col)
                Color(1, 1, 1, 1)
                Rectangle(texture=tex, pos=(x0 - tex.width - dp(4), gy - tex.height / 2),
                          size=tex.size)
            title = PARAM_TITLES.get(self._param, self._param.upper())
            tex = self._texture(f"{title} ({unit_of(self._param)})", sp(13),
                                tuple(theme['c_text']), True)
            Color(1, 1, 1, 1)
            Rectangle(texture=tex, pos=(x0, self.y + h - pt + dp(3)), size=tex.size)
            tex = self._texture(t("последние {n} точек").format(n=GRAPH_HISTORY),
                                sp(10), text_col)
            Rectangle(texture=tex, pos=(x0 + (plot_w - tex.width) / 2, self.y + dp(3)),
                      size=tex.size)

            if self._peak is not None:
                py = y_of(self._peak)
                Color(0.0, 0.72, 0.58, 1)
                Line(points=[x0, py, x0 + plot_w, py], width=1, dash_length=dp(4),
                     dash_offset=dp(3))
            if len(self._values) < 2:
                return
            span = max(GRAPH_HISTORY - 1, 1)
            pts: list[float] = []
            for i, v in enumerate(self._values[-GRAPH_HISTORY:]):
                pts.extend([x0 + plot_w * i / span, y_of(v)])
            line_col = (0.6, 0.6, 0.6, 1) if self._stale else (0.0, 0.62, 0.9, 1)
            Color(*line_col)
            Line(points=pts, width=dp(1.5))
            lx, ly = pts[-2], pts[-1]
            r = dp(4)
            Ellipse(pos=(lx - r, ly - r), size=(2 * r, 2 * r))
            label = t("нет свежих данных") if self._stale else \
                f"{fmt_num(self._values[-1])} {unit_of(self._param)}"
            tex = self._texture(label, sp(13), line_col, True)
            Color(1, 1, 1, 1)
            Rectangle(texture=tex, pos=(self.x + w - pr - tex.width, self.y + h - pt + dp(3)),
                      size=tex.size)


class RotatedBox(Widget):
    """Показывает вложенный layout повёрнутым на 90° (альбомно).

    Scatter, а не голый Rotate по canvas: Scatter применяет ту же
    трансформацию к касаниям, поэтому кнопка внутри остаётся кликабельной.
    """

    def __init__(self, inner: Widget, **kw: Any) -> None:
        super().__init__(**kw)
        from kivy.uix.scatter import Scatter
        self._inner = inner
        inner.size_hint = (None, None)
        self._scatter = Scatter(do_rotation=False, do_scale=False,
                                do_translation=False, size_hint=(None, None))
        self._scatter.add_widget(inner)
        self.add_widget(self._scatter)
        self.bind(pos=self._sync, size=self._sync)

    def _sync(self, *a: Any) -> None:
        land = (self.height, self.width)
        self._scatter.size = land
        self._inner.size = land
        self._scatter.rotation = 90
        self._scatter.center = self.center


# =========================================================
# KV-разметка
# =========================================================

KV = """
#:import dp kivy.metrics.dp
#:import sp kivy.metrics.sp

<ActionButton@Button>:
    background_normal: ''
    background_down: ''
    background_color: (0, 0, 0, 0)
    color: 1, 1, 1, 1
    font_size: sp(16)
    bold: True
    size_hint_y: None
    height: dp(54)
    canvas.before:
        Color:
            rgba: app.c_accent if self.state == 'normal' else (app.c_accent[0]*0.82, app.c_accent[1]*0.82, app.c_accent[2]*0.82, 1)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(15)]

<FlatButton@Button>:
    background_normal: ''
    background_down: ''
    background_color: (0, 0, 0, 0)
    color: app.c_text
    font_size: sp(15)
    canvas.before:
        Color:
            rgba: app.c_button2 if self.state == 'normal' else app.c_accent
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(14)]

<RoleButton@Button>:
    active: False
    role_color: app.c_accent
    background_normal: ''
    background_down: ''
    background_color: (0, 0, 0, 0)
    font_size: sp(14)
    bold: True
    color: (1, 1, 1, 1) if self.active else app.c_sub
    canvas.before:
        Color:
            rgba: self.role_color if self.active else app.c_button2
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]

<TabButton@RoleButton>:
    font_size: sp(16)
    size_hint_y: None
    height: dp(46)

<SubTabs@BoxLayout>:
    size_hint_y: None
    height: dp(50)
    padding: dp(8), dp(3)
    spacing: dp(6)
    # Arabic UI: first child is the leftmost, so the order is reversed.
    TabButton:
        text: app.nav_antenna
        height: dp(44)
        active: app.current_page == 'monitor'
        on_release: app.go('monitor')
    TabButton:
        text: app.nav_cells
        height: dp(44)
        active: app.current_page == 'cells'
        on_release: app.go('cells')
    TabButton:
        text: app.nav_readings
        height: dp(44)
        active: app.current_page == 'readings'
        on_release: app.go('readings')

<ModeTabs@BoxLayout>:
    size_hint_y: None
    height: dp(50)
    padding: dp(8), dp(3)
    spacing: dp(6)
    # Arabic UI: first child is the leftmost, so the speed tab (right) comes last.
    TabButton:
        text: app.lbl_tab_ping
        height: dp(44)
        active: app.current_page == 'ping'
        on_release: app.go('ping')
    TabButton:
        text: app.lbl_tab_speed
        height: dp(44)
        active: app.current_page == 'speed'
        on_release: app.go('speed')

<SectionCard@BoxLayout>:
    orientation: 'vertical'
    size_hint_y: None
    height: self.minimum_height
    padding: dp(12)
    spacing: dp(8)
    canvas.before:
        Color:
            rgba: app.c_card
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(12)]

<SectionTitle@Label>:
    font_size: sp(19)
    bold: True
    color: app.c_text
    size_hint_y: None
    height: dp(34)
    text_size: self.width, None
    halign: app.text_align
    valign: 'middle'

<AutoLabel@Label>:
    font_size: sp(15)
    color: app.c_text
    size_hint_y: None
    height: self.texture_size[1] + dp(6)
    text_size: self.width, None
    halign: app.text_align
    valign: 'top'

<HintLabel@AutoLabel>:
    font_size: sp(13)
    color: app.c_sub

<InfoLabel@AutoLabel>:
    font_size: sp(16)
    line_height: 1.3
    markup: True

<MetricCard@BoxLayout>:
    orientation: 'vertical'
    m_name: ''
    m_value: '-'
    m_status: ''
    m_peak: ''
    m_color: 0.5, 0.5, 0.5, 1
    glow: 0, 0, 0, 0
    glow_fill: 0, 0, 0, 0
    glow_soft: 0, 0, 0, 0
    value_size: sp(22)
    padding: dp(6)
    spacing: dp(1)
    canvas.before:
        Color:
            rgba: app.c_card
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]
        Color:
            rgba: root.glow_fill
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]
        Color:
            rgba: root.glow_soft
        Line:
            rounded_rectangle: (self.x - dp(2), self.y - dp(2), self.width + dp(4), self.height + dp(4), dp(12))
            width: dp(3)
        Color:
            rgba: root.glow
        Line:
            rounded_rectangle: (self.x, self.y, self.width, self.height, dp(10))
            width: dp(1.6)
    Label:
        text: root.m_name
        font_size: sp(14)
        color: app.c_sub
        size_hint_y: None
        height: dp(18)
    Label:
        text: root.m_value
        # Fit complete live values in narrow cards without replacing digits with ellipses.
        font_size: min(root.value_size, max(sp(10), (self.width - dp(8)) / max(len(root.m_value), 5) * 1.75))
        bold: True
        color: root.m_color
        halign: 'center'
        valign: 'middle'
        text_size: self.width - dp(4), self.height
        shorten: False
    Label:
        text: root.m_status
        font_size: sp(13)
        color: root.m_color
        size_hint_y: None
        height: dp(18)
    Label:
        text: root.m_peak
        font_size: sp(14)
        color: app.c_sub
        size_hint_y: None
        height: dp(20) if self.text else 0

<NavButton@ButtonBehavior+BoxLayout>:
    icon: ''
    label: ''
    active: False
    orientation: 'vertical'
    padding: dp(1), dp(5), dp(1), dp(2)
    spacing: dp(1)
    canvas.before:
        Color:
            rgba: (0.10, 0.38, 0.95, 0.30) if self.active else ((0.90, 0.92, 0.95, 1) if app.theme_name == 'sun' else (0.08, 0.12, 0.18, 0.96))
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(14)]
        Color:
            rgba: (0.22, 0.52, 1, 1) if self.active else ((0.55, 0.60, 0.68, 1) if app.theme_name == 'sun' else (0.24, 0.29, 0.38, 0.75))
        Line:
            rounded_rectangle: (self.x, self.y, self.width, self.height, dp(14))
            width: dp(1.8) if self.active else dp(0.8)
    Image:
        source: root.icon
        size_hint: None, None
        size: dp(26), dp(26)
        pos_hint: {'center_x': 0.5}
        color: ((0.0, 0.3, 0.7, 1) if app.theme_name == 'sun' else (0.38, 0.66, 1, 1)) if root.active else app.c_sub
    Label:
        text: root.label
        font_name: 'AlMohanad'
        font_size: sp(12)
        bold: True
        halign: 'center'
        valign: 'top'
        text_size: self.width, self.height
        color: ((0.0, 0.3, 0.7, 1) if app.theme_name == 'sun' else (0.38, 0.66, 1, 1)) if root.active else app.c_sub

<ThemeNavButton@ButtonBehavior+BoxLayout>:
    icon: ''
    label: ''
    orientation: 'vertical'
    padding: dp(1), dp(5), dp(1), dp(2)
    spacing: dp(1)
    canvas.before:
        Color:
            rgba: (0.22, 0.19, 0.12, 0.88)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(14)]
        Color:
            rgba: (0.72, 0.48, 0.08, 0.55)
        Line:
            rounded_rectangle: (self.x, self.y, self.width, self.height, dp(14))
            width: dp(1.0)
    Image:
        source: root.icon
        size_hint: None, None
        size: dp(20), dp(20)
        pos_hint: {'center_x': 0.5}
        color: (1, 0.78, 0.32, 1)
    Label:
        text: root.label
        font_name: 'AlMohanad'
        font_size: sp(9)
        bold: True
        halign: 'center'
        valign: 'top'
        text_size: self.width, self.height
        color: (1, 0.78, 0.32, 1)

<Header@BoxLayout>:
    title: ''
    size_hint_y: None
    height: dp(50)
    padding: dp(12), dp(4)
    Label:
        text: root.title
        font_size: sp(19)
        bold: True
        color: app.c_text
        halign: 'center'
        valign: 'middle'

BoxLayout:
    orientation: 'vertical'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    ScreenManager:
        id: main_sm
        ConnectionScreen:
        MonitorScreen:
        InfoScreen:
        ReadingsScreen:
        CellsScreen:
        ToolsScreen:
        SettingsScreen:
        PingScreen:
        MoreScreen:
        PhoneScreen:
        SpeedScreen:
    BoxLayout:
        size_hint_y: None
        height: dp(66)
        spacing: dp(2)
        padding: dp(10), dp(5)
        canvas.before:
            Color:
                rgba: app.c_card
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20), dp(20), 0, 0]

        # 4.1.7.9: five buttons. In the Arabic UI the first child is the leftmost.
        NavButton:
            icon: app.nav_icon_dir + '/more.png'
            label: app.nav_more
            active: (app.current_page in ('more', 'info', 'router_settings'))
            on_release: app.go('more')

        NavButton:
            icon: app.nav_icon_dir + '/ping.png'
            label: app.nav_ping
            active: (app.current_page in ('ping', 'speed'))
            on_release: app.go('ping')

        NavButton:
            icon: app.nav_icon_dir + '/network.png'
            label: app.nav_network
            active: (app.current_page == 'tools')
            on_release: app.go('tools')

        NavButton:
            icon: app.nav_icon_dir + '/readings.png'
            label: app.nav_readings
            active: (app.current_page in ('readings', 'cells', 'monitor'))
            on_release: app.go('readings')

        NavButton:
            icon: app.nav_icon_dir + '/home.png'
            label: app.nav_home
            active: (app.current_page in ('connection', 'phone'))
            on_release: app.go('connection')

<RouterCard@BoxLayout>:
    r_brand: ''
    r_name: ''
    r_meta: ''
    r_tag: ''
    r_connect: ''
    brand_bg: 0.4, 0.45, 0.55, 0.2
    brand_fg: 0.8, 0.85, 0.92, 1
    card_index: 0
    size_hint_y: None
    height: dp(82)
    padding: dp(8), dp(8)
    spacing: dp(6)
    canvas.before:
        Color:
            rgba: app.c_card
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(16)]
    Button:
        id: menu_btn
        size_hint_x: None
        width: dp(40)
        background_normal: ''
        background_down: ''
        background_color: 0, 0, 0, 0
        on_release: app.router_menu(root.card_index)
        canvas.after:
            Color:
                rgba: app.c_sub
            Ellipse:
                pos: self.center_x - dp(2), self.center_y + dp(8)
                size: dp(4), dp(4)
            Ellipse:
                pos: self.center_x - dp(2), self.center_y - dp(2)
                size: dp(4), dp(4)
            Ellipse:
                pos: self.center_x - dp(2), self.center_y - dp(12)
                size: dp(4), dp(4)
    Button:
        id: connect_btn
        text: root.r_connect
        size_hint_x: None
        width: dp(76)
        background_normal: ''
        background_down: ''
        background_color: 0, 0, 0, 0
        color: 1, 1, 1, 1
        bold: True
        font_size: sp(15)
        on_release: app.connect_saved(root.card_index)
        canvas.before:
            Color:
                rgba: app.c_accent if self.state == 'normal' else (app.c_accent[0]*0.8, app.c_accent[1]*0.8, app.c_accent[2]*0.8, 1)
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(13)]
    BoxLayout:
        id: info
        orientation: 'vertical'
        spacing: dp(1)
        Label:
            text: root.r_name
            bold: True
            font_size: sp(16)
            color: app.c_text
            halign: app.text_align
            valign: 'middle'
            text_size: self.size
        Label:
            text: root.r_meta
            font_size: sp(12)
            color: app.c_sub
            halign: app.text_align
            valign: 'middle'
            text_size: self.size
        Label:
            text: root.r_tag
            font_size: sp(11)
            color: 0.45, 0.85, 0.6, 1
            halign: app.text_align
            valign: 'middle'
            text_size: self.size
            size_hint_y: None
            height: dp(16) if self.text else 0
    Label:
        id: badge
        text: root.r_brand
        size_hint_x: None
        width: dp(62)
        bold: True
        font_size: sp(11)
        color: root.brand_fg
        canvas.before:
            Color:
                rgba: root.brand_bg
            RoundedRectangle:
                pos: self.x, self.center_y - dp(22)
                size: self.width, dp(44)
                radius: [dp(12)]

<ConnectionScreen>:
    name: 'connection'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    ScrollView:
        bar_width: dp(5)
        scroll_type: ['bars', 'content']
        BoxLayout:
            orientation: 'vertical'
            size_hint_y: None
            height: self.minimum_height
            padding: dp(18), dp(20)
            spacing: dp(14)
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(118)
                padding: dp(16), dp(12)
                spacing: dp(4)
                canvas.before:
                    Color:
                        rgba: app.c_accent[0], app.c_accent[1], app.c_accent[2], 0.13
                    RoundedRectangle:
                        pos: self.x - dp(2), self.y - dp(2)
                        size: self.width + dp(4), self.height + dp(4)
                        radius: [dp(20)]
                    Color:
                        rgba: app.c_card
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(18)]
                    Color:
                        rgba: app.c_accent[0], app.c_accent[1], app.c_accent[2], 0.75
                    Line:
                        rounded_rectangle: (self.x, self.y, self.width, self.height, dp(18))
                        width: dp(1.2)
                Label:
                    text: 'HATIM5G'
                    font_size: sp(36)
                    bold: True
                    color: (0.35, 0.78, 1, 1)
                    outline_width: dp(1)
                    outline_color: (0.05, 0.35, 0.95, 0.5)
                    size_hint_y: None
                    height: dp(52)
                Label:
                    text: root.subtitle
                    font_size: sp(16)
                    color: app.c_sub
                    size_hint_y: None
                    height: dp(30)
            SectionTitle:
                text: root.lbl_saved
            BoxLayout:
                id: routers_box
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                spacing: dp(10)
            SectionCard:
                SectionTitle:
                    text: root.lbl_new
                AutoLabel:
                    text: root.lbl_name
                TextInput:
                    id: name_input
                    multiline: False
                    font_size: sp(17)
                    padding: dp(12), dp(12)
                    size_hint_y: None
                    height: dp(46)
                    background_normal: ''
                    background_active: ''
                    background_color: app.c_bg
                    foreground_color: app.c_text
                    cursor_color: app.c_accent
                AutoLabel:
                    text: root.lbl_ip
                BoxLayout:
                    id: ip_row
                    size_hint_y: None
                    height: dp(50)
                    spacing: dp(8)
                    TextInput:
                        id: ip_input
                        text: '192.168.8.1'
                        multiline: False
                        font_size: sp(17)
                        padding: dp(12), dp(12)
                        background_normal: ''
                        background_active: ''
                        background_color: app.c_bg
                        foreground_color: app.c_text
                        cursor_color: app.c_accent
                    FlatButton:
                        id: find_btn
                        text: root.lbl_find
                        size_hint_x: 0.42
                        font_size: sp(14)
                        on_release: root.on_find()
                AutoLabel:
                    text: root.lbl_pw
                BoxLayout:
                    id: pw_row
                    size_hint_y: None
                    height: dp(50)
                    spacing: dp(8)
                    TextInput:
                        id: pw_input
                        password: True
                        multiline: False
                        font_size: sp(17)
                        padding: dp(12), dp(12)
                        background_normal: ''
                        background_active: ''
                        background_color: app.c_bg
                        foreground_color: app.c_text
                        cursor_color: app.c_accent
                        on_text_validate: root.on_connect()
                    FlatButton:
                        id: pw_show_btn
                        text: root.lbl_pw_toggle
                        size_hint_x: 0.32
                        font_size: sp(14)
                        on_release: root.toggle_password()
                BoxLayout:
                    id: remember_row
                    size_hint_y: None
                    height: dp(38)
                    spacing: dp(8)
                    CheckBox:
                        id: remember_router
                        active: True
                        size_hint_x: None
                        width: dp(40)
                    AutoLabel:
                        id: remember_lbl
                        text: root.lbl_remember
                Button:
                    text: root.lbl_connect
                    size_hint_y: None
                    height: dp(58)
                    background_normal: ''
                    background_down: ''
                    background_color: 0, 0, 0, 0
                    color: 1, 1, 1, 1
                    font_size: sp(18)
                    bold: True
                    canvas.before:
                        Color:
                            rgba: (0.06, 0.42, 0.98, 0.25)
                        RoundedRectangle:
                            pos: self.x - dp(2), self.y - dp(2)
                            size: self.width + dp(4), self.height + dp(4)
                            radius: [dp(20)]
                        Color:
                            rgba: (0.06, 0.42, 0.98, 1) if self.state == 'normal' else (0.03, 0.32, 0.78, 1)
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [dp(18)]
                    on_release: root.on_connect()
                AutoLabel:
                    id: status_lbl
                    text: ''
                    font_size: sp(14)
                    color: root.status_color
                    halign: 'center'
                HintLabel:
                    text: root.lbl_hint
                    halign: 'center'
            FlatButton:
                id: phone_btn
                text: root.lbl_phone
                size_hint_y: None
                height: dp(50)
                on_release: app.open_phone_screen()
            BoxLayout:
                id: foot_row
                size_hint_y: None
                height: dp(50)
                spacing: dp(10)
                FlatButton:
                    id: help_btn
                    text: root.lbl_help
                    on_release: root.on_help()
                Spinner:
                    id: lang_spinner
                    text: root.lang_name
                    values: root.lang_values
                    background_normal: ''
                    background_down: ''
                    background_color: 0, 0, 0, 0
                    color: app.c_text
                    canvas.before:
                        Color:
                            rgba: app.c_button2
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [dp(14)]
                    on_text: root.on_language(self.text)

<MonitorScreen>:
    name: 'monitor'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        padding: dp(8)
        spacing: dp(6)
        SubTabs:
        Label:
            text: root.lbl_title
            font_size: sp(17)
            bold: True
            color: app.c_text
            size_hint_y: None
            height: dp(24)
        Label:
            id: status_lbl
            text: ''
            font_size: sp(15)
            bold: True
            color: root.status_color
            size_hint_y: None
            height: self.texture_size[1] + dp(2)
            text_size: self.width, None
            halign: 'center'
        Label:
            id: tower_lbl
            text: '—'
            font_size: sp(15)
            bold: True
            color: app.c_text
            size_hint_y: None
            height: self.texture_size[1] + dp(2)
            text_size: self.width, None
            halign: 'center'
        Label:
            id: event_lbl
            text: ''
            font_size: sp(13)
            color: app.c_sub
            size_hint_y: None
            height: self.texture_size[1] if self.text else 0
            text_size: self.width, None
            halign: 'center'
        BoxLayout:
            size_hint_y: 0.30
            spacing: dp(6)
            MetricCard:
                id: primary_box
                size_hint_x: 0.66
                value_size: sp(54)
            BoxLayout:
                orientation: 'vertical'
                size_hint_x: 0.34
                canvas.before:
                    Color:
                        rgba: app.c_card
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(10)]
                Label:
                    id: dir_lbl
                    text: '—'
                    font_size: sp(72)
                    bold: True
                    color: 0.5, 0.5, 0.5, 1
                Label:
                    id: dir_text_lbl
                    text: ''
                    font_size: sp(12)
                    color: app.c_sub
                    size_hint_y: None
                    height: dp(44)
                    text_size: self.width - dp(8), None
                    halign: 'center'
                    valign: 'middle'
        GridLayout:
            cols: 3
            spacing: dp(6)
            size_hint_y: 0.17
            MetricCard:
                id: secondary_box
                value_size: sp(30)
            MetricCard:
                id: small1_box
                value_size: sp(24)
            MetricCard:
                id: small2_box
                value_size: sp(24)
        Label:
            id: advice_lbl
            text: ''
            font_size: sp(13)
            color: root.advice_color
            size_hint_y: None
            height: self.texture_size[1] if self.text else 0
            text_size: self.width, None
            halign: 'left'
        BoxLayout:
            size_hint_y: None
            height: dp(42)
            spacing: dp(6)
            Spinner:
                id: graph_param
                text: 'sinr'
                values: root.graph_values
                size_hint_x: 0.5
                font_size: sp(15)
                on_text: app.set_graph_param(self.text)
            FlatButton:
                text: root.lbl_fullscreen
                size_hint_x: 0.5
                font_size: sp(14)
                on_release: app.open_fullscreen_graph()
        SignalGraph:
            id: signal_graph
            size_hint_y: 0.26
        BoxLayout:
            size_hint_y: None
            height: dp(56)
            spacing: dp(6)
            FlatButton:
                text: root.lbl_sound
                background_color: app.c_accent if app.sound_on else app.c_button2
                color: (1, 1, 1, 1) if app.sound_on else app.c_text
                on_release: app.toggle_sound()
            FlatButton:
                text: root.lbl_peaks
                on_release: app.reset_peaks()

<InfoScreen>:
    name: 'info'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        ScrollView:
            bar_width: dp(8)
            scroll_type: ['bars', 'content']
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(10)
                spacing: dp(10)
                SectionCard:
                    SectionTitle:
                        text: root.lbl_tower_title
                    InfoLabel:
                        id: tower_block
                        text: ''
                SectionCard:
                    SectionTitle:
                        text: root.lbl_cells_title
                    InfoLabel:
                        id: cells_block
                        text: ''
                SectionCard:
                    SectionTitle:
                        text: root.lbl_sim_title
                    InfoLabel:
                        id: sim_block
                        text: ''
                SectionCard:
                    SectionTitle:
                        text: root.lbl_status_title
                    InfoLabel:
                        id: status_block
                        text: ''

<CellCard@BoxLayout>:
    orientation: 'vertical'
    size_hint_y: None
    height: self.minimum_height
    padding: dp(9)
    spacing: dp(5)
    band: '—'
    title: ''
    sub: ''
    rsrp: ''
    rsrq: ''
    sinr: ''
    bars: 0
    band_color: 0.28, 0.73, 1, 1
    band_fill: 0.28, 0.73, 1, 0.18
    signal_color: 0.5, 0.5, 0.5, 1
    rsrp_color: 0.7, 0.75, 0.8, 1
    rsrq_color: 0.7, 0.75, 0.8, 1
    status_text: ''
    show_button: False
    cell_index: -1
    canvas.before:
        Color:
            rgba: (0.93, 0.96, 0.97, 1) if app.theme_name == 'sun' else (0.06, 0.115, 0.125, 1)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(16)]
    BoxLayout:
        size_hint_y: None
        height: dp(40)
        spacing: dp(8)
        Label:
            text: root.band
            size_hint_x: None
            width: dp(56)
            bold: True
            font_size: sp(18)
            color: root.band_color
            canvas.before:
                Color:
                    rgba: root.band_fill
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(12)]
                Color:
                    rgba: root.band_color
                Line:
                    rounded_rectangle: (self.x, self.y, self.width, self.height, dp(12))
                    width: dp(1.5)
        BoxLayout:
            orientation: 'vertical'
            Label:
                text: root.title
                bold: True
                font_size: sp(13)
                color: app.c_text
                halign: 'right'
                valign: 'middle'
                text_size: self.size
            Label:
                text: root.sub
                font_size: sp(11)
                color: app.c_sub
                halign: 'right'
                valign: 'middle'
                text_size: self.size
        Widget:
            size_hint_x: None
            width: dp(34)
            canvas:
                Color:
                    rgba: root.signal_color if root.bars >= 1 else (0.78, 0.81, 0.86, 1) if app.theme_name == 'sun' else (0.17, 0.21, 0.28, 1)
                RoundedRectangle:
                    pos: self.x, self.y + dp(8)
                    size: dp(6), dp(8)
                    radius: [dp(3)]
                Color:
                    rgba: root.signal_color if root.bars >= 2 else (0.78, 0.81, 0.86, 1) if app.theme_name == 'sun' else (0.17, 0.21, 0.28, 1)
                RoundedRectangle:
                    pos: self.x + dp(9), self.y + dp(8)
                    size: dp(6), dp(13)
                    radius: [dp(3)]
                Color:
                    rgba: root.signal_color if root.bars >= 3 else (0.78, 0.81, 0.86, 1) if app.theme_name == 'sun' else (0.17, 0.21, 0.28, 1)
                RoundedRectangle:
                    pos: self.x + dp(18), self.y + dp(8)
                    size: dp(6), dp(19)
                    radius: [dp(3)]
                Color:
                    rgba: root.signal_color if root.bars >= 4 else (0.78, 0.81, 0.86, 1) if app.theme_name == 'sun' else (0.17, 0.21, 0.28, 1)
                RoundedRectangle:
                    pos: self.x + dp(27), self.y + dp(8)
                    size: dp(6), dp(26)
                    radius: [dp(3)]
    BoxLayout:
        size_hint_y: None
        height: dp(46)
        spacing: dp(5)
        MetricCard:
            m_name: 'RSRP'
            m_value: root.rsrp
            m_color: root.rsrp_color
            value_size: sp(12)
        MetricCard:
            m_name: 'RSRQ'
            m_value: root.rsrq
            m_color: root.rsrq_color
            value_size: sp(12)
        MetricCard:
            m_name: 'SINR'
            m_value: root.sinr
            m_color: (0.30, 0.34, 0.40, 1) if app.theme_name == 'sun' else (0.62, 0.68, 0.74, 1)
            value_size: sp(12)
    Label:
        text: root.status_text
        size_hint_y: None
        height: dp(20) if self.text else 0
        bold: True
        font_size: sp(12)
        color: 0.21, 0.82, 0.50, 1
    ActionButton:
        text: app.lbl_cell_connect
        height: dp(38) if root.show_button else 0
        opacity: 1 if root.show_button else 0
        disabled: not root.show_button
        on_release: app.cell_connect(root.cell_index)

<SpeedStat@BoxLayout>:
    k: ''
    v: '—'
    u: ''
    orientation: 'vertical'
    padding: dp(2), dp(4)
    canvas.before:
        Color:
            rgba: 0.5, 0.56, 0.64, 0.14
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]
    Label:
        text: root.k
        font_size: sp(11)
        color: app.c_sub
        size_hint_y: None
        height: dp(14)
    Label:
        text: root.v
        font_size: sp(18)
        bold: True
        color: app.c_text
    Label:
        text: root.u
        font_size: sp(10)
        color: app.c_sub
        size_hint_y: None
        height: dp(12)

<SpeedScreen>:
    name: 'speed'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        ModeTabs:
        ScrollView:
            bar_width: dp(8)
            scroll_type: ['bars', 'content']
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(8)
                spacing: dp(8)
                BoxLayout:
                    size_hint_y: None
                    height: dp(30)
                    Widget:
                    Label:
                        text: root.net_text
                        font_size: sp(13)
                        bold: True
                        color: root.net_color
                        size_hint_x: None
                        width: self.texture_size[0] + dp(28)
                        canvas.before:
                            Color:
                                rgba: root.net_color[0], root.net_color[1], root.net_color[2], 0.16
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [dp(14)]
                            Color:
                                rgba: root.net_color[0], root.net_color[1], root.net_color[2], 0.6
                            Line:
                                rounded_rectangle: (self.x, self.y, self.width, self.height, dp(14))
                                width: dp(1)
                    Widget:
                SectionCard:
                    padding: dp(8)
                    spacing: dp(2)
                    HintLabel:
                        text: root.gauge_title
                        halign: 'center'
                        font_size: sp(13)
                    SpeedGauge:
                        id: gauge
                        size_hint_y: None
                        height: dp(176)
                    Label:
                        size_hint_y: None
                        height: dp(52)
                        text: root.big_value
                        font_size: sp(44)
                        bold: True
                        color: root.value_color
                    Label:
                        text: root.gauge_unit
                        font_size: sp(13)
                        color: app.c_sub
                        size_hint_y: None
                        height: dp(16)
                    Label:
                        text: root.phase_text
                        font_size: sp(13)
                        color: app.c_sub
                        size_hint_y: None
                        height: dp(24)
                    BoxLayout:
                        size_hint_y: None
                        height: dp(66)
                        spacing: dp(6)
                        # Arabic UI reads right to left: ping, download, upload, then the size.
                        SpeedStat:
                            k: root.lbl_used
                            v: root.used_text
                            u: 'MB'
                        SpeedStat:
                            k: root.lbl_upload
                            v: root.up_text
                            u: 'Mbps'
                        SpeedStat:
                            k: root.lbl_download
                            v: root.down_text
                            u: 'Mbps'
                        SpeedStat:
                            k: root.lbl_latency
                            v: root.latency_text
                            u: 'ms'
                ActionButton:
                    size_hint_x: 1
                    text: root.lbl_running if root.busy else root.lbl_start
                    disabled: root.busy
                    on_release: app.run_speed_test()
                HintLabel:
                    text: root.lbl_note
                    halign: 'center'
                    font_size: sp(12)
                HintLabel:
                    text: root.lbl_note2
                    halign: 'center'
                    font_size: sp(12)
                SectionTitle:
                    text: root.lbl_recent
                SectionCard:
                    padding: dp(10)
                    spacing: dp(6)
                    BoxLayout:
                        size_hint_y: None
                        height: dp(34)
                        Label:
                            text: root.hist_router_vals
                            font_size: sp(13)
                            bold: True
                            color: app.c_accent
                            size_hint_x: 0.62
                            halign: 'left'
                            valign: 'middle'
                            text_size: self.size
                        Label:
                            text: root.hist_router_title
                            font_size: sp(14)
                            color: app.c_text
                            halign: 'right'
                            valign: 'middle'
                            text_size: self.size
                    BoxLayout:
                        size_hint_y: None
                        height: dp(34)
                        Label:
                            text: root.hist_phone_vals
                            font_size: sp(13)
                            bold: True
                            color: app.c_accent
                            size_hint_x: 0.62
                            halign: 'left'
                            valign: 'middle'
                            text_size: self.size
                        Label:
                            text: root.hist_phone_title
                            font_size: sp(14)
                            color: app.c_text
                            halign: 'right'
                            valign: 'middle'
                            text_size: self.size

<PhoneScreen>:
    name: 'phone'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        BoxLayout:
            size_hint_y: None
            height: dp(46)
            padding: dp(14), dp(4)
            spacing: dp(8)
            Label:
                text: root.scan_info
                font_size: sp(12)
                color: app.c_sub
                halign: 'left'
                valign: 'middle'
                text_size: self.size
            FlatButton:
                text: root.lbl_scan
                size_hint_x: None
                width: dp(110)
                font_size: sp(13)
                on_release: app.refresh_phone_screen(force=True)
            FlatButton:
                text: app.lbl_back
                size_hint_x: None
                width: dp(100)
                font_size: sp(13)
                on_release: app.go('connection')
        ScrollView:
            bar_width: dp(8)
            scroll_type: ['bars', 'content']
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(12)
                spacing: dp(10)
                BoxLayout:
                    id: main_box
                    orientation: 'vertical'
                    size_hint_y: None
                    height: self.minimum_height
                    spacing: dp(8)
                SectionTitle:
                    text: root.lbl_nearby
                BoxLayout:
                    id: cells_box
                    orientation: 'vertical'
                    size_hint_y: None
                    height: self.minimum_height
                    spacing: dp(10)

<CellsScreen>:
    name: 'cells'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        SubTabs:
        BoxLayout:
            size_hint_y: None
            height: dp(50)
            padding: dp(14), dp(4)
            spacing: dp(8)
            FlatButton:
                text: root.lbl_scan
                size_hint_x: None
                width: dp(130)
                on_release: app.refresh_cells_screen(rescan=True)
            Label:
                text: root.scan_info
                font_size: sp(12)
                color: app.c_sub
                halign: 'right'
                valign: 'middle'
                text_size: self.size
        BoxLayout:
            size_hint_y: None
            height: dp(40)
            padding: dp(14), dp(0)
            spacing: dp(8)
            FlatButton:
                text: root.lbl_src_router
                font_size: sp(13)
                opacity: 1 if root.source == 'router' else 0.5
                on_release: app.set_cells_source('router')
            FlatButton:
                text: root.lbl_src_phone
                font_size: sp(13)
                opacity: 1 if root.source == 'phone' else 0.5
                on_release: app.set_cells_source('phone')
        ScrollView:
            bar_width: dp(8)
            scroll_type: ['bars', 'content']
            BoxLayout:
                id: cells_box
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(12)
                spacing: dp(10)

<ToggleArrow@ButtonBehavior+Widget>:
    group: ''
    expanded: False
    on_release: app.toggle_carriers(self.group)
    size_hint_y: None
    height: dp(26)
    canvas:
        Color:
            rgba: 0.16, 0.21, 0.28, 0.9
        RoundedRectangle:
            pos: self.center_x - dp(26), self.center_y - dp(13)
            size: dp(52), dp(26)
            radius: [dp(13)]
        Color:
            rgba: 0.62, 0.70, 0.80, 1
        Line:
            points: (self.center_x - dp(8), self.center_y - dp(3), self.center_x, self.center_y + dp(4), self.center_x + dp(8), self.center_y - dp(3)) if self.expanded else (self.center_x - dp(8), self.center_y + dp(3), self.center_x, self.center_y - dp(4), self.center_x + dp(8), self.center_y + dp(3))
            width: dp(2)
            cap: 'round'
            joint: 'round'

<FactCell@BoxLayout>:
    k: ''
    v: ''
    orientation: 'vertical'
    size_hint_y: None
    height: dp(30)
    Label:
        text: root.k
        font_size: sp(10)
        color: app.c_sub
        size_hint_y: None
        height: dp(13)
    Label:
        text: root.v
        font_size: sp(12)
        bold: True
        color: app.c_text

<ReadingTile@BoxLayout>:
    m_title: ''
    m_num: ''
    m_unit: ''
    m_rate: ''
    tone: 0.7, 0.75, 0.8, 1
    pill_fill: 0.1, 0.14, 0.2, 1
    pill_line: 0.2, 0.25, 0.3, 1
    orientation: 'vertical'
    padding: dp(2), dp(3)
    spacing: 0
    canvas.before:
        Color:
            rgba: app.c_card
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]
    Label:
        text: root.m_title
        font_size: sp(10)
        color: app.c_sub
        size_hint_y: None
        height: dp(12)
    Label:
        text: root.m_num
        font_size: sp(15)
        bold: True
        color: root.tone
    Label:
        text: root.m_unit
        font_size: sp(9)
        color: root.tone
        size_hint_y: None
        height: dp(11)
    BoxLayout:
        size_hint_y: None
        height: dp(17)
        padding: dp(2), dp(1)
        canvas.before:
            Color:
                rgba: root.pill_fill
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(8)]
            Color:
                rgba: root.pill_line
            Line:
                rounded_rectangle: (self.x, self.y, self.width, self.height, dp(8))
                width: dp(1)
        Label:
            text: root.m_rate
            font_size: sp(10)
            bold: True
            color: root.tone

<CarrierCard@BoxLayout>:
    orientation: 'vertical'
    size_hint_y: None
    height: self.minimum_height
    padding: dp(6)
    spacing: dp(4)
    band: '—'
    tech: 'LTE'
    band_label: ''
    band_size: sp(28)
    band_color: 0.28, 0.73, 1, 1
    band_fill: 0.28, 0.73, 1, 0.18
    glow_soft: 0.28, 0.73, 1, 0.3
    role: ''
    role_color: 0.21, 0.82, 0.5, 1
    role_fill: 0.21, 0.82, 0.5, 0.16
    frame: 0.21, 0.82, 0.5, 0.35
    sub: ''
    canvas.before:
        Color:
            rgba: (0.96, 0.97, 0.98, 1) if app.theme_name == 'sun' else (0.06, 0.10, 0.13, 1)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(14)]
        Color:
            rgba: root.frame
        Line:
            rounded_rectangle: (self.x, self.y, self.width, self.height, dp(14))
            width: dp(1.2)
    BoxLayout:
        size_hint_y: None
        height: dp(20)
        spacing: dp(8)
        Label:
            text: root.role
            size_hint_x: None
            width: dp(56)
            bold: True
            font_size: sp(11)
            color: root.role_color
            canvas.before:
                Color:
                    rgba: root.role_fill
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(14)]
                Color:
                    rgba: root.role_color
                Line:
                    rounded_rectangle: (self.x, self.y, self.width, self.height, dp(14))
                    width: dp(1)
        Label:
            text: root.sub
            font_size: sp(11)
            color: app.c_sub
            halign: 'left'
            valign: 'middle'
            text_size: self.size
    BoxLayout:
        id: tiles
        size_hint_y: None
        height: dp(76)
        spacing: dp(4)
        BoxLayout:
            size_hint_x: 1.15
            orientation: 'vertical'
            padding: dp(4)
            canvas.before:
                Color:
                    rgba: root.glow_soft
                Line:
                    rounded_rectangle: (self.x - dp(2), self.y - dp(2), self.width + dp(4), self.height + dp(4), dp(14))
                    width: dp(3)
                Color:
                    rgba: root.band_fill
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(12)]
                Color:
                    rgba: root.band_color
                Line:
                    rounded_rectangle: (self.x, self.y, self.width, self.height, dp(12))
                    width: dp(1.8)
            Label:
                text: root.band_label
                font_size: sp(10)
                color: app.c_sub
                size_hint_y: None
                height: dp(12)
            Label:
                text: root.band
                font_size: root.band_size
                bold: True
                color: root.band_color
            Label:
                text: root.tech
                font_size: sp(10)
                color: root.band_color
                size_hint_y: None
                height: dp(12)
    GridLayout:
        id: facts_grid
        cols: 3
        size_hint_y: None
        height: self.minimum_height
        spacing: dp(4), 0

<ReadingsScreen>:
    name: 'readings'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        SubTabs:
        ScrollView:
            bar_width: dp(8)
            scroll_type: ['bars', 'content']
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(8)
                spacing: dp(8)
                SectionCard:
                    canvas.before:
                        Color:
                            rgba: (0.90, 0.95, 0.99, 1) if app.theme_name == 'sun' else (0.047, 0.11, 0.17, 1)
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [dp(14)]
                    SectionTitle:
                        font_name: 'AlMohanadLongKaf'
                        font_size: sp(16)
                        color: (0.05, 0.33, 0.62, 1) if app.theme_name == 'sun' else (0.28, 0.73, 1, 1)
                        text: root.lbl_lte
                    BoxLayout:
                        id: lte_cards
                        orientation: 'vertical'
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(6)
                SectionCard:
                    canvas.before:
                        Color:
                            rgba: (0.89, 0.97, 0.95, 1) if app.theme_name == 'sun' else (0.025, 0.12, 0.12, 1)
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [dp(14)]
                    SectionTitle:
                        font_name: 'AlMohanadLongKaf'
                        font_size: sp(16)
                        color: (0.0, 0.43, 0.38, 1) if app.theme_name == 'sun' else (0.20, 0.86, 0.79, 1)
                        text: root.lbl_nr
                    BoxLayout:
                        id: nr_cards
                        orientation: 'vertical'
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(6)
                BoxLayout:
                    id: agg_wrap
                    orientation: 'vertical'
                    size_hint_y: None
                    height: self.minimum_height
                    SectionCard:
                        id: agg_card
                        SectionTitle:
                            font_name: 'AlMohanadLongKaf'
                            font_size: sp(21)
                            text: root.lbl_aggregation
                        InfoLabel:
                            font_name: 'AlMohanadLongKaf'
                            font_size: sp(17)
                            id: aggregation_readings
                            text: root.aggregation_text
                HintLabel:
                    text: root.lbl_note

<ToolsScreen>:
    name: 'tools'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        ScrollView:
            id: tools_scroll
            bar_width: dp(8)
            scroll_type: ['bars', 'content']
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(8)
                spacing: dp(8)
                AutoLabel:
                    text: root.net_msg
                    color: root.net_msg_color
                    bold: True
                    height: (self.texture_size[1] + dp(6)) if self.text else 0
                SectionCard:
                    SectionTitle:
                        text: root.lbl_bandlock
                    BoxLayout:
                        size_hint_y: None
                        height: dp(46)
                        spacing: dp(8)
                        padding: dp(0), dp(3)
                        TabButton:
                            text: root.lbl_tab_lte
                            active: root.band_tab == 'lte'
                            on_release: app.set_band_tab('lte')
                        TabButton:
                            text: root.lbl_tab_nr
                            active: root.band_tab == 'nr'
                            on_release: app.set_band_tab('nr')
                    AutoLabel:
                        text: root.lock_state if root.band_tab == 'lte' else root.nr_lock_state
                        bold: True
                    HintLabel:
                        text: root.hint_bandlock if root.band_tab == 'lte' else root.nr_bands_display
                    BoxLayout:
                        id: lte_box
                        orientation: 'vertical'
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(8)
                        BoxLayout:
                            id: bands_grid
                            orientation: 'vertical'
                            size_hint_y: None
                            height: self.minimum_height
                            spacing: dp(6)
                        FlatButton:
                            text: root.lbl_mark_current
                            size_hint_y: None
                            height: dp(42)
                            on_release: app.mark_current_bands()
                        ActionButton:
                            text: root.lbl_apply_bands
                            on_release: app.apply_bands()
                        BoxLayout:
                            size_hint_y: None
                            height: dp(44)
                            spacing: dp(8)
                            FlatButton:
                                text: root.lbl_reset_auto
                                on_release: app.reset_bands()
                            FlatButton:
                                text: root.lbl_restore
                                on_release: app.restore_bands()
                    BoxLayout:
                        id: nr_box
                        orientation: 'vertical'
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(8)
                        BoxLayout:
                            id: nr_bands_grid
                            orientation: 'vertical'
                            size_hint_y: None
                            height: self.minimum_height
                            spacing: dp(6)
                        ActionButton:
                            text: root.lbl_apply_nr
                            on_release: app.apply_nr_bands()
                        FlatButton:
                            text: root.lbl_unlock_nr
                            size_hint_y: None
                            height: dp(44)
                            on_release: app.unlock_cell()

<SettingsScreen>:
    name: 'router_settings'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        ScrollView:
            id: settings_scroll
            bar_width: dp(8)
            scroll_type: ['bars', 'content']
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(10)
                spacing: dp(12)
                AutoLabel:
                    text: root.net_msg
                    color: root.net_msg_color
                    bold: True
                    height: (self.texture_size[1] + dp(6)) if self.text else 0
                SectionCard:
                    SectionTitle:
                        text: root.lbl_netsel
                    HintLabel:
                        text: root.hint_netsel
                    BoxLayout:
                        size_hint_y: None
                        height: dp(52)
                        spacing: dp(10)
                        ActionButton:
                            text: root.lbl_net_nsa
                            on_release: app.set_network_kind('nsa')
                        ActionButton:
                            text: root.lbl_net_lte
                            on_release: app.set_network_kind('lte')
                    FlatButton:
                        text: root.lbl_unlock_cell
                        size_hint_y: None
                        height: dp(48)
                        on_release: app.unlock_cell()
                SectionCard:
                    id: antenna_card
                    SectionTitle:
                        text: root.lbl_antenna
                    Spinner:
                        id: antenna_spinner
                        text: root.antenna_text
                        values: root.antenna_values
                        font_size: sp(16)
                        size_hint_y: None
                        height: dp(48)
                    ActionButton:
                        text: root.lbl_apply_antenna
                        on_release: app.apply_antenna(antenna_spinner.text)
                SectionCard:
                    SectionTitle:
                        text: root.lbl_router
                    HintLabel:
                        text: root.hint_router
                    FlatButton:
                        text: root.lbl_reattach
                        size_hint_y: None
                        height: dp(52)
                        on_release: app.confirm_reattach()
                    FlatButton:
                        text: root.lbl_reboot
                        size_hint_y: None
                        height: dp(52)
                        on_release: app.confirm_reboot()
                    FlatButton:
                        text: root.lbl_diag
                        size_hint_y: None
                        height: dp(52)
                        on_release: app.copy_diagnostics()

<PingScreen>:
    name: 'ping'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        ModeTabs:
        ScrollView:
            bar_width: dp(8)
            scroll_type: ['bars', 'content']
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(8)
                spacing: dp(8)
                SectionCard:
                    padding: dp(8)
                    spacing: dp(2)
                    HintLabel:
                        text: root.lbl_current
                        halign: 'center'
                        font_size: sp(12)
                    Label:
                        size_hint_y: None
                        height: dp(54)
                        markup: True
                        text: (root.hero_ms + '[size=' + str(int(sp(16))) + ']  ms[/size]') if root.hero_ms != '—' else root.hero_ms
                        font_size: sp(44)
                        bold: True
                        color: root.hero_color
                        halign: 'center'
                        valign: 'middle'
                        text_size: self.size
                    Label:
                        text: root.hero_label
                        font_size: sp(14)
                        bold: True
                        color: root.hero_color
                        size_hint_y: None
                        height: dp(22)
                    Widget:
                        size_hint_y: None
                        height: dp(16)
                        canvas:
                            Color:
                                rgba: 0.24, 0.86, 0.59, 1
                            Rectangle:
                                pos: self.x, self.y + dp(3)
                                size: self.width * 0.2, dp(8)
                            Color:
                                rgba: 0.96, 0.77, 0.32, 1
                            Rectangle:
                                pos: self.x + self.width * 0.2, self.y + dp(3)
                                size: self.width * 0.2, dp(8)
                            Color:
                                rgba: 1, 0.54, 0.30, 1
                            Rectangle:
                                pos: self.x + self.width * 0.4, self.y + dp(3)
                                size: self.width * 0.35, dp(8)
                            Color:
                                rgba: 1, 0.36, 0.42, 1
                            Rectangle:
                                pos: self.x + self.width * 0.75, self.y + dp(3)
                                size: self.width * 0.25, dp(8)
                            Color:
                                rgba: 1, 1, 1, root.marker_on
                            Rectangle:
                                pos: self.x + self.width * root.marker - dp(2), self.y
                                size: dp(4), dp(14)
                    BoxLayout:
                        size_hint_y: None
                        height: dp(38)
                        spacing: dp(8)
                        BoxLayout:
                            orientation: 'vertical'
                            Label:
                                text: root.stat_jitter
                                font_size: sp(17)
                                bold: True
                                color: app.c_text
                            Label:
                                text: root.lbl_jitter
                                font_size: sp(11)
                                color: app.c_sub
                        BoxLayout:
                            orientation: 'vertical'
                            Label:
                                text: root.stat_loss
                                font_size: sp(17)
                                bold: True
                                color: app.c_text
                            Label:
                                text: root.lbl_loss
                                font_size: sp(11)
                                color: app.c_sub
                        BoxLayout:
                            orientation: 'vertical'
                            Label:
                                text: root.stat_best
                                font_size: sp(17)
                                bold: True
                                color: app.c_text
                            Label:
                                text: root.lbl_best
                                font_size: sp(11)
                                color: app.c_sub
                ActionButton:
                    text: root.lbl_running if root.busy else root.lbl_start
                    disabled: root.busy
                    on_release: app.run_ping_suite()
                BoxLayout:
                    size_hint_y: None
                    height: dp(66) if root.busy else 0
                    opacity: 1 if root.busy else 0
                    padding: dp(10), 0
                    spacing: dp(12)
                    canvas.before:
                        Color:
                            rgba: app.c_card
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [dp(12)]
                    Widget:
                        size_hint_x: None
                        width: dp(40)
                        canvas:
                            Color:
                                rgba: 0.18, 0.84, 0.71, 1
                            Line:
                                circle: (self.center_x, self.center_y, dp(14), root.spin, root.spin + 270)
                                width: dp(3)
                                cap: 'round'
                    BoxLayout:
                        orientation: 'vertical'
                        padding: 0, dp(10)
                        spacing: dp(6)
                        Label:
                            text: root.progress_text
                            font_size: sp(14)
                            bold: True
                            color: app.c_text
                            halign: 'center'
                            valign: 'middle'
                            text_size: self.size
                        Widget:
                            size_hint_y: None
                            height: dp(8)
                            canvas:
                                Color:
                                    rgba: 0.16, 0.27, 0.36, 1
                                RoundedRectangle:
                                    pos: self.pos
                                    size: self.size
                                    radius: [dp(4)]
                                Color:
                                    rgba: 0.18, 0.84, 0.71, 1
                                RoundedRectangle:
                                    pos: self.pos
                                    size: max(self.width * root.progress, dp(8)), self.height
                                    radius: [dp(4)]
                BoxLayout:
                    size_hint_y: None
                    height: dp(54)
                    spacing: dp(10)
                    FlatButton:
                        text: root.lbl_improve_speed
                        on_release: app.improve_speed()
                    FlatButton:
                        text: root.lbl_improve_ping
                        on_release: app.improve_ping()
                AutoLabel:
                    text: root.status_text
                    bold: True
                    height: (self.texture_size[1] + dp(6)) if self.text else 0
                SectionTitle:
                    text: root.lbl_games
                BoxLayout:
                    id: games_list
                    orientation: 'vertical'
                    size_hint_y: None
                    height: self.minimum_height
                    spacing: dp(8)
                SectionTitle:
                    text: root.lbl_regions
                BoxLayout:
                    id: regions_list
                    orientation: 'vertical'
                    size_hint_y: None
                    height: self.minimum_height
                    spacing: dp(8)
                HintLabel:
                    text: root.lbl_note

<MoreRow@ButtonBehavior+BoxLayout>:
    icon: ''
    title: ''
    sub: ''
    size_hint_y: None
    height: dp(72)
    padding: dp(14), dp(8)
    spacing: dp(12)
    canvas.before:
        Color:
            rgba: app.c_card
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(16)]
    Image:
        source: root.icon
        size_hint: None, None
        size: dp(30), dp(30)
        pos_hint: {'center_y': 0.5}
        color: (0.38, 0.66, 1, 1)
    BoxLayout:
        orientation: 'vertical'
        Label:
            text: root.title
            font_size: sp(17)
            bold: True
            color: app.c_text
            halign: app.text_align
            valign: 'bottom'
            text_size: self.size
        Label:
            text: root.sub
            font_size: sp(12)
            color: app.c_sub
            halign: app.text_align
            valign: 'top'
            text_size: self.size

<MoreScreen>:
    name: 'more'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        BoxLayout:
            orientation: 'vertical'
            padding: dp(12)
            spacing: dp(10)
            ActionButton:
                text: root.lbl_refresh
                on_release: app.refresh_connection()
            MoreRow:
                icon: app.nav_icon_dir + '/settings.png'
                title: root.lbl_router
                sub: root.hint_router
                on_release: app.go('router_settings')
            MoreRow:
                icon: app.nav_icon_dir + '/info.png'
                title: root.lbl_info
                sub: root.hint_info
                on_release: app.go('info')
            BoxLayout:
                size_hint_y: None
                height: dp(72)
                padding: dp(14), dp(10)
                spacing: dp(8)
                canvas.before:
                    Color:
                        rgba: app.c_card
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(16)]
                RoleButton:
                    text: root.lbl_sun
                    active: app.theme_name == 'sun'
                    size_hint_x: None
                    width: dp(92)
                    on_release: app.apply_theme('sun')
                RoleButton:
                    text: root.lbl_dark
                    active: app.theme_name != 'sun'
                    size_hint_x: None
                    width: dp(92)
                    on_release: app.apply_theme('dark')
                Label:
                    text: root.lbl_theme
                    font_size: sp(17)
                    bold: True
                    color: app.c_text
                    halign: app.text_align
                    valign: 'middle'
                    text_size: self.size
            Widget:
"""


# =========================================================
# ЭКРАНЫ
# =========================================================

class ConnectionScreen(Screen):
    subtitle = StringProperty("")
    lbl_ip = StringProperty("")
    lbl_pw = StringProperty("")
    lbl_remember = StringProperty("")
    lbl_name = StringProperty("")
    lbl_pw_toggle = StringProperty("")
    lbl_find = StringProperty("")
    lbl_connect = StringProperty("")
    lbl_lang = StringProperty("")
    lbl_demo = StringProperty("")
    lbl_help = StringProperty("")
    lbl_zte = StringProperty("")
    lbl_phone = StringProperty("")
    lbl_saved = StringProperty("")
    lbl_new = StringProperty("")
    lbl_hint = StringProperty("")
    lang_name = StringProperty("")
    lang_values = ListProperty([])
    status_color = ListProperty([0.9, 0.5, 0.2, 1])

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()
        App.get_running_app().refresh_saved_routers()

    def refresh_texts(self) -> None:
        self.subtitle = t("راوتر كنترول 4G/5G")
        self.lbl_ip = t("عنوان IP")
        self.lbl_pw = t("كلمة المرور")
        self.lbl_name = t("اسم الراوتر (اختياري)")
        pw_box = self.ids.get('pw_input')
        self.lbl_pw_toggle = (t("إخفاء") if pw_box is not None and not pw_box.password
                              else t("إظهار"))
        self.lbl_remember = t("حفظ في القائمة على هذا الجهاز")
        self.lbl_find = t("بحث")
        self.lbl_connect = t("اتصال")
        self.lbl_lang = t("Язык:")
        self.lbl_demo = t("Тестовый режим (без модема)")
        self.lbl_help = t("مساعدة")
        self.lbl_zte = t("فحص راوتر ZTE (قراءة فقط)")
        self.lbl_phone = t("قراءات الجوال (بدون راوتر)")
        self.lbl_new = t("اتصال جديد")
        self.lbl_hint = t("يدعم راوترات هواوي وZTE، ويتعرّف على النوع تلقائيًا.")
        self.lang_values = [_shape_arabic_display(name) for name in LANGUAGES.values()]
        self.lang_name = _shape_arabic_display(LANGUAGES.get(current_language(), "العربية"))
        self._apply_direction()

    def _apply_direction(self) -> None:
        """Mirror the row order for Arabic (RTL): the label sits on the right."""
        rtl = current_language() == 'ar'

        def arrange(row_id: str, ltr_ids: list[str]) -> None:
            row = self.ids.get(row_id)
            widgets = [self.ids.get(i) for i in ltr_ids]
            if row is None or any(w is None for w in widgets):
                return
            order = list(reversed(widgets)) if rtl else widgets
            if list(reversed(row.children)) == order:
                return
            row.clear_widgets()
            for widget in order:
                row.add_widget(widget)

        arrange('ip_row', ['ip_input', 'find_btn'])
        arrange('pw_row', ['pw_input', 'pw_show_btn'])
        arrange('remember_row', ['remember_router', 'remember_lbl'])
        arrange('foot_row', ['help_btn', 'lang_spinner'])

    def set_status(self, text: str, color: list[float]) -> None:
        lbl = self.ids.get('status_lbl')
        if lbl is not None:
            lbl.text = text
        self.status_color = color

    def on_language(self, name: str) -> None:
        code = {_shape_arabic_display(v): k for k, v in LANGUAGES.items()}.get(name)
        if code and code != current_language():
            set_language(code)
            App.get_running_app().refresh_all_texts()

    def on_help(self) -> None:
        App.get_running_app().show_popup(t("Подключение и частые ошибки"), t(
            "IP по умолчанию: 192.168.8.1 (для B315/B525 — 192.168.1.1 или "
            "192.168.3.1) — кнопка «Найти» проверит их сама. Логин: admin, "
            "пароль — на наклейке роутера.\n\n"
            "Частые ошибки и что делать:\n"
            "• 108006 — неверный логин или пароль.\n"
            "• 108007 — слишком много неудачных попыток: роутер временно "
            "заблокировал вход. Подождите несколько минут.\n"
            "• 108003 — уже выполнен вход с другого устройства. Закройте "
            "веб-интерфейс роутера.\n"
            "• 100002 — функция не поддерживается этой моделью или "
            "прошивкой. Часть возможностей будет недоступна — это нормально.\n"
            "• 100003 / 125002 / 125003 — истекла сессия. Программа войдёт "
            "заново сама.\n"
            "• Нет ответа — проверьте, что телефон подключён к Wi-Fi именно "
            "этого роутера и IP введён верно.\n\n"
            "Тестовый режим показывает работу программы без роутера."))

    def on_find(self) -> None:
        ip_input = self.ids.get('ip_input')
        entered = ip_input.text.strip() if ip_input is not None else ''
        App.get_running_app().discover(entered)

    def on_zte_probe(self) -> None:
        ip_input = self.ids.get('ip_input')
        ip = ip_input.text.strip() if ip_input is not None else ''
        pw_input = self.ids.get('pw_input')
        pw = pw_input.text if pw_input is not None else ''
        App.get_running_app().zte_probe(ip, pw)

    def toggle_password(self) -> None:
        """Show / hide the typed password so a typo can be fixed without retyping everything."""
        pw_input = self.ids.get('pw_input')
        if pw_input is None:
            return
        pw_input.password = not pw_input.password
        self.lbl_pw_toggle = t("إظهار") if pw_input.password else t("إخفاء")

    def on_connect(self) -> None:
        ip_input, pw_input = self.ids.get('ip_input'), self.ids.get('pw_input')
        if ip_input is None or pw_input is None:
            return
        ip = ip_input.text.strip()
        if not is_valid_ip(ip):
            self.set_status(t("Неверный IP-адрес: {ip}\nПример: 192.168.8.1").format(ip=ip),
                            [0.9, 0.3, 0.3, 1])
            return
        App.get_running_app().connect(ip, pw_input.text)


class MonitorScreen(Screen):
    lbl_title = StringProperty("")
    lbl_fullscreen = StringProperty("")
    lbl_sound = StringProperty("")
    lbl_peaks = StringProperty("")
    lbl_menu = StringProperty("")
    graph_values = ListProperty(list(LTE_PARAMS))
    status_color = ListProperty([0.2, 0.8, 0.4, 1])
    advice_color = ListProperty([0.95, 0.62, 0.25, 1])

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()

    def refresh_texts(self) -> None:
        self.lbl_title = t("وزن الأنتينا")
        self.lbl_fullscreen = t("Во весь экран")
        self.lbl_sound = t("♪ Звук")
        self.lbl_peaks = t("⟲ Пики")
        self.lbl_menu = t("☰ Меню")


class InfoScreen(Screen):
    lbl_title = StringProperty("")
    lbl_tower_title = StringProperty("")
    lbl_cells_title = StringProperty("")
    lbl_sim_title = StringProperty("")
    lbl_status_title = StringProperty("")

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()
        App.get_running_app().refresh_info_screen()

    def refresh_texts(self) -> None:
        self.lbl_title = t("Информация")
        self.lbl_tower_title = t("Информация о станции")
        self.lbl_cells_title = t("Лучшие соты за сессию")
        self.lbl_sim_title = t("SIM / Устройство")
        self.lbl_status_title = t("Состояние")


class ReadingsScreen(Screen):
    lbl_title = StringProperty("")
    lbl_lte = StringProperty("")
    lbl_nr = StringProperty("")
    lbl_aggregation = StringProperty("")
    lbl_note = StringProperty("")
    lte_text = StringProperty("")
    nr_text = StringProperty("")
    aggregation_text = StringProperty("")

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()
        app = App.get_running_app()
        app.refresh_readings_screen()
        app._refresh_nbr_cache()

    def refresh_texts(self) -> None:
        self.lbl_title = t("القراءات")
        self.lbl_lte = t("قراءات 4G LTE")
        self.lbl_nr = t("قراءات 5G NR")
        self.lbl_aggregation = t("الدمج الفعلي الحالي")
        self.lbl_note = t("تعرض الصفحة القيم التي يوفرها الراوتر فقط. قد لا تتوفر قياسات مستقلة لكل حامل ثانوي.")


class CellsScreen(Screen):
    lbl_title = StringProperty("")
    lbl_scan = StringProperty("")
    scan_info = StringProperty("")
    source = StringProperty('router')
    lbl_src_router = StringProperty("")
    lbl_src_phone = StringProperty("")

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()
        App.get_running_app().refresh_cells_screen(rescan=True)

    def refresh_texts(self) -> None:
        self.lbl_title = t("الخلايا القريبة")
        self.lbl_scan = t("مسح الآن")
        self.lbl_src_router = t("من الراوتر")
        self.lbl_src_phone = t("من الجوال")


class PhoneScreen(Screen):
    """Phone-only readings (no router): cells seen by the phone's own modem."""
    lbl_title = StringProperty("")
    lbl_scan = StringProperty("")
    scan_info = StringProperty("")
    lbl_nearby = StringProperty("")

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()
        App.get_running_app().start_phone_live()

    def on_leave(self, *args: Any) -> None:
        App.get_running_app().stop_phone_live()

    def refresh_texts(self) -> None:
        self.lbl_title = t("قراءات الجوال")
        self.lbl_scan = t("مسح الآن")
        self.lbl_nearby = t("الخلايا القريبة")


class SpeedGauge(Widget):
    """Half-circle speed dial (0 - 1000 Mbps, non-linear like the usual speed tests)."""
    value = NumericProperty(0.0)

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        from kivy.graphics import Color, Ellipse, Line
        from kivy.uix.label import Label
        from core.speed_test import GAUGE_TICKS
        with self.canvas:
            self._c_bg = Color(0.5, 0.56, 0.64, 0.22)
            self._arc_bg = Line(width=dp(9), cap='round')
            self._c_fill = Color(0.06, 0.42, 0.96, 1)
            self._arc_fill = Line(width=dp(9), cap='round')
            self._c_needle = Color(0.91, 0.93, 0.96, 1)
            self._needle = Line(width=dp(2.4), cap='round')
            self._hub = Ellipse()
            self._c_hole = Color(0.04, 0.07, 0.10, 1)
            self._hole = Ellipse()
        self._labels: list[Any] = []
        for tick in GAUGE_TICKS:
            label = Label(text=str(tick), font_size=sp(10), size_hint=(None, None),
                          size=(dp(34), dp(14)), color=(0.54, 0.59, 0.65, 1))
            self.add_widget(label)
            self._labels.append(label)
        self.bind(pos=self._redraw, size=self._redraw, value=self._redraw)

    def _redraw(self, *_args: Any) -> None:
        import math
        from core.speed_test import GAUGE_TICKS, gauge_fraction
        cx = self.center_x
        cy = self.y + dp(18)
        radius = min(self.width / 2 - dp(24), self.height - dp(30))
        if radius <= dp(20):
            return
        app = App.get_running_app()
        text_color = tuple(getattr(app, 'c_text', (0.9, 0.93, 0.96, 1)))
        frac = gauge_fraction(self.value)
        self._arc_bg.circle = (cx, cy, radius, -90, 90)
        self._arc_fill.circle = (cx, cy, radius, -90, -90 + 180 * max(frac, 0.006))
        low, high = (0.06, 0.42, 0.96), (0.21, 0.82, 0.50)
        self._c_fill.rgba = tuple(a + (b - a) * frac for a, b in zip(low, high)) + (1,)
        angle = math.radians(-90 + 180 * frac)
        length = radius - dp(16)
        self._c_needle.rgba = text_color
        self._needle.points = [cx, cy, cx + length * math.sin(angle), cy + length * math.cos(angle)]
        self._hub.pos, self._hub.size = (cx - dp(7), cy - dp(7)), (dp(14), dp(14))
        self._c_hole.rgba = tuple(getattr(app, 'c_bg', (0.04, 0.07, 0.10, 1)))
        self._hole.pos, self._hole.size = (cx - dp(3), cy - dp(3)), (dp(6), dp(6))
        steps = len(GAUGE_TICKS) - 1
        for i, label in enumerate(self._labels):
            a = math.radians(-90 + 180 * i / steps)
            label.center = (cx + (radius - dp(26)) * math.sin(a), cy + (radius - dp(26)) * math.cos(a))


class SpeedScreen(Screen):
    """Internet speed (download / upload / latency) with a dial; sits beside the ping test."""
    lbl_title = StringProperty("")
    lbl_download = StringProperty("")
    lbl_upload = StringProperty("")
    lbl_latency = StringProperty("")
    lbl_used = StringProperty("")
    lbl_start = StringProperty("")
    lbl_running = StringProperty("")
    lbl_note = StringProperty("")
    lbl_note2 = StringProperty("")
    lbl_recent = StringProperty("")
    gauge_title = StringProperty("")
    gauge_unit = StringProperty('Mbps')
    down_text = StringProperty('—')
    net_text = StringProperty("")
    net_color = ListProperty([0.6, 0.68, 0.78, 1])
    big_value = StringProperty('0')
    value_color = ListProperty([0.21, 0.82, 0.50, 1])
    phase_text = StringProperty("")
    up_text = StringProperty('—')
    latency_text = StringProperty('—')
    used_text = StringProperty('—')
    hist_router_title = StringProperty("")
    hist_router_vals = StringProperty("")
    hist_phone_title = StringProperty("")
    hist_phone_vals = StringProperty("")
    busy = BooleanProperty(False)

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()
        App.get_running_app().prepare_speed_screen()

    def refresh_texts(self) -> None:
        self.lbl_title = t("فحص البنق")
        self.lbl_download = t("التحميل")
        self.lbl_upload = t("الرفع")
        self.lbl_latency = t("زمن الاستجابة")
        self.lbl_used = t("الحجم المستخدم")
        self.lbl_start = t("ابدأ قياس السرعة")
        self.lbl_running = t("جارٍ القياس…")
        self.lbl_recent = t("آخر النتائج")
        self.hist_router_title = t("واي فاي - الراوتر")
        self.hist_phone_title = t("بيانات الجوال")
        self.lbl_note = t("القياس على الشبكة المتصل بها الجوال الآن.")
        self.lbl_note2 = t("لقياس بيانات الجوال أطفئ الواي فاي ثم اضغط ابدأ.")
        if not self.busy:
            self.gauge_title = t("السرعة")


class SettingsScreen(Screen):
    """Router settings: antenna mode, router management, game connection test."""
    lbl_title = StringProperty("")
    lbl_antenna = StringProperty("")
    lbl_apply_antenna = StringProperty("")
    lbl_netsel = StringProperty("")
    hint_netsel = StringProperty("")
    lbl_net_lte = StringProperty("")
    lbl_net_nsa = StringProperty("")
    lbl_unlock_cell = StringProperty("")
    antenna_text = StringProperty("")
    antenna_values = ListProperty([])
    lbl_router = StringProperty("")
    hint_router = StringProperty("")
    lbl_reattach = StringProperty("")
    lbl_reboot = StringProperty("")
    lbl_diag = StringProperty("")
    lbl_whitelist = StringProperty("")
    hint_whitelist = StringProperty("")
    lbl_wl_check = StringProperty("")
    wl_verdict = StringProperty("")
    wl_detail = StringProperty("")
    wl_color = ListProperty([0.5, 0.5, 0.5, 1])
    net_msg = StringProperty("")
    net_msg_color = ListProperty([0.5, 0.5, 0.5, 1])

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()
        App.get_running_app().load_router_config()

    def refresh_texts(self) -> None:
        self.lbl_title = t("إعدادات الراوتر")
        self.lbl_antenna = t("إعدادات الأنتينا")
        self.lbl_netsel = t("تحديد الشبكة")
        self.hint_netsel = t("اختر نوع الشبكة التي يتصل بها الراوتر: 4G فقط أو NSA (4G+5G).")
        self.lbl_net_lte = t("4G فقط")
        self.lbl_net_nsa = t("NSA 4G+5G")
        self.lbl_unlock_cell = t("إلغاء قفل الخلية و5G")
        self.lbl_apply_antenna = t("Применить")
        self.antenna_values = [t(k) for k in ANTENNA_MODES]
        if not self.antenna_text:
            self.antenna_text = t("Авто")
        self.lbl_router = t("Управление роутером")
        self.hint_router = t(
            "«Переподключить связь» заставляет модем заново выбрать лучшую "
            "соту — быстрее перезагрузки. После перезагрузки программа "
            "переподключится сама.")
        self.lbl_reattach = t("Переподключить связь")
        self.lbl_reboot = t("Перезагрузить роутер")
        self.lbl_diag = t("Скопировать диагностику")
        self.lbl_whitelist = t("اختبار الألعاب")
        self.hint_whitelist = t(
            "اختبر اتصال PUBG Mobile وEA SPORTS FC Mobile. القياس إلى خوادم HTTPS عامة وليس Ping خادم المباراة الفعلي.")
        self.lbl_wl_check = t("بدء الاختبار الشامل")


class BandFlag(EventDispatcher):
    """Non-visual on/off state of a band choice (selected / P / S)."""
    active = BooleanProperty(False)


class ToolsScreen(Screen):
    lbl_title = StringProperty("")
    lbl_bandlock = StringProperty("")
    hint_bandlock = StringProperty("")
    lock_state = StringProperty("")
    lbl_mark_current = StringProperty("")
    lbl_apply_bands = StringProperty("")
    nr_lock_note = StringProperty("")
    nr_bands_display = StringProperty("")
    lbl_nr_bands = StringProperty("")
    lbl_nr_lock_check = StringProperty("")
    lbl_reset_auto = StringProperty("")
    lbl_restore = StringProperty("")
    band_tab = StringProperty('lte')
    lbl_tab_lte = StringProperty("")
    lbl_tab_nr = StringProperty("")
    lbl_apply_nr = StringProperty("")
    lbl_unlock_nr = StringProperty("")
    nr_lock_state = StringProperty("")
    lbl_antenna = StringProperty("")
    lbl_apply_antenna = StringProperty("")
    antenna_text = StringProperty("")
    antenna_values = ListProperty([])
    lbl_router = StringProperty("")
    hint_router = StringProperty("")
    lbl_reattach = StringProperty("")
    lbl_reboot = StringProperty("")
    lbl_diag = StringProperty("")
    lbl_whitelist = StringProperty("")
    hint_whitelist = StringProperty("")
    lbl_wl_check = StringProperty("")
    wl_verdict = StringProperty("")
    wl_detail = StringProperty("")
    wl_color = ListProperty([0.5, 0.5, 0.5, 1])
    net_msg = StringProperty("")
    net_msg_color = ListProperty([0.5, 0.5, 0.5, 1])

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()
        app = App.get_running_app()
        app.build_band_checkboxes()
        app.build_nr_band_checkboxes()
        app._show_band_box(self.band_tab)
        app.load_router_config()

    def refresh_texts(self) -> None:
        self.lbl_title = t("الترددات")
        self.lbl_bandlock = t("Фиксация частот (Band Lock)")
        self.hint_bandlock = t(
            "Список взят из модема; замеченные в эфире бэнды — первыми. "
            "Меняются только LTE-бэнды; «Как было» восстановит настройки, "
            "прочитанные при подключении.")
        self.lbl_mark_current = t("تحديد الحالية")
        self.lbl_apply_bands = t("تطبيق قفل 4G")
        self.lbl_nr_bands = t("باندات 5G NR")
        self.lbl_tab_lte = t("4G LTE")
        self.lbl_tab_nr = t("5G NR")
        self.lbl_apply_nr = t("تطبيق قفل 5G")
        self.lbl_unlock_nr = t("إلغاء قفل 5G")
        self.nr_lock_state = t("الحالي على الراوتر: غير متوفر (5G)")
        self.nr_bands_display = t(
            "الأرقام بالميغاهرتز. P رئيسي وS ثانوي. في 5G يمكن أكثر من رئيسي، "
            "والباند الواحد يتجمّع تلقائيًا إذا أرسل البرج حاملين فيه.")
        self.lbl_reset_auto = t("Все (AUTO)")
        self.lbl_restore = t("↩ Как было")


# =========================================================
# ПРИЛОЖЕНИЕ
# =========================================================

class PingScreen(Screen):
    lbl_title = StringProperty("")
    lbl_current = StringProperty("")
    lbl_jitter = StringProperty("")
    lbl_loss = StringProperty("")
    lbl_best = StringProperty("")
    lbl_start = StringProperty("")
    lbl_improve_ping = StringProperty("")
    lbl_improve_speed = StringProperty("")
    lbl_games = StringProperty("")
    lbl_regions = StringProperty("")
    lbl_note = StringProperty("")
    hero_ms = StringProperty('—')
    hero_label = StringProperty("")
    hero_color = ListProperty([0.6, 0.68, 0.78, 1])
    marker = NumericProperty(0)
    marker_on = NumericProperty(0)
    stat_jitter = StringProperty('—')
    stat_loss = StringProperty('—')
    stat_best = StringProperty('—')
    status_text = StringProperty("")
    busy = BooleanProperty(False)
    progress = NumericProperty(0)
    spin = NumericProperty(0)
    progress_text = StringProperty("")
    lbl_running = StringProperty("")

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()

    def refresh_texts(self) -> None:
        self.lbl_running = t("جاري الفحص…")
        self.lbl_title = t("فحص البنق")
        self.lbl_current = t("البنق الحالي")
        self.lbl_jitter = t("تذبذب Jitter")
        self.lbl_loss = t("فقد الحزم")
        self.lbl_best = t("أقل قيمة")
        self.lbl_start = t("ابدأ فحص الألعاب")
        self.lbl_improve_ping = t("تحسين البنق")
        self.lbl_improve_speed = t("تحسين السرعة")
        self.lbl_games = t("سيرفرات الألعاب")
        self.lbl_regions = t("نقاط مرجعية إقليمية")
        self.lbl_note = t(
            "الرقم = زمن اتصال TCP بخوادم الناشر أو بنقطة الإقليم (أقرب قياس للبنق)، "
            "وليس البنق داخل المباراة. الألعاب مرتبة من الأقل بنقًا.")
        if not self.hero_label:
            self.hero_label = t("لم يُقَس بعد")


class MoreScreen(Screen):
    lbl_title = StringProperty("")
    lbl_router = StringProperty("")
    hint_router = StringProperty("")
    lbl_info = StringProperty("")
    hint_info = StringProperty("")
    lbl_theme = StringProperty("")
    lbl_sun = StringProperty("")
    lbl_dark = StringProperty("")
    lbl_refresh = StringProperty("")

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()

    def refresh_texts(self) -> None:
        self.lbl_refresh = t("تنشيط الاتصال بالراوتر")
        self.lbl_title = t("المزيد")
        self.lbl_router = t("إعدادات الراوتر")
        self.hint_router = t("تحديد الشبكة، الهوائي، إعادة التشغيل، التشخيص")
        self.lbl_info = t("المعلومات")
        self.hint_info = t("الشريحة والجهاز والبرج")
        self.lbl_theme = t("المظهر")
        self.lbl_sun = t("شمس")
        self.lbl_dark = t("قمر")


class Hua4GMonApp(App):
    sm = ObjectProperty(None, allownone=True)
    current_page = StringProperty('connection')
    text_align = StringProperty('right')
    lbl_cell_connect = StringProperty("")
    lbl_cells_open = StringProperty("")
    nav_icon_dir = StringProperty(os.path.join(_ASSETS, 'nav'))
    nav_home = StringProperty("")
    nav_readings = StringProperty("")
    nav_cells = StringProperty("")
    nav_network = StringProperty("")
    nav_router_settings = StringProperty("")
    nav_antenna = StringProperty("")
    nav_info = StringProperty("")
    nav_settings = StringProperty("")
    nav_theme = StringProperty("")
    nav_ping = StringProperty("")
    lbl_tab_ping = StringProperty("")
    lbl_tab_speed = StringProperty("")
    nav_more = StringProperty("")
    theme_name = StringProperty('dark')
    c_bg = ListProperty(THEMES['dark']['c_bg'])
    c_card = ListProperty(THEMES['dark']['c_card'])
    c_text = ListProperty(THEMES['dark']['c_text'])
    c_sub = ListProperty(THEMES['dark']['c_sub'])
    c_accent = ListProperty(THEMES['dark']['c_accent'])
    c_button2 = ListProperty(THEMES['dark']['c_button2'])
    sound_on = BooleanProperty(False)
    lbl_back = StringProperty("")

    # ---------- запуск и жизненный цикл ----------

    def build(self) -> Any:
        """Safety wrapper: a startup exception is saved and shown on screen
        instead of silently closing the app, so the cause can be read."""
        try:
            return self._build_app()
        except Exception:
            import traceback
            text = traceback.format_exc()
            self._startup_failed = True
            try:
                logger.error("Startup failed:\n%s", text)
                path = os.path.join(self.user_data_dir, 'startup_error.txt')
                with open(path, 'w', encoding='utf-8') as fh:
                    fh.write(text)
            except Exception:
                path = ''
            from kivy.uix.label import Label as _Label
            from kivy.uix.scrollview import ScrollView as _ScrollView
            lbl = _Label(text="HATIM5G startup error\n" + (path + "\n\n" if path else "\n") + text[-3500:],
                         font_name='Roboto', font_size=sp(11), size_hint_y=None,
                         halign='left', valign='top', color=(1, 0.6, 0.6, 1),
                         text_size=(Window_width(), None))
            lbl.bind(texture_size=lambda inst, size: setattr(inst, 'height', size[1]))
            view = _ScrollView()
            view.add_widget(lbl)
            return view

    _startup_failed = False

    def _install_guard(self) -> None:
        """An uncaught error in a UI callback no longer closes the app: it is
        written to crash_log.txt (app data folder) and the app keeps running."""
        from kivy.base import ExceptionHandler, ExceptionManager
        app = self

        class _Guard(ExceptionHandler):
            def handle_exception(self, inst: BaseException) -> Any:
                try:
                    import traceback
                    text = ''.join(traceback.format_exception(type(inst), inst, inst.__traceback__))
                    logger.error("Guarded UI error:\n%s", text)
                    path = os.path.join(app.user_data_dir, 'crash_log.txt')
                    if os.path.exists(path) and os.path.getsize(path) > 200_000:
                        os.remove(path)
                    with open(path, 'a', encoding='utf-8') as fh:
                        fh.write(time.strftime('%Y-%m-%d %H:%M:%S') + '\n' + text + '\n')
                except Exception:
                    pass
                return ExceptionManager.PASS

        ExceptionManager.add_handler(_Guard())

    def _build_app(self) -> ScreenManager:
        self._install_guard()
        from kivy.core.window import Window
        Window.clearcolor = tuple(self.c_bg)
        Window.softinput_mode = 'below_target'
        Window.bind(on_keyboard=self._on_keyboard)
        # One font for the whole app: Al-Mohanad plus the symbols/Cyrillic it lacks
        # (merged from DejaVu), so no screen mixes fonts and no symbol becomes a square.
        if os.path.exists(_UNIFIED_PATH):
            ubold = _UNIFIED_BOLD_PATH if os.path.exists(_UNIFIED_BOLD_PATH) else _UNIFIED_PATH
            for _name in ('Roboto', 'AlMohanad', 'DejaVuSans'):
                LabelBase.register(name=_name, fn_regular=_UNIFIED_PATH, fn_bold=ubold)
        elif os.path.exists(_FONT_PATH):
            bold = _FONT_BOLD_PATH if os.path.exists(_FONT_BOLD_PATH) else _FONT_PATH
            LabelBase.register(name='DejaVuSans', fn_regular=_FONT_PATH, fn_bold=bold)
            LabelBase.register(name='AlMohanad', fn_regular=_FONT_PATH, fn_bold=bold)
            LabelBase.register(name='Roboto', fn_regular=_FONT_PATH, fn_bold=bold)
        if os.path.exists(_UNIFIED_PATH):
            LabelBase.register(name='AlMohanadLongKaf', fn_regular=_UNIFIED_PATH,
                               fn_bold=_UNIFIED_BOLD_PATH if os.path.exists(_UNIFIED_BOLD_PATH) else _UNIFIED_PATH)
        elif os.path.exists(_ARABIC_READINGS_FONT_PATH):
            LabelBase.register(name='AlMohanadLongKaf', fn_regular=_ARABIC_READINGS_FONT_PATH,
                               fn_bold=_ARABIC_READINGS_FONT_PATH)
        self.title = f"{APP_NAME} v{__version__}"
        self._router_store = JsonStore(os.path.join(self.user_data_dir, 'router.json'))
        self._speed_store = JsonStore(os.path.join(self.user_data_dir, 'speed.json'))
        # Журнал сессии нужен только для экспорта CSV, которого на Android нет.
        self.state = SignalState(trend_param='sinr', log_max=GRAPH_HISTORY)
        self.session: RouterSession | None = None
        self.worker: SessionWorker | None = None
        self.demo_modem: DemoModem | None = None
        self.link = 'offline'
        self.interval = 1.0
        self.band_vars: dict[int, Any] = {}
        self.nr_band_vars: dict[int, Any] = {}
        self.nr_role_vars: dict[int, dict[str, Any]] = {}
        self._nr_bands_shown: Any = ()
        self.band_role_vars: dict[int, dict[str, Any]] = {}
        self._band_list: list[int] = list(REGION_BANDS)
        self._bands_shown: Any = ()
        self._busy = False
        self._discovering = False       # идёт автопоиск роутера
        self._wl_running = False        # идёт проверка белых списков
        self._ping_running = False
        self._ping_last: Any = None
        self._fs_graph: SignalGraph | None = None
        self._last_back = 0.0
        self._beep_ev: Any = None
        self.beeper = ToneBeeper()
        self.lbl_back = t("رجوع")
        self.lbl_tab_ping = t("زمن البنق")
        self.lbl_tab_speed = t("سرعة الإنترنت")
        self.nav_home = t("الرئيسية")
        self.nav_readings = t("القراءات")
        self.nav_cells = t("الخلايا")
        self.nav_network = t("الترددات")
        self.nav_router_settings = t("إعدادات الراوتر")
        self.nav_antenna = t("وزن الانتينا")
        self.nav_info = t("المعلومات")
        self.nav_settings = t("الإعدادات")
        self.nav_theme = t("المظهر")
        self.nav_ping = t("البنق")
        self.nav_more = t("المزيد")
        self.lbl_cell_connect = t("اتصال بهذه الخلية")
        self.lbl_cells_open = t("الخلايا القريبة")
        self.text_align = 'right' if current_language() == 'ar' else 'left'
        self._root_widget = Builder.load_string(KV)
        self.sm: ScreenManager = self._root_widget.ids.main_sm
        self.current_page = self.sm.current
        try:
            self.refresh_saved_routers()           # skipped during KV load; draw the list now
        except Exception:
            logger.exception("Could not draw the saved routers")
        self.sm.bind(current=lambda _inst, value: setattr(self, 'current_page', value))
        Clock.schedule_interval(self._tick, 0.5)
        Clock.schedule_interval(self._refresh_nbr_cache, 15)
        return self._root_widget

    def on_start(self) -> None:
        if self._startup_failed:
            return
        try:
            self._load_routers()            # also migrates the old single saved router
            self.refresh_saved_routers()
        except Exception:
            logger.exception("Could not restore saved routers")

    # ---------- saved routers (stored in the app-private data directory) ----------

    def _load_routers(self) -> list[dict[str, Any]]:
        store = self._router_store
        items: list[dict[str, Any]] = []
        try:
            if store.exists('routers'):
                items = [dict(x) for x in store.get('routers').get('items', []) if x.get('ip')]
            if store.exists('router'):                  # migrate the old single entry
                old = store.get('router')
                if old.get('ip') and not any(x['ip'] == old['ip'] for x in items):
                    items.append({'ip': old['ip'], 'password': old.get('password', ''),
                                  'brand': '', 'model': '', 'operator': '', 'last': 0})
                store.put('routers', items=items)
                store.delete('router')
        except Exception:
            logger.exception("Could not read saved routers")
        changed = False
        for item in items:
            if not item.get('id'):
                item['id'] = uuid.uuid4().hex
                changed = True
            if 'name' not in item:
                item['name'] = ''
                changed = True
        if changed:
            self._save_routers(items)
        return items

    def _save_routers(self, items: list[dict[str, Any]]) -> None:
        try:
            self._router_store.put('routers', items=items)
        except Exception:
            logger.exception("Could not save routers")

    def save_router_details(self, ip: str, password: str, remember: bool, name: str = '') -> None:
        """Add or update a router in the saved list (only when «save» is ticked).
        A router is identified by IP *and* name, so two customers' routers that both use
        192.168.8.1 stay separate entries when they are given different names."""
        self._current_router_id = ''
        if not remember:
            return
        ip, name = ip.strip(), name.strip()
        items = self._load_routers()
        for item in items:
            if item['ip'] == ip and item.get('name', '').lower() == name.lower():
                item['password'] = password
                self._current_router_id = item['id']
                break
        else:
            entry = {'id': uuid.uuid4().hex, 'ip': ip, 'name': name, 'password': password,
                     'brand': '', 'model': '', 'operator': '', 'last': 0}
            items.append(entry)
            self._current_router_id = entry['id']
        self._save_routers(items)

    _current_router_id = ''

    def _note_router_connected(self, info: dict[str, Any]) -> None:
        """After a successful login: remember the brand/model and the connection time."""
        session = self.session
        if session is None or getattr(session, 'ip', '') in ('', 'demo'):
            return
        items = self._load_routers()
        for item in items:
            if (item['id'] == self._current_router_id if self._current_router_id
                    else item['ip'] == session.ip):
                item['brand'] = 'ZTE' if getattr(session, 'is_zte', False) else 'HUAWEI'
                model = str((info or {}).get('DeviceName') or '').strip()
                if model:
                    item['model'] = model
                item['last'] = time.time()
                self._save_routers(items)
                self._op_pending_ip = item['id'] if not item.get('operator') else ''
                return
        self._op_pending_ip = ''

    def _note_router_operator(self, operator: str) -> None:
        rid, self._op_pending_ip = self._op_pending_ip, ''
        if not rid or not operator:
            return
        items = self._load_routers()
        for item in items:
            if item['id'] == rid:
                item['operator'] = operator
                self._save_routers(items)
                return

    _op_pending_ip = ''

    def refresh_saved_routers(self) -> None:
        if getattr(self, 'sm', None) is None:      # KV is still loading: screens not attached yet
            return
        scr = self._conn_screen()
        box = scr.ids.get('routers_box')
        if box is None:
            return
        box.clear_widgets()
        items = self._load_routers()
        scr.lbl_saved = (t("الراوترات المحفوظة ({count})").format(count=len(items))
                         if items else t("الراوترات المحفوظة"))
        if not items:
            card = _make_widget('SectionCard', {})
            card.add_widget(Factory.SectionTitle(text=t("لا توجد راوترات محفوظة")))
            card.add_widget(Factory.HintLabel(
                text=t("اتصل براوتر وفعّل «حفظ في القائمة» ليظهر هنا، وتتصل به لاحقًا بضغطة واحدة.")))
            box.add_widget(card)
            return
        newest = max(range(len(items)), key=lambda i: items[i].get('last', 0))
        has_last = items[newest].get('last', 0) > 0
        order = sorted(range(len(items)), key=lambda i: -items[i].get('last', 0))
        for i in order:
            item = items[i]
            brand = item.get('brand', '')
            if brand == 'ZTE':
                bg, fg = (0.18, 0.55, 1, 0.18), (0.56, 0.75, 1, 1)
            elif brand == 'HUAWEI':
                bg, fg = (0.9, 0.28, 0.30, 0.16), (1, 0.56, 0.58, 1)
            else:
                bg, fg = (0.4, 0.45, 0.55, 0.2), (0.8, 0.85, 0.92, 1)
            parts = [item['ip']]
            if item.get('name') and item.get('model'):
                parts.append(item['model'])
            if item.get('operator'):
                parts.append(item['operator'])
            meta = "  -  ".join(parts)
            card = _make_widget('RouterCard', dict(
                r_brand=brand or 'ROUTER', brand_bg=bg, brand_fg=fg,
                r_name=item.get('name') or item.get('model') or t("راوتر"), r_meta=meta,
                r_tag=t("آخر اتصال") if (has_last and i == newest) else '',
                r_connect=t("اتصال"), card_index=i))
            if current_language() != 'ar':
                kids = list(reversed(card.children))     # menu, connect, info, badge
                card.clear_widgets()
                for w in reversed(kids):
                    card.add_widget(w)
            box.add_widget(card)

    def connect_saved(self, index: int) -> None:
        items = self._load_routers()
        if not 0 <= index < len(items):
            return
        item = items[index]
        scr = self._conn_screen()
        scr.ids.ip_input.text = item['ip']
        scr.ids.pw_input.text = item.get('password', '')
        scr.ids.name_input.text = item.get('name', '')
        self.connect(item['ip'], item.get('password', ''), remember=True,
                     name=item.get('name', ''))

    def router_menu(self, index: int) -> None:
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.button import Button
        items = self._load_routers()
        if not 0 <= index < len(items):
            return
        item = items[index]
        content = BoxLayout(orientation='vertical', spacing=dp(10), padding=dp(10))
        popup = Popup(title=f"{item.get('model') or t('راوتر')} · {item['ip']}",
                      content=content, size_hint=(0.85, None), height=dp(240))
        for text, action in ((t("تعديل"), lambda: self.edit_router(index)),
                             (t("حذف"), lambda: self.confirm_delete_router(index)),
                             (t("إلغاء"), lambda: None)):
            btn = Button(text=text, size_hint_y=None, height=dp(50), font_size=sp(16))
            btn.bind(on_release=lambda _b, act=action: (popup.dismiss(), act()))
            content.add_widget(btn)
        popup.open()

    def edit_router(self, index: int) -> None:
        items = self._load_routers()
        if not 0 <= index < len(items):
            return
        scr = self._conn_screen()
        scr.ids.ip_input.text = items[index]['ip']
        scr.ids.pw_input.text = items[index].get('password', '')
        scr.ids.name_input.text = items[index].get('name', '')
        self.toast(t("عدّل البيانات ثم اضغط «اتصال» لحفظها. تغيير الاسم أو الـIP يحفظ راوترًا جديدًا."), 4.5)

    def confirm_delete_router(self, index: int) -> None:
        items = self._load_routers()
        if not 0 <= index < len(items):
            return
        rid, ip = items[index]['id'], items[index]['ip']
        label = items[index].get('name') or ip

        def delete() -> None:
            fresh = [x for x in self._load_routers() if x['id'] != rid]
            self._save_routers(fresh)
            self.refresh_saved_routers()
        self.confirm(t("حذف الراوتر"), t("حذف الراوتر {ip} من القائمة؟").format(ip=label),
                     t("حذف"), delete)

    def on_pause(self) -> bool:
        if self._startup_failed:
            return True
        """Свернули приложение: опрос на паузу, звук выключаем."""
        if self.worker is not None:
            self.worker.pause()
        self._stop_beeps()
        return True

    def on_resume(self) -> None:
        if self._startup_failed:
            return
        if self.worker is not None:
            self.worker.resume()       # reads at once; logs in again after a long absence
            if self.link in ('online', 'reconnecting'):
                self.toast(t("جاري تحديث القراءات…"), 3)
        if self.sound_on:
            self._schedule_beep()

    def refresh_connection(self) -> None:
        """Manual refresh: log in again and read the router now (no waiting for the next poll)."""
        worker = self.worker
        if worker is None or not hasattr(worker, 'refresh'):
            self.toast(t("غير متصل بالراوتر."), 3)
            return
        worker.refresh(reopen=True)
        self.toast(t("جاري تنشيط الاتصال بالراوتر…"), 3)

    def on_stop(self) -> None:
        if self._startup_failed:
            return
        worker = self.worker
        if worker is not None:
            worker.stop()
            worker.join(timeout=2.0)       # дать отправить logout
        self.beeper.release()
        set_keep_screen_on(False)

    # ---------- тема, тексты, навигация ----------

    def apply_theme(self, name: str) -> None:
        from kivy.core.window import Window
        self.theme_name = name
        for key, value in THEMES[name].items():
            if hasattr(self, key):
                setattr(self, key, value)
        Window.clearcolor = tuple(self.c_bg)
        self._bands_shown = ()          # подписи бэндов — заново, в цвете темы
        self._nr_bands_shown = ()
        self.build_band_checkboxes()
        self.build_nr_band_checkboxes()
        self._render_ping()
        if self.state.last is not None:
            self._render(self.state.last)
        else:
            self.refresh_graph()

    def refresh_all_texts(self) -> None:
        self.text_align = 'right' if current_language() == 'ar' else 'left'
        self.lbl_back = t("رجوع")
        self.lbl_tab_ping = t("زمن البنق")
        self.lbl_tab_speed = t("سرعة الإنترنت")
        for name in ('connection', 'monitor', 'info', 'readings', 'cells', 'tools', 'router_settings',
                     'ping', 'more', 'phone', 'speed'):
            self.sm.get_screen(name).refresh_texts()
        self.refresh_saved_routers()
        self._render_link_state()
        if self.state.last is not None:
            self._render(self.state.last)

    def go(self, screen: str) -> None:
        self.sm.current = screen

    def open_antenna_tools(self) -> None:
        """Open network tools and scroll directly to antenna controls."""
        self.go('router_settings')
        try:
            screen = self.sm.get_screen('router_settings')
            scroll = screen.ids.get('settings_scroll')
            card = screen.ids.get('antenna_card')
            if scroll is not None and card is not None:
                Clock.schedule_once(lambda _dt: scroll.scroll_to(card, padding=dp(12), animate=True), 0.12)
        except Exception:
            logger.exception("Could not focus antenna controls")

    def _on_keyboard(self, window: Any, key: int, *args: Any) -> bool:
        """Системная «Назад» (Esc на десктопе).

        Hardware validation required: жест «Назад» Android 13+ на устройстве.
        """
        if self._startup_failed or key != 27:
            return False
        if any(isinstance(w, ModalView) for w in window.children):
            return False            # открытый диалог закроется сам
        current = self.sm.current
        if current == 'phone':
            self.sm.current = 'connection'
            return True
        if current in ('info', 'router_settings'):
            self.sm.current = 'more'
            return True
        if current in ('readings', 'tools', 'cells', 'ping', 'more', 'speed'):
            self.sm.current = 'monitor'
            return True
        if current == 'monitor':
            now = time.monotonic()
            if now - self._last_back < 2.0:
                self.disconnect()
            else:
                self._last_back = now
                self.toast(t("Нажмите «Назад» ещё раз, чтобы отключиться"))
            return True
        if current == 'connection':
            now = time.monotonic()
            if now - self._last_back < 2.0:
                return False        # second press: leave the app
            self._last_back = now
            self.toast(t("اضغط «رجوع» مرة أخرى للخروج"))
            return True
        return False

    # ---------- подключение ----------

    def _conn_screen(self) -> ConnectionScreen:
        return self.sm.get_screen('connection')

    def discover(self, entered: str) -> None:
        # Повторное нажатие во время поиска игнорируется: иначе результат
        # первого поиска мог бы прийти последним и затереть второй.
        if self._discovering:
            return
        self._discovering = True
        scr = self._conn_screen()
        scr.set_status(t("Ищу роутер…"), [0.3, 0.6, 0.95, 1])
        candidates = ([entered] if is_valid_ip(entered) else []) + list(DISCOVERY_CANDIDATES)

        def done(found: Any) -> None:
            self._discovering = False
            if found is None:
                scr.set_status(t("Роутер не найден. Проверьте подключение к его Wi-Fi/USB."),
                               [0.9, 0.3, 0.3, 1])
                return
            ip_input = scr.ids.get('ip_input')
            if ip_input is not None:
                ip_input.text = found.ip
            scr.set_status(t("Найден роутер {model} на {ip}").format(
                model=found.model or "Huawei", ip=found.ip), [0.2, 0.75, 0.45, 1])
        self._run_bg(lambda: discover_router(candidates), done, lambda e: done(None))

    def connect(self, ip: str, password: str, remember: bool | None = None,
                name: str | None = None) -> None:
        if self.worker is not None:
            return
        remember_widget = self._conn_screen().ids.get('remember_router')
        if remember is None:
            remember = bool(remember_widget.active) if remember_widget is not None else False
        if name is None:
            name_input = self._conn_screen().ids.get('name_input')
            name = name_input.text if name_input is not None else ''
        self.save_router_details(ip, password, remember, name)
        self.demo_modem = None
        self._conn_screen().set_status(t("Подключение..."), [0.9, 0.6, 0.2, 1])
        self._start_session(RouterSession(ip, password))

    def start_demo(self) -> None:
        if self.worker is not None:
            return
        self.demo_modem = DemoModem()
        self._start_session(RouterSession("demo", "", factory=demo_factory(self.demo_modem)))

    def _start_session(self, session: RouterSession) -> None:
        self.state.reset()
        self.session = session
        worker: SessionWorker | None = None

        def mine(fn: Callable[..., None]) -> Callable[..., None]:
            """Событие фонового потока → главный поток, только для текущей сессии."""
            def post(*args: Any) -> None:
                def call(_dt: float) -> None:
                    if worker is self.worker:
                        fn(*args)
                Clock.schedule_once(call)
            return post

        worker = SessionWorker(
            session, interval=lambda: self.interval,
            on_connected=mine(self._on_connected), on_snapshot=mine(self._on_snapshot),
            on_status=mine(self._on_status), on_fatal=mine(self._on_fatal))
        self.worker = worker
        self.link = 'connecting'
        worker.start()

    def disconnect(self) -> None:
        """Мгновенно для UI: выход из роутера выполняет фоновый поток."""
        if self.worker is not None:
            self.worker.stop()
        self.worker = None
        self.session = None
        self.demo_modem = None
        self.link = 'offline'
        self._busy = False
        self._stop_beeps()
        set_keep_screen_on(False)
        self._conn_screen().set_status("", [0.5, 0.5, 0.5, 1])
        self.sm.current = 'connection'

    def _on_connected(self, info: dict[str, Any]) -> None:
        self.link = 'online'
        try:
            self._note_router_connected(info)
        except Exception:
            logger.exception("Could not update the saved router")
        session = self.session
        if session is not None:
            self._band_list = lockable_bands(session.supported_bands, self.state.observed_bands)
        self._conn_screen().set_status("", [0.5, 0.5, 0.5, 1])
        self.sm.current = 'readings'
        set_keep_screen_on(True)
        self._render_link_state()
        self._show_last_event()         # не текст ошибки прошлой сессии
        if self.sound_on:
            self._schedule_beep()

    def _show_last_event(self) -> None:
        ev = self.sm.get_screen('monitor').ids.get('event_lbl')
        if ev is not None:
            ev.text = self._event_text(self.state.events[-1]) if self.state.events else ""

    def _on_status(self, status: str, delay: float | None, exc: BaseException | None) -> None:
        recovered = self.link == 'reconnecting' and status != 'reconnecting'
        self.link = 'reconnecting' if status == 'reconnecting' else 'online'
        self._render_link_state(humanize_error(exc) if exc is not None else "")
        if recovered:
            # Строка событий показывала ошибку связи — возвращаем последнее событие.
            self._show_last_event()

    def _on_fatal(self, exc: BaseException) -> None:
        failed = self.session
        self.disconnect()
        # Huawei login on a non-Huawei router fails with KeyError('token'). Only then
        # check whether it is a ZTE router and, if so, use the read-only ZTE session.
        if (isinstance(exc, KeyError) and exc.args and exc.args[0] == 'token'
                and isinstance(failed, RouterSession) and failed.ip != 'demo'):
            self._try_zte(failed.ip, failed.password, exc)
            return
        self._conn_screen().set_status(humanize_error(exc), [0.9, 0.3, 0.3, 1])

    def _try_zte(self, ip: str, password: str, original: BaseException) -> None:
        self._conn_screen().set_status(t("جارٍ التحقق إن كان الراوتر ZTE…"), [0.9, 0.6, 0.2, 1])

        def work() -> bool:
            from core.zte_session import is_zte
            return is_zte(ip)

        def done(found: bool) -> None:
            if self.worker is not None:
                return
            if found:
                from core.zte_session import ZteSession
                self._conn_screen().set_status(t("راوتر ZTE (قراءة فقط)"), [0.2, 0.75, 0.45, 1])
                self._start_session(ZteSession(ip, password))
            else:
                self._conn_screen().set_status(humanize_error(original), [0.9, 0.3, 0.3, 1])

        self._run_bg(work, done, lambda _e: done(False))

    @staticmethod
    def _event_text(change: Any) -> str:
        return t("{at} смена соты: {old} → {new}").format(
            at=change.at, old=change.old_label, new=change.new_label)

    def _render_link_state(self, detail: str = "") -> None:
        scr = self.sm.get_screen('monitor')
        lbl = scr.ids.get('status_lbl')
        if lbl is None:
            return
        sun = self.theme_name == 'sun'
        if self.link == 'reconnecting':
            lbl.text = t("Нет связи с роутером — переподключаюсь…")
            scr.status_color = hex_to_rgba('#e68033', sun)
            ev = scr.ids.get('event_lbl')
            if detail and ev is not None:
                ev.text = detail
        elif self.demo_modem is not None:
            lbl.text = t("Тестовый режим")
            scr.status_color = hex_to_rgba('#e68033', sun)

    # ---------- данные ----------

    def _on_snapshot(self, snap: Snapshot) -> None:
        if self._op_pending_ip and snap.operator:
            try:
                self._note_router_operator(snap.operator)
            except Exception:
                logger.exception("Could not save the operator name")
        change = self.state.ingest(snap, time.monotonic())
        scr = self.sm.get_screen('monitor')
        if change is not None:
            ev = scr.ids.get('event_lbl')
            if ev is not None:
                ev.text = self._event_text(change)
        if snap.has_nr and 'nr_sinr' not in scr.graph_values:
            scr.graph_values = LTE_PARAMS + NR_PARAMS
        if any(b not in self._band_list for b in snap.bands) and self.session is not None:
            self._band_list = lockable_bands(self.session.supported_bands,
                                             self.state.observed_bands)
        self._render(snap)
        self.refresh_readings_screen(snap)

    def _tick(self, _dt: float) -> None:
        """Каждые 0.5 с: признак устаревших данных."""
        if self.link not in ('online', 'reconnecting') or self.state.last is None:
            return
        now = time.monotonic()
        if self.state.is_stale(now, self.interval):
            scr = self.sm.get_screen('monitor')
            lbl = scr.ids.get('status_lbl')
            if lbl is not None:
                lbl.text = t("⚠ Данные устарели — нет ответа {s:.0f} с").format(
                    s=self.state.age(now) or 0)
                scr.status_color = hex_to_rgba('#d63031', self.theme_name == 'sun')
            self.refresh_graph(stale=True)

    def _metric_card(self, card: Any, param: str) -> None:
        val = self.state.current(param)
        label, color, _ = evaluate_signal(param.replace('nr_', ''), val)
        card.m_name = PARAM_TITLES.get(param, param.upper())
        card.m_value = fmt_num(val)
        card.m_status = t(label)
        card.m_color = hex_to_rgba(color, self.theme_name == 'sun')
        peak, delta = self.state.peaks.get(param), self.state.delta_to_peak(param)
        card.m_peak = "" if peak is None or delta is None else \
            t("Пик: {v} (Δ {d})").format(v=fmt_num(peak), d=f"{delta:+g}")

    def _layout_params(self) -> list[str]:
        """Крупно — выбранная метрика, рядом RSRP (или SINR), мелко — остальные."""
        primary = self.state.trend_param
        secondary = 'rsrp' if primary not in ('rsrp', 'nr_rsrp') else 'sinr'
        rest = [p for p in LTE_PARAMS if p not in (primary, secondary)][:2]
        return [primary, secondary, *rest]

    def _render(self, snap: Snapshot) -> None:
        scr = self.sm.get_screen('monitor')
        ids = scr.ids
        if not ids:
            return
        sun = self.theme_name == 'sun'
        score, summary, color = calculate_overall_health(snap.rsrp, snap.sinr)
        health = t(summary).format(pct=score)
        if self.demo_modem is not None:
            health = t("ДЕМО · азимут {a}").format(
                a=demo_angle_hint(self.demo_modem)) + " · " + health
        ids.status_lbl.text = health
        scr.status_color = hex_to_rgba(color, sun)
        ids.tower_lbl.text = self._tower_summary(snap)
        cards = (ids.primary_box, ids.secondary_box, ids.small1_box, ids.small2_box)
        for card, param in zip(cards, self._layout_params(), strict=True):
            self._metric_card(card, param)

        glyph = TREND_GLYPHS.get(self.state.trend, "—")
        ids.dir_lbl.text = glyph
        ids.dir_lbl.color = hex_to_rgba(
            {"↑": '#00b894', "↓": '#d63031', "→": '#fdcb6e'}.get(glyph, 'gray'), sun)
        ids.dir_text_lbl.text = {
            "↑": t("Лучше — продолжайте"), "↓": t("Хуже — поверните обратно"),
            "→": t("Стабильно — фиксируйте"),
        }.get(glyph, t("Накапливаю данные..."))

        mimo = mimo_status(snap.cqi0, snap.cqi1)
        up = uplink_status(snap.pusch_dbm)
        tips = advice(rsrp=snap.rsrp, sinr=snap.sinr, rsrq=snap.rsrq,
                      jitter=self.state.jitter(), mimo=mimo, uplink=up)
        if snap.data_enabled is False:
            tips.insert(0, "Мобильные данные на роутере выключены.")
        ids.advice_lbl.text = "\n".join("• " + t(tip) for tip in tips[:2])
        scr.advice_color = hex_to_rgba('#e68033', sun)
        self.refresh_graph()
        if self.sm.current == 'info':
            self.refresh_info_screen()

    def _tower_summary(self, snap: Snapshot) -> str:
        parts = []
        if snap.bands:
            freq = f" · {snap.freq_mhz:g} {t('МГц')}" if snap.freq_mhz else ""
            parts.append(f"B{snap.bands[0]}{freq}")
            if len(snap.bands) > 1:
                parts.append("CA " + "+".join(f"B{b}" for b in snap.bands[1:]))
        if snap.pci is not None:
            parts.append(f"PCI {snap.pci}")
        if snap.rat:
            parts.append(t(RAT_LABELS.get(snap.rat, snap.rat)))
        return " · ".join(parts) if parts else "—"

    def set_graph_param(self, param: str) -> None:
        self.state.set_trend_param(param)
        if self.state.last is not None:
            self._render(self.state.last)
        else:
            self.refresh_graph()

    def refresh_graph(self, stale: bool = False) -> None:
        param = self.state.trend_param
        values = list(self.state.history.get(param, []))
        peak = self.state.peaks.get(param)
        graph = self.sm.get_screen('monitor').ids.get('signal_graph')
        if graph is not None:
            graph.set_data(values, param, peak, stale)
        if self._fs_graph is not None:
            self._fs_graph.set_data(values, param, peak, stale)

    def reset_peaks(self) -> None:
        self.state.reset_peaks()
        if self.state.last is not None:
            self._render(self.state.last)
        self.toast(t("Пики сброшены"))

    # ---------- звук-парктроник ----------

    def toggle_sound(self) -> None:
        if not self.beeper.available:
            self.toast(t("Звук недоступен на этом устройстве"))
            return
        self.sound_on = not self.sound_on
        if self.sound_on:
            self._schedule_beep()
        else:
            self._stop_beeps()

    def _schedule_beep(self) -> None:
        self._stop_beeps()
        delta = self.state.delta_to_peak(self.state.trend_param)
        self._beep_ev = Clock.schedule_once(self._beep_tick, beep_interval(delta))

    def _beep_tick(self, _dt: float) -> None:
        self._beep_ev = None
        if not self.sound_on or self.link == 'offline':
            return
        # Во время переподключения молчим, но цикл не прерываем — иначе звук
        # не вернулся бы после перезагрузки роутера или обрыва Wi-Fi.
        if self.link == 'online' and not self.state.is_stale(time.monotonic(), self.interval):
            self.beeper.beep(50)
        self._schedule_beep()

    def _stop_beeps(self) -> None:
        if self._beep_ev is not None:
            self._beep_ev.cancel()
            self._beep_ev = None

    # ---------- меню и диалоги ----------

    def open_menu(self) -> None:
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.button import Button
        box = BoxLayout(orientation='vertical', spacing=dp(8), padding=dp(8))
        popup = Popup(title=t("Меню"), content=box, size_hint=(0.85, None), height=dp(470))
        sun = self.theme_name == 'sun'
        items = [
            (t("وزن الأنتينا"), lambda: self.go('monitor')),
            (t("القراءات"), lambda: (self.refresh_readings_screen(), self.go('readings'))),
            (t("ℹ Информация"), lambda: self.go('info')),
            (t("⚙ Сеть"), lambda: self.go('tools')),
            (t("☀ Солнце: выкл") if sun else t("☀ Солнце: вкл"),
             lambda: self.apply_theme('dark' if sun else 'sun')),
            (t("⏏ Отключиться"), self.confirm_disconnect),
        ]
        for text, action in items:
            btn = Button(text=text, font_size=sp(17), size_hint_y=None, height=dp(56))
            btn.bind(on_release=lambda _b, a=action: (popup.dismiss(), a()))
            box.add_widget(btn)
        popup.open()

    def confirm(self, title: str, message: str, yes_text: str,
                on_yes: Callable[[], None]) -> None:
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.button import Button
        from kivy.uix.label import Label
        content = BoxLayout(orientation='vertical', spacing=dp(10), padding=dp(10))
        msg = Label(text=message, halign='center', valign='middle', font_size=sp(15))
        msg.bind(size=lambda i, v: setattr(i, 'text_size', v))
        content.add_widget(msg)
        btns = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(10))
        popup = Popup(title=title, content=content, size_hint=(0.92, 0.55))
        no = Button(text=t("← Назад"), font_size=sp(16))
        yes = Button(text=yes_text, font_size=sp(16), background_color=(0.8, 0.4, 0.15, 1))
        no.bind(on_release=lambda *a: popup.dismiss())
        yes.bind(on_release=lambda *a: (popup.dismiss(), on_yes()))
        btns.add_widget(no)
        btns.add_widget(yes)
        content.add_widget(btns)
        popup.open()

    def confirm_disconnect(self) -> None:
        self.confirm(t("Подтверждение"), t("Отключиться от роутера?"),
                     t("Отключиться"), self.disconnect)

    def show_popup(self, title: str, message: str) -> None:
        from kivy.uix.label import Label
        from kivy.uix.scrollview import ScrollView
        lbl = Label(text=message, halign='left', valign='top', size_hint_y=None,
                    font_size=sp(14))
        lbl.bind(width=lambda i, w: setattr(i, 'text_size', (w, None)),
                 texture_size=lambda i, ts: setattr(i, 'height', ts[1]))
        sv = ScrollView()
        sv.add_widget(lbl)
        Popup(title=title, content=sv, size_hint=(0.92, 0.8)).open()

    def toast(self, text: str, seconds: float = 2.0) -> None:
        from kivy.core.window import Window
        from kivy.graphics import Color, RoundedRectangle
        from kivy.uix.label import Label
        lbl = Label(text=text, font_size=sp(15), size_hint=(None, None), color=(1, 1, 1, 1))
        lbl.texture_update()
        lbl.size = (lbl.texture_size[0] + dp(24), lbl.texture_size[1] + dp(16))
        lbl.pos = ((Window.width - lbl.width) / 2, dp(80))
        with lbl.canvas.before:
            Color(0, 0, 0, 0.8)
            RoundedRectangle(pos=lbl.pos, size=lbl.size, radius=[dp(8)])
        Window.add_widget(lbl)
        Clock.schedule_once(lambda dt: Window.remove_widget(lbl), seconds)

    def open_fullscreen_graph(self) -> None:
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.button import Button
        inner = BoxLayout(orientation='vertical', spacing=dp(6), padding=dp(8))
        graph = SignalGraph()
        close = Button(text=t("← Назад"), size_hint_y=None, height=dp(48))
        inner.add_widget(graph)
        inner.add_widget(close)
        self._fs_graph = graph
        popup = Popup(title='', separator_height=0, content=RotatedBox(inner),
                      size_hint=(0.98, 0.96))
        popup.bind(on_dismiss=lambda *a: setattr(self, '_fs_graph', None))
        close.bind(on_release=lambda *a: popup.dismiss())
        popup.open()
        self.refresh_graph()

    # ---------- экран «Информация» ----------

    _carrier_open: dict = {}

    def toggle_carriers(self, group: str) -> None:
        self._carrier_open = {**self._carrier_open, group: not self._carrier_open.get(group)}
        self.refresh_readings_screen()

    def refresh_readings_screen(self, snap: Snapshot | None = None) -> None:
        """Render modem-reported LTE/NR carriers as cards (primary first, then secondary)."""
        if not hasattr(self, 'sm') or 'readings' not in self.sm.screen_names:
            return
        snap = snap or self.state.last
        screen = self.sm.get_screen('readings')
        lte_box = screen.ids.get('lte_cards')
        nr_box = screen.ids.get('nr_cards')
        if lte_box is None or nr_box is None:
            return
        # Rebuild only when something shown actually changed: recreating every
        # card on each poll made scrolling stutter (display-only; no router I/O).
        raw_sig = dict(snap.raw or {}) if snap is not None else {}
        sig = (None if snap is None else tuple(
            getattr(snap, f, None) for f in (
                'rsrp', 'rsrq', 'sinr', 'rssi', 'pci', 'earfcn', 'dl_bandwidth',
                'nr_rsrp', 'nr_rsrq', 'nr_sinr', 'nr_pci', 'nr_arfcn', 'nr_bandwidth',
                'nr_band_label', 'band_label', 'band_raw', 'has_nr')),
            tuple(sorted((k, str(v)) for k, v in raw_sig.items() if k in (
                'cell_id', 'cellId', 'CellID', 'cellid', 'nr_cell_id', 'nrcellid',
                'nrCellId', 'nrpci', 'scc_pci', 'dlbandwidth', 'nrdlbandwidth',
                'bandInfo', 'band', 'lte_band', 'nr_band', 'nrBand'))),
            tuple(sorted(self._carrier_open.items())), t('رئيسي'), self.theme_name,
            tuple((c.arfcn, c.pci, c.rsrp, c.rsrq, c.sinr) for c in self._nbr_cells),
            tuple((k, c.arfcn, c.pci, c.rsrp, c.rsrq, c.sinr)
                  for k, cells in sorted(self._sec_cells.items()) for c in cells))
        if sig == getattr(self, '_readings_sig', None) and lte_box.children:
            return
        self._readings_sig = sig
        # Same cards, only new numbers: update them in place instead of rebuilding every widget
        # (rebuilding all carrier cards on each poll made the page heavy once secondary carriers
        # were expanded). The layout key lists everything that changes which widgets exist.
        nr_probe = bool(snap is not None and (snap.has_nr or snap.nr_pci is not None
                                              or snap.nr_rsrp is not None
                                              or raw_sig.get('nrpci') is not None
                                              or raw_sig.get('scc_pci') is not None))
        layout_key = (snap is None, None if snap is None else (snap.band_raw, snap.band_label,
                                                               snap.nr_band_label, nr_probe),
                      tuple(sorted(self._carrier_open.items())), t('رئيسي'), self.theme_name,
                      tuple(sorted((k, tuple(sorted(c.arfcn for c in cells if c.arfcn is not None)))
                                   for k, cells in self._sec_cells.items())),
                      tuple(sorted({c.arfcn for c in self._nbr_cells if c.arfcn is not None})))
        update = (snap is not None and layout_key == getattr(self, '_readings_layout', None)
                  and bool(getattr(self, '_reading_cards', None)) and bool(lte_box.children))
        self._readings_layout = layout_key
        cards_cache: list = getattr(self, '_reading_cards', []) if update else []
        cursor = [0]
        mismatch = [False]
        if not update:
            lte_box.clear_widgets()
            nr_box.clear_widgets()
            self._reading_cards = cards_cache = []
        if snap is None:
            lte_box.add_widget(Factory.HintLabel(text=t("لا توجد بيانات بعد. اتصل بالراوتر أولًا.")))
            nr_box.add_widget(Factory.HintLabel(text=t("لا توجد بيانات 5G بعد.")))
            screen.aggregation_text = '—'
            return

        green = (0.21, 0.82, 0.50, 1)
        yellow = (1.0, 0.83, 0.31, 1)
        red = (1.0, 0.36, 0.38, 1)
        grey = (0.48, 0.53, 0.60, 1)
        orange = (1.0, 0.62, 0.26, 1)
        if self.theme_name == 'sun':
            green, yellow, red, grey, orange = (self._sunny(c) for c in (green, yellow, red, grey, orange))

        def val(value: Any) -> str:
            return '—' if value is None or value == '' else str(value)

        def fact(label: str, value: Any) -> tuple[str, str]:
            return (label, val(value))

        def rate(metric: str, num: float) -> tuple[str, tuple]:
            good, mid = {'rsrp': (-90, -105), 'rsrq': (-10, -15), 'sinr': (20, 5)}[metric]
            if num >= good:
                return _shape_arabic_display('قوي'), green
            if num >= mid:
                return _shape_arabic_display('متوسط'), yellow
            return _shape_arabic_display('ضعيف'), red

        def tile(metric: str, value: Any, unit: str) -> dict[str, Any]:
            num = _to_float(value)
            if num is None:
                return dict(m_title=metric.upper(), m_num='—', m_unit='', m_rate=t("غير متوفر"),
                            tone=grey, pill_fill=(0.11, 0.14, 0.20, 1), pill_line=(0.16, 0.21, 0.28, 1))
            text, col = rate(metric, num)
            return dict(m_title=metric.upper(), m_num=f"{num:g}", m_unit=unit, m_rate=text,
                        tone=col, pill_fill=col[:3] + (0.16,), pill_line=col[:3] + (0.6,))

        def add_card(box: Any, *, band: str, primary: bool, sub: str,
                     metrics: tuple[Any, Any, Any], facts: list[tuple[str, str]]) -> None:
            if update:
                index = cursor[0]
                cursor[0] += 1
                card = cards_cache[index] if index < len(cards_cache) else None
                if (card is None or len(card._fact_cells) != len(facts)
                        or card._band_text != (band or '—')):
                    mismatch[0] = True
                    return
                card.sub = sub
                for cell, (label, value) in zip(card._fact_cells, facts):
                    cell.k, cell.v = label, value
                for widget, (metric, value, unit) in zip(
                        card._tile_widgets, (('rsrp', metrics[0], 'dBm'), ('rsrq', metrics[1], 'dB'),
                                             ('sinr', metrics[2], 'dB'))):
                    for key, new in tile(metric, value, unit).items():
                        setattr(widget, key, new)
                return
            is_nr = band.upper().startswith('N')
            bc = self._sunny((0.20, 0.86, 0.79, 1) if is_nr else (0.28, 0.73, 1, 1))
            rc = green if primary else orange
            card = _make_widget('CarrierCard', dict(
                band=band or '—', tech='NR' if is_nr else 'LTE', band_label=t('الباند'),
                band_size=sp(22 if primary else 19), band_color=bc,
                band_fill=bc[:3] + (0.18,), glow_soft=bc[:3] + ((0.45 if primary else 0.15),),
                role=t('رئيسي' if primary else 'ثانوي'), role_color=rc,
                role_fill=rc[:3] + (0.16,), frame=rc[:3] + (0.35,), sub=sub))
            card._fact_cells = []
            for label, value in facts:
                cell = _make_widget('FactCell', dict(k=label, v=value))
                card._fact_cells.append(cell)
                card.ids.facts_grid.add_widget(cell)
            tiles = card.ids.tiles
            card._tile_widgets = []
            for metric, value, unit in (('rsrp', metrics[0], 'dBm'), ('rsrq', metrics[1], 'dB'),
                                        ('sinr', metrics[2], 'dB')):
                tile_widget = _make_widget('ReadingTile', tile(metric, value, unit))
                card._tile_widgets.append(tile_widget)
                tiles.add_widget(tile_widget)
            card._band_text = band or '—'
            cards_cache.append(card)
            box.add_widget(card)

        def sec_cell(kind: str, channel: str) -> Any:
            """The router's own aggregated-carrier entry (device/seccellinfo) for this channel."""
            if not str(channel).isdigit():
                return None
            for c in self._sec_cells.get(kind, []):
                if c.arfcn == int(channel):
                    return c
            return None

        def measured(kind: str, channel: str) -> tuple[Any, Any, Any] | None:
            """Secondary-carrier readings: first the router's own carrier list, else (LTE only)
            a nearby cell on the same channel and the same PCI as the serving cell."""
            own = sec_cell(kind, channel)
            if own is not None:
                return (own.rsrp, own.rsrq, own.sinr)
            if kind != 'lte' or snap.pci is None or not str(channel).isdigit():
                return None
            for c in self._nbr_cells:
                if c.arfcn == int(channel) and c.pci == snap.pci:
                    return (c.rsrp, c.rsrq, c.sinr)
            return None

        def add_group(box: Any, group: str, secondary: list[tuple[str, str, str]],
                      channel_label: str) -> None:
            """Secondary carriers appear only if the router reported them: a small
            arrow under the primary card expands/collapses them."""
            if not secondary:
                return
            expanded = bool(self._carrier_open.get(group))
            if not update:
                box.add_widget(_make_widget('ToggleArrow', dict(group=group, expanded=expanded)))
            if not expanded:
                return
            for n, (width, channel, band) in enumerate(secondary, 1):
                found = measured(group, channel)
                own = sec_cell(group, channel)
                sub = f"{t('حامل ثانوي')} {n}"
                if found is not None:
                    sub += f" · {t('من الراوتر') if own is not None else t('من قائمة الخلايا')}"
                facts_row = [fact(t('العرض'), width), fact(channel_label, channel)]
                if own is not None:
                    facts_row.insert(1, fact('PCI', own.pci))
                add_card(box, band=band, primary=False, sub=sub,
                         metrics=found or (None, None, None), facts=facts_row)

        # Band names come from modem data only; never from raw strings with quotes.
        raw = dict(snap.raw or {})
        lte_band = str(snap.band_label or '').strip().upper()
        if not re.fullmatch(r'B\d+', lte_band):
            lte_band = ''
            for candidate in (raw.get('bandInfo'), raw.get('band'), raw.get('lte_band'), snap.band_raw):
                match = re.search(r'(?<![A-Z0-9])B\d+(?![A-Z0-9])', str(candidate or ''), re.IGNORECASE)
                if match:
                    lte_band = match.group(0).upper()
                    break
        if not lte_band and snap.bands:
            lte_band = f'B{snap.bands[0]}'

        nr_band = str(snap.nr_band_label or '').strip().upper()
        if not re.fullmatch(r'N\d+', nr_band):
            nr_band = ''
            for candidate in (raw.get('nr_band'), raw.get('nrBand'), snap.band_raw, raw.get('bandInfo')):
                match = re.search(r'(?<![A-Z0-9])N\d+(?![A-Z0-9])', str(candidate or ''), re.IGNORECASE)
                if match:
                    nr_band = match.group(0).upper()
                    break

        carriers = [(w.strip(), ch, b.upper()) for w, ch, b in re.findall(
            r'([0-9.]+\s*MHz)\s*@\s*(\d+)\s*\((B\d+|N\d+)\)', snap.band_raw or '', re.IGNORECASE)]
        if not carriers:
            carriers = [('', '', b.upper()) for b in re.findall(
                r'\((B\d+|N\d+)\)', snap.band_raw or '', re.IGNORECASE)]

        if not carriers:
            # Some firmwares report aggregation only as a list of band names
            # ("B1+B3", "N78 N41"): take the first reported field that has any.
            for source in (snap.band_raw, raw.get('bandInfo'), raw.get('band')):
                found = re.findall(r'(?<![A-Z0-9])([BN]\d+)(?![A-Z0-9])', str(source or ''), re.IGNORECASE)
                if found:
                    carriers = [('', '', b.upper()) for b in found]
                    break

        def split_secondary(kind: str, primary_band: str) -> list[tuple[str, str, str]]:
            """Carriers of one technology minus ONE occurrence of the primary band
            (duplicate bands are separate component carriers and are kept)."""
            result, skipped = [], False
            for width, channel, band in carriers:
                if not band.startswith(kind):
                    continue
                if not skipped and band == primary_band:
                    skipped = True
                    continue
                result.append((width, channel, band))
            return result

        cell_id = raw.get('cell_id') or raw.get('cellId') or raw.get('CellID') or raw.get('cellid')
        add_card(lte_box, band=lte_band, primary=True, sub=t("الحامل الرئيسي"),
                 metrics=(snap.rsrp, snap.rsrq, snap.sinr),
                 facts=[fact(t('معرّف الخلية'), cell_id), fact('RSSI', snap.rssi),
                        fact('PCI', snap.pci), fact('EARFCN', snap.earfcn),
                        fact(t('العرض'), snap.dl_bandwidth or raw.get('dlbandwidth'))])
        lte_secondary = split_secondary('B', lte_band)
        add_group(lte_box, 'lte', lte_secondary, 'EARFCN')

        nr_pci = snap.nr_pci if snap.nr_pci is not None else raw.get('nrpci', raw.get('scc_pci'))
        nr_cell = raw.get('nr_cell_id') or raw.get('nrcellid') or raw.get('nrCellId')
        nr_active = bool(snap.has_nr or nr_pci is not None or snap.nr_rsrp is not None)
        nr_secondary: list[tuple[str, str, str]] = []
        if nr_active:
            add_card(nr_box, band=nr_band, primary=True, sub=t("الحامل الرئيسي"),
                     metrics=(snap.nr_rsrp, snap.nr_rsrq, snap.nr_sinr),
                     facts=[fact(t('معرّف الخلية'), nr_cell), fact('PCI', nr_pci),
                            fact('NR-ARFCN', snap.nr_arfcn),
                            fact(t('العرض'), snap.nr_bandwidth or raw.get('nrdlbandwidth'))])
            nr_secondary = split_secondary('N', nr_band)
            add_group(nr_box, 'nr', nr_secondary, 'NR-ARFCN')
        elif not update:
            nr_box.add_widget(Factory.HintLabel(text=t("اتصال 5G غير ظاهر حاليًا.")))

        if update and mismatch[0]:          # the cards no longer match: rebuild them once
            self._readings_sig = None
            self._readings_layout = None
            self.refresh_readings_screen(snap)
            return

        # Aggregation: primary carriers on top, secondary below.
        agg_wrap = screen.ids.get('agg_wrap')
        agg_card = screen.ids.get('agg_card')
        has_aggregation = bool(lte_secondary or nr_secondary)
        if agg_wrap is not None and agg_card is not None:
            if has_aggregation and agg_card.parent is None:
                agg_wrap.add_widget(agg_card)
            elif not has_aggregation and agg_card.parent is not None:
                agg_wrap.remove_widget(agg_card)
        if not has_aggregation:
            screen.aggregation_text = ''
            return
        mains = [b for b in (lte_band, nr_band if nr_active else '') if b]
        subs = [b for _w, _c, b in lte_secondary + nr_secondary]
        subs.sort(key=lambda b: (b.startswith('N'), int(b[1:])))
        lines = []
        if mains:
            lines.append('[b][color=35D07F]' + t('رئيسي') + '[/color][/b]')
            lines.append('[b][size=21sp][color=35D07F]' + '  +  '.join(mains) + '[/color][/size][/b]')
        if subs:
            lines.append('[b][color=FF9F43]' + t('ثانوي') + '[/color][/b]')
            lines.append('[b][size=19sp][color=FF9F43]' + '  +  '.join(subs) + '[/color][/size][/b]')
        screen.aggregation_text = '\n'.join(lines)

    # ---------- экран «Cells» ----------

    _cell_rows: list = []
    _cell_scan_serial = 0
    _nbr_cells: list = []
    _sec_cells: dict = {}
    _nbr_busy = False

    def _refresh_nbr_cache(self, *_args: Any) -> None:
        """While the readings page is open: re-read the router's nearby-cell list
        (read-only, every 15 s) so secondary carriers can show its measurements."""
        session = self.session
        if (self.sm.current != 'readings' or session is None or self.link != 'online'
                or self._nbr_busy):
            return
        self._nbr_busy = True

        def work() -> tuple[list, dict]:
            try:
                cells = parse_nbrcell_response(session.read_neighbor_cells_raw())
            except Exception:
                cells = []
            secondary: dict = {}
            reader = getattr(session, 'read_secondary_cells_raw', None)
            if reader is not None:                 # Huawei only; read-only GET
                try:
                    secondary = parse_seccell_response(reader())
                except Exception:
                    logger.debug("device/seccellinfo unavailable", exc_info=True)
            return cells, secondary

        def done(result: tuple[list, dict]) -> None:
            self._nbr_busy = False
            self._nbr_cells, self._sec_cells = result
            self.refresh_readings_screen()

        def fail(_exc: BaseException) -> None:
            self._nbr_busy = False

        self._run_bg(work, done, fail)

    def _sunny(self, color: Any) -> tuple:
        """Bright dark-mode colours become darker in the Sun theme so they stay readable on light cards."""
        rgba = tuple(color)
        if self.theme_name != 'sun':
            return rgba
        return (rgba[0] * 0.62, rgba[1] * 0.62, rgba[2] * 0.62, rgba[3] if len(rgba) > 3 else 1)

    @staticmethod
    def _signal_rgba(metric: str, value: float | None) -> tuple:
        if value is None:
            return (0.62, 0.68, 0.74, 1)
        good, mid = {'rsrp': (-90, -105), 'rsrq': (-10, -15)}[metric]
        if value >= good:
            return (0.21, 0.82, 0.50, 1)
        return (1.0, 0.83, 0.31, 1) if value >= mid else (1.0, 0.36, 0.38, 1)

    def _cell_card_props(self, *, band: str | None, pci: Any, arfcn: Any, arfcn_name: str,
                         rsrp: float | None, rsrq: float | None, sinr: float | None,
                         tag: str, index: int, current: bool) -> dict[str, Any]:
        na = t("غير متوفر")
        def fmt(v: float | None, unit: str) -> str:
            return na if v is None else f"{v:g} {unit}"
        is_nr = (band or '').upper().startswith('N')
        bars = 0
        if rsrp is not None:
            bars = 4 if rsrp >= -90 else 3 if rsrp >= -100 else 2 if rsrp >= -108 else 1
        return dict(
            band=band or '—',
            title=f"PCI {pci if pci is not None else '—'}  ·  {arfcn_name} {arfcn if arfcn is not None else '—'}",
            sub=tag, rsrp=fmt(rsrp, 'dBm'), rsrq=fmt(rsrq, 'dB'), sinr=fmt(sinr, 'dB'),
            bars=bars,
            band_color=self._sunny((0.20, 0.86, 0.79, 1) if is_nr else (0.28, 0.73, 1, 1)),
            band_fill=(0.20, 0.86, 0.79, 0.18) if is_nr else (0.28, 0.73, 1, 0.18),
            signal_color=self._sunny(self._signal_rgba('rsrp', rsrp)),
            rsrp_color=self._sunny(self._signal_rgba('rsrp', rsrp)),
            rsrq_color=self._sunny(self._signal_rgba('rsrq', rsrq)),
            status_text=t("متصل حاليًا بهذه الخلية") if current else '',
            show_button=not current, cell_index=index)

    def refresh_cells_screen(self, rescan: bool = False) -> None:
        if 'cells' not in self.sm.screen_names:
            return
        screen = self.sm.get_screen('cells')
        box = screen.ids.get('cells_box')
        if box is None:
            return
        if screen.source == 'phone':
            self._refresh_phone_cells(screen, box)
            return
        snap = self.state.last
        session = self.session
        self._cell_scan_serial += 1
        serial = self._cell_scan_serial

        def render(neighbors: list[NeighborCell] | None, note: str) -> None:
            if serial != self._cell_scan_serial:
                return
            box.clear_widgets()
            self._cell_rows = []
            cards: list[dict[str, Any]] = []
            if snap is not None:
                # band_label may be a long text such as "B1 (2100 MHz)": keep only "B1".
                m_band = re.search(r'(?<![A-Z0-9])B\d+(?![A-Z0-9])', str(snap.band_label or ''), re.IGNORECASE)
                lte_band = m_band.group(0).upper() if m_band else (band_from_earfcn(snap.earfcn) or None)
                cards.append(self._cell_card_props(
                    band=lte_band, pci=snap.pci, arfcn=snap.earfcn, arfcn_name='EARFCN',
                    rsrp=_to_float(snap.rsrp), rsrq=_to_float(snap.rsrq), sinr=_to_float(snap.sinr),
                    tag=t("الخلية الحالية"), index=-1, current=True))
                if snap.has_nr:
                    cards.append(self._cell_card_props(
                        band=(snap.nr_band_label or '').upper() or None, pci=snap.nr_pci,
                        arfcn=snap.nr_arfcn, arfcn_name='NR-ARFCN',
                        rsrp=_to_float(snap.nr_rsrp), rsrq=_to_float(snap.nr_rsrq),
                        sinr=_to_float(snap.nr_sinr), tag=t("خلية 5G الحالية"),
                        index=-1, current=True))
            for cell in neighbors or []:
                if snap is not None and cell.pci == snap.pci and cell.arfcn == snap.earfcn:
                    continue                      # already shown as the current cell
                self._cell_rows.append(cell)
                cards.append(self._cell_card_props(
                    band=cell.band, pci=cell.pci, arfcn=cell.arfcn,
                    arfcn_name='NR-ARFCN' if (cell.band or '').startswith('N') else 'EARFCN',
                    rsrp=cell.rsrp, rsrq=cell.rsrq, sinr=cell.sinr,
                    tag=t("خلية مجاورة"), index=len(self._cell_rows) - 1, current=False))
            for props in cards:
                box.add_widget(_make_widget('CellCard', props))
            hint = Factory.HintLabel(text=note)
            box.add_widget(hint)
            screen.scan_info = t("آخر مسح: {time}").format(time=time.strftime('%H:%M:%S')) \
                if neighbors is not None else ''

        if session is None or self.link != 'online':
            render(None, t("اتصل بالراوتر أولًا لقراءة الخلايا."))
            return
        if not rescan and self._cell_rows:
            return
        screen.scan_info = t("جارٍ المسح…")

        def work() -> list[NeighborCell]:
            cells: list[NeighborCell] = []
            try:                                   # router's own cell-info page source
                cells = parse_nbrcell_response(session.read_neighbor_cells_raw())
            except Exception:
                logger.debug("device/nbrcellinfo unavailable", exc_info=True)
            if not cells:
                cells = parse_cell_info(session.read_cell_info())
            return cells

        def done(cells: list[NeighborCell]) -> None:
            note = (t("تعرض الصفحة ما يرجعه الراوتر فقط.") if cells
                    else t("الراوتر لم يعرض خلايا مجاورة (غير متوفر)."))
            render(cells, note)

        def fail(exc: BaseException) -> None:
            render(None, t("الراوتر لم يعرض خلايا مجاورة (غير متوفر)."))

        self._run_bg(work, done, fail)

    def set_cells_source(self, source: str) -> None:
        screen = self.sm.get_screen('cells')
        screen.source = source
        self.refresh_cells_screen(rescan=True)

    def _refresh_phone_cells(self, screen: Any, box: Any) -> None:
        """Cells seen by the phone's own modem (read-only, Android permissions)."""
        self._cell_scan_serial += 1
        serial = self._cell_scan_serial
        self._cell_rows = []
        box.clear_widgets()
        if platform != 'android':
            box.add_widget(Factory.HintLabel(text=t("قراءة الجوال متاحة على أندرويد فقط.")))
            screen.scan_info = ''
            return
        try:
            from android.permissions import Permission, check_permission, request_permissions  # type: ignore
            needed = [Permission.ACCESS_FINE_LOCATION, Permission.ACCESS_COARSE_LOCATION,
                      Permission.READ_PHONE_STATE]
            if not check_permission(Permission.ACCESS_FINE_LOCATION):
                request_permissions(needed, lambda *_a: Clock.schedule_once(
                    lambda _dt: self.refresh_cells_screen(rescan=True), 0.5))
                box.add_widget(Factory.HintLabel(
                    text=t("اسمح بالموقع «الدقيق» (Precise) وحالة الهاتف ليقرأ التطبيق الأبراج التي يراها الجوال، ثم اضغط «مسح الآن».")))
                screen.scan_info = ''
                return
        except Exception:
            logger.debug("permission check failed", exc_info=True)
        screen.scan_info = t("جارٍ المسح…")

        def work() -> list:
            from core.phone_cells import read_phone_cells
            return read_phone_cells()

        def render(cells: list, note: str) -> None:
            if serial != self._cell_scan_serial or screen.source != 'phone':
                return
            box.clear_widgets()
            order = sorted(cells, key=lambda c: (not c.registered, c.tech != 'NR', -(c.rsrp or -999)))
            for c in order:
                props = self._cell_card_props(
                    band=c.band, pci=c.pci, arfcn=c.arfcn,
                    arfcn_name='NR-ARFCN' if c.tech == 'NR' else 'EARFCN',
                    rsrp=c.rsrp, rsrq=c.rsrq, sinr=c.sinr,
                    tag=t("خلية الجوال المتصل بها") if c.registered else t("خلية مجاورة (من الجوال)"),
                    index=-1, current=False)
                props['show_button'] = False
                props['status_text'] = ''
                box.add_widget(_make_widget('CellCard', props))
            box.add_widget(Factory.HintLabel(text=note))
            screen.scan_info = t("آخر مسح: {time}").format(time=time.strftime('%H:%M:%S'))

        def done(cells: list) -> None:
            note = t("هذه قراءات مودم الجوال نفسه وليست قراءات الراوتر.") if cells \
                else t("الجوال لم يعرض خلايا (غير متوفر).")
            render(cells, note)

        def fail(exc: BaseException) -> None:
            render([], f"{t('تعذرت قراءة الجوال')}: {humanize_error(exc)}")

        self._run_bg(work, done, fail)

    # ---- Internet speed test ----------------------------------------------------
    _speed_running = False

    _NET_NAMES = {'wifi': "واي فاي - الراوتر", 'ethernet': "كابل - الراوتر",
                  'cellular': "بيانات الجوال", 'vpn': "VPN (قد يبطئ القياس)"}

    def _speed_net_label(self, kind: str | None) -> tuple[str, tuple]:
        if kind in ('wifi', 'ethernet'):
            return t(self._NET_NAMES[kind]), self._sunny((0.21, 0.82, 0.50, 1))
        if kind == 'cellular':
            return t(self._NET_NAMES[kind]), self._sunny((0.28, 0.73, 1, 1))
        if kind == 'vpn':
            return t(self._NET_NAMES[kind]), self._sunny((1.0, 0.62, 0.26, 1))
        return t("الشبكة غير معروفة"), (0.6, 0.68, 0.78, 1)

    def _speed_history(self) -> dict[str, Any]:
        try:
            return dict(self._speed_store.get('last')) if self._speed_store.exists('last') else {}
        except Exception:
            return {}

    def _render_speed_history(self, screen: Any) -> None:
        hist = self._speed_history()

        def line(entry: Any) -> str:
            if not entry:
                return t("لم يُقَس بعد")
            up = '—' if entry.get('up') is None else f"{entry['up']:g}"
            return f"{entry['down']:g} \u2193    {up} \u2191"
        screen.hist_router_vals = line(hist.get('router'))
        screen.hist_phone_vals = line(hist.get('phone'))

    def prepare_speed_screen(self) -> None:
        screen = self.sm.get_screen('speed')
        if screen.busy:
            return
        from core.speed_test import active_network_kind
        kind = active_network_kind() if platform == 'android' else None
        screen.net_text, screen.net_color = self._speed_net_label(kind)
        if not screen.phase_text:
            screen.phase_text = t("جاهز")
        self._render_speed_history(screen)

    def run_speed_test(self) -> None:
        if self._speed_running:
            return
        from core.speed_test import active_network_kind
        kind = active_network_kind() if platform == 'android' else None
        if kind == 'cellular':
            self.confirm(t("القياس على بيانات الجوال"),
                         t("سيستهلك الفحص نحو 40 ميغابايت من باقة بيانات الجوال."),
                         t("ابدأ"), lambda: self._start_speed(kind))
            return
        self._start_speed(kind)

    def _start_speed(self, kind: str | None) -> None:
        """Ping first (recorded), then download (dial back to zero), then upload (back to zero)."""
        from core.speed_test import run_speed_test as measure
        screen = self.sm.get_screen('speed')
        gauge = screen.ids.get('gauge')
        self._speed_running = True
        screen.busy = True
        screen.net_text, screen.net_color = self._speed_net_label(kind)
        screen.big_value, screen.gauge_unit = '0', 'ms'
        screen.down_text = screen.up_text = screen.latency_text = screen.used_text = '—'
        screen.gauge_title = t("زمن الاستجابة")
        screen.phase_text = t("جارٍ قياس زمن الاستجابة…")
        set_keep_screen_on(True)

        def to_gauge(value: float) -> None:
            if gauge is None:
                return
            from kivy.animation import Animation
            Animation.cancel_all(gauge, 'value')
            Animation(value=value, d=0.35, t='out_quad').start(gauge)

        def on_progress(phase: str, value: float, fraction: float) -> None:
            def apply(_dt: float) -> None:
                if phase == 'latency':
                    screen.big_value = f"{value:.0f}"
                    return
                screen.big_value = f"{value:.1f}"
                to_gauge(value)
                label = "جارٍ قياس التحميل…" if phase == 'download' else "جارٍ قياس الرفع…"
                screen.phase_text = t(label) + f" {int(fraction * 100)}%"
            Clock.schedule_once(apply)

        def on_result(phase: str, value: float | None) -> None:
            def apply(_dt: float) -> None:
                shown = '—' if value is None else (f"{value:.0f}" if phase == 'latency' else f"{value:g}")
                if phase == 'latency':
                    screen.latency_text = shown
                    screen.big_value, screen.gauge_unit = '0', 'Mbps'
                    screen.gauge_title = t("التحميل")
                    screen.phase_text = t("جارٍ قياس التحميل…")
                elif phase == 'download':
                    screen.down_text = shown
                    screen.big_value = '0'
                    to_gauge(0.0)                       # back to zero before the upload
                    screen.gauge_title = t("الرفع")
                    screen.phase_text = t("جارٍ قياس الرفع…")
                else:
                    screen.up_text = shown
                    screen.big_value = '0'
                    to_gauge(0.0)
            Clock.schedule_once(apply)

        def work() -> Any:
            return measure(cellular=(kind == 'cellular'), progress=on_progress, on_result=on_result)

        def finish() -> None:
            screen.busy = False
            self._speed_running = False
            if self.worker is None:
                set_keep_screen_on(False)

        def done(result: Any) -> None:
            finish()
            screen.down_text = f"{result.download_mbps:g}"
            screen.up_text = '—' if result.upload_mbps is None else f"{result.upload_mbps:g}"
            screen.latency_text = '—' if result.latency_ms is None else f"{result.latency_ms:.0f}"
            screen.used_text = f"{result.bytes_used / 1e6:.0f}"
            screen.big_value, screen.gauge_unit = '0', 'Mbps'
            screen.gauge_title = t("السرعة")
            to_gauge(0.0)
            screen.phase_text = t("اكتمل القياس") + " - " + time.strftime('%H:%M')
            entry = {'down': result.download_mbps, 'up': result.upload_mbps,
                     'lat': result.latency_ms, 'time': time.strftime('%H:%M')}
            slot = 'phone' if kind == 'cellular' else 'router' if kind in ('wifi', 'ethernet') else None
            if slot is not None:
                try:
                    hist = self._speed_history()
                    hist[slot] = entry
                    self._speed_store.put('last', **hist)
                except Exception:
                    logger.exception("Could not save the speed result")
            self._render_speed_history(screen)

        def fail(exc: BaseException) -> None:
            finish()
            screen.gauge_title, screen.gauge_unit, screen.big_value = t("السرعة"), 'Mbps', '0'
            screen.phase_text = t("تعذر القياس. تأكد من وجود إنترنت على هذه الشبكة.")
            to_gauge(0.0)
            self.toast(f"{t('تعذر الاتصال بخادم القياس')}: {humanize_error(exc)}", 5)

        self._run_bg(work, done, fail)

    # ---- Phone-only readings (no router) --------------------------------------
    _phone_ev: Any = None
    _phone_serial = 0
    _phone_reading = False
    _phone_perm_asked = False
    _phone_sig: Any = None

    def open_phone_screen(self) -> None:
        self.go('phone')

    def start_phone_live(self) -> None:
        self.stop_phone_live()
        self._phone_sig = None
        self._phone_main = None
        self._phone_ev = Clock.schedule_interval(lambda _dt: self.refresh_phone_screen(), 3.0)
        set_keep_screen_on(True)            # the installer watches the numbers while aiming
        self.refresh_phone_screen(force=True)

    def stop_phone_live(self) -> None:
        if self._phone_ev is not None:
            self._phone_ev.cancel()
            self._phone_ev = None
        self._phone_serial += 1
        if self.worker is None:
            set_keep_screen_on(False)

    _phone_main: Any = None

    def _render_phone_main(self, box: Any, main: list, operator: str | None) -> None:
        """The cells the phone is registered on, as the same small carrier cards the router
        readings page uses. Same cells as last time: only the numbers are updated."""
        green = self._sunny((0.21, 0.82, 0.50, 1))
        yellow = self._sunny((1.0, 0.83, 0.31, 1))
        red = self._sunny((1.0, 0.36, 0.38, 1))
        grey = self._sunny((0.48, 0.53, 0.60, 1))

        def tile(metric: str, value: float | None, unit: str) -> dict[str, Any]:
            if value is None:
                return dict(m_title=metric.upper(), m_num='-', m_unit='', m_rate=t("غير متوفر"),
                            tone=grey, pill_fill=(0.11, 0.14, 0.20, 1), pill_line=(0.16, 0.21, 0.28, 1))
            good, mid = {'rsrp': (-90, -105), 'rsrq': (-10, -15), 'sinr': (20, 5)}[metric]
            word, col = ((_shape_arabic_display('قوي'), green) if value >= good else
                         (_shape_arabic_display('متوسط'), yellow) if value >= mid else
                         (_shape_arabic_display('ضعيف'), red))
            return dict(m_title=metric.upper(), m_num=f"{value:g}", m_unit=unit, m_rate=word,
                        tone=col, pill_fill=col[:3] + (0.16,), pill_line=col[:3] + (0.6,))

        key = (tuple((c.tech, c.band, c.pci, c.arfcn) for c in main), self.theme_name, operator)
        sub = t("من الجوال") + (f" - {_shape_arabic(operator)}" if operator else "")
        if self._phone_main is not None and self._phone_main[0] == key and box.children:
            for c, card in zip(main, self._phone_main[1]):
                for widget, (metric, value, unit) in zip(
                        card._tile_widgets, (('rsrp', c.rsrp, 'dBm'), ('rsrq', c.rsrq, 'dB'),
                                             ('sinr', c.sinr, 'dB'))):
                    for k, new in tile(metric, value, unit).items():
                        setattr(widget, k, new)
            return
        box.clear_widgets()
        cards: list = []
        if not main:
            box.add_widget(Factory.HintLabel(
                text=t("لا توجد خلية متصل بها الآن (غير متوفر). تأكد من الشريحة والتغطية.")))
        seen: dict[str, int] = {}
        for c in main:
            is_nr = c.tech == 'NR'
            n = seen.get(c.tech, 0)             # 4G and 5G are separate networks: each has its own main cell
            seen[c.tech] = n + 1
            bc = self._sunny((0.20, 0.86, 0.79, 1) if is_nr else (0.28, 0.73, 1, 1))
            rc = green if n == 0 else self._sunny((1.0, 0.62, 0.26, 1))
            card = _make_widget('CarrierCard', dict(
                band=c.band or 'N/A', tech='NR' if is_nr else 'LTE', band_label=t('الباند'),
                band_size=sp(22 if c.band else 17), band_color=bc, band_fill=bc[:3] + (0.18,),
                glow_soft=bc[:3] + (0.45,), role=t('رئيسي' if n == 0 else 'ثانوي'),
                role_color=rc, role_fill=rc[:3] + (0.16,), frame=rc[:3] + (0.35,),
                sub=f"{'5G' if is_nr else '4G'} - {sub}"))
            na = t("غير متوفر")
            card._fact_cells = []
            for label, value in (('PCI', c.pci), ('NR-ARFCN' if is_nr else 'EARFCN', c.arfcn)):
                cell = _make_widget('FactCell', dict(k=label, v=na if value is None else str(value)))
                card._fact_cells.append(cell)
                card.ids.facts_grid.add_widget(cell)
            card._tile_widgets = []
            for metric, value, unit in (('rsrp', c.rsrp, 'dBm'), ('rsrq', c.rsrq, 'dB'),
                                        ('sinr', c.sinr, 'dB')):
                widget = _make_widget('ReadingTile', tile(metric, value, unit))
                card._tile_widgets.append(widget)
                card.ids.tiles.add_widget(widget)
            cards.append(card)
            box.add_widget(card)
        self._phone_main = (key, cards)

    def phone_diagnostics(self) -> None:
        """Explain why the phone shows no cells: permissions, location switch, SIM and what the
        modem returned. Copied to the clipboard and shown; nothing is sent anywhere."""
        if platform != 'android':
            self.toast(t("قراءة الجوال متاحة على أندرويد فقط."), 3)
            return

        def work() -> str:
            from core.phone_cells import phone_report
            return phone_report()

        def done(text: str) -> None:
            try:
                from kivy.core.clipboard import Clipboard
                Clipboard.copy(text)
                self.toast(t("نُسخ التشخيص إلى الحافظة. الصقه في المحادثة."), 4)
            except Exception:
                logger.debug("clipboard failed", exc_info=True)
            self.show_popup(t("تشخيص الجوال"), text[:6000])

        def fail(exc: BaseException) -> None:
            self.toast(humanize_error(exc), 5)

        self._run_bg(work, done, fail)

    def refresh_phone_screen(self, force: bool = False) -> None:
        if 'phone' not in self.sm.screen_names or self.sm.current != 'phone':
            return
        screen = self.sm.get_screen('phone')
        box = screen.ids.get('cells_box')
        main_box = screen.ids.get('main_box')
        if box is None or main_box is None:
            return
        if platform != 'android':
            box.clear_widgets()
            box.add_widget(Factory.HintLabel(text=t("قراءة الجوال متاحة على أندرويد فقط.")))
            return
        try:
            from android.permissions import Permission, check_permission, request_permissions  # type: ignore
            needed = [Permission.ACCESS_FINE_LOCATION, Permission.ACCESS_COARSE_LOCATION,
                      Permission.READ_PHONE_STATE]
            if not check_permission(Permission.ACCESS_FINE_LOCATION):
                main_box.clear_widgets()
                self._phone_main = None
                box.clear_widgets()
                box.add_widget(Factory.HintLabel(
                    text=t("اسمح بالموقع «الدقيق» (Precise) وحالة الهاتف ليقرأ التطبيق الأبراج التي يراها الجوال، ثم اضغط «مسح الآن».")))
                if force or not self._phone_perm_asked:
                    self._phone_perm_asked = True
                    request_permissions(needed, lambda *_a: Clock.schedule_once(
                        lambda _dt: self.refresh_phone_screen(force=True), 0.5))
                return
        except Exception:
            logger.debug("permission check failed", exc_info=True)
        if self._phone_reading:
            return
        self._phone_reading = True
        serial = self._phone_serial

        def work() -> tuple:
            from core.phone_cells import phone_blockers, read_phone_cells, read_phone_operator
            cells = read_phone_cells()
            return cells, read_phone_operator(), ([] if cells else phone_blockers())

        def render(cells: list, operator: str | None, note: str) -> None:
            if serial != self._phone_serial or self.sm.current != 'phone':
                return
            from core.phone_cells import main_cells
            screen.scan_info = t("آخر مسح: {time}").format(time=time.strftime('%H:%M:%S'))
            main = main_cells(cells)
            nearby = [c for c in cells if not c.registered]
            self._render_phone_main(main_box, main, operator)
            sig = tuple((c.tech, c.band, c.pci, c.arfcn, c.rsrp, c.rsrq, c.sinr) for c in nearby)
            if sig == self._phone_sig and not force and box.children:
                return                      # nothing changed: keep the cards as they are
            self._phone_sig = sig
            box.clear_widgets()
            order = sorted(nearby, key=lambda c: (c.tech != 'NR', -(c.rsrp or -999)))
            for c in order:
                props = self._cell_card_props(
                    band=c.band, pci=c.pci, arfcn=c.arfcn,
                    arfcn_name='NR-ARFCN' if c.tech == 'NR' else 'EARFCN',
                    rsrp=c.rsrp, rsrq=c.rsrq, sinr=c.sinr,
                    tag=t("خلية مجاورة (من الجوال)"), index=-1, current=False)
                props['show_button'] = False
                props['status_text'] = ''
                box.add_widget(_make_widget('CellCard', props))
            if not order:
                box.add_widget(Factory.HintLabel(text=t("لا توجد خلايا مجاورة معروضة.")))
            diag = _make_widget('FlatButton', dict(text=t("تشخيص الجوال (نسخ)"),
                                                   size_hint_y=None, height=dp(44)))
            diag.bind(on_release=lambda *_a: self.phone_diagnostics())
            box.add_widget(diag)
            box.add_widget(Factory.HintLabel(text=note))

        def done(result: tuple) -> None:
            self._phone_reading = False
            from core.phone_cells import is_signal_only
            cells, operator, blockers = result
            reasons = {
                'location_off': t("مفتاح الموقع (GPS) مطفأ: شغّله من إعدادات الجوال."),
                'no_sim': t("لا توجد شريحة جاهزة في الجوال."),
            }
            if cells and all(is_signal_only(c) for c in cells):
                note = t("مودم الجوال لم يعرض الباند والتردد وPCI، فتظهر قوة الإشارة فقط. "
                         "اضغط «تشخيص الجوال» وأرسل لي النص.")
            elif any(is_signal_only(c) for c in cells):
                note = t("5G: يعرض أندرويد قوة الإشارة فقط (الباند والتردد وPCI غير متاحة "
                         "للتطبيقات في هذا الجوال).")
            elif cells:
                note = t("هذه قراءات مودم الجوال نفسه. قد يحدّثها أندرويد كل بضع ثوانٍ فقط.")
            else:
                why = " ".join(reasons[b] for b in blockers if b in reasons)
                note = (why + " " if why else "") + t(
                    "الجوال لم يعرض خلايا (غير متوفر). اضغط «تشخيص الجوال» وأرسل لي النص.")
            render(cells, operator, note)

        def fail(exc: BaseException) -> None:
            self._phone_reading = False
            render([], None, f"{t('تعذرت قراءة الجوال')}: {humanize_error(exc)}")

        self._run_bg(work, done, fail)

    def cell_connect(self, index: int) -> None:
        """Lock the router to the chosen LTE cell (NSA: the current 5G cell is kept).

        Sends the router's own ``net/lock-freq`` request only after a confirmation
        dialog; nothing is sent when any required value is missing."""
        from core.cell_lock import build_request, make_target
        cell = self._cell_rows[index] if 0 <= index < len(self._cell_rows) else None
        snap, session = self.state.last, self.session
        if session is None or self.link != 'online' or snap is None:
            self.toast(t("اتصل بالراوتر أولًا لقراءة الخلايا."), 3.5)
            return
        if cell is None or (cell.band or '').upper().startswith('N'):
            self.toast(t("قفل الخلية مدعوم لخلايا 4G فقط حاليًا."), 4)
            return
        lte = make_target(cell.band, cell.arfcn, cell.pci)
        if lte is None:
            self.toast(t("بيانات الخلية ناقصة (الباند أو التردد أو PCI)؛ لم يُرسل شيء."), 4.5)
            return
        if self._busy:
            return
        lines = [
            t("سيُرسل أمر قفل 4G إلى الراوتر:"),
            f"4G:  B{lte.band}  ·  EARFCN {lte.freq}  ·  PCI {lte.pci}",
            t("5G: لا يُقفل (كما تفعل صفحة الراوتر)."),
            t("بعد الإرسال يظهر عدّاد 45 ثانية: إن لم تضغط «ثبّت القفل» يتراجع التطبيق تلقائيًا."),
        ]
        popup_box = BoxLayout(orientation='vertical', padding=dp(12), spacing=dp(10))
        msg = Label(text="\n".join(lines), halign='center', valign='middle',
                    font_size=sp(14))
        msg.bind(size=lambda i, s_: setattr(i, 'text_size', s_))
        row = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(10))
        popup = Popup(title=t("تأكيد قفل الخلية"), content=popup_box, size_hint=(0.92, 0.5),
                      auto_dismiss=False)
        ok = Button(text=t("تأكيد"))
        cancel = Button(text=t("إلغاء"))
        cancel.bind(on_release=lambda *_: popup.dismiss())

        def confirmed(*_a: Any) -> None:
            popup.dismiss()
            self._busy = True
            self.toast(t("جارٍ إرسال أمر القفل…"), 3)
            data = build_request(lte, None)     # same shape the router's own page sends

            def work() -> Any:
                return session.lock_cells(data)

            def done(_result: Any) -> None:
                self._busy = False
                self._cell_lock_guard(session, lte)

            def fail(exc: BaseException) -> None:
                self._busy = False
                self.toast(humanize_error(exc), 6)

            self._run_bg(work, done, fail)

        ok.bind(on_release=confirmed)
        row.add_widget(cancel)
        row.add_widget(ok)
        popup_box.add_widget(msg)
        popup_box.add_widget(row)
        popup.open()

    def _cell_lock_guard(self, session: Any, lte: Any) -> None:
        """45 s countdown after a cell lock: keep it, or it is rolled back automatically."""
        from core.cell_lock import locked_on
        box = BoxLayout(orientation='vertical', padding=dp(12), spacing=dp(10))
        status = Label(halign='center', valign='middle', font_size=sp(15))
        status.bind(size=lambda i, s_: setattr(i, 'text_size', s_))
        row = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(10))
        popup = Popup(title=t("تثبيت الخلية"), content=box, size_hint=(0.92, 0.45),
                      auto_dismiss=False)
        keep = Button(text=t("ثبّت القفل"))
        undo = Button(text=t("تراجع الآن"))
        state = {'left': 45, 'done': False}

        def finish(keep_lock: bool) -> None:
            if state['done']:
                return
            state['done'] = True
            ticker.cancel()
            popup.dismiss()
            if keep_lock:
                self._net_msg(t("تم تثبيت الخلية. لفك القفل استخدم «إلغاء قفل 5G» في الترددات أو إعدادات الراوتر."),
                              '#00b894')
            else:
                self._revert_cell_lock(session)

        def show() -> None:
            matched = locked_on(self.state.last, lte)
            status.text = (t("انتقل الراوتر إلى الخلية المطلوبة.") if matched
                           else t("بانتظار انتقال الراوتر إلى الخلية…")) + "\n" + \
                t("تراجع تلقائي خلال {n} ث").format(n=state['left'])

        def tick(_dt: float) -> None:
            state['left'] -= 1
            if state['left'] <= 0:
                finish(False)
            else:
                show()
        ticker = Clock.schedule_interval(tick, 1)
        keep.bind(on_release=lambda *_: finish(True))
        undo.bind(on_release=lambda *_: finish(False))
        row.add_widget(undo)
        row.add_widget(keep)
        box.add_widget(status)
        box.add_widget(row)
        show()
        popup.open()

    def _revert_cell_lock(self, session: Any) -> None:
        """Send the router's own "no lock" request; keep trying for 90 s (it drops its page briefly)."""
        from core.cell_lock import build_unlock
        self._net_msg(t("جاري التراجع عن قفل الخلية…"), '#e68033')
        deadline = time.monotonic() + 90

        def attempt() -> None:
            def done(res: Any) -> None:
                self._net_msg(t("تم التراجع عن قفل الخلية. رد الراوتر: {reply}").format(
                    reply=str(res)[:80] or "-"), '#00b894')

            def failed(_exc: BaseException) -> None:
                if time.monotonic() < deadline and session is self.session:
                    Clock.schedule_once(lambda _dt: attempt(), 5)
                else:
                    self._net_msg(t("تعذّر التراجع تلقائيًا. أعد تشغيل الراوتر وتحقق من حالته."), '#d63031')
            self._run_bg(lambda: session.lock_cells(build_unlock()), done, failed)
        attempt()

    def unlock_cell(self) -> None:
        """Cell lock back to automatic (router's lock-freq with lock_mode 0). Needs confirmation."""
        from core.cell_lock import build_unlock
        session, snap = self.session, self.state.last
        if session is None or self.link != 'online' or getattr(session, 'is_zte', False):
            self._net_msg(t("متاح لراوتر هواوي بعد الاتصال."), '#d63031')
            return
        with_nr = bool(snap is not None and snap.nr_pci is not None)
        data = build_unlock(with_nr)

        def send() -> None:
            self._net_action(lambda: session.lock_cells(data),
                             lambda res: self._net_msg(t("أُرسل فك القفل. رد الراوتر: {reply}").format(
                                 reply=str(res)[:120] or "-"), '#00b894'),
                             t("جاري فك قفل الخلية…"))
        self.confirm(t("تأكيد فك قفل الخلية"),
                     t("سيعود الراوتر لاختيار الخلية تلقائيًا.\nقد ينقطع الاتصال لثوانٍ."),
                     t("تأكيد"), send)

    def _verify_cell_lock(self, lte: Any) -> None:
        from core.cell_lock import locked_on
        if locked_on(self.state.last, lte):
            self.toast(t("تم التحقق: الراوتر على الخلية المطلوبة."), 4)
        else:
            self.toast(t("لم يتحقق: الراوتر ما زال على خلية أخرى."), 5)

    def refresh_info_screen(self) -> None:
        ids = self.sm.get_screen('info').ids
        if not ids:
            return
        snap = self.state.last or Snapshot()
        nd = t("Нет данных")
        mhz = t('МГц')

        def row(name: str, value: Any) -> str:
            # Строки от роутера — без разметки Kivy: «[» и «]» в них не теги.
            text = escape_markup(str(value)) if value not in (None, '', '-') else nd
            label = t(name)
            if current_language() == 'ar':
                return f"{text} [b]:{label}[/b]"
            return f"[b]{label}:[/b] {text}"

        ca = {True: t("Активна"), False: t("Нет"), None: None}[snap.ca]
        nr = snap.nr_summary() if snap.has_nr else None
        dl, ul = snap.dl_bandwidth, snap.ul_bandwidth
        tower = [
            row('Оператор (PLMN)', f"{snap.plmn} ({snap.operator or t('Неизвестный оператор')})"
                if snap.plmn else None),
            row('Технология', t(RAT_LABELS.get(snap.rat, snap.rat)) if snap.rat else None),
            row('Рабочий Band (LTE)', snap.band_label.replace('МГц', mhz)),
            row('Частота DL', f"{snap.freq_mhz:g} {mhz}" if snap.freq_mhz else None),
            row('EARFCN (канал DL)', snap.earfcn_raw),
            row('Агрегация (CA)', ca),
            row('Ширина канала', f"DL {dl} / UL {ul}" if ul else dl),
            row('Сектор антенны (PCI)', fmt_num(snap.pci)),
            row('eNodeB (Вышка)', fmt_num(snap.enodeb) if snap.enodeb is not None else
                (f"NCI {snap.nci}" if snap.nci else None)),
            row('Cell (Локальный сектор)', fmt_num(snap.sector)),
            row('TAC (зона)', snap.tac),
            row('5G NR', nr),
        ]
        current = snap.cell
        cells = [
            f"{'▶ ' if c.key == current else ''}{c.band_label.replace('МГц', mhz)}"
            f" · PCI {fmt_num(c.key.pci)} · SINR {fmt_num(c.best_sinr)}"
            f" · RSRP {fmt_num(c.best_rsrp)}"
            for c in self.state.top_cells()]
        info = self.session.device_info if self.session is not None else {}
        sim = [row(name, info.get(key)) for key, name in (
            ('Imei', 'IMEI (роутер)'), ('Imsi', 'IMSI (SIM)'), ('Iccid', 'ICCID (SIM-карта)'),
            ('Msisdn', 'Номер телефона'), ('SerialNumber', 'Серийный номер'),
            ('DeviceName', 'Модель'), ('SoftwareVersion', 'Прошивка'))]
        mimo = mimo_status(snap.cqi0, snap.cqi1)
        up = uplink_status(snap.pusch_dbm)
        mods = [f"{d} {m}" for d, m in (("DL", format_modulation(snap.dl_mcs)),
                                        ("UL", format_modulation(snap.ul_mcs, uplink=True))) if m]
        cqi = None
        if snap.cqi0 is not None:
            cqi = f"{snap.cqi0}" + (f" / {snap.cqi1}" if snap.cqi1 is not None else "") + \
                (f" — {t(MIMO_LABELS[mimo])}" if mimo else "")
        tx = (snap.txpower + (f" — {t(UPLINK_LABELS[up])}" if up else "")) or None
        st = self.state

        def minmax(p: str) -> str | None:
            lo, hi = st.session_min.get(p), st.session_max.get(p)
            return None if lo is None else f"{fmt_num(lo)} / {fmt_num(hi)} {unit_of(p)}"

        month = None
        if snap.month_dl is not None or snap.month_ul is not None:
            month = f"{format_bytes_mb(snap.month_dl or 0)} / {format_bytes_mb(snap.month_ul or 0)}"
        status = [
            row('Время сессии', str(datetime.timedelta(seconds=snap.connect_time))
                if snap.connect_time else None),
            row('Температура чипа', snap.temperature),
            row('Мобильные данные', {True: t("включены"), False: t("ВЫКЛЮЧЕНЫ"),
                                     None: None}[snap.data_enabled]),
            row('Скорость (Download)', format_rate_mbps(snap.dl_rate)),
            row('Скорость (Upload)', format_rate_mbps(snap.ul_rate)),
            row('Скачано за сессию', format_bytes_mb(snap.total_dl)),
            row('Отдано за сессию', format_bytes_mb(snap.total_ul)),
            row('Трафик за месяц (↓/↑)', month),
            row('Модуляция DL / UL', " / ".join(mods) if mods else None),
            row('Режим MIMO', format_mimo(snap.transmode) if snap.transmode else None),
            row('CQI (потоки)', cqi),
            row('Мощность передатчика', tx),
            row('RRC', snap.rrc),
            row('RSRP мин / макс', minmax('rsrp')),
            row('SINR мин / макс', minmax('sinr')),
        ]
        for key, lines in (('tower_block', tower), ('cells_block', cells or [nd]),
                           ('sim_block', sim), ('status_block', status)):
            ids[key].text = "\n".join(lines)

    # ---------- экран «Сеть» ----------

    def _tools(self) -> ToolsScreen:
        return self.sm.get_screen('tools')

    def _settings(self) -> SettingsScreen:
        return self.sm.get_screen('router_settings')

    def _net_msg(self, text: str, color: str, seconds: float = 8.0) -> None:
        """Status line on the Frequencies and Router-settings pages; clears itself after `seconds`."""
        rgba = hex_to_rgba(color, self.theme_name == 'sun')
        for screen in (self._tools(), self._settings()):
            screen.net_msg = text
            screen.net_msg_color = rgba
        pending = getattr(self, '_net_msg_clear', None)
        if pending is not None:
            pending.cancel()
        self._net_msg_clear = None
        if text and seconds > 0:
            def clear(_dt: float) -> None:
                self._net_msg_clear = None
                for screen in (self._tools(), self._settings()):
                    if screen.net_msg == text:      # a newer message is left alone
                        screen.net_msg = ''
            self._net_msg_clear = Clock.schedule_once(clear, seconds)

    # ---------- 4.1.7.8: بطاقات الباندات (تبويب 4G وتبويب 5G) ----------

    def set_band_tab(self, tab: str) -> None:
        tab = 'nr' if tab == 'nr' else 'lte'
        self._tools().band_tab = tab
        self._show_band_box(tab)

    def _show_band_box(self, tab: str) -> None:
        """Only the active tab's box stays in the layout. A hidden box (height 0, disabled) still
        laid its children out over the visible one and swallowed their touches."""
        screen = self._tools()
        boxes = getattr(self, '_band_boxes', None)
        if boxes is None:
            lte_box, nr_box = screen.ids.get('lte_box'), screen.ids.get('nr_box')
            if lte_box is None or nr_box is None:
                return
            boxes = self._band_boxes = {'lte': lte_box, 'nr': nr_box}   # strong references
        show, hide = boxes[tab], boxes['nr' if tab == 'lte' else 'lte']
        parent = hide.parent or show.parent
        if parent is None:
            return
        if hide.parent is parent:
            index = parent.children.index(hide)
            parent.remove_widget(hide)
            if show.parent is None:
                parent.add_widget(show, index=index)

    def _group_texts(self, key: str) -> tuple[str, str]:
        return {
            'low': (t("ترددات منخفضة"), t("تغطية ونفاذ")),
            'mid': (t("ترددات متوسطة"), t("توازن")),
            'fdd': (t("ترددات FDD"), t("تغطية")),
            'tdd': (t("ترددات TDD"), t("سرعة أعلى")),
        }[key]

    def _make_band_card(self, label: str, mhz_text: str, duplex: str, seen: bool,
                        select: Any, p_flag: Any, s_flag: Any, selectable: bool = False) -> Any:
        """Compact band card: name, MHz, FDD/TDD chip, P/S buttons. Writes only the flags.

        selectable (4G): the band name is a toggle that selects the band; P/S stay empty and
        disabled until the band is selected. Otherwise (5G) tapping P or S selects the band."""
        from kivy.graphics import Color, Ellipse, RoundedRectangle
        sun = self.theme_name == 'sun'
        tdd = duplex == 'TDD'
        accent = hex_to_rgba('#F5B544' if tdd else '#2FD6B5', sun)
        card = BoxLayout(orientation='vertical', size_hint_y=None, height=dp(82),
                         padding=dp(6), spacing=dp(2))
        inset = dp(1.5)
        base_border = [0.62, 0.66, 0.72, 1.0] if sun else hex_to_rgba('#29465B')
        with card.canvas.before:
            border_color = Color(*base_border)
            border = RoundedRectangle(pos=card.pos, size=card.size, radius=[dp(12)])
            Color(*((0.95, 0.96, 0.98, 1) if sun else hex_to_rgba('#17283A')))
            bg = RoundedRectangle(pos=(card.x + inset, card.y + inset),
                                  size=(card.width - 2 * inset, card.height - 2 * inset),
                                  radius=[dp(11)])

        def layout(widget: Any, *_a: Any) -> None:
            border.pos = widget.pos
            border.size = widget.size
            bg.pos = (widget.x + inset, widget.y + inset)
            bg.size = (max(widget.width - 2 * inset, 0), max(widget.height - 2 * inset, 0))
        card.bind(pos=layout, size=layout)

        def fit(widget: Any, size: Any) -> None:
            widget.text_size = size

        top = BoxLayout(orientation='horizontal', size_hint_y=None,
                        height=dp(26) if selectable else dp(22), spacing=dp(4))
        if selectable:
            name = Factory.RoleButton(text=label)
            name.font_size = sp(15)
            name.role_color = hex_to_rgba('#2F6FD6', sun)
            name.active = bool(select.active)
            name.bind(on_release=lambda _b: setattr(select, 'active', not select.active))
        else:
            name = Label(text=label, color=accent, font_size=sp(15), bold=True,
                         halign='center', valign='middle')
            name.bind(size=fit)
        top.add_widget(name)
        if seen:
            dot = Widget(size_hint=(None, None), size=(dp(8), dp(8)),
                         pos_hint={'center_y': .5})
            with dot.canvas:
                Color(*hex_to_rgba('#3DDC97', sun))
                dot_shape = Ellipse(pos=dot.pos, size=dot.size)
            dot.bind(pos=lambda w, _v: setattr(dot_shape, 'pos', w.pos))
            top.add_widget(dot)
        mid = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(15), spacing=dp(4))
        mhz = Label(text=mhz_text, color=self.c_text, font_size=sp(12), bold=True,
                    halign='center', valign='middle')
        mhz.bind(size=fit)
        chip = Label(text=duplex, color=accent, font_size=sp(10), bold=True,
                     halign='center', valign='middle', size_hint_x=None, width=dp(34))
        chip.bind(size=fit)
        mid.add_widget(mhz)
        if duplex:
            mid.add_widget(chip)
        roles = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(28), spacing=dp(4))
        # KV-defined properties exist only after construction: set them afterwards, not as kwargs.
        p_btn = Factory.RoleButton(text='P')
        p_btn.role_color = hex_to_rgba('#1573E0', sun)
        p_btn.active = bool(p_flag.active)
        s_btn = Factory.RoleButton(text='S')
        s_btn.role_color = hex_to_rgba('#6D4AE8', sun)
        s_btn.active = bool(s_flag.active)
        roles.add_widget(p_btn)
        roles.add_widget(s_btn)
        card.add_widget(top)
        card.add_widget(mid)
        card.add_widget(roles)

        def sync(*_a: Any) -> None:
            p_btn.active = bool(p_flag.active)
            s_btn.active = bool(s_flag.active)
            if selectable:
                name.active = bool(select.active)
                for btn in (p_btn, s_btn):
                    btn.disabled = not select.active
                    btn.opacity = 1.0 if select.active else 0.45
            if p_flag.active:
                border_color.rgba = hex_to_rgba('#1573E0', sun)
            elif s_flag.active:
                border_color.rgba = hex_to_rgba('#6D4AE8', sun)
            elif select.active:
                border_color.rgba = hex_to_rgba('#4F8FD6', sun)
            else:
                border_color.rgba = base_border
        sync()
        for flag in (select, p_flag, s_flag):
            flag.bind(active=sync)

        def tap(flag: Any) -> None:
            if flag.active:
                if selectable:
                    flag.active = False       # keep the band selected, drop only the role
                else:
                    select.active = False     # clears P and S too (see _wire_band_flags)
            else:
                flag.active = True
        p_btn.bind(on_release=lambda _b: tap(p_flag))
        s_btn.bind(on_release=lambda _b: tap(s_flag))
        return card

    @staticmethod
    def _wire_band_flags(select: Any, p_flag: Any, s_flag: Any) -> None:
        """Roles imply selection; un-selecting clears the roles; P and S are exclusive."""
        p_flag.bind(active=lambda _f, a: setattr(select, 'active', True) if a else None)
        s_flag.bind(active=lambda _f, a: setattr(select, 'active', True) if a else None)
        select.bind(active=lambda _f, a: (setattr(p_flag, 'active', False),
                                          setattr(s_flag, 'active', False)) if not a else None)

    def _fill_band_grid(self, grid: Any, groups: list[tuple[str, list[int]]],
                        make: Callable[[int], Any]) -> None:
        from kivy.uix.gridlayout import GridLayout
        grid.clear_widgets()
        for key, bands in groups:
            title, hint = self._group_texts(key)
            head = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(20))
            title_lbl = Label(text=title, color=self.c_text, font_size=sp(13), bold=True,
                              halign=self.text_align, valign='middle')
            hint_lbl = Label(text=hint, color=self.c_sub, font_size=sp(11),
                             halign='left' if self.text_align == 'right' else 'right',
                             valign='middle')
            for lbl in (title_lbl, hint_lbl):
                lbl.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
                head.add_widget(lbl)
            grid.add_widget(head)
            cards = GridLayout(cols=3, size_hint_y=None, spacing=dp(5))
            cards.bind(minimum_height=cards.setter('height'))
            for band in bands:
                try:
                    cards.add_widget(make(band))
                except Exception:           # one bad card must never break the page
                    logger.exception("Band card %s failed", band)
            grid.add_widget(cards)

    def build_band_checkboxes(self) -> None:
        grid = self._tools().ids.get('bands_grid')
        seen = set(self.state.observed_bands)
        key = (tuple(self._band_list), tuple(sorted(seen)), self.theme_name)
        if grid is None or self._bands_shown == key:
            return
        old = {b: (self.band_vars[b].active, self.band_role_vars[b]['p'].active,
                   self.band_role_vars[b]['s'].active)
               for b in self.band_vars if b in self.band_role_vars}
        self.band_vars = {}
        self.band_role_vars = {}
        from core.band_layout import group_bands, lte_entry
        info = {b: lte_entry(b) for b in self._band_list}

        def make(band: int) -> Any:
            sel_on, p_on, s_on = old.get(band, (False, False, False))
            select, p_flag, s_flag = BandFlag(), BandFlag(), BandFlag()
            select.active, p_flag.active, s_flag.active = sel_on, p_on, s_on
            self.band_vars[band] = select
            self.band_role_vars[band] = {'p': p_flag, 's': s_flag}
            label, mhz_text, duplex, _f = info[band]
            card = self._make_band_card(label, mhz_text, duplex, band in seen,
                                        select, p_flag, s_flag, selectable=True)
            self._wire_band_flags(select, p_flag, s_flag)
            p_flag.bind(active=lambda _f, active, other=s_flag, b=band: self._on_primary(b, other, active))
            s_flag.bind(active=lambda _f, active, other=p_flag: setattr(other, 'active', False) if active else None)
            return card
        self._fill_band_grid(grid, group_bands(info, 'lte'), make)
        self._bands_shown = key

    def build_nr_band_checkboxes(self) -> None:
        """5G cards. Selected without S = Pcell+Scell, S = Scell only (see _lock_nr_bands)."""
        grid = self._tools().ids.get('nr_bands_grid')
        from core.band_layout import NR_BANDS_SHOWN, group_bands, nr_entry
        bands = list(NR_BANDS_SHOWN)
        key = (tuple(bands), self.theme_name)
        if grid is None or self._nr_bands_shown == key:
            return
        old = {b: (self.nr_band_vars[b].active, self.nr_role_vars[b]['p'].active,
                   self.nr_role_vars[b]['s'].active)
               for b in self.nr_band_vars if b in self.nr_role_vars}
        self.nr_band_vars = {}
        self.nr_role_vars = {}
        info = {b: nr_entry(b) for b in bands}

        def make(band: int) -> Any:
            sel_on, p_on, s_on = old.get(band, (False, False, False))
            select, p_flag, s_flag = BandFlag(), BandFlag(), BandFlag()
            select.active, p_flag.active, s_flag.active = sel_on, p_on, s_on
            self.nr_band_vars[band] = select
            self.nr_role_vars[band] = {'p': p_flag, 's': s_flag}
            label, mhz_text, duplex, _f = info[band]
            card = self._make_band_card(label, mhz_text, duplex, False, select, p_flag, s_flag)
            self._wire_band_flags(select, p_flag, s_flag)
            p_flag.bind(active=lambda _f, active, other=s_flag: setattr(other, 'active', False) if active else None)
            s_flag.bind(active=lambda _f, active, other=p_flag: setattr(other, 'active', False) if active else None)
            return card
        self._fill_band_grid(grid, group_bands(info, 'nr'), make)
        self._nr_bands_shown = key

    def _run_bg(self, work: Callable[[], Any], done: Callable[[Any], None],
                fail: Callable[[BaseException], None]) -> None:
        """Выполнить work в фоне, результат/ошибку — в главном потоке."""
        def task() -> None:
            try:
                result = work()
            except Exception as exc:
                logger.exception("Background task failed")
                Clock.schedule_once(lambda dt, err=exc: fail(err))
            else:
                Clock.schedule_once(lambda dt: done(result))
        threading.Thread(target=task, daemon=True).start()

    def _net_action(self, work: Callable[[], Any], done: Callable[[Any], None],
                    busy_text: str) -> None:
        """Команда роутеру: повторное нажатие до ответа игнорируется."""
        if self.session is None or self.link != 'online':
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return
        if self._busy:
            return
        self._busy = True
        self._net_msg(busy_text, '#3399ff')
        session = self.session

        def finish(result: Any) -> None:
            if session is not self.session:
                return          # ответ прошлой сессии: её состояние уже сброшено
            self._busy = False
            done(result)

        def failed(exc: BaseException) -> None:
            if session is not self.session:
                return
            self._busy = False
            self._net_msg(t("Команда не выполнена: {err}").format(
                err=humanize_error(exc)), '#d63031')
        self._run_bg(work, finish, failed)

    def load_router_config(self) -> None:
        """Читает текущий Band Lock и антенну (только чтение)."""
        session = self.session
        if session is None:
            return
        unread = t("Сейчас на модеме: не прочитано")
        # Пока не прочитано — не показываем состояние прошлой сессии.
        self._tools().lock_state = unread

        def done(cfg: Any) -> None:
            if session is not self.session:
                return
            tools = self._tools()
            if cfg.locked is None:
                tools.lock_state = t("Сейчас на модеме: не прочитано")
            elif not cfg.locked:
                tools.lock_state = t("Сейчас на модеме: AUTO (все бэнды)")
                for cb in self.band_vars.values():
                    cb.active = False
            else:
                tools.lock_state = t("Сейчас на модеме: {bands}").format(
                    bands=", ".join(f"B{b}" for b in cfg.locked))
                extra = [b for b in cfg.locked if b not in self._band_list]
                if extra:
                    self._band_list += extra
                    self.build_band_checkboxes()
                for b, cb in self.band_vars.items():
                    cb.active = b in cfg.locked
            if cfg.antenna is not None:
                for label, code in ANTENNA_MODES.items():
                    if code == cfg.antenna:
                        self._settings().antenna_text = t(label)

        def failed(_exc: BaseException) -> None:
            if session is self.session:
                self._tools().lock_state = unread
        self._run_bg(session.read_config, done, failed)

    def mark_current_bands(self) -> None:
        snap = self.state.last
        if snap is None or not snap.bands:
            self._net_msg(t("Текущий бэнд ещё не определён."), '#d63031')
            return
        missing = [b for b in snap.bands if b not in self._band_list]
        if missing:
            self._band_list += missing
        self.build_band_checkboxes()
        for b, cb in self.band_vars.items():
            cb.active = b in snap.bands
        self._net_msg(t("Отмечены текущие бэнды: {bands}").format(
            bands=", ".join(f"B{b}" for b in snap.bands)), '#3399ff')

    def check_nr_band_lock_support(self) -> None:
        """Read-only capability probe; never sends an undocumented NR write."""
        session = self.session
        if session is None or self.link != 'online':
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return

        def inspect() -> tuple[bool, str]:
            dumps, errors = session.collect_diagnostics()
            candidates = (dumps.get('net_net_mode_list'), dumps.get('net_net_mode'))
            # A named NR band field is only a hint, not proof that a write API exists.
            keys = {'NRBand', 'NRBandList', 'NRBandLock', 'NRBandMask',
                    'NRSABand', 'NR5GBand', 'NRBandSelect'}
            found = False
            def walk(value: Any) -> None:
                nonlocal found
                if isinstance(value, dict):
                    for key, child in value.items():
                        if str(key).replace('_', '').lower() in {k.replace('_', '').lower() for k in keys}:
                            found = True
                        walk(child)
                elif isinstance(value, (list, tuple)):
                    for child in value:
                        walk(child)
            for candidate in candidates:
                walk(candidate)
            if found:
                return True, t("ظهرت حقول NR في قراءة الراوتر، لكن وجودها لا يثبت وجود أمر كتابة آمن. أرسل تقرير التشخيص لتحديد طريقة القفل قبل تفعيلها.")
            if errors.get('net_net_mode_list'):
                return False, t("تعذرت قراءة قائمة أوضاع الشبكة؛ لم يتم اختبار دعم قفل 5G بشكل كامل.")
            return False, t("الراوتر لم يعرض حقول قفل NR معروفة في واجهة القراءة. لم يتم إرسال أي أمر تغيير. نحتاج تقرير التشخيص أو توثيق واجهة هذا الإصدار قبل تنفيذ قفل حقيقي.")

        self._net_action(inspect,
                         lambda result: self._net_msg(result[1], '#d6a000' if result[0] else '#d63031'),
                         t("أفحص واجهة الراوتر للقراءة فقط…"))

    def _on_primary(self, band: int, secondary_cb: Any, active: bool) -> None:
        """P is exclusive: one primary band at most; P and S never on the same band."""
        if not active:
            return
        secondary_cb.active = False
        for other, roles in self.band_role_vars.items():
            if other != band and roles['p'].active:
                roles['p'].active = False

    def _apply_zte_bands(self, session: Any) -> None:
        """ZTE LTE lock: allowed = ticked + P + S. Needs confirmation; Huawei is untouched."""
        picked = {b for b, cb in self.band_vars.items() if cb.active}
        primary = [b for b, r in self.band_role_vars.items() if r['p'].active]
        secondary = [b for b, r in self.band_role_vars.items() if r['s'].active]
        allowed = sorted(picked | set(primary) | set(secondary))
        if not allowed:
            self._net_msg(t("اختر باندًا واحدًا على الأقل!"), '#d63031')
            return
        names = ", ".join(f"B{b}" for b in allowed)
        want = primary[0] if primary else None

        def send() -> None:
            def done(ok: Any) -> None:
                self._after_write(ok, t("تم إرسال أمر LTE للباندات: {bands}.").format(bands=names))
                if want is not None:
                    Clock.schedule_once(lambda _dt: self._verify_primary(want), 25)
            self._net_action(lambda: session.apply_plan(session.plan_band_lock(allowed)), done,
                             t("جاري إرسال أمر قفل LTE…"))

        self.confirm(t("تأكيد قفل الباندات"),
                     t("سيُقفل الراوتر على: {bands}\nقد ينقطع الاتصال لثوانٍ.").format(bands=names),
                     t("قفل"), send)

    def _verify_primary(self, want: int) -> None:
        snap = self.state.last
        if snap is not None and snap.bands:
            if snap.bands[0] == want:
                self.toast(t("الباند الرئيسي الآن B{b} كما طلبت.").format(b=want), 4)
            else:
                self.toast(t("الشبكة اختارت B{b} رئيسيًا بدل B{w}.").format(
                    b=snap.bands[0], w=want), 5)

    def apply_bands(self) -> None:
        session = self.session
        if session is not None and self.link == 'online' and getattr(session, 'is_zte', False):
            self._apply_zte_bands(session)
            return
        selected = [b for b, cb in self.band_vars.items() if cb.active]
        if session is None or self.link != 'online':
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return
        if not selected:
            self._net_msg(t("اختر باندًا واحدًا على الأقل!"), '#d63031')
            return
        names = ", ".join(f"B{b}" for b in selected)

        # 4G tab: the existing LTE write (unchanged). 5G has its own tab and its own command.
        def done(ok: Any) -> None:
            self._after_write(ok, t("تم إرسال أمر LTE للباندات: {bands}.").format(bands=names))
        self._net_action(lambda: session.apply_plan(session.plan_band_lock(selected)), done,
                         t("جاري إرسال أمر قفل LTE…"))

    def apply_nr_bands(self) -> None:
        """5G tab: lock-freq by band (lock_mode 3) for the chosen NR bands only."""
        session = self.session
        if session is None or self.link != 'online':
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return
        if getattr(session, 'is_zte', False):
            self._net_msg(t("قفل 5G غير متاح بعد لهذا الراوتر."), '#d63031')
            return
        if not any(cb.active for cb in self.nr_band_vars.values()):
            self._net_msg(t("اختر باندًا واحدًا على الأقل!"), '#d63031')
            return
        self._lock_nr_bands(session)

    def _lock_nr_bands(self, session: Any) -> None:
        """5G band lock (lock_mode 3, as saved by the router's developer page).
        Checked band without S = Pcell+Scell; S = Scell only."""
        from core.cell_lock import build_nr_band_lock
        picked = [b for b, cb in self.nr_band_vars.items() if cb.active]
        sec = [b for b, r in self.nr_role_vars.items() if r['s'].active]
        prim = [b for b, r in self.nr_role_vars.items() if r['p'].active]
        bands = sorted(set(picked) | set(prim))
        try:
            data = build_nr_band_lock([b for b in bands if b not in sec], sec)
        except ValueError as exc:
            self._net_msg(str(exc), '#d63031')
            return
        names = ", ".join(f"N{b}" for b in sorted(set(bands) | set(sec)))
        txt = t("سيُقفل 5G على: {bands}\nيحتاج دخولًا ثانيًا (مطورين) بمحاولة واحدة.").format(bands=names)

        def send() -> None:
            self._net_action(lambda: session.lock_cells(data),
                             lambda res: self._net_msg(t("أُرسل قفل 5G. رد الراوتر: {reply}").format(
                                 reply=str(res)[:120] or "-"), '#00b894'),
                             t("جاري قفل 5G…"))
        self.confirm(t("تأكيد قفل 5G"), txt, t("قفل"), send)

    def reset_bands(self) -> None:
        session = self.session
        if session is None:
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return
        self._net_action(lambda: session.apply_plan(session.plan_all_bands()),
                         lambda ok: self._after_write(ok, t("Включены все бэнды (AUTO).")),
                         t("Включаю все бэнды…"))

    def restore_bands(self) -> None:
        session = self.session
        if session is None:
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return
        plan = session.plan_restore_original()
        if plan is None:
            self._net_msg(t("Исходные настройки не прочитаны — роутер не отдал net-mode."),
                          '#d63031')
            return
        self._net_action(lambda: session.apply_plan(plan),
                         lambda ok: self._after_write(ok, t(
                             "Восстановлены настройки, прочитанные при подключении.")),
                         t("Восстанавливаю настройки…"))

    def _after_write(self, verified: bool, success_text: str) -> None:
        if verified:
            self._net_msg(success_text + " " + t(
                "Модем перерегистрируется в сети (до ~30 с)."), '#00b894')
        else:
            self._net_msg(t("Команда отправлена, но роутер не подтвердил запись — "
                            "проверьте строку «Сейчас на модеме»."), '#e68033')
        self.load_router_config()

    def set_network_kind(self, kind: str) -> None:
        """4G only / NSA. Huawei: only NetworkMode changes (same write path as the band lock)."""
        session = self.session
        if session is None or self.link != 'online':
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return
        label = t("4G فقط") if kind == 'lte' else t("NSA 4G+5G")
        zte = getattr(session, 'is_zte', False)

        def send() -> None:
            def work() -> Any:
                plan = session.plan_network_mode(kind)
                return session.apply_network_plan(plan) if zte else session.apply_plan(plan)
            self._net_action(work,
                             lambda ok: self._after_write(ok, t("تم تحديد الشبكة: {mode}.").format(mode=label)),
                             t("جاري تحديد الشبكة…"))
        self.confirm(t("تأكيد تحديد الشبكة"),
                     t("سيُضبط الراوتر على: {mode}\nقد ينقطع الاتصال لثوانٍ.").format(mode=label),
                     t("تأكيد"), send)

    def apply_antenna(self, label: str) -> None:
        session = self.session
        rev = {t(k): k for k in ANTENNA_MODES}
        code = parse_antenna_value(rev.get(label, label))
        if session is None:
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return
        if code is None:
            self._net_msg(t("Неизвестный режим антенны."), '#d63031')
            return

        def work() -> int | None:
            session.set_antenna(code)
            return session.read_antenna()

        def done(read_back: int | None) -> None:
            if read_back in (code, None):
                self._net_msg(t("Тип антенны изменён: {mode}").format(mode=label), '#00b894')
            else:
                self._net_msg(t("Роутер принял команду, но сообщает другой режим антенны."),
                              '#e68033')
        self._net_action(work, done, t("Переключаю антенну…"))

    def confirm_reattach(self) -> None:
        session = self.session
        if session is None:
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return

        def done(ok: bool) -> None:
            if ok:
                self._net_msg(t("Связь переподключена."), '#00b894')
            else:
                self._net_msg(t("Не удалось включить мобильные данные — включите их в "
                                "веб-интерфейсе роутера."), '#d63031')
        self.confirm(t("Подтверждение"), t(
            "Переподключить мобильную связь?\n\nИнтернет пропадёт примерно "
            "на 5–10 секунд."), t("Переподключить"),
            lambda: self._net_action(session.reattach, done, t("Переподключаю связь…")))

    def confirm_reboot(self) -> None:
        session, worker = self.session, self.worker
        if session is None or worker is None:
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return

        def done(_: Any) -> None:
            self._net_msg(t("Роутер перезагружается — переподключусь автоматически."),
                          '#3399ff')
        self.confirm(t("Подтверждение"), t(
            "Перезагрузить роутер?\n\nСоединение с интернетом прервётся "
            "на 1–2 минуты. Программа переподключится автоматически."),
            t("Перезагрузить роутер"),
            lambda: self._net_action(session.reboot, done, t("Отправляю команду перезагрузки…")))

    def zte_probe(self, ip: str, password: str = '') -> None:
        """Read-only GET probe of a ZTE router's signal commands (one login request if a password is typed; no writes).
        The reply is copied to the clipboard and shown so its real format can be
        reviewed before ZTE support is built."""
        if not ip:
            self.toast(t("اكتب عنوان IP للراوتر أولًا."), 3)
            return
        if self._busy:
            return
        self._busy = True
        self.toast(t("جارٍ فحص راوتر ZTE (قراءة فقط)…"), 3)

        def work() -> str:
            from core.zte_probe import probe, to_text
            return to_text(probe(ip, password))

        def done(text: str) -> None:
            self._busy = False
            try:
                from kivy.core.clipboard import Clipboard
                Clipboard.copy(text)
                self.toast(t("نُسخ الناتج إلى الحافظة. الصقه في المحادثة."), 4)
            except Exception:
                logger.debug("clipboard failed", exc_info=True)
            self.show_popup(t("نتيجة فحص ZTE"), text[:6000])

        def fail(exc: BaseException) -> None:
            self._busy = False
            self.toast(humanize_error(exc), 5)

        self._run_bg(work, done, fail)

    def copy_diagnostics(self) -> None:
        """Диагностика (JSON) в буфер обмена: удобно вставить в issue/мессенджер.

        Hardware validation required: вставка из буфера на Android 12+.
        """
        session = self.session
        if session is None:
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return

        def work() -> str:
            dumps, errors = session.collect_diagnostics()
            report = build_diagnostics(
                app_version=__version__, library_version=library_version(),
                platform=f"{platform} / Python {py_platform.python_version()}",
                dumps=dumps, errors=errors)
            return diagnostics_json(report)

        def done(text: str) -> None:
            from kivy.core.clipboard import Clipboard
            Clipboard.copy(text)
            self._net_msg(t("Диагностика скопирована в буфер обмена. Личные номера "
                            "замаскированы."), '#00b894')
        self._net_action(work, done, t("Собираю диагностику…"))

    # ---------- 4.1.7.9: صفحة البنق ----------

    _QUALITY_STYLE = {
        'excellent': ('#3DDC97', "ممتاز"), 'good': ('#F5C451', "جيد"),
        'fair': ('#FF8A4C', "متوسط"), 'poor': ('#FF5C6C', "ضعيف"),
        'none': ('#8A98AA', "غير متاح"),
    }

    def game_connection_check(self) -> None:
        self.go('ping')
        self.run_ping_suite()

    def run_ping_suite(self) -> None:
        """Measure every game host and regional point (TCP connect), then draw the page."""
        if self._ping_running:
            return
        from core.game_ping import run_ping_suite as measure
        self._ping_running = True
        screen = self.sm.get_screen('ping')
        screen.status_text = ""
        screen.progress = 0.0
        screen.busy = True
        started = time.monotonic()
        state = {'done': 0, 'total': 0}

        def show() -> None:
            seconds = int(time.monotonic() - started)
            counted = (f"{state['done']}/{state['total']}  -  " if state['total'] else "")
            screen.progress_text = counted + t("جاري الفحص… {n} ث").format(n=seconds)

        def tick(_dt: float) -> None:
            screen.spin = (screen.spin + 14) % 360     # keeps turning until the check ends
            show()
        ticker = Clock.schedule_interval(tick, 1 / 20)

        def on_progress(done_n: int, total: int) -> None:
            def apply(_dt: float) -> None:
                state['done'], state['total'] = done_n, total
                screen.progress = done_n / total if total else 0.0
            Clock.schedule_once(apply)

        def finish() -> None:
            ticker.cancel()
            screen.busy = False
            self._ping_running = False

        def done(result: Any) -> None:
            finish()
            self._ping_last = result
            screen.status_text = ""
            self._render_ping()

        def failed(exc: BaseException) -> None:
            finish()
            screen.status_text = t("تعذّر الفحص: {err}").format(err=humanize_error(exc))
        show()
        self._run_bg(lambda: measure(progress=on_progress), done, failed)

    def improve_ping(self) -> None:
        self.toast(t("تحسين البنق: يحتاج تجربة الباندات واختيار الأفضل، وسيُفعَّل بعد اعتماد آلية القفل."), 5)

    def improve_speed(self) -> None:
        self.toast(t("تحسين السرعة: يحتاج تجربة الباندات واختيار الأفضل، وسيُفعَّل بعد اعتماد آلية القفل."), 5)

    def _quality_color(self, key: str) -> list[float]:
        return hex_to_rgba(self._QUALITY_STYLE[key][0], self.theme_name == 'sun')

    def _render_ping(self) -> None:
        if self._ping_last is None:
            return
        from core.game_ping import quality, sort_by_ping, summarize
        games, regions = self._ping_last
        screen = self.sm.get_screen('ping')
        summary = summarize(games)
        key = quality(summary.ping_ms)
        screen.hero_color = self._quality_color(key)
        if summary.ping_ms is None:
            screen.hero_ms = '—'
            screen.hero_label = t("لم يرد أي سيرفر")
            screen.marker_on = 0
        else:
            screen.hero_ms = f"{summary.ping_ms:.0f}"
            screen.hero_label = t(self._QUALITY_STYLE[key][1]) + " " + t("للألعاب")
            screen.marker = min(summary.ping_ms, 200.0) / 200.0
            screen.marker_on = 1
        screen.stat_jitter = f"{summary.jitter_ms:.0f} ms" if summary.jitter_ms is not None else '—'
        screen.stat_loss = f"{summary.loss_pct:.0f}%" if summary.loss_pct is not None else '—'
        screen.stat_best = f"{summary.best_ms:.0f} ms" if summary.best_ms is not None else '—'
        for list_id, rows in (('games_list', games), ('regions_list', regions)):
            box = screen.ids.get(list_id)
            if box is None:
                continue
            box.clear_widgets()
            for result in sort_by_ping(rows):
                try:
                    box.add_widget(self._ping_row(result))
                except Exception:
                    logger.exception("Ping row %s failed", getattr(result, 'key', '?'))

    def _ping_row(self, result: Any) -> Any:
        from core.game_ping import quality
        from kivy.graphics import Color, Rectangle, RoundedRectangle
        sun = self.theme_name == 'sun'
        key = quality(result.ping_ms)
        color = self._quality_color(key)
        card = BoxLayout(orientation='vertical', size_hint_y=None, height=dp(60),
                         padding=dp(7), spacing=dp(3))
        with card.canvas.before:
            Color(*((0.93, 0.95, 0.97, 1) if sun else hex_to_rgba('#17283A')))
            bg = RoundedRectangle(pos=card.pos, size=card.size, radius=[dp(14)])
        card.bind(pos=lambda w, _v: setattr(bg, 'pos', w.pos),
                  size=lambda w, _v: setattr(bg, 'size', w.size))

        def fit(widget: Any, size: Any) -> None:
            widget.text_size = size

        badge = Label(text=result.badge, color=self.c_text, font_size=sp(16), bold=True,
                      size_hint=(None, 1), width=dp(32))
        name = Label(text=t(result.name), color=self.c_text, font_size=sp(14), bold=True,
                     halign=self.text_align, valign='bottom')
        host = Label(text=result.host, color=self.c_sub, font_size=sp(10),
                     halign=self.text_align, valign='top')
        for lbl in (name, host):
            lbl.bind(size=fit)
        names = BoxLayout(orientation='vertical')
        names.add_widget(name)
        names.add_widget(host)
        ms_text = f"{result.ping_ms:.0f}" if result.ping_ms is not None else '—'
        ms = Label(text=ms_text, color=color, font_size=sp(21), bold=True,
                   size_hint=(None, None), size=(dp(64), dp(26)))
        quality_lbl = Label(text=t(self._QUALITY_STYLE[key][1]), color=color, font_size=sp(11),
                            bold=True, size_hint=(None, None), size=(dp(64), dp(14)))
        values = BoxLayout(orientation='vertical', size_hint_x=None, width=dp(66))
        values.add_widget(ms)
        values.add_widget(quality_lbl)
        top = BoxLayout(orientation='horizontal', spacing=dp(8))
        # Arabic UI: the badge sits on the right, so it is the last child.
        for widget in ((values, names, badge) if current_language() == 'ar'
                       else (badge, names, values)):
            top.add_widget(widget)
        bar = Widget(size_hint_y=None, height=dp(5))
        fill = (min(result.ping_ms, 200.0) / 200.0) if result.ping_ms is not None else 0.0
        with bar.canvas:
            Color(*((0.80, 0.83, 0.87, 1) if sun else hex_to_rgba('#0E1621')))
            track = Rectangle(pos=bar.pos, size=bar.size)
            Color(*color)
            part = Rectangle(pos=bar.pos, size=(bar.width * fill, bar.height))

        def layout_bar(widget: Any, *_a: Any) -> None:
            track.pos = widget.pos
            track.size = widget.size
            part.pos = widget.pos
            part.size = (widget.width * fill, widget.height)
        bar.bind(pos=layout_bar, size=layout_bar)
        card.add_widget(top)
        card.add_widget(bar)
        return card


def main() -> None:
    Hua4GMonApp().run()


if __name__ == "__main__":
    main()
