"""Cells seen by the PHONE's own modem (Android TelephonyManager), read-only.

Separate from router readings: the phone talks to towers by itself, so these
numbers are shown on their own with a clear label and never mixed with the
router's. Values Android reports as unavailable (Integer.MAX_VALUE) become
``None`` and the UI shows them as unavailable. Nothing is sent anywhere.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from core.neighbor_cells import band_from_earfcn

_UNAVAILABLE = 2147483647

# 3GPP TS 38.104 NR-ARFCN ranges (downlink) for the bands used locally.
_NR_ARFCN_BANDS: tuple[tuple[int, int, int], ...] = (
    (422000, 434000, 1), (361000, 376000, 3), (524000, 538000, 7),
    (185000, 192000, 8), (158200, 164200, 20), (151600, 160600, 28),
    (514000, 524000, 38), (460000, 480000, 40), (499200, 537999, 41),
    (620000, 653333, 78), (653334, 680000, 77), (693334, 733333, 79),
)


@dataclass(frozen=True)
class PhoneCell:
    tech: str                 # 'LTE' or 'NR'
    band: str | None
    pci: int | None
    arfcn: int | None
    rsrp: float | None
    rsrq: float | None
    sinr: float | None
    registered: bool


def clean(value: Any) -> float | None:
    """Android 'unavailable' markers -> None."""
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if abs(number) >= _UNAVAILABLE - 1:
        return None
    return number


def nr_band_from_arfcn(arfcn: int | None) -> str | None:
    if arfcn is None:
        return None
    for low, high, band in _NR_ARFCN_BANDS:
        if low <= arfcn <= high:
            return f'N{band}'
    return None


def _int(value: Any) -> int | None:
    number = clean(value)
    return None if number is None else int(number)


def build_cell(tech: str, *, pci: Any, arfcn: Any, rsrp: Any, rsrq: Any, sinr: Any,
               registered: bool, bands: Any = None) -> PhoneCell:
    arfcn_i = _int(arfcn)
    band = None
    try:
        first = next(iter(bands), None) if bands is not None else None
    except TypeError:
        first = None
    if first is not None:
        band = f"{'N' if tech == 'NR' else 'B'}{int(first)}"
    if band is None:
        band = nr_band_from_arfcn(arfcn_i) if tech == 'NR' else band_from_earfcn(arfcn_i)
    return PhoneCell(tech, band, _int(pci), arfcn_i, clean(rsrp), clean(rsrq),
                     clean(sinr), bool(registered))


def tidy_cells(cells: list[PhoneCell]) -> list[PhoneCell]:
    """Drop duplicate entries Android may report for the same cell and blank the
    SINR of neighbour cells (modems only measure RSRP/RSRQ on neighbours; a 0
    there is a filler value, not a reading)."""
    best: dict[tuple, PhoneCell] = {}
    for c in cells:
        key = (c.tech, c.pci, c.arfcn, c.registered)
        old = best.get(key)
        if old is None:
            best[key] = c
            continue
        score = lambda x: sum(v is not None and v != 0 for v in (x.rsrp, x.rsrq, x.sinr))
        if score(c) > score(old):
            best[key] = c
    out = []
    for c in best.values():
        if not c.registered and c.sinr is not None:
            c = PhoneCell(c.tech, c.band, c.pci, c.arfcn, c.rsrp, c.rsrq, None, False)
        out.append(c)
    return out


def cell_kind(description: Any) -> str | None:
    """'CellInfoLte' / 'CellInfoNr' from a CellInfo's toString() or class name."""
    text = str(description or '')
    for kind in ('CellInfoLte', 'CellInfoNr'):
        if text.startswith(kind) or text.endswith(kind) or f'.{kind}' in text[:80]:
            return kind
    return None


def signal_level(rsrp: float | None) -> str | None:
    """'excellent' / 'good' / 'fair' / 'poor' from RSRP (dBm); None when unknown.

    Same thresholds as the signal bars of the cell cards."""
    if rsrp is None:
        return None
    if rsrp >= -90:
        return 'excellent'
    if rsrp >= -100:
        return 'good'
    if rsrp >= -108:
        return 'fair'
    return 'poor'


def main_cells(cells: list[PhoneCell]) -> list[PhoneCell]:
    """The cells the phone is registered on (4G anchor and, if any, 5G), strongest first."""
    return sorted((c for c in cells if c.registered),
                  key=lambda c: (c.tech == 'NR', -(c.rsrp if c.rsrp is not None else -999)))


def read_phone_operator() -> str | None:
    """Operator name shown by the phone (no extra permission); None when unavailable."""
    try:
        from jnius import autoclass  # type: ignore[import-not-found]
        activity = autoclass('org.kivy.android.PythonActivity').mActivity
        context = autoclass('android.content.Context')
        manager = activity.getSystemService(context.TELEPHONY_SERVICE)
        name = str(manager.getNetworkOperatorName() or '').strip()
        return name or None
    except Exception:
        return None


def _signal_only_cells(manager: Any) -> list[PhoneCell]:
    """Fallback when getAllCellInfo() is empty: the modem's own SignalStrength still carries
    RSRP/RSRQ/SINR (no band, channel or PCI). Shown as signal only."""
    from jnius import cast  # type: ignore[import-not-found]
    strength = manager.getSignalStrength()
    if strength is None:
        return []
    cells: list[PhoneCell] = []
    items = strength.getCellSignalStrengths()
    for i in range(items.size()):
        item = items.get(i)
        text = str(item.toString())
        try:
            if text.startswith('CellSignalStrengthLte'):
                sig = cast('android.telephony.CellSignalStrengthLte', item)
                cells.append(build_cell('LTE', pci=None, arfcn=None, rsrp=sig.getRsrp(),
                                        rsrq=sig.getRsrq(), sinr=sig.getRssnr(),
                                        registered=True))
            elif text.startswith('CellSignalStrengthNr'):
                sig = cast('android.telephony.CellSignalStrengthNr', item)
                cells.append(build_cell('NR', pci=None, arfcn=None, rsrp=sig.getSsRsrp(),
                                        rsrq=sig.getSsRsrq(), sinr=sig.getSsSinr(),
                                        registered=True))
        except Exception:
            continue
    return [c for c in cells if c.rsrp is not None or c.rsrq is not None or c.sinr is not None]


def add_missing_nr(cells: list[PhoneCell], extra: list[PhoneCell]) -> list[PhoneCell]:
    """NSA 5G is often missing from getAllCellInfo() although the modem reports its signal
    (SignalStrength). When the list has no NR cell, add the NR signal-only entry, if any."""
    if any(c.tech == 'NR' for c in cells):
        return cells
    return cells + [c for c in extra if c.tech == 'NR']


def is_signal_only(cell: PhoneCell) -> bool:
    """True for a cell that came from SignalStrength (no band / channel / PCI)."""
    return cell.band is None and cell.arfcn is None and cell.pci is None


def read_phone_cells() -> list[PhoneCell]:
    """Android only (pyjnius). Raises on any failure; the caller shows the reason."""
    from jnius import autoclass, cast  # type: ignore[import-not-found]
    activity = autoclass('org.kivy.android.PythonActivity').mActivity
    context = autoclass('android.content.Context')
    manager = activity.getSystemService(context.TELEPHONY_SERVICE)
    infos = manager.getAllCellInfo()
    if infos is None or infos.size() == 0:
        try:
            return _signal_only_cells(manager)
        except Exception:
            return []
    cells: list[PhoneCell] = []
    for i in range(infos.size()):
        info = infos.get(i)
        # toString() is "CellInfoLte:{...}" / "CellInfoNr:{...}" (pyjnius' Class proxy
        # does not expose getSimpleName).
        kind = cell_kind(info.toString())
        if kind is None:
            try:
                kind = cell_kind(info.getClass().getName())
            except Exception:
                kind = None
        try:
            if kind == 'CellInfoLte':
                obj = cast('android.telephony.CellInfoLte', info)
                ident, sig = obj.getCellIdentity(), obj.getCellSignalStrength()
                bands = list(ident.getBands()) if hasattr(ident, 'getBands') else None
                cells.append(build_cell(
                    'LTE', pci=ident.getPci(), arfcn=ident.getEarfcn(), rsrp=sig.getRsrp(),
                    rsrq=sig.getRsrq(), sinr=sig.getRssnr(), registered=obj.isRegistered(),
                    bands=bands))
            elif kind == 'CellInfoNr':
                obj = cast('android.telephony.CellInfoNr', info)
                ident = cast('android.telephony.CellIdentityNr', obj.getCellIdentity())
                sig = cast('android.telephony.CellSignalStrengthNr', obj.getCellSignalStrength())
                bands = list(ident.getBands()) if hasattr(ident, 'getBands') else None
                cells.append(build_cell(
                    'NR', pci=ident.getPci(), arfcn=ident.getNrarfcn(), rsrp=sig.getSsRsrp(),
                    rsrq=sig.getSsRsrq(), sinr=sig.getSsSinr(), registered=obj.isRegistered(),
                    bands=bands))
        except Exception:  # one odd cell must not hide the others
            continue
    if not cells:                       # cells were listed but none could be read
        try:
            return _signal_only_cells(manager)
        except Exception:
            return []
    cells = tidy_cells(cells)
    if not any(c.tech == 'NR' for c in cells):
        try:
            cells = add_missing_nr(cells, _signal_only_cells(manager))
        except Exception:
            pass
    return cells


_NR_RANGE_LABELS = {1: '< 1 GHz', 2: '1-3 GHz', 3: '3-6 GHz', 4: 'mmWave'}


def parse_nr_frequency_range(text: Any) -> int | None:
    """NR frequency range code (1 low, 2 mid, 3 high = 3-6 GHz, 4 mmWave) from a ServiceState
    description; None when the phone does not state it."""
    match = re.search(r'\bm?[Nn]rFrequencyRange\s*=\s*(\d+)', str(text or ''))
    if match is None:
        return None
    value = int(match.group(1))
    return value if value in _NR_RANGE_LABELS else None


def nr_range_label(code: int | None) -> str | None:
    return _NR_RANGE_LABELS.get(code) if code is not None else None


# Which 5G bands each Saudi operator uses, by the coarse range Android states (2 = 1-3 GHz,
# 3 = 3-6 GHz). From the operators' bands as seen in Samsung ServiceMode (*#0011#).
_PLMN_NR_BANDS: dict[str, dict[int, str]] = {
    '42001': {2: 'N40', 3: 'N78/N77'},      # STC
    '42003': {2: 'N41', 3: 'N77'},          # Mobily
    '42004': {2: 'N41', 3: 'N78'},          # Zain
}
_OPERATOR_NAMES: tuple[tuple[str, str], ...] = (
    ('stc', '42001'), ('اس تي سي', '42001'), ('mobily', '42003'), ('موبايلي', '42003'),
    ('zain', '42004'), ('زين', '42004'))


def estimate_nr_band(plmn: str | None, range_code: int | None,
                     operator_name: str | None = None) -> str | None:
    """Likely 5G band from the operator and the frequency range (an ESTIMATE, shown as such):
    used only when Android hides the real band. None when it cannot be told."""
    if range_code is None:
        return None
    code = re.sub(r'\D', '', str(plmn or ''))[:5]
    if code not in _PLMN_NR_BANDS and operator_name:
        low = operator_name.strip().lower()
        code = next((c for name, c in _OPERATOR_NAMES if name in low), code)
    bands = _PLMN_NR_BANDS.get(code)
    if bands is not None:
        return bands.get(range_code)
    return 'N78/N77' if range_code == 3 else None


def read_phone_plmn() -> str | None:
    """MCC+MNC of the network the phone is on (e.g. '42001'); None when unavailable."""
    try:
        from jnius import autoclass  # type: ignore[import-not-found]
        activity = autoclass('org.kivy.android.PythonActivity').mActivity
        context = autoclass('android.content.Context')
        manager = activity.getSystemService(context.TELEPHONY_SERVICE)
        code = str(manager.getNetworkOperator() or '').strip()
        return code or None
    except Exception:
        return None


def read_nr_frequency_range() -> int | None:
    """Frequency range of the 5G carrier as the phone's ServiceState states it (Android only).
    This is the only 5G channel information a normal app can get on phones whose modem
    does not list the NR cell: the band, channel and PCI stay unavailable."""
    try:
        from jnius import autoclass  # type: ignore[import-not-found]
        activity = autoclass('org.kivy.android.PythonActivity').mActivity
        context = autoclass('android.content.Context')
        manager = activity.getSystemService(context.TELEPHONY_SERVICE)
        state = manager.getServiceState()
        return None if state is None else parse_nr_frequency_range(state.toString())
    except Exception:
        return None


def phone_blockers() -> list[str]:
    """Why getAllCellInfo() may be empty: 'location_off', 'no_sim' (Android only, best effort)."""
    out: list[str] = []
    try:
        from jnius import autoclass  # type: ignore[import-not-found]
        activity = autoclass('org.kivy.android.PythonActivity').mActivity
        context = autoclass('android.content.Context')
        location = activity.getSystemService(context.LOCATION_SERVICE)
        if not location.isLocationEnabled():
            out.append('location_off')
        manager = activity.getSystemService(context.TELEPHONY_SERVICE)
        if int(manager.getSimState()) != 5:             # SIM_STATE_READY
            out.append('no_sim')
    except Exception:
        pass
    return out


def phone_report() -> str:
    """Plain-text diagnosis of why the phone may show no cells (Android only, best effort).
    Contains the phone model, permission and location state, SIM state and what the modem
    returned; cell identities are shortened. Meant to be copied and pasted to the developer."""
    lines: list[str] = []

    def add(label: str, getter: Any) -> None:
        try:
            lines.append(f"{label}: {getter()}")
        except Exception as exc:                 # every line is independent
            lines.append(f"{label}: ERROR {exc.__class__.__name__}: {str(exc)[:120]}")

    try:
        from jnius import autoclass  # type: ignore[import-not-found]
    except Exception as exc:
        return f"not Android ({exc.__class__.__name__})"
    build = autoclass('android.os.Build')
    version = autoclass('android.os.Build$VERSION')
    activity = autoclass('org.kivy.android.PythonActivity').mActivity
    context = autoclass('android.content.Context')
    add("device", lambda: f"{build.MANUFACTURER} {build.MODEL}")
    add("android", lambda: f"{version.RELEASE} (SDK {version.SDK_INT})")
    for name in ('ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'READ_PHONE_STATE'):
        add(f"permission {name}", lambda n=name: (
            'granted' if activity.checkSelfPermission(f'android.permission.{n}') == 0 else 'DENIED'))
    manager = activity.getSystemService(context.TELEPHONY_SERVICE)
    location = activity.getSystemService(context.LOCATION_SERVICE)
    add("location switch", lambda: 'on' if location.isLocationEnabled() else 'OFF')
    add("sim state (5 = ready)", lambda: manager.getSimState())
    add("phone count", lambda: manager.getPhoneCount())
    add("operator", lambda: manager.getNetworkOperatorName())
    add("data network type", lambda: manager.getDataNetworkType())

    def cells_text() -> str:
        infos = manager.getAllCellInfo()
        if infos is None:
            return "getAllCellInfo = null"
        out = [f"getAllCellInfo count = {infos.size()}"]
        for i in range(min(infos.size(), 12)):
            out.append("  " + str(infos.get(i).toString())[:260])
        return "\n".join(out)
    add("cells", cells_text)

    def service_text() -> str:
        state = manager.getServiceState()
        if state is None:
            return "null"
        text = str(state.toString())
        return f"nrFrequencyRange={parse_nr_frequency_range(text)}  " + text[:900]
    add("serviceState", service_text)

    def strength_text() -> str:
        strength = manager.getSignalStrength()
        return "null" if strength is None else str(strength.toString())[:900]
    add("signalStrength", strength_text)
    return "\n".join(lines)
