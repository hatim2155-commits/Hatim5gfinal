"""Speed test logic against a local fake speed server (no internet)."""
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from core import speed_test as st


class _Quiet(ThreadingHTTPServer):
    def handle_error(self, request, client_address):
        pass                      # clients close early on purpose


class _Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *a):
        pass

    def do_GET(self):
        n = int(parse_qs(urlparse(self.path).query).get('bytes', ['0'])[0])
        self.send_response(200)
        self.send_header('Content-Length', str(n))
        self.end_headers()
        sent = 0
        while sent < n:
            part = min(65536, n - sent)
            self.wfile.write(b'x' * part)
            sent += part

    def do_POST(self):
        n = int(self.headers.get('Content-Length', '0'))
        got = 0
        while got < n:
            data = self.rfile.read(min(65536, n - got))
            if not data:
                break
            got += len(data)
        self.send_response(200)
        self.send_header('Content-Length', '0')
        self.end_headers()


def _server():
    srv = _Quiet(('127.0.0.1', 0), _Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_address[1]}"


def test_gauge_fraction_is_monotonic_and_bounded():
    assert st.gauge_fraction(None) == 0.0
    assert st.gauge_fraction(0) == 0.0
    assert st.gauge_fraction(5000) == 1.0
    values = [1, 5, 8, 10, 30, 50, 86.4, 100, 300, 600, 999]
    fr = [st.gauge_fraction(v) for v in values]
    assert fr == sorted(fr) and 0 < fr[0] and fr[-1] < 1
    assert abs(st.gauge_fraction(50) - 4 / 8) < 1e-9
    assert abs(st.gauge_fraction(100) - 5 / 8) < 1e-9


def test_mbps_math():
    assert st.mbps(1_250_000, 1.0) == 10.0
    assert st.mbps(10, 0) == 0.0


def test_full_run_against_local_server():
    srv, url = _server()
    try:
        phases = []
        done = []
        result = st.run_speed_test(
            base_url=url, progress=lambda p, v, f: phases.append((p, v, f)),
            on_result=lambda p, v: done.append((p, v)), pause=0.0)
    finally:
        srv.shutdown()
    assert result.download_mbps and result.download_mbps > 1
    assert result.upload_mbps and result.upload_mbps > 1
    assert result.latency_ms is not None and result.latency_ms < 1000
    assert result.bytes_used > 0
    assert {'latency', 'download', 'upload'} <= {p for p, _v, _f in phases}
    assert all(0 <= f <= 1 for _p, _v, f in phases)
    assert [p for p, _v in done] == ['latency', 'download', 'upload']     # recorded in this order
    first = {p: i for i, (p, _v, _f) in reversed(list(enumerate(phases)))}
    assert first['latency'] < first['download'] < first['upload']


def test_cap_limits_bytes():
    srv, url = _server()
    try:
        _speed, used = st.measure_download(url, seconds=5, max_bytes=2_000_000)
    finally:
        srv.shutdown()
    assert used < 6_000_000        # stops soon after the cap (a few streams may overshoot)


def test_unreachable_server_raises_speed_error():
    try:
        st.measure_latency('http://127.0.0.1:9', tries=2, timeout=1.0)
    except st.SpeedError:
        return
    raise AssertionError("expected SpeedError")


def test_upload_failure_keeps_download():
    srv, url = _server()

    class Bad(_Handler):
        def do_POST(self):
            self.send_response(500)
            self.send_header('Content-Length', '0')
            self.end_headers()
    srv.shutdown()
    bad = _Quiet(('127.0.0.1', 0), Bad)
    threading.Thread(target=bad.serve_forever, daemon=True).start()
    try:
        r = st.run_speed_test(base_url=f"http://127.0.0.1:{bad.server_address[1]}", pause=0.0)
    finally:
        bad.shutdown()
    assert r.download_mbps is not None


def test_refused_large_requests_shrink_and_still_measure():
    class Picky(_Handler):
        def do_GET(self):
            n = int(parse_qs(urlparse(self.path).query).get('bytes', ['0'])[0])
            if n > 3_000_000:                      # like a server that refuses big single requests
                body = b'Forbidden'
                self.send_response(403)
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            super().do_GET()
    srv = _Quiet(('127.0.0.1', 0), Picky)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        speed, used = st.measure_download(f"http://127.0.0.1:{srv.server_address[1]}",
                                          seconds=2, max_bytes=20_000_000)
    finally:
        srv.shutdown()
    assert speed > 0 and used > 0


def test_http_error_shows_server_reason():
    class Denied(_Handler):
        def do_GET(self):
            self.send_response(403)
            self.send_header('Content-Length', '9')
            self.end_headers()
            self.wfile.write(b'Forbidden')
    srv = _Quiet(('127.0.0.1', 0), Denied)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        st.measure_latency(f"http://127.0.0.1:{srv.server_address[1]}", tries=2)
    except st.SpeedError as exc:
        assert 'HTTP 403' in str(exc)
    else:
        raise AssertionError("expected SpeedError")
    finally:
        srv.shutdown()
