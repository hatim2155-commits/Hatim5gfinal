"""Internet speed test: latency, download and upload against a public speed server.

It measures the network the phone is using at that moment (Wi-Fi to the router, or the
phone's own mobile data); the caller labels the result with :func:`active_network_kind`.
Traffic goes to a public test server (Cloudflare's speed endpoints) over verified HTTPS;
nothing is sent to the router and no band or router setting is touched. Every number is
measured; when the server cannot be reached :class:`SpeedError` is raised and the UI says so.
"""
from __future__ import annotations

import http.client
import os
import ssl
import threading
import time
from dataclasses import dataclass
from typing import Callable
from urllib.parse import urlparse

SERVER = 'https://speed.cloudflare.com'
_DOWN_PATH = '/__down?bytes={n}'
_UP_PATH = '/__up'
_CHUNK = 64 * 1024
_USER_AGENT = 'HATIM5G-speedtest'

# Gauge scale (Mbps), equally spaced like the usual speed-test dials.
GAUGE_TICKS: tuple[int, ...] = (0, 5, 10, 25, 50, 100, 250, 500, 1000)

# (download seconds, download byte cap, upload seconds, upload byte cap)
LIMITS_WIFI = (10.0, 130_000_000, 6.0, 25_000_000)
LIMITS_CELLULAR = (6.0, 30_000_000, 5.0, 10_000_000)

Progress = Callable[[str, float, float], None]      # phase, Mbps now, 0..1 of the phase


class SpeedError(Exception):
    """The speed server could not be reached or returned nothing."""


@dataclass(frozen=True)
class SpeedResult:
    download_mbps: float | None
    upload_mbps: float | None
    latency_ms: float | None
    bytes_used: int


def mbps(num_bytes: float, seconds: float) -> float:
    return 0.0 if seconds <= 0 else num_bytes * 8 / 1e6 / seconds


def gauge_fraction(value: float | None) -> float:
    """Needle position 0..1 for a speed in Mbps (piecewise linear between the ticks)."""
    if value is None or value <= 0:
        return 0.0
    ticks = GAUGE_TICKS
    if value >= ticks[-1]:
        return 1.0
    for i in range(1, len(ticks)):
        if value <= ticks[i]:
            low, high = ticks[i - 1], ticks[i]
            return ((i - 1) + (value - low) / (high - low)) / (len(ticks) - 1)
    return 1.0


MAX_REQUEST_BYTES = 10_000_000       # the size known to work; bigger single requests were refused


def _http_error(resp: http.client.HTTPResponse, body: bytes | None = None) -> str:
    """'HTTP 403 <start of the server's reply>' so the cause is visible, not only the code."""
    try:
        text = (body if body is not None else resp.read(160)).decode('utf-8', 'replace')
    except Exception:
        text = ''
    text = ' '.join(text.split())[:80]
    return f"HTTP {resp.status}" + (f" ({text})" if text else "")


def _connect(base_url: str, timeout: float) -> http.client.HTTPConnection:
    parts = urlparse(base_url)
    host, port = parts.hostname or '', parts.port
    if parts.scheme == 'https':
        try:
            import certifi
            ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            ctx = ssl.create_default_context()      # verification stays on either way
        return http.client.HTTPSConnection(host, port, timeout=timeout, context=ctx)
    return http.client.HTTPConnection(host, port, timeout=timeout)


def measure_latency(base_url: str = SERVER, tries: int = 6, timeout: float = 5.0,
                    on_sample: Callable[[float, float], None] | None = None) -> float:
    """Median round-trip time (ms) of tiny requests on one open connection.
    ``on_sample(ms, fraction)`` is called after every timed request."""
    times: list[float] = []
    try:
        conn = _connect(base_url, timeout)
        try:
            for i in range(tries):
                started = time.perf_counter()
                conn.request('GET', _DOWN_PATH.format(n=0), headers={'User-Agent': _USER_AGENT})
                resp = conn.getresponse()
                resp.read()
                if resp.status != 200:
                    raise SpeedError(_http_error(resp))
                if i:                                  # the first request pays the TLS handshake
                    times.append((time.perf_counter() - started) * 1000)
                    if on_sample is not None:
                        on_sample(times[-1], i / max(1, tries - 1))
        finally:
            conn.close()
    except (OSError, http.client.HTTPException) as exc:
        raise SpeedError(str(exc) or exc.__class__.__name__) from exc
    if not times:
        raise SpeedError("no latency samples")
    times.sort()
    return times[len(times) // 2]


class _Meter:
    """Thread-safe byte counter with a rolling speed over the last ~1 second."""

    def __init__(self, warmup: float) -> None:
        self.lock = threading.Lock()
        self.start = time.perf_counter()
        self.warmup = warmup
        self.total = 0
        self.counted = 0                   # bytes after the warm-up window
        self.counted_since: float | None = None
        self.samples: list[tuple[float, int]] = []
        self.errors: list[str] = []
        self.req_bytes = 10_000_000        # size of one download request; shrinks if refused

    def add(self, n: int) -> None:
        now = time.perf_counter()
        with self.lock:
            self.total += n
            if now - self.start >= self.warmup:
                if self.counted_since is None:
                    self.counted_since = now
                self.counted += n
            self.samples.append((now, self.total))
            cut = now - 1.0
            while len(self.samples) > 2 and self.samples[0][0] < cut:
                self.samples.pop(0)

    def now_mbps(self) -> float:
        with self.lock:
            if len(self.samples) < 2:
                return 0.0
            (t0, b0), (t1, b1) = self.samples[0], self.samples[-1]
            return mbps(b1 - b0, t1 - t0)

    def average_mbps(self) -> float:
        with self.lock:
            if self.counted_since is None:
                return 0.0
            return mbps(self.counted, time.perf_counter() - self.counted_since)


def _run(workers: int, target: Callable[[_Meter, float, int], None], meter: _Meter,
         seconds: float, cap: int, phase: str, progress: Progress | None) -> None:
    deadline = time.perf_counter() + seconds
    threads = [threading.Thread(target=target, args=(meter, deadline, cap), daemon=True)
               for _ in range(workers)]
    for th in threads:
        th.start()
    started = time.perf_counter()
    while any(th.is_alive() for th in threads):
        time.sleep(0.1)
        if progress is not None:
            done = max((time.perf_counter() - started) / seconds, meter.total / cap)
            progress(phase, meter.now_mbps(), min(1.0, done))
    for th in threads:
        th.join(timeout=1.0)


def measure_download(base_url: str = SERVER, seconds: float = 8.0, max_bytes: int = 80_000_000,
                     streams: int = 4, progress: Progress | None = None,
                     timeout: float = 8.0) -> tuple[float, int]:
    """Returns (average Mbps after a 1 s warm-up, bytes downloaded)."""
    meter = _Meter(warmup=min(1.0, seconds / 4))
    meter.req_bytes = min(MAX_REQUEST_BYTES, max(1_000_000, max_bytes // (streams * 2)))

    def worker(m: _Meter, deadline: float, cap: int) -> None:
        try:
            conn = _connect(base_url, timeout)
            try:
                while time.perf_counter() < deadline and m.total < cap:
                    conn.request('GET', _DOWN_PATH.format(n=m.req_bytes),
                                 headers={'User-Agent': _USER_AGENT})
                    resp = conn.getresponse()
                    if resp.status in (403, 413, 429) and m.req_bytes > 1_000_000:
                        resp.read()                 # refused: ask for a smaller piece next time
                        with m.lock:
                            m.req_bytes = max(1_000_000, m.req_bytes // 2)
                        time.sleep(0.2)
                        continue
                    if resp.status != 200:
                        raise SpeedError(_http_error(resp))
                    while time.perf_counter() < deadline and m.total < cap:
                        data = resp.read(_CHUNK)
                        if not data:
                            break
                        m.add(len(data))
                    else:
                        return                      # time or cap reached mid-response
            finally:
                conn.close()
        except (OSError, http.client.HTTPException, SpeedError) as exc:
            m.errors.append(str(exc) or exc.__class__.__name__)

    _run(streams, worker, meter, seconds, max_bytes, 'download', progress)
    if meter.total == 0:
        raise SpeedError(meter.errors[0] if meter.errors else "no data received")
    return meter.average_mbps() or mbps(meter.total, seconds), meter.total


def measure_upload(base_url: str = SERVER, seconds: float = 6.0, max_bytes: int = 25_000_000,
                   streams: int = 3, progress: Progress | None = None,
                   timeout: float = 8.0) -> tuple[float, int]:
    """Returns (average Mbps after a short warm-up, bytes uploaded)."""
    meter = _Meter(warmup=min(1.0, seconds / 4))
    block = os.urandom(_CHUNK)
    per_request = max(1_000_000, max_bytes // (streams * 3))

    def worker(m: _Meter, deadline: float, cap: int) -> None:
        try:
            conn = _connect(base_url, timeout)
            try:
                while time.perf_counter() < deadline and m.total < cap:
                    conn.putrequest('POST', _UP_PATH)
                    conn.putheader('User-Agent', _USER_AGENT)
                    conn.putheader('Content-Type', 'application/octet-stream')
                    conn.putheader('Content-Length', str(per_request))
                    conn.endheaders()
                    sent = 0
                    while sent < per_request:
                        if time.perf_counter() >= deadline or m.total >= cap:
                            return                  # stop; the connection is dropped
                        n = min(_CHUNK, per_request - sent)
                        conn.send(block[:n])
                        sent += n
                        m.add(n)
                    resp = conn.getresponse()
                    body = resp.read(160)
                    if resp.status >= 400:
                        raise SpeedError(_http_error(resp, body))
            finally:
                conn.close()
        except (OSError, http.client.HTTPException, SpeedError) as exc:
            m.errors.append(str(exc) or exc.__class__.__name__)

    _run(streams, worker, meter, seconds, max_bytes, 'upload', progress)
    if meter.total == 0:
        raise SpeedError(meter.errors[0] if meter.errors else "nothing could be sent")
    return meter.average_mbps() or mbps(meter.total, seconds), meter.total


def run_speed_test(*, cellular: bool = False, base_url: str = SERVER,
                   progress: Progress | None = None,
                   on_result: Callable[[str, float | None], None] | None = None,
                   cancelled: Callable[[], bool] | None = None,
                   pause: float = 0.6) -> SpeedResult:
    """Latency first, then download, then upload (the dial returns to zero between them).

    ``progress(phase, value, fraction)`` runs while a phase is measuring (value = ms for
    'latency', Mbps for the others); ``on_result(phase, value)`` runs once when a phase is
    finished, so the UI can record it before the next phase starts. An upload failure still
    returns the latency and the download."""
    dl_s, dl_cap, ul_s, ul_cap = LIMITS_CELLULAR if cellular else LIMITS_WIFI

    def sample(ms: float, fraction: float) -> None:
        if progress is not None:
            progress('latency', ms, fraction)

    latency = round(measure_latency(base_url, on_sample=sample), 1)
    if on_result is not None:
        on_result('latency', latency)
    time.sleep(pause)
    down, used_down = measure_download(base_url, dl_s, dl_cap, progress=progress)
    down = round(down, 1)
    if on_result is not None:
        on_result('download', down)
    up: float | None = None
    used_up = 0
    if cancelled is None or not cancelled():
        time.sleep(pause)
        try:
            up, used_up = measure_upload(base_url, ul_s, ul_cap, progress=progress)
            up = round(up, 1)
        except SpeedError:
            up = None                                  # shown as «غير متوفر»
        if on_result is not None:
            on_result('upload', up)
    return SpeedResult(down, up, latency, used_down + used_up)


def active_network_kind() -> str | None:
    """'wifi', 'cellular', 'ethernet', 'vpn' or None (unknown / not Android)."""
    try:
        from jnius import autoclass  # type: ignore[import-not-found]
        activity = autoclass('org.kivy.android.PythonActivity').mActivity
        context = autoclass('android.content.Context')
        manager = activity.getSystemService(context.CONNECTIVITY_SERVICE)
        network = manager.getActiveNetwork()
        if network is None:
            return None
        caps = manager.getNetworkCapabilities(network)
        if caps is None:
            return None
        for transport, name in ((1, 'wifi'), (0, 'cellular'), (3, 'ethernet'), (4, 'vpn')):
            if caps.hasTransport(transport):
                return name
    except Exception:
        return None
    return None
