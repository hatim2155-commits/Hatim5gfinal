Bottom navigation icon assets for HATIM5G.
Files are transparent PNG, 128x128 px, suitable for Kivy Image widgets and Android packaging.
ic_theme.png, ic_info.png, ic_network.png, ic_readings.png, ic_antenna.png, ic_home.png
These assets are included in the project; the KV navigation buttons still need to be wired to Image widgets to display them.
