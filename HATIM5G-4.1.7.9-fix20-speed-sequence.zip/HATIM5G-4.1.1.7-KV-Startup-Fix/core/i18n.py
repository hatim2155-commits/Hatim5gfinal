"""
Простая система локализации для Hua4GMon.

Подход «русский-как-ключ»:
    * исходные строки в коде остаются на русском и используются как ключи;
    * для английского хранится словарь RU → EN;
    * если перевода нет — возвращается сам ключ (русский), ничего не падает.

Это позволяет добавить второй язык в уже существующий русский UI с
минимальным риском: достаточно обернуть строку в t("..."), а её перевод
добавить в EN ниже. Отсутствие перевода не ломает интерфейс.

Модуль НЕ зависит от Tkinter/Kivy — пригоден и для Windows, и для Android.

Использование:
    from core.i18n import t, set_language, current_language

    set_language("en")
    label = t("Подключиться")        # -> "Connect"

Строки с подстановкой переводятся как шаблоны:
    t("Отличный сигнал ({pct}%)").format(pct=90)
"""
from __future__ import annotations

# Поддерживаемые языки: код → человекочитаемое имя (для меню выбора).
LANGUAGES: dict[str, str] = {
    "ar": "العربية",
    "en": "English",
}

_DEFAULT_LANG = "ar"
_current_lang = _DEFAULT_LANG

# RU → EN. Ключ — исходная русская строка (ровно как в коде).
# Если строки здесь нет, t() вернёт ключ (т.е. русский вариант).
EN: dict[str, str] = {
    "القراءات": "Readings",
    "وزن الأنتينا": "Antenna alignment",
    "قراءات 4G LTE": "4G LTE readings",
    "ترددات 5G المدعومة للعرض": "5G bands available for display",
    "قفل ترددات 5G غير مدعوم بعد عبر واجهة الراوتر الحالية؛ لن يتم إرسال أوامر قفل غير مؤكدة.": "5G band locking is not yet supported by the current router API; unverified lock commands will not be sent.",
    "إشارة ممتازة": "Excellent signal",
    "إشارة متوسطة": "Fair signal",
    "إشارة ضعيفة": "Weak signal",
    "معرّف الخلية": "Cell ID",
    "الدمج الفعلي": "Active aggregation",
    "رئيسي": "Primary",
    "ثانوي": "Secondary",
    "قراءات 5G NR": "5G NR readings",
    "الدمج الفعلي الحالي": "Current active aggregation",
    "تعرض الصفحة القيم التي يوفرها الراوتر فقط. قد لا تتوفر قياسات مستقلة لكل حامل ثانوي.": "This page shows only values provided by the router. Independent readings may not be available for each secondary carrier.",
    "لا توجد بيانات بعد. اتصل بالراوتر أولًا.": "No readings yet. Connect to the router first.",
    "لا توجد بيانات 5G بعد.": "No 5G readings yet.",
    "اتصال 5G غير ظاهر حاليًا.": "No active 5G connection is currently reported.",
    "لم يوفر الراوتر تفاصيل الدمج.": "The router did not provide aggregation details.",
    "الباند الرئيسي: {band}": "Primary band: {band}",
    "PCI: {value}": "PCI: {value}",
    "EARFCN: {value}": "EARFCN: {value}",
    "التردد الهابط: {value}": "Downlink frequency: {value}",
    "RSRP: {rsrp}  |  RSRQ: {rsrq}": "RSRP: {rsrp}  |  RSRQ: {rsrq}",
    "SINR: {sinr}  |  RSSI: {rssi}": "SINR: {sinr}  |  RSSI: {rssi}",
    "عرض النطاق الحالي: {value}": "Current bandwidth: {value}",
    "الحوامل التي أبلغ عنها الراوتر:": "Carriers reported by the router:",
    "رئيسي": "Primary",
    "ثانوي": "Secondary",
    "{role}: {band} — {width} — EARFCN {channel}": "{role}: {band} — {width} — EARFCN {channel}",
    "الباند: {value}": "Band: {value}",
    "PCI الخاص بـ NR: {value}": "NR PCI: {value}",
    "NR-ARFCN: {value}": "NR-ARFCN: {value}",
    "SINR: {value}": "SINR: {value}",
    "عرض النطاق: {value}": "Bandwidth: {value}",
    "حفظ بيانات الراوتر على هذا الجهاز": "Save router details on this device",
    "إعدادات الأنتينا": "Antenna settings",
    # --- Ядро (core): статусы сигнала, ошибки, RF-подсказки, Band Lock, белые списки ---
    "1 поток":
        "1 stream",
    "2 потока":
        "2 streams",
    "DNS не отвечает":
        "DNS not responding",
    "TCP есть, TLS оборван ({reason})":
        "TCP ok, TLS dropped ({reason})",
    "Авто":
        "Auto",
    "МБ":
        "MB",
    "Мбит/с":
        "Mbit/s",
    ("Не удалось прочитать настройки модема — запись отменена, модем "
     "не изменён. Повторите через несколько секунд."):
        ("Could not read the modem settings — nothing was written, the modem "
         "is unchanged. Try again in a few seconds."),
    "Агрегация пропадёт: не выбраны {bands}.":
        "Carrier aggregation will stop: {bands} not selected.",
    "Аномалия":
        "Anomaly",
    "Белые списки ВЫКЛЮЧЕНЫ":
        "Whitelist OFF",
    "Внешняя":
        "External",
    "Внутренняя":
        "Internal",
    "Загрузка/помехи":
        "Load/interference",
    "Идеальный":
        "Ideal",
    "Критичный":
        "Critical",
    ("Модем передаёт почти на максимуме мощности: отдача ограничена — нужна "
     "антенна точнее или выше."):
        ("The modem transmits near maximum power: upload is limited — aim the "
         "antenna better or mount it higher."),
    "Н/Д":
        "N/A",
    "Неверное имя пользователя.":
        "Wrong username.",
    "Неверный логин или пароль. Пароль — на наклейке роутера.":
        "Wrong username or password. The password is on the router's label.",
    "Неверный пароль.":
        "Wrong password.",
    ("Нейтральные сайты доступны, но «белые» не отвечают. Скорее всего, вы "
     "вышли в интернет не через 4G (другой Wi-Fi, провод, VPN). "
     "Подключитесь к Wi-Fi роутера и повторите."):
        ("Neutral sites are reachable but whitelisted ones are not. You are "
         "likely online not via 4G (another Wi-Fi, cable, VPN). Connect to the "
         "router's Wi-Fi and retry."),
    "Нет данных":
        "No data",
    "Нет интернета":
        "No internet",
    "Нет сети":
        "No service",
    ("Ни одна цель не отвечает. Либо у роутера нет связи с БС, либо "
     "проблема с DNS/маршрутом. Проверьте RSRP и трафик."):
        ("No target responds. Either the router has no cell link, or there is a "
         "DNS/route problem. Check RSRP and traffic."),
    "Нормальный":
        "Normal",
    ("Обычный режим — открыт весь интернет (белых: {w}/{wt}, нейтральных: "
     "{n}/{nt})."):
        ("Normal mode — full internet is open (whitelisted: {w}/{wt}, neutral: "
         "{n}/{nt})."),
    "Отличный":
        "Excellent",
    "Отличный сигнал ({pct}%)":
        "Excellent signal ({pct}%)",
    "Очень слабый":
        "Very weak",
    "Плохой":
        "Poor",
    "Потоки MIMO неравны: проверьте разъёмы и кабели обоих портов.":
        "MIMO streams are unequal: check connectors and cables of both ports.",
    "Похоже на фильтрацию по SNI: TCP проходит, TLS — нет.":
        "Looks like SNI filtering: TCP passes, TLS does not.",
    ("Работает один поток MIMO: проверьте второй кабель и поляризацию "
     "второго порта."):
        ("Only one MIMO stream is active: check the second cable and the second "
         "port's polarization."),
    ("Разрешённые сайты отвечают, а нейтральные — нет (белых: {w}/{wt}, "
     "нейтральных: 0/{nt}). Похоже на режим белых списков оператора. Для "
     "точности проверьте открытие обычного сайта в браузере."):
        ("Allowed sites respond but neutral ones do not (whitelisted: {w}/{wt}, "
         "neutral: 0/{nt}). Looks like the operator's whitelist mode. To be "
         "sure, try opening a regular site in a browser."),
    "Роутер занят — повторите через несколько секунд.":
        "Router is busy — retry in a few seconds.",
    "Роутер не отвечает: проверьте подключение к его Wi-Fi/USB и IP-адрес.":
        "Router is not responding: check the Wi-Fi/USB link and the IP address.",
    "Роутер требует сменить пароль — сделайте это в веб-интерфейсе.":
        "The router requires a password change — do it in the web interface.",
    "Сессия истекла — нужно войти заново.":
        "Session expired — log in again.",
    "Сессия устарела — нужно войти заново.":
        "Session is stale — log in again.",
    "Сигнал «гуляет»: проверьте крепление антенны и переотражения.":
        "The signal fluctuates: check the antenna mount and reflections.",
    ("Сигнал чистый, но слабый: поднимите антенну выше, возьмите антенну с "
     "большим усилением или укоротите кабель."):
        ("Signal is clean but weak: mount the antenna higher, use a higher-gain "
         "antenna or a shorter cable."),
    "Сильный":
        "Strong",
    "Слабый":
        "Weak",
    "Слабый сигнал — ищите лучше ({pct}%)":
        "Weak signal — look for a better spot ({pct}%)",
    ("Слишком много неудачных попыток входа — роутер временно заблокировал "
     "вход. Подождите несколько минут и проверьте пароль."):
        ("Too many failed login attempts — the router has temporarily blocked "
         "logins. Wait a few minutes and check the password."),
    "Смешанная":
        "Mixed",
    "Сота загружена: сравните с соседней сотой или другим бэндом.":
        "The cell is loaded: compare with a neighbor cell or another band.",
    "Средний":
        "Fair",
    "Средний сигнал — крутите антенну ({pct}%)":
        "Fair signal — adjust the antenna ({pct}%)",
    ("Текущий бэнд B{band} исключён — связь пропадёт до перерегистрации "
     "модема."):
        ("The current band B{band} is excluded — the link will drop until the "
         "modem re-registers."),
    ("Уже выполнен вход с другого устройства — закройте веб-интерфейс "
     "роутера и повторите."):
        ("Already logged in from another device — close the router's web "
         "interface and retry."),
    ("Уровень есть, но много помех: сместите азимут, попробуйте другой "
     "сектор или проверьте поляризацию."):
        ("Level is fine but interference is high: shift the azimuth, try "
         "another sector or check polarization."),
    "Функция не поддерживается этой моделью или прошивкой.":
        "Not supported by this model or firmware.",
    "Хороший":
        "Good",
    "Хороший сигнал ({pct}%)":
        "Good signal ({pct}%)",
    "Шумный":
        "Noisy",
    "на пределе":
        "at the limit",
    "норма":
        "normal",
    "ошибка ({code})":
        "error ({code})",
    "повышенная":
        "elevated",
    "потоки неравны":
        "streams unequal",
    "соединение отклонено":
        "connection refused",
    "соединение сброшено":
        "connection reset",
    "таймаут":
        "timeout",
    "⚠ Вероятна фильтрация (белые списки)":
        "⚠ Filtering likely (whitelist)",

    # --- Общие строки Windows и Android ---
    "Band Lock применён: {bands}.":
        "Band Lock applied: {bands}.",
    "CQI (потоки)":
        "CQI (streams)",
    "Cell (Локальный сектор)":
        "Cell (local sector)",
    "EARFCN (канал DL)":
        "EARFCN (DL channel)",
    "ICCID (SIM-карта)":
        "ICCID (SIM card)",
    "IMEI (роутер)":
        "IMEI (router)",
    "IP адрес:":
        "IP address:",
    "RSRP мин / макс":
        "RSRP min / max",
    "SIM / Устройство":
        "SIM / Device",
    "SINR мин / макс":
        "SINR min / max",
    "TAC (зона)":
        "TAC (area)",
    "eNodeB (Вышка)":
        "eNodeB (Tower)",
    "{at} смена соты: {old} → {new}":
        "{at} cell change: {old} → {new}",
    "Агрегация (CA)":
        "Aggregation (CA)",
    "Активна":
        "Active",
    "ВЫКЛЮЧЕНЫ":
        "OFF",
    "Включаю все бэнды…":
        "Enabling all bands…",
    "Включены все бэнды (AUTO).":
        "All bands enabled (AUTO).",
    "Восстанавливаю настройки…":
        "Restoring settings…",
    "Восстановлены настройки, прочитанные при подключении.":
        "Settings read at connection time have been restored.",
    "Время сессии":
        "Session time",
    "Выберите хотя бы один диапазон!":
        "Select at least one band!",
    "Зафиксировать бэнды: {bands}?":
        "Lock bands: {bands}?",
    "Информация о станции":
        "Cell info",
    "Исходные настройки не прочитаны — роутер не отдал net-mode.":
        "Original settings were not read — the router did not return net-mode.",
    "Ищу роутер…":
        "Looking for the router…",
    ("Команда отправлена, но роутер не подтвердил запись — проверьте "
     "строку «Сейчас на модеме»."):
        ("Command sent, but the router did not confirm the change — check the "
         "“Now on the modem” line."),
    "Лучшие соты за сессию":
        "Best cells this session",
    "МГц":
        "MHz",
    "Мобильные данные":
        "Mobile data",
    "Мобильные данные на роутере выключены.":
        "Mobile data is turned off on the router.",
    "Модель":
        "Model",
    "Модем перерегистрируется в сети (до ~30 с).":
        "The modem is re-registering on the network (up to ~30 s).",
    "Модуляция DL / UL":
        "Modulation DL / UL",
    "Мощность передатчика":
        "TX power",
    "Найден роутер {model} на {ip}":
        "Found router {model} at {ip}",
    "Накапливаю данные...":
        "Collecting data...",
    ("Не удалось включить мобильные данные — включите их в веб-интерфейсе "
     "роутера."):
        ("Could not turn mobile data back on — enable it in the router's web "
         "interface."),
    ("Неверный IP-адрес: {ip}\n"
     "Пример: 192.168.8.1"):
        ("Invalid IP address: {ip}\n"
         "Example: 192.168.8.1"),
    "Неизвестный оператор":
        "Unknown operator",
    "Неизвестный режим антенны.":
        "Unknown antenna mode.",
    "Нет":
        "No",
    "Нет связи с роутером — переподключаюсь…":
        "No link to the router — reconnecting…",
    "Номер телефона":
        "Phone number",
    "Оператор (PLMN)":
        "Operator (PLMN)",
    "Отдано за сессию":
        "Uploaded this session",
    "Отметить текущие":
        "Mark current",
    "Отмечены текущие бэнды: {bands}":
        "Current bands marked: {bands}",
    "Отправляю команду перезагрузки…":
        "Sending the reboot command…",
    "Ошибка":
        "Error",
    "Пароль:":
        "Password:",
    ("Перезагрузить роутер?\n"
     "\n"
     "Соединение с интернетом прервётся на 1–2 минуты. Программа "
     "переподключится автоматически."):
        ("Reboot the router?\n"
         "\n"
         "The internet connection will drop for 1–2 minutes. The app will "
         "reconnect automatically."),
    "Переключаю антенну…":
        "Switching the antenna…",
    "Переключение антенн":
        "Antenna switching",
    "Переподключаю связь…":
        "Reconnecting the link…",
    ("Переподключить мобильную связь?\n"
     "\n"
     "Интернет пропадёт примерно на 5–10 секунд."):
        ("Reconnect the mobile link?\n"
         "\n"
         "The internet will drop for about 5–10 seconds."),
    "Пик: {v} (Δ {d})":
        "Peak: {v} (Δ {d})",
    "Подключение и частые ошибки":
        "Connection & common errors",
    "Подключение...":
        "Connecting...",
    "Проверка занимает несколько секунд.":
        "The check takes a few seconds.",
    "Подтверждение":
        "Confirm",
    "Применить":
        "Apply",
    "Применить Band Lock":
        "Apply Band Lock",
    "Применяю Band Lock…":
        "Applying Band Lock…",
    "Проверка…":
        "Checking…",
    "Прошивка":
        "Firmware",
    "Рабочий Band (LTE)":
        "Working band (LTE)",
    "Режим MIMO":
        "MIMO mode",
    "Режим сети будет «только 4G».":
        "Network mode will be “4G only”.",
    "Если у модема нет 5G, режим сети будет «только 4G».":
        "If the modem has no 5G, the network mode will be “4G only”.",
    "Роутер не найден. Проверьте подключение к его Wi-Fi/USB.":
        "Router not found. Check the connection to its Wi-Fi/USB.",
    "Команда не выполнена: {err}":
        "Command failed: {err}",
    "Роутер перезагружается — переподключусь автоматически.":
        "The router is rebooting — I will reconnect automatically.",
    "Роутер принял команду, но сообщает другой режим антенны.":
        "The router accepted the command but reports a different antenna mode.",
    "Связь переподключена.":
        "Link reconnected.",
    "Сейчас на модеме: AUTO (все бэнды)":
        "Now on the modem: AUTO (all bands)",
    "Сейчас на модеме: {bands}":
        "Now on the modem: {bands}",
    "Сейчас на модеме: не прочитано":
        "Now on the modem: not read",
    "Сектор антенны (PCI)":
        "Antenna sector (PCI)",
    "Серийный номер":
        "Serial number",
    "Скачано за сессию":
        "Downloaded this session",
    "Скорость (Download)":
        "Speed (Download)",
    "Скорость (Upload)":
        "Speed (Upload)",
    "Сначала подключитесь к роутеру.":
        "Connect to the router first.",
    "Собираю диагностику…":
        "Collecting diagnostics…",
    "Текущий бэнд ещё не определён.":
        "The current band is not known yet.",
    "Температура чипа":
        "Chip temperature",
    "Технология":
        "Technology",
    "Тип антенны изменён: {mode}":
        "Antenna type changed: {mode}",
    "Трафик за месяц (↓/↑)":
        "Monthly traffic (↓/↑)",
    "Управление роутером":
        "Router management",
    "Фиксация частот (Band Lock)":
        "Band Lock",
    "Частота DL":
        "DL frequency",
    "Ширина канала":
        "Channel width",
    "Язык:":
        "Language:",
    "включены":
        "on",
    "нет свежих данных":
        "no fresh data",
    "последние {n} точек":
        "last {n} points",
    "الجهاز ليس راوتر هواوي.":
        "This device is not a Huawei router.",
    "⚠ Данные устарели — нет ответа {s:.0f} с":
        "⚠ Data is stale — no response for {s:.0f} s",
    "⚪ Нейтральные":
        "⚪ Neutral",
    "✅ В белых списках":
        "✅ In whitelist",
    "📶 Переподключить связь":
        "📶 Reconnect link",
    "🔄 Перезагрузить роутер":
        "🔄 Reboot router",
    "🧪 ДЕМО · азимут {a}":
        "🧪 DEMO · azimuth {a}",
    "🧪 Тестовый режим":
        "🧪 Test mode",

    # --- Windows (main.py) ---
    ("IP по умолчанию: 192.168.8.1 (для B315/B525 — 192.168.1.1 или "
     "192.168.3.1) — кнопка «Найти роутер» проверит их сама. Логин: admin, "
     "пароль — на наклейке роутера.\n"
     "\n"
     "Частые ошибки и что делать:\n"
     "• 108006 — неверный логин или пароль.\n"
     "• 108007 — слишком много неудачных попыток: роутер временно "
     "заблокировал вход. Подождите несколько минут.\n"
     "• 108003 — уже выполнен вход с другого устройства. Закройте "
     "веб-интерфейс роутера.\n"
     "• 100002 — функция не поддерживается этой моделью или прошивкой. "
     "Часть возможностей будет недоступна — это нормально.\n"
     "• 100003 / 125002 / 125003 — истекла сессия. Программа войдёт заново "
     "сама.\n"
     "• Нет ответа — проверьте, что компьютер подключён к Wi-Fi или USB "
     "именно этого роутера и IP введён верно.\n"
     "\n"
     "Тестовый режим показывает работу программы без роутера."):
        ("Default IP: 192.168.8.1 (B315/B525: 192.168.1.1 or 192.168.3.1) — the "
         "“Find router” button checks them automatically. Login: admin, the "
         "password is on the router's label.\n"
         "\n"
         "Common errors and what to do:\n"
         "• 108006 — wrong username or password.\n"
         "• 108007 — too many failed attempts: the router has temporarily "
         "blocked logins. Wait a few minutes.\n"
         "• 108003 — already logged in from another device. Close the router's "
         "web interface.\n"
         "• 100002 — not supported by this model or firmware. Some features "
         "will be unavailable — this is normal.\n"
         "• 100003 / 125002 / 125003 — session expired. The app logs in again "
         "by itself.\n"
         "• No response — make sure the computer is connected to this router's "
         "Wi-Fi or USB and the IP is correct.\n"
         "\n"
         "Test mode shows how the app works without a router."),
    "[ESC] или F11 — выход":
        "[ESC] or F11 — exit",
    ("«Переподключить связь» выключает и включает мобильные данные: модем "
     "заново выбирает лучшую соту — быстрее перезагрузки. После "
     "перезагрузки программа переподключится сама."):
        ("“Reconnect link” turns mobile data off and on: the modem picks the "
         "best cell again — faster than a reboot. After a reboot the app "
         "reconnects by itself."),
    "Авто-переподключение при обрыве":
        "Auto-reconnect on drop",
    "Бэнд":
        "Band",
    "Вердикт":
        "Verdict",
    "Внимание":
        "Warning",
    "Все бэнды (AUTO)":
        "All bands (AUTO)",
    "График и стрелка:":
        "Graph and arrow:",
    "Джиттер: -":
        "Jitter: -",
    "Джиттер: {j:.1f} dB":
        "Jitter: {j:.1f} dB",
    "Диагностика сохранена: {path}. Личные номера замаскированы.":
        "Diagnostics saved: {path}. Personal identifiers are masked.",
    "Замеров":
        "Samples",
    "Лог сессии пуст. Подключитесь и подождите, пока соберутся данные.":
        "Session log is empty. Connect and wait for data to accumulate.",
    "Лучший RSRP":
        "Best RSRP",
    "Лучший SINR":
        "Best SINR",
    "Мониторинг железа и трафика":
        "Hardware & traffic monitor",
    "Не открыть браузер: {e}":
        "Cannot open browser: {e}",
    "Не проверялось":
        "Not tested",
    "Не удалось записать файл: {e}":
        "Failed to write file: {e}",
    "Недостаточно данных о вышке (нужны PLMN и eNodeB).":
        "Not enough cell data (PLMN and eNodeB required).",
    "Общее качество связи":
        "Overall link quality",
    "Опрос (сек):":
        "Polling (sec):",
    "Отключено":
        "Disconnected",
    "Параметры роутера":
        "Router settings",
    "Перед проверкой":
        "Before testing",
    "Пик: -":
        "Peak: -",
    "Нет свежих данных":
        "No fresh data",
    "Поверх окон":
        "Always on top",
    "Построение окна…":
        "Building the window…",
    "Подключено":
        "Connected",
    "Подключитесь к роутеру":
        "Connect to the router",
    "Режим:":
        "Mode:",
    "Сбросить пики (Ctrl+R)":
        "Reset peaks (Ctrl+R)",
    "Связь с роутером потеряна":
        "Connection to the router lost",
    "Сейчас на модеме: -":
        "Now on the modem: -",
    "Сигнал стабилен — зафиксируйте антенну":
        "Signal stable — fix the antenna",
    "Сигнал улучшается — продолжайте в том же направлении":
        "Signal improving — keep turning that way",
    "Сигнал ухудшается — поверните обратно":
        "Signal getting worse — turn back",
    ("Сохранено {n} записей в:\n"
     "{path}"):
        ("Saved {n} records to:\n"
         "{path}"),
    "Тенденция {param} (поворачивайте антенну)":
        "{param} trend (turn the antenna)",
    ("Фиксация бэндов привязывает модем к выбранным частотам. Список взят "
     "из модема; замеченные в эфире бэнды — первыми. Перед записью "
     "программа читает текущие настройки и меняет только LTE-бэнды; "
     "«Вернуть как было» восстановит настройки, прочитанные при подключении."):
        ("Band locking ties the modem to the selected frequencies. The list "
         "comes from the modem; bands seen on air come first. Before writing, "
         "the app reads the current settings and changes only the LTE bands; "
         "“Restore as before” brings back the settings read at connection time."),
    "Экспорт":
        "Export",
    "не проверено":
        "not tested",
    "пик {v}":
        "peak {v}",
    "↩ Вернуть как было":
        "↩ Restore as before",
    "⏹ Отключиться":
        "⏹ Disconnect",
    "⚙️ Подключение":
        "⚙️ Connection",
    ("⚠ Ноутбук должен быть подключён к Wi-Fi или USB именно этого роутера "
     "— иначе тест измерит чужой канал.\n"
     "• Применимо только для РФ."):
        ("⚠ The laptop must be connected to the Wi-Fi or USB of this exact "
         "router — otherwise the test measures a different link.\n"
         "• Applies to Russia only."),
    "🎛️ Сеть":
        "🎛️ Network",
    "💾 Экспорт CSV":
        "💾 Export CSV",
    "📈 Монитор":
        "📈 Monitor",
    "📊 Состояние":
        "📊 Status",
    "🔊 Аудио (ОС не поддерживается)":
        "🔊 Audio (OS not supported)",
    "🔊 Звук (Ctrl+M)":
        "🔊 Sound (Ctrl+M)",
    "🔍 Проверить сейчас":
        "🔍 Check now",
    "🔎 Найти роутер":
        "🔎 Find router",
    "🖥 Крышный режим (F11)":
        "🖥 Roof mode (F11)",
    "🗺 Открыть на CellMapper":
        "🗺 Open in CellMapper",
    "🗼 Вышка":
        "🗼 Tower",
    "🚀 Подключиться":
        "🚀 Connect",
    "🛡 Белые списки (РФ)":
        "🛡 Whitelist (RU)",
    "🧾 Сохранить диагностику":
        "🧾 Save diagnostics",

    # --- Android (android_main.py) ---
    "В белых списках:":
        "Whitelisted:",
    "ДЕМО · азимут {a}":
        "DEMO · azimuth {a}",
    "Найти":
        "Find",
    "Нейтральные:":
        "Neutral:",
    "Переподключить связь":
        "Reconnect link",
    "Скопировать диагностику":
        "Copy diagnostics",
    "Тестовый режим":
        "Test mode",
    "♪ Звук":
        "♪ Sound",
    "⚙ Сеть":
        "⚙ Network",
    ("IP по умолчанию: 192.168.8.1 (для B315/B525 — 192.168.1.1 или "
     "192.168.3.1) — кнопка «Найти» проверит их сама. Логин: admin, пароль "
     "— на наклейке роутера.\n"
     "\n"
     "Частые ошибки и что делать:\n"
     "• 108006 — неверный логин или пароль.\n"
     "• 108007 — слишком много неудачных попыток: роутер временно "
     "заблокировал вход. Подождите несколько минут.\n"
     "• 108003 — уже выполнен вход с другого устройства. Закройте "
     "веб-интерфейс роутера.\n"
     "• 100002 — функция не поддерживается этой моделью или прошивкой. "
     "Часть возможностей будет недоступна — это нормально.\n"
     "• 100003 / 125002 / 125003 — истекла сессия. Программа войдёт заново "
     "сама.\n"
     "• Нет ответа — проверьте, что телефон подключён к Wi-Fi именно этого "
     "роутера и IP введён верно.\n"
     "\n"
     "Тестовый режим показывает работу программы без роутера."):
        ("Default IP: 192.168.8.1 (B315/B525: 192.168.1.1 or 192.168.3.1) — the "
         "“Find” button checks them automatically. Login: admin, the password "
         "is on the router's label.\n"
         "\n"
         "Common errors and what to do:\n"
         "• 108006 — wrong username or password.\n"
         "• 108007 — too many failed attempts: the router has temporarily "
         "blocked logins. Wait a few minutes.\n"
         "• 108003 — already logged in from another device. Close the router's "
         "web interface.\n"
         "• 100002 — not supported by this model or firmware. Some features "
         "will be unavailable — this is normal.\n"
         "• 100003 / 125002 / 125003 — session expired. The app logs in again "
         "by itself.\n"
         "• No response — make sure the phone is connected to this router's "
         "Wi-Fi and the IP is correct.\n"
         "\n"
         "Test mode shows how the app works without a router."),
    ("«Переподключить связь» заставляет модем заново выбрать лучшую соту — "
     "быстрее перезагрузки. После перезагрузки программа переподключится "
     "сама."):
        ("“Reconnect link” makes the modem pick the best cell again — faster "
         "than a reboot. After a reboot the app reconnects by itself."),
    "Белые списки (РФ)":
        "Whitelist (RU)",
    "Во весь экран":
        "Fullscreen",
    "Все (AUTO)":
        "All (AUTO)",
    "Диагностика скопирована в буфер обмена. Личные номера замаскированы.":
        "Diagnostics copied to the clipboard. Personal identifiers are masked.",
    "Звук недоступен на этом устройстве":
        "Sound is not available on this device",
    "Информация":
        "Information",
    "Лучше — продолжайте":
        "Better — keep going",
    "Меню":
        "Menu",
    "Нажмите «Назад» ещё раз, чтобы отключиться":
        "Press “Back” again to disconnect",
    "Отключиться":
        "Disconnect",
    "Отключиться от роутера?":
        "Disconnect from the router?",
    "Перезагрузить роутер":
        "Reboot router",
    "Переподключить":
        "Reconnect",
    "Пики сброшены":
        "Peaks reset",
    "Подключиться":
        "Connect",
    "Подсказка":
        "Help",
    "Портативный монитор LTE/5G Huawei":
        "Portable Huawei LTE/5G monitor",
    "Проверить сейчас":
        "Check now",
    "Сеть":
        "Network",
    "Состояние":
        "Status",
    ("Список взят из модема; замеченные в эфире бэнды — первыми. Меняются "
     "только LTE-бэнды; «Как было» восстановит настройки, прочитанные при "
     "подключении."):
        ("The list comes from the modem; bands seen on air come first. Only LTE "
         "bands are changed; “As before” restores the settings read at "
         "connection time."),
    "Стабильно — фиксируйте":
        "Stable — fix it here",
    "Тестовый режим (без модема)":
        "Test mode (no modem)",
    "Хуже — поверните обратно":
        "Worse — turn back",
    "ℹ Информация":
        "ℹ Information",
    "← Назад":
        "← Back",
    "↩ Как было":
        "↩ As before",
    "⏏ Отключиться":
        "⏏ Disconnect",
    "☀ Солнце: вкл":
        "☀ Sun mode: on",
    "☀ Солнце: выкл":
        "☀ Sun mode: off",
    "☰ Меню":
        "☰ Menu",
    ("⚠ Телефон должен быть подключён к Wi-Fi именно этого роутера — иначе "
     "тест измерит чужой канал. Применимо только для РФ."):
        ("⚠ The phone must be connected to the Wi-Fi of this exact router — "
         "otherwise the test measures a different link. Applies to Russia only."),
    "⟲ Пики":
        "⟲ Peaks",
    "الحامل الرئيسي": "Primary carrier",
    "الخلايا": "Cells",
    "حامل ثانوي": "Secondary carrier",
    "غير متوفر": "Unavailable",
    "العرض": "Width",
    "الباند": "Band",
    "الخلايا القريبة": "Nearby cells",
    "اتصال بهذه الخلية": "Connect to this cell",
    "مسح الآن": "Scan now",
    "الخلية الحالية": "Current cell",
    "خلية 5G الحالية": "Current 5G cell",
    "خلية مجاورة": "Neighbor cell",
    "متصل حاليًا بهذه الخلية": "Connected to this cell",
    "آخر مسح: {time}": "Last scan: {time}",
    "جارٍ المسح…": "Scanning…",
    "اتصل بالراوتر أولًا لقراءة الخلايا.": "Connect to the router first to read cells.",
    "تعرض الصفحة ما يرجعه الراوتر فقط.": "This page shows only what the router returns.",
    "الراوتر لم يعرض خلايا مجاورة (غير متوفر).": "The router did not report neighbor cells (unavailable).",
    "قفل خلية محددة غير مدعوم: لم يُتحقق من واجهة موثقة في هذا الراوتر، ولم يُرسل أي تغيير.": "Locking a specific cell is not supported: no documented router API was verified, and no change was sent.",
}



# ترجمة عربية للواجهة مع إبقاء النصوص الأصلية ووظائف المشروع كما هي.
AR: dict[str, str] = {
    "Host: {host}": "الخادم: {host}",
    "Average TCP/TLS latency: {value}": "متوسط زمن اتصال TCP/TLS: {value}",
    "Jitter (successive latency difference): {value}": "التذبذب (فرق زمن المحاولات المتتالية): {value}",
    "Failed connection attempts: {failed}/{attempts} ({loss:.0f}%)": "محاولات الاتصال الفاشلة: {failed}/{attempts} ({loss:.0f}%)",
    "Minimum / maximum: {minimum} / {maximum}": "أقل / أعلى زمن: {minimum} / {maximum}",
    "Error: {error}": "الخطأ: {error}",
    "PUBG MOBILE": "PUBG MOBILE",
    "EA SPORTS FC MOBILE": "EA SPORTS FC MOBILE",
    "Game connection test": "اختبار اتصال الألعاب",
    "Test PUBG Mobile and EA SPORTS FC Mobile over the router connection. This measures HTTPS latency to public publisher endpoints, not the live match server ping.": "اختبر PUBG Mobile وEA SPORTS FC Mobile عبر اتصال الراوتر. يقيس الاختبار زمن اتصال HTTPS بخوادم عامة للناشرين، وليس Ping المباراة نفسها.",
    "Run full test": "بدء الاختبار الشامل",
    "Testing game connection…": "جارٍ اختبار اتصال الألعاب…",
    "Measuring latency, jitter, and failed probes. This may take about 20 seconds.": "يتم قياس زمن الاتصال والتذبذب وفشل المحاولات؛ قد يستغرق ذلك نحو 20 ثانية.",
    "Test complete — no failed probes": "اكتمل الاختبار — لا توجد محاولات فاشلة",
    "Test complete — some probes failed": "اكتمل الاختبار — توجد محاولات فاشلة",
    "Could not reach test endpoints": "تعذر الوصول إلى خوادم الاختبار",
    "Note: these are measurements to public publisher HTTPS endpoints, not the actual game match server ping.": "ملاحظة: هذه قياسات لخوادم HTTPS عامة للناشرين وليست Ping خادم المباراة الفعلي.",
    "Test error": "خطأ في الاختبار",
    "القراءات": "القراءات",
    "وزن الأنتينا": "وزن الأنتينا",
    "قراءات 4G LTE": "قراءات 4G LTE",
    "ترددات 5G المدعومة للعرض": "نطاقات 5G التي يمكن عرضها",
    "قفل ترددات 5G غير مدعوم بعد عبر واجهة الراوتر الحالية؛ لن يتم إرسال أوامر قفل غير مؤكدة.": "قفل ترددات 5G غير مدعوم حاليًا عبر واجهة الراوتر؛ لن نرسل أوامر غير مؤكدة.",
    "إشارة ممتازة": "إشارة ممتازة",
    "إشارة متوسطة": "إشارة متوسطة",
    "إشارة ضعيفة": "إشارة ضعيفة",
    "معرّف الخلية": "معرّف الخلية",
    "الدمج الفعلي": "الدمج الفعلي",
    "اختبار الألعاب": "اختبار الألعاب",
    "اختبر اتصال PUBG Mobile وEA SPORTS FC Mobile. القياس إلى خوادم HTTPS عامة وليس Ping خادم المباراة الفعلي.": "اختبر اتصال PUBG Mobile وEA SPORTS FC Mobile. القياس إلى خوادم HTTPS عامة وليس Ping خادم المباراة الفعلي.",
    "بدء الاختبار الشامل": "بدء الاختبار الشامل",
    "قراءات 5G NR": "قراءات 5G NR",
    "الدمج الفعلي الحالي": "الدمج الفعلي الحالي",
    "تعرض الصفحة القيم التي يوفرها الراوتر فقط. قد لا تتوفر قياسات مستقلة لكل حامل ثانوي.": "تعرض الصفحة القيم التي يوفرها الراوتر فقط. قد لا تتوفر قياسات مستقلة لكل حامل ثانوي.",
    "لا توجد بيانات بعد. اتصل بالراوتر أولًا.": "لا توجد بيانات بعد. اتصل بالراوتر أولًا.",
    "لا توجد بيانات 5G بعد.": "لا توجد بيانات 5G بعد.",
    "اتصال 5G غير ظاهر حاليًا.": "اتصال 5G غير ظاهر حاليًا.",
    "لم يوفر الراوتر تفاصيل الدمج.": "لم يوفر الراوتر تفاصيل الدمج.",
    "الباند الرئيسي: {band}": "الباند الرئيسي: {band}",
    "PCI: {value}": "PCI: {value}",
    "EARFCN: {value}": "EARFCN: {value}",
    "التردد الهابط: {value}": "التردد الهابط: {value}",
    "RSRP: {rsrp}  |  RSRQ: {rsrq}": "RSRP: {rsrp}  |  RSRQ: {rsrq}",
    "SINR: {sinr}  |  RSSI: {rssi}": "SINR: {sinr}  |  RSSI: {rssi}",
    "عرض النطاق الحالي: {value}": "عرض النطاق الحالي: {value}",
    "الحوامل التي أبلغ عنها الراوتر:": "الحوامل التي أبلغ عنها الراوتر:",
    "رئيسي": "رئيسي",
    "ثانوي": "ثانوي",
    "{role}: {band} — {width} — EARFCN {channel}": "{role}: {band} — {width} — EARFCN {channel}",
    "الباند: {value}": "الباند: {value}",
    "PCI الخاص بـ NR: {value}": "PCI الخاص بـ NR: {value}",
    "NR-ARFCN: {value}": "NR-ARFCN: {value}",
    "RSRP: {rsrp}  |  RSRQ: {rsrq}": "RSRP: {rsrp}  |  RSRQ: {rsrq}",
    "SINR: {value}": "SINR: {value}",
    "عرض النطاق: {value}": "عرض النطاق: {value}",
    "حفظ بيانات الراوتر على هذا الجهاز": "حفظ بيانات الراوتر على هذا الجهاز",
    "إعدادات الأنتينا": "إعدادات الأنتينا",
    "Авто": "تلقائي", "Внешняя": "خارجي", "Внутренняя": "داخلي", "Смешанная": "مختلط",
    "Идеальный": "مثالي", "Критичный": "حرج", "Н/Д": "غير متاح", "Нет данных": "لا توجد بيانات",
    "Нет интернета": "لا يوجد إنترنت", "Нет сети": "لا توجد شبكة", "Нормальный": "طبيعي",
    "Отличный": "ممتاز", "Очень слабый": "ضعيف جدًا", "Плохой": "سيئ", "Сильный": "قوي",
    "Слабый": "ضعيف", "Средний": "متوسط", "Хороший": "جيد", "Шумный": "مشوش",
    "Подключиться": "اتصال", "Отключиться": "قطع الاتصال", "Отключиться от роутера?": "هل تريد قطع الاتصال بالراوتر؟",
    "Подсказка": "مساعدة", "Информация": "المعلومات", "Сеть": "الشبكة", "Состояние": "الحالة",
    "Меню": "القائمة", "Найти": "بحث", "Переподключить": "إعادة الاتصال", "Переподключить связь": "إعادة اتصال الشبكة",
    "Перезагрузить роутер": "إعادة تشغيل الراوتر", "Тестовый режим": "وضع الاختبار",
    "Тестовый режим (без модема)": "وضع الاختبار (بدون مودم)", "Проверить сейчас": "تحقق الآن",
    "Скопировать диагностику": "نسخ التشخيص", "Диагностика скопирована в буфер обмена. Личные номера замаскированы.": "تم نسخ بيانات التشخيص. أُخفيت المعرّفات الشخصية.",
    "Звук недоступен на этом устройстве": "الصوت غير متاح على هذا الجهاز", "Пики сброшены": "تمت إعادة ضبط القمم",
    "Время сессии": "مدة الجلسة", "Агрегация (CA)": "تجميع الترددات (CA)", "Активна": "نشط",
    "Информация о станции": "معلومات البرج", "SIM / Устройство": "الشريحة / الجهاز", "IP адрес:": "عنوان IP:",
    "IMEI (роутер)": "IMEI (الراوتر)", "ICCID (SIM-карта)": "ICCID (الشريحة)", "TAC (зона)": "TAC (المنطقة)",
    "eNodeB (Вышка)": "eNodeB (البرج)", "Cell (Локальный сектор)": "الخلية (القطاع المحلي)",
    "EARFCN (канал DL)": "EARFCN (قناة التنزيل)", "CQI (потоки)": "CQI (التدفقات)",
    "RSRP мин / макс": "أدنى / أعلى RSRP", "SINR мин / макс": "أدنى / أعلى SINR",
    "Белые списки (РФ)": "القوائم البيضاء (روسيا)", "Во весь экран": "ملء الشاشة", "Все (AUTO)": "الكل (تلقائي)",
    "Включаю все бэнды…": "جارٍ تفعيل جميع النطاقات…", "Включены все бэнды (AUTO).": "تم تفعيل جميع النطاقات (تلقائي).",
    "Восстанавливаю настройки…": "جارٍ استعادة الإعدادات…", "Выберите хотя бы один диапазон!": "اختر نطاقًا واحدًا على الأقل!",
    "Подключение": "الاتصال", "Лучше — продолжайте": "أفضل — واصل", "Хуже — поверните обратно": "أسوأ — أعد الاتجاه السابق",
    "Стабильно — фиксируйте": "الإشارة مستقرة — ثبّت الاتجاه", "Портативный монитор LTE/5G Huawei": "مراقب هواوي المحمول LTE/5G",
    "← Назад": "← رجوع", "↩ Как было": "↩ استعادة السابق", "⏏ Отключиться": "⏏ قطع الاتصال",
    "☰ Меню": "☰ القائمة", "☰ Menu": "☰ القائمة", "⚙ Сеть": "⚙ الشبكة", "ℹ Информация": "ℹ المعلومات",
    "♪ Звук": "♪ الصوت", "⟲ Пики": "⟲ القمم", "☀ Солнце: вкл": "☀ وضع الشمس: تشغيل", "☀ Солнце: выкл": "☀ وضع الشمس: إيقاف",
    "Белые списки ВЫКЛЮЧЕНЫ": "القوائم البيضاء معطلة", "ВЫКЛЮЧЕНЫ": "معطّل", "Нейтральные:": "محايدة:", "В белых списках:": "ضمن القائمة البيضاء:",
    "ДЕМО · азимут {a}": "تجريبي · السمت {a}", "IP по умолчанию": "عنوان IP الافتراضي",
}

def set_language(lang: str) -> None:
    """Set the UI language to Arabic or English only."""
    global _current_lang
    if lang in LANGUAGES:
        _current_lang = lang


def current_language() -> str:
    """Возвращает код текущего языка."""
    return _current_lang


def t(text: str) -> str:
    """Переводит строку на текущий язык.

    Русский — возвращает ключ как есть. Английский — ищет в EN,
    при отсутствии возвращает ключ (русский) как fallback.
    """
    if _current_lang == "ru":
        return text
    if _current_lang == "ar":
        if text in AR:
            return AR[text]
        # Arabic source text must stay Arabic in Arabic mode; only Russian
        # keys may fall back to their English translation.
        if any("\u0600" <= ch <= "\u06ff" for ch in text):
            return text
        return EN.get(text, text)
    return EN.get(text, text)


from core.i18n_ar_extra import AR_EXTRA as _AR_EXTRA  # noqa: E402

for _key, _value in _AR_EXTRA.items():
    AR.setdefault(_key, _value)
