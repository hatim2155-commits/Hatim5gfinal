"""Read-only parsing of neighbouring-cell data reported by the router.

Nothing here is invented: a cell is returned only when the router's own
response contains a physical-cell-id field. Missing fields stay ``None`` and
the UI shows them as unavailable. The router response layout differs between
models/firmwares, so field names are matched loosely (case/underscore
insensitive) and an unrecognised response simply yields an empty list.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

# 3GPP TS 36.101 downlink EARFCN ranges (inclusive) for common LTE bands.
_LTE_EARFCN_BANDS: tuple[tuple[int, int, int], ...] = (
    (0, 599, 1), (600, 1199, 2), (1200, 1949, 3), (1950, 2399, 4),
    (2400, 2649, 5), (2750, 3449, 7), (3450, 3799, 8), (6150, 6449, 20),
    (9210, 9659, 28), (37750, 38249, 38), (38650, 39649, 40), (39650, 41589, 41),
)

_PCI = {'pci', 'phycellid', 'physcellid', 'physicalcellid', 'physicalcellidentity'}
_EARFCN = {'earfcn', 'dlearfcn', 'arfcn', 'nrarfcn', 'channel'}
_BAND = {'band', 'lteband', 'bandinfo', 'nrband'}
_RSRP = {'rsrp'}
_RSRQ = {'rsrq'}
_SINR = {'sinr', 'snr'}


@dataclass(frozen=True)
class NeighborCell:
    band: str | None
    pci: int | None
    arfcn: int | None
    rsrp: float | None
    rsrq: float | None
    sinr: float | None


def band_from_earfcn(earfcn: int | None) -> str | None:
    if earfcn is None:
        return None
    for low, high, band in _LTE_EARFCN_BANDS:
        if low <= earfcn <= high:
            return f'B{band}'
    return None


def _norm(key: Any) -> str:
    return str(key).replace('_', '').replace('-', '').lower()


def _num(value: Any) -> float | None:
    if value is None:
        return None
    text = str(value).lower().replace('dbm', '').replace('db', '').strip()
    try:
        return float(text)
    except ValueError:
        return None


def _pick(entry: dict[str, Any], names: set[str]) -> Any:
    for key, value in entry.items():
        if _norm(key) in names and not isinstance(value, (dict, list)):
            return value
    return None


def _band_text(value: Any) -> str | None:
    text = str(value or '').strip().upper()
    if not text:
        return None
    digits = ''.join(ch for ch in text if ch.isdigit())
    if text.startswith('N') and digits:
        return f'N{digits}'
    if digits:
        return f'B{digits}'
    return None


def parse_cell_info(data: Any) -> list[NeighborCell]:
    """Return every dict in ``data`` that carries a PCI, as a NeighborCell."""
    found: list[NeighborCell] = []

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            pci_raw = _pick(node, _PCI)
            if pci_raw is not None and _num(pci_raw) is not None:
                earfcn_raw = _num(_pick(node, _EARFCN))
                earfcn = int(earfcn_raw) if earfcn_raw is not None else None
                band = _band_text(_pick(node, _BAND)) or band_from_earfcn(earfcn)
                found.append(NeighborCell(
                    band=band, pci=int(_num(pci_raw)), arfcn=earfcn,
                    rsrp=_num(_pick(node, _RSRP)), rsrq=_num(_pick(node, _RSRQ)),
                    sinr=_num(_pick(node, _SINR))))
                return
            for child in node.values():
                walk(child)
        elif isinstance(node, list):
            for child in node:
                walk(child)

    walk(data)
    return found


def parse_seccell_response(data: Any) -> dict[str, list[NeighborCell]]:
    """Parse ``api/device/seccellinfo`` (read-only): the router's own list of aggregated carriers.

    Two text fields, cells separated by ``;``, each cell
    ``ARFCN,Band,Width,PCI,RSRP,RSRQ,RSSI,SINR`` (``--`` = not reported). Real example::

        lteseccell_list: 1279,B3,15MHz,3,-71dBm,-6dB,-43dBm,--;
        nrseccell_list:  640776,N77,100MHz,505,-90dBm,-10dB,-67dBm,13dB;656640,N77,100MHz,505,-76dBm,-10dB,-53dBm,31dB;

    Returns ``{'lte': [...], 'nr': [...]}``. A missing or unreadable field stays ``None``.
    """
    result: dict[str, list[NeighborCell]] = {'lte': [], 'nr': []}
    if not isinstance(data, dict):
        return result
    fields = {'lteseccelllist': 'lte', 'nrseccelllist': 'nr'}
    for key, value in data.items():
        kind = fields.get(_norm(key))
        if kind is None or not isinstance(value, str):
            continue
        for entry in value.split(';'):
            parts = [p.strip() for p in entry.split(',')]
            if len(parts) < 4 or _num(parts[0]) is None or _num(parts[3]) is None:
                continue
            result[kind].append(NeighborCell(
                band=_band_text(parts[1]), pci=int(_num(parts[3])), arfcn=int(_num(parts[0])),
                rsrp=_num(parts[4]) if len(parts) > 4 else None,
                rsrq=_num(parts[5]) if len(parts) > 5 else None,
                sinr=_num(parts[7]) if len(parts) > 7 else None))
    return result


def parse_nbrcell_response(data: Any) -> list[NeighborCell]:
    """Parse ``api/device/nbrcellinfo`` (read-only).

    The router returns the LTE neighbours as one text field ``nbrcell_ltelist``:
    cells separated by ``;``, each cell ``EARFCN,Band,PCI,RSRP,RSRQ,RSSI,SINR``
    (real example: ``9310,B28,311,-82dBm,-9dB,-53dBm,--``; ``--`` = not reported). Any field that is missing stays ``None``.
    Other lists in the response (e.g. 5G) are ignored here, never guessed.
    """
    if not isinstance(data, dict):
        return []
    text = None
    for key, value in data.items():
        if _norm(key) == 'nbrcellltelist' and isinstance(value, str):
            text = value
            break
    if not text or not text.strip() or text.strip() == '--':
        return []
    cells: list[NeighborCell] = []
    for entry in text.split(';'):
        parts = [p.strip() for p in entry.split(',')]
        if len(parts) < 3 or _num(parts[2]) is None:
            continue
        earfcn_raw = _num(parts[0])
        earfcn = int(earfcn_raw) if earfcn_raw is not None else None
        band = _band_text(parts[1]) or band_from_earfcn(earfcn)
        cells.append(NeighborCell(
            band=band, pci=int(_num(parts[2])), arfcn=earfcn,
            rsrp=_num(parts[3]) if len(parts) > 3 else None,
            rsrq=_num(parts[4]) if len(parts) > 4 else None,
            sinr=_num(parts[6]) if len(parts) > 6 else None))
    return cells
