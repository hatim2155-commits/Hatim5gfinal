"""Second login (``loginflag`` 2) the router's own developer page performs before it allows
``net/lock-freq``. Requests, as captured from the page::

    POST user/challenge_login      <username><firstnonce><mode>1</mode><loginflag>2</loginflag>
      -> <newType><iterations><salt><servernonce><modeselected>
    POST user/authentication_login <clientproof><finalnonce><loginflag>2</loginflag>

The proof is computed exactly like the page's own script (main.js, forge library), where
``A(hex, key)`` is HMAC-SHA256 with the KEY being the text and the MESSAGE the bytes of ``hex``
(the reverse of RFC 5802)::

    salted     = PBKDF2-HMAC-SHA256(password, bytes.fromhex(salt), iterations, 32)
    clientKey  = A(salted, "Client Key")        # HMAC(key="Client Key", msg=salted)
    storedKey  = SHA256(clientKey)
    signature  = A(storedKey, first + "," + server + "," + server)   # key = auth message
    proof      = clientKey XOR signature
    serverSig  = A(A(salted, "Server Key"), authMessage)

ONE attempt only, never retried (a wrong proof counts as a failed login).
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import secrets
from typing import Any, Mapping

logger = logging.getLogger(__name__)


def _A(message: bytes, key: str) -> bytes:
    """The page's ``A(e, t)``: HMAC-SHA256, key = the text, message = the bytes."""
    return hmac.new(key.encode('utf-8'), message, hashlib.sha256).digest()


def scram_values(password: str, salt_hex: str, iterations: int,
                 first_nonce: str, server_nonce: str) -> tuple[str, str]:
    """-> (client proof hex, expected server signature hex)."""
    salted = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'),
                                 bytes.fromhex(salt_hex), int(iterations), 32)
    auth_msg = f'{first_nonce},{server_nonce},{server_nonce}'
    client_key = _A(salted, 'Client Key')
    stored_key = hashlib.sha256(client_key).digest()
    signature = _A(stored_key, auth_msg)
    proof = bytes(x ^ y for x, y in zip(client_key, signature)).hex()
    server_sig = _A(_A(salted, 'Server Key'), auth_msg).hex()
    return proof, server_sig


class DeveloperLoginError(Exception):
    pass


def _step(name: str, fn: Any) -> Any:
    try:
        return fn()
    except DeveloperLoginError:
        raise
    except Exception as exc:
        raise DeveloperLoginError(f'{name}: {exc}') from exc


def developer_login(session: Any, username: str, password: str) -> bool:
    """Run the requests on an already logged-in ``huawei_lte_api`` Session.
    Returns True when the router accepted the proof. Errors name the failing step."""
    # The page fetches a fresh token (webserver/token) right before the challenge.
    if hasattr(session, 'reload'):
        _step('token', session.reload)
    first = secrets.token_hex(32)
    challenge = _step('challenge', lambda: session.post_get('user/challenge_login', {
        'username': username, 'firstnonce': first, 'mode': 1, 'loginflag': 2}))
    if not isinstance(challenge, Mapping):
        raise DeveloperLoginError('challenge: رد غير مفهوم من الراوتر.')
    try:
        salt = str(challenge['salt'])
        iterations = int(challenge['iterations'])
        server_nonce = str(challenge['servernonce'])
    except (KeyError, ValueError, TypeError) as exc:
        raise DeveloperLoginError('challenge: الراوتر لم يعطِ بيانات التحدي المتوقعة.') from exc
    if not server_nonce.startswith(first):
        raise DeveloperLoginError('challenge: رد تحدٍ غير متطابق؛ لم يُرسل الإثبات.')
    proof, expected = scram_values(password, salt, iterations, first, server_nonce)
    # refresh_csrf: old tokens are dropped, the new ones come from this reply's headers.
    reply = _step('authentication', lambda: session.post_get('user/authentication_login', {
        'clientproof': proof, 'finalnonce': server_nonce, 'loginflag': 2}, refresh_csrf=True))
    if isinstance(reply, Mapping):
        sig = str(reply.get('serversignature') or '')
        if sig and sig.lower() != expected.lower():
            logger.warning("Router server signature differs from the computed one")
    return True
