"""Network type choice: 4G only / NSA (4G+5G).

Huawei: only the ``NetworkMode`` field of the router's own ``net/net-mode`` write changes;
the LTE band mask and NetworkBand are written back exactly as read. The NSA code is taken
from the router's own mode list (a code holding both 08 = NR and 03 = LTE), never invented.
ZTE: the router's own ``SET_BEARER_PREFERENCE``.
Separate from ``core.band_lock`` (not touched).
"""
from __future__ import annotations

from typing import Iterable

KIND_LTE = 'lte'
KIND_NSA = 'nsa'

ZTE_BEARER = {KIND_LTE: 'Only_LTE', KIND_NSA: 'LTE_AND_5G'}


def nsa_code(access_modes: Iterable[str]) -> str | None:
    """The router's own LTE+NR mode code, or None when it lists none."""
    best = None
    for mode in access_modes:
        m = str(mode).strip()
        if len(m) >= 4 and '08' in m and '03' in m:
            if m in ('0803', '0308'):
                return m
            best = best or m
    return best


def kind_of_huawei(mode: str | None) -> str | None:
    m = (mode or '').strip()
    if m == '03':
        return KIND_LTE
    if len(m) >= 4 and '08' in m and '03' in m:
        return KIND_NSA
    return None


def kind_of_zte(value: str | None) -> str | None:
    v = (value or '').strip()
    for kind, code in ZTE_BEARER.items():
        if v.lower() == code.lower():
            return kind
    return None
