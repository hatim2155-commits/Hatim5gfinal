"""Band card data for the Frequencies page: label, MHz text, FDD/TDD and grouping.

Pure functions (no Kivy), so the layout rules can be tested without a device.
"""
from __future__ import annotations

from .constants import LTE_BAND_TABLE

# Standard 3GPP NR bands the router can lock: band -> (MHz text, duplex, MHz number).
NR_BAND_INFO: dict[int, tuple[str, str, int]] = {
    1: ('2100', 'FDD', 2100), 3: ('1800', 'FDD', 1800), 5: ('850', 'FDD', 850),
    7: ('2600', 'FDD', 2600), 8: ('900', 'FDD', 900), 20: ('800', 'FDD', 800),
    28: ('700', 'FDD', 700), 38: ('2600', 'TDD', 2600), 40: ('2300', 'TDD', 2300),
    41: ('2500', 'TDD', 2500), 71: ('600', 'FDD', 600), 77: ('3700', 'TDD', 3700),
    78: ('3500', 'TDD', 3500), 79: ('4700', 'TDD', 4700),
}
NR_BANDS_SHOWN: tuple[int, ...] = (28, 3, 1, 40, 41, 78, 77)

Entry = tuple[str, str, str, float]     # label, MHz text, duplex, MHz number


def lte_entry(band: int) -> Entry:
    info = LTE_BAND_TABLE.get(band)
    if info is None:
        return f'B{band}', '', '', 1800.0
    name, duplex, f_low = info[0], info[1], info[2]
    first = name.split()[0] if name.split() else name
    return f'B{band}', (first if first[:1].isdigit() else name), duplex, float(f_low)


def nr_entry(band: int) -> Entry:
    text, duplex, freq = NR_BAND_INFO.get(band, ('', '', 3500))
    return f'N{band}', text, duplex, float(freq)


def group_bands(entries: dict[int, Entry], kind: str) -> list[tuple[str, list[int]]]:
    """[(group key, bands sorted by frequency)] — 4G: low/mid/tdd, 5G: fdd/tdd. Empty groups dropped."""
    order = ['fdd', 'tdd'] if kind == 'nr' else ['low', 'mid', 'tdd']
    buckets: dict[str, list[tuple[float, int]]] = {k: [] for k in order}
    for band, (_label, _mhz, duplex, freq) in entries.items():
        if duplex == 'TDD':
            key = 'tdd'
        elif kind == 'nr':
            key = 'fdd'
        else:
            key = 'low' if freq < 1000 else 'mid'
        buckets[key].append((freq, band))
    return [(k, [b for _f, b in sorted(buckets[k])]) for k in order if buckets[k]]
