"""Lock the router to one specific cell (NSA: one LTE cell + one NR cell).

Separate from ``core.band_lock`` (4G band masks), which is not touched.
Request layout is taken from the router's own frequency-lock call
(``POST api/net/lock-freq``, ``lock_mode`` 2 = band + channel + PCI)::

    <request>
      <lte_info><lock_mode>2</lock_mode>
        <freq_infos><freq_info><band>28</band><freq>9310</freq><pci>311</pci></freq_info></freq_infos>
        <all_bands>28</all_bands></lte_info>
      <nr_info> ... same shape with the NR band / NR-ARFCN / PCI ... </nr_info>
    </request>

Band is the plain number ("28", "78"), freq is the EARFCN / NR-ARFCN.
Nothing is guessed: a target with a missing field is refused.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

LOCK_ENDPOINT = 'net/lock-freq'
LOCK_MODE_CELL = 2


@dataclass(frozen=True)
class CellTarget:
    band: int
    freq: int
    pci: int


def band_number(text: Any) -> int | None:
    """'B28' / 'n78' / '28' -> 28 / 78 / 28; None if there is no number."""
    match = re.search(r'\d+', str(text or ''))
    return int(match.group(0)) if match else None


def make_target(band: Any, freq: Any, pci: Any) -> CellTarget | None:
    b = band_number(band)
    try:
        f = int(float(freq))
        p = int(float(pci))
    except (TypeError, ValueError):
        return None
    if b is None or f < 0 or p < 0:
        return None
    return CellTarget(b, f, p)


def _tech(target: CellTarget) -> dict[str, Any]:
    return {
        'lock_mode': LOCK_MODE_CELL,
        'freq_infos': {'freq_info': {'band': target.band, 'freq': target.freq,
                                     'pci': target.pci}},
        'all_bands': target.band,
    }


def _empty_block() -> dict[str, Any]:
    """Block the router's page sends for a technology it is not locking."""
    return {'lock_mode': 0, 'freq_infos': '', 'all_bands': ''}


def build_request(lte: CellTarget, nr: CellTarget | None = None) -> dict[str, Any]:
    """Both blocks, as the router's own page always sends them (serialised to XML by the
    API client). A technology that is not locked is an empty ``lock_mode`` 0 block."""
    return {'lte_info': _tech(lte), 'nr_info': _tech(nr) if nr is not None else _empty_block()}


def build_unlock(with_nr: bool = True) -> dict[str, Any]:
    """Back to automatic: both blocks empty, lock_mode 0 (shape of the page's own "no lock";
    the router's reply is shown to the user and nothing is retried)."""
    return {'lte_info': _empty_block(), 'nr_info': _empty_block()}


LOCK_MODE_BANDS = 3


def build_nr_band_lock(bands: list[int], secondary_only: list[int] | None = None) -> dict[str, Any]:
    """5G lock by band, exactly as the developer page saves it (lock_mode 3).

    ``all_bands`` = every allowed band; ``freq_infos`` = the bands that may be the primary
    carrier (Pcell+Scell). Bands in ``secondary_only`` (Scell) appear only in ``all_bands``."""
    sec = set(secondary_only or [])
    allowed = sorted(set(bands) | sec)
    primary = [b for b in sorted(set(bands)) if b not in sec]
    if not allowed:
        raise ValueError('لم يُختر أي باند 5G')
    if not primary:
        raise ValueError('اختر باندًا واحدًا على الأقل غير ثانوي (S)')
    infos: Any = [{'band': b} for b in primary]
    return {'lte_info': _empty_block(),
            'nr_info': {'lock_mode': LOCK_MODE_BANDS,
                        'freq_infos': {'freq_info': infos if len(infos) > 1 else infos[0]},
                        'all_bands': ','.join(str(b) for b in allowed)}}


def to_xml(data: dict[str, Any]) -> str:
    """Plain XML rendering of ``build_request`` (used by tests and diagnostics)."""
    def render(node: Any) -> str:
        if isinstance(node, dict):
            return ''.join(''.join(f'<{k}>{render(i)}</{k}>' for i in (v if isinstance(v, list) else [v]))
                           for k, v in node.items())
        return str(node)
    return '<?xml version="1.0" encoding="UTF-8"?><request>' + render(data) + '</request>'


def locked_on(snap: Any, lte: CellTarget) -> bool:
    """Is the router now served by the requested LTE cell? (read-back check)"""
    if snap is None:
        return False
    return getattr(snap, 'pci', None) == lte.pci and getattr(snap, 'earfcn', None) == lte.freq
