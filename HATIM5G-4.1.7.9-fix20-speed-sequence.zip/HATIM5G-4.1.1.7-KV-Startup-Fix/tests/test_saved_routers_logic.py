"""Saved-router identity rules (IP + name) without Kivy: mirrors save_router_details."""


def _save(items, ip, name, password):
    ip, name = ip.strip(), name.strip()
    for item in items:
        if item['ip'] == ip and item.get('name', '').lower() == name.lower():
            item['password'] = password
            return item
    entry = {'ip': ip, 'name': name, 'password': password}
    items.append(entry)
    return entry


def test_same_ip_different_names_stay_separate():
    items = []
    _save(items, '192.168.8.1', 'Ahmed', 'a')
    _save(items, '192.168.8.1', 'Khaled', 'k')
    assert len(items) == 2


def test_same_ip_and_name_updates_password():
    items = []
    _save(items, '192.168.8.1', 'Ahmed', 'a')
    _save(items, '192.168.8.1', 'ahmed', 'new')
    assert len(items) == 1 and items[0]['password'] == 'new'
