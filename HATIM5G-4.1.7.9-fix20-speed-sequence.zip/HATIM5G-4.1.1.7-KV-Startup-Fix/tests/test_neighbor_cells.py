from core.neighbor_cells import band_from_earfcn, parse_cell_info


def test_parses_only_entries_with_pci():
    data = {'CellInfo': {'Cell': [
        {'PCI': '301', 'EARFCN': '1300', 'RSRP': '-89dBm', 'RSRQ': '-11dB', 'SINR': '9dB'},
        {'phy_cell_id': 112, 'dlearfcn': 100, 'rsrp': '-97'},
    ]}}
    cells = parse_cell_info(data)
    assert len(cells) == 2
    assert (cells[0].band, cells[0].pci, cells[0].rsrp) == ('B3', 301, -89.0)
    assert cells[1].band == 'B1' and cells[1].rsrq is None


def test_unrecognised_or_empty_response_gives_no_cells():
    assert parse_cell_info({'a': 1}) == []
    assert parse_cell_info(None) == []
    assert band_from_earfcn(9999) is None


def test_parse_nbrcell_response_router_format():
    from core.neighbor_cells import parse_nbrcell_response
    cells = parse_nbrcell_response(
        {'nbrcell_ltelist': '500,1,461,-93dBm,-15dB;500,1,162,-93dBm,-16dB'})
    assert [(c.pci, c.arfcn, c.rsrp, c.rsrq, c.sinr) for c in cells] == [
        (461, 500, -93.0, -15.0, None), (162, 500, -93.0, -16.0, None)]
    assert parse_nbrcell_response({'nbrcell_ltelist': '--'}) == []
    assert parse_nbrcell_response(None) == []


def test_parse_nbrcell_response_real_router_sample():
    from core.neighbor_cells import parse_nbrcell_response
    cells = parse_nbrcell_response({
        'nbrcell_ltelist': '9310,B28,311,-82dBm,-9dB,-53dBm,--;1450,B3,310,-100dBm,-18dB,-59dBm,12dB;',
        'nbrcell_nrlist': None})
    assert [(c.band, c.arfcn, c.pci, c.rsrp, c.rsrq, c.sinr) for c in cells] == [
        ('B28', 9310, 311, -82.0, -9.0, None), ('B3', 1450, 310, -100.0, -18.0, 12.0)]


# Real device/seccellinfo from an H155-381 with B1+B3 and two N77 carriers.
REAL_SECCELL = {
    'lteseccell_list': '1279,B3,15MHz,3,-71dBm,-6dB,-43dBm,--;',
    'nrseccell_list': ('640776,N77,100MHz,505,-90dBm,-10dB,-67dBm,13dB;'
                       '656640,N77,100MHz,505,-76dBm,-10dB,-53dBm,31dB;'),
}


def test_seccell_parses_real_router_sample():
    from core.neighbor_cells import parse_seccell_response
    out = parse_seccell_response(REAL_SECCELL)
    lte, nr = out['lte'][0], out['nr']
    assert (lte.band, lte.arfcn, lte.pci, lte.rsrp, lte.rsrq, lte.sinr) == ('B3', 1279, 3, -71.0, -6.0, None)
    assert [(c.arfcn, c.band, c.pci, c.rsrp, c.rsrq, c.sinr) for c in nr] == [
        (640776, 'N77', 505, -90.0, -10.0, 13.0), (656640, 'N77', 505, -76.0, -10.0, 31.0)]


def test_seccell_missing_or_garbage_gives_empty_lists():
    from core.neighbor_cells import parse_seccell_response
    assert parse_seccell_response(None) == {'lte': [], 'nr': []}
    assert parse_seccell_response({'nrseccell_list': '--', 'lteseccell_list': None}) == {'lte': [], 'nr': []}
