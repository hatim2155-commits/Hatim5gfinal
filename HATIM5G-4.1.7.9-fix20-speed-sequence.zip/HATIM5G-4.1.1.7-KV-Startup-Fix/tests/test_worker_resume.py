"""Back from the background / manual refresh: the worker polls at once instead of waiting."""
import threading
import time

import core
from core.demo import DemoModem, demo_factory


def _worker(interval=30.0):
    snaps, lock = [], threading.Lock()

    def on_snap(s):
        with lock:
            snaps.append(s)
    session = core.RouterSession("demo", "pw", factory=demo_factory(DemoModem()))
    worker = core.SessionWorker(
        session, interval=lambda: interval, on_connected=lambda info: None, on_snapshot=on_snap,
        on_status=lambda *a: None, on_fatal=lambda exc: None)
    return worker, snaps, lock


def _wait(snaps, lock, n, timeout=3.0):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        with lock:
            if len(snaps) >= n:
                return True
        time.sleep(0.01)
    return False


def test_refresh_polls_immediately_even_with_a_long_interval():
    worker, snaps, lock = _worker()
    worker.start()
    assert _wait(snaps, lock, 1)
    count = len(snaps)
    worker.refresh(reopen=True)
    assert _wait(snaps, lock, count + 1)
    worker.stop()
    worker.join(3)
    assert not worker.is_alive()


def test_resume_after_pause_polls_immediately():
    worker, snaps, lock = _worker()
    worker.start()
    assert _wait(snaps, lock, 1)
    count = len(snaps)
    worker.pause()
    time.sleep(0.1)
    worker.resume()
    assert _wait(snaps, lock, count + 1)
    worker.stop()
    worker.join(3)


def test_long_absence_asks_for_a_new_login(monkeypatch=None):
    worker, snaps, lock = _worker()
    worker.start()
    assert _wait(snaps, lock, 1)
    opened = []
    real_open = worker.session.open
    worker.session.open = lambda: opened.append(1) or real_open()
    worker.pause()
    worker._paused_at -= core.router.RESUME_REOPEN_AFTER + 1     # pretend a long absence
    count = len(snaps)
    worker.resume()
    assert _wait(snaps, lock, count + 1)
    assert opened, "a long absence must log in again"
    worker.stop()
    worker.join(3)
