"""Frequencies page: band cards data and grouping (pure logic)."""
from core.band_layout import NR_BANDS_SHOWN, group_bands, lte_entry, nr_entry


def test_lte_entries_show_mhz_and_duplex():
    assert lte_entry(40) == ('B40', '2300', 'TDD', 2300.0)
    assert lte_entry(3)[:3] == ('B3', '1800', 'FDD')
    assert lte_entry(28)[1] == '700'          # "700 APT" -> 700
    assert lte_entry(4)[1] == 'AWS-1'         # no leading number: show the name
    assert lte_entry(999)[:3] == ('B999', '', '')


def test_lte_groups_are_ordered_by_frequency():
    bands = [1, 3, 5, 7, 8, 20, 28, 38, 40, 41, 42, 43]
    groups = dict(group_bands({b: lte_entry(b) for b in bands}, 'lte'))
    assert groups['low'] == [28, 20, 5, 8]
    assert groups['mid'] == [3, 1, 7]
    assert groups['tdd'] == [40, 41, 38, 42, 43]


def test_lte_tdd_group_sorted_by_dl_start():
    groups = dict(group_bands({b: lte_entry(b) for b in (43, 40, 42, 41, 38)}, 'lte'))
    assert groups['tdd'] == [40, 41, 38, 42, 43]


def test_empty_groups_are_dropped():
    groups = group_bands({b: lte_entry(b) for b in (40, 41)}, 'lte')
    assert [k for k, _ in groups] == ['tdd']


def test_nr_groups():
    info = {b: nr_entry(b) for b in NR_BANDS_SHOWN}
    groups = dict(group_bands(info, 'nr'))
    assert groups['fdd'] == [28, 3, 1]
    assert groups['tdd'] == [40, 41, 78, 77]
    assert nr_entry(78) == ('N78', '3500', 'TDD', 3500.0)
    assert nr_entry(77)[1:3] == ('3700', 'TDD')
