from core.network_mode import kind_of_huawei, kind_of_zte, nsa_code


def test_nsa_code_comes_from_router_list_only():
    assert nsa_code(['00', '03', '0803', '08']) == '0803'
    assert nsa_code(['00', '03']) is None


def test_kinds():
    assert kind_of_huawei('03') == 'lte' and kind_of_huawei('0803') == 'nsa'
    assert kind_of_huawei('00') is None
    assert kind_of_zte('Only_LTE') == 'lte' and kind_of_zte('LTE_AND_5G') == 'nsa'
