from core.game_test import GameProbe, probe_game_endpoint


def test_game_probe_metrics():
    p = GameProbe("test.example", (10.0, 12.0, 15.0), 1, 4)
    assert p.packet_loss_pct == 25.0
    assert round(p.average_ms, 2) == 12.33
    assert p.min_ms == 10.0
    assert p.max_ms == 15.0
    assert p.jitter_ms == 2.5


def test_probe_failure_is_reported(monkeypatch):
    import core.game_test as gt
    monkeypatch.setattr(gt, "_one_probe", lambda host, timeout: (None, "Timed out"))
    p = probe_game_endpoint("example.invalid", attempts=3, timeout=0.01)
    assert p.failures == 3
    assert p.packet_loss_pct == 100.0
    assert p.average_ms is None
    assert p.error == "Timed out"
