"""Run directly: python tests/test_zte_session.py (no router needed)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.models import build_snapshot
from core.neighbor_cells import parse_nbrcell_response
from core.zte_session import hex_to_dec, neighbors_to_huawei_text, to_huawei_style


def test_real_mc801a_values():
    z = {'lte_rsrp': '-102', 'lte_rsrq': '-14', 'lte_snr': '6.4', 'lte_rssi': '-68',
         'lte_pci': '135', 'lte_band': '1', 'wan_active_channel': '500',
         'nr5g_pci': '39f', 'nr5g_action_band': 'n78', 'nr5g_action_channel': '640776'}
    snap = build_snapshot(to_huawei_style(z))
    assert (snap.rsrp, snap.sinr, snap.pci, snap.earfcn) == (-102.0, 6.4, 309, 500)
    assert (snap.nr_pci, snap.nr_arfcn, snap.nr_band_label) == (927, 640776, 'n78')
    assert snap.bands == (1,)


def test_empty_stays_empty():
    assert hex_to_dec('') == '' and hex_to_dec('zz') == ''
    snap = build_snapshot(to_huawei_style({}))
    assert snap.rsrp is None and snap.pci is None


def test_neighbors():
    text = neighbors_to_huawei_text('500,309,-13,-101,-67;500,311,-16,-110,-82')
    cells = parse_nbrcell_response({'nbrcell_ltelist': text})
    assert [(c.pci, c.rsrp, c.rsrq, c.sinr) for c in cells] == [
        (309, -101.0, -13.0, None), (311, -110.0, -16.0, None)]


if __name__ == '__main__':
    for name, fn in list(globals().items()):
        if name.startswith('test_'):
            fn()
    print('ok')


def test_band_lock_mask():
    from core.zte_session import ZteSession, ZTE_ALL_LTE_MASK
    s = ZteSession('x', 'y')
    assert s.plan_band_lock([1, 3, 20]).lteband == '0x80005'
    assert s.plan_all_bands().mask == ZTE_ALL_LTE_MASK
