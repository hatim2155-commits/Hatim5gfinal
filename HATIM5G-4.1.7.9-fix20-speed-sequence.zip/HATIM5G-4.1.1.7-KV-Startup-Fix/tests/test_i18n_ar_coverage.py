"""Every Russian UI key used through t() must have an Arabic translation,
otherwise Arabic mode falls back to the English text."""
import ast
import glob
import re

from core import i18n

_CYR = re.compile('[Ѐ-ӿ]')
_PH = re.compile(r'\{[^}]*\}')


def _keys():
    found = set()
    for path in ['android_main.py'] + glob.glob('core/*.py'):
        if path.endswith('i18n.py') or path.endswith('i18n_ar_extra.py'):
            continue
        tree = ast.parse(open(path, encoding='utf-8').read())
        for node in ast.walk(tree):
            if (isinstance(node, ast.Call) and getattr(node.func, 'id', None) == 't'
                    and node.args and isinstance(node.args[0], ast.Constant)
                    and isinstance(node.args[0].value, str) and _CYR.search(node.args[0].value)):
                found.add(node.args[0].value)
    return found


def test_all_t_keys_have_arabic():
    missing = sorted(k for k in _keys() if k not in i18n.AR)
    assert not missing, missing


def test_arabic_keeps_placeholders():
    for key, value in i18n.AR.items():
        assert sorted(_PH.findall(key)) == sorted(_PH.findall(value)) or not _CYR.search(key), key
