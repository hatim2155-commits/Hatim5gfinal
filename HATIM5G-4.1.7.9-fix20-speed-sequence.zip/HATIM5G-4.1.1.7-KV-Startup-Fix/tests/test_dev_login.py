import hashlib

from core.dev_login import scram_values


def _page_js_style(password, salt_hex, iterations, first, server):
    """The page's own script, transcribed literally with hex strings (forge style)."""
    import hmac

    def r(e, t, n):  # pbkdf2 -> hex
        return hashlib.pbkdf2_hmac('sha256', e.encode(), t, n, 32).hex()

    def A(e, t):     # hmac key = text t, message = bytes of hex e
        return hmac.new(t.encode(), bytes.fromhex(e), hashlib.sha256).hexdigest()

    def c(e):
        return hashlib.sha256(bytes.fromhex(e)).hexdigest()

    def u(e, t, n, o):
        a = r(e, t, n)
        s = A(a, 'Client Key')
        l = A(c(s), o)
        p, f = bytes.fromhex(s), bytes.fromhex(l)
        return bytes(x ^ y for x, y in zip(p, f)).hex()

    def l_(e, t, n, o):
        return A(A(r(e, t, n), 'Server Key'), o)

    msg = f'{first},{server},{server}'
    return u(password, bytes.fromhex(salt_hex), iterations, msg), l_(password, bytes.fromhex(salt_hex), iterations, msg)


def test_matches_page_script_transcription():
    first, server = 'a' * 64, 'a' * 64 + 'xyZ+/'
    got = scram_values('Secret1', 'ab' * 32, 1000, first, server)
    assert got == _page_js_style('Secret1', 'ab' * 32, 1000, first, server)
    assert len(got[0]) == 64
