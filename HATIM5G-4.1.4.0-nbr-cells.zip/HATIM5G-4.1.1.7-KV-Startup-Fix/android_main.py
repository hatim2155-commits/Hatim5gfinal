"""
Hua4GMon — Android-версия (Kivy).

Использует тот же пакет ``core/``, что и Windows-версия (main.py):
сессия с роутером (RouterSession/SessionWorker), разбор данных
(Snapshot), состояние (SignalState), Band Lock, RF-аналитика, переводы.
Здесь только UI-слой на Kivy.

Экраны:
    * Подключение — автопоиск роутера, пароль, язык, подсказка, тестовый режим;
    * Монитор — крупная выбранная метрика со стрелкой и «Δ до пика»,
      RSRP/SINR/RSRQ/RSSI, строка вышки, события смены соты, советы,
      график; нижняя панель: звук-парктроник, сброс пиков, меню;
    * Информация — вышка, лучшие соты сессии, SIM/устройство, состояние
      (обновляется в реальном времени);
    * Сеть — Band Lock, антенна, перезагрузка, переподключение связи,
      диагностика и اختبار اتصال الألعاب.

Жизненный цикл: на паузе опрос приостанавливается, экран не гаснет
только во время мониторинга, «Назад» ведёт к монитору.
Сборка APK — Buildozer (buildozer.spec).
"""
from __future__ import annotations

import datetime
import importlib
import importlib.abc
import importlib.util
import logging
import os
import platform as py_platform
import re
import sys
import threading
import time
from collections.abc import Callable
from typing import Any

# --- Android crypto-совместимость (ДО первого обращения к huawei_lte_api) ---
# huawei-lte-api требует pycryptodomex (неймспейс Cryptodome), но у него
# нет рецепта python-for-android, и его нативные .so не грузятся на
# Android. Зато pycryptodome (неймспейс Crypto) рецепт имеет. Код пакетов
# идентичен — перенаправляем Cryptodome.* -> Crypto.*. На десктопе, где
# настоящий Cryptodome есть, алиас не включается.


class _CryptodomeAliasFinder(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    PREFIX = 'Cryptodome'

    def find_spec(self, fullname, path=None, target=None):
        if fullname == self.PREFIX or fullname.startswith(self.PREFIX + '.'):
            return importlib.util.spec_from_loader(fullname, self)
        return None

    def create_module(self, spec):
        real_name = 'Crypto' + spec.name[len(self.PREFIX):]
        module = importlib.import_module(real_name)
        sys.modules[spec.name] = module
        return module

    def exec_module(self, module):
        pass


try:
    import Cryptodome  # noqa: F401  (есть на десктопе — pycryptodomex)
except ImportError:
    sys.meta_path.insert(0, _CryptodomeAliasFinder())

from kivy.app import App
from kivy.clock import Clock
from kivy.core.text import LabelBase
from kivy.factory import Factory
from kivy.lang import Builder
from kivy.metrics import dp, sp
from kivy.properties import BooleanProperty, ListProperty, ObjectProperty, StringProperty
from kivy.uix.modalview import ModalView
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.uix.widget import Widget
from kivy.storage.jsonstore import JsonStore
from kivy.utils import escape_markup, platform

from core.neighbor_cells import NeighborCell, band_from_earfcn, parse_cell_info, parse_nbrcell_response
from core import (
    ANTENNA_MODES,
    DISCOVERY_CANDIDATES,
    GRAPH_HISTORY,
    GRAPH_MIN_SPAN,
    LANGUAGES,
    MIMO_LABELS,
    PARAM_RANGES,
    RAT_LABELS,
    REGION_BANDS,
    TREND_DOWN,
    TREND_FLAT,
    TREND_UP,
    UPLINK_LABELS,
    DemoModem,
    RouterSession,
    SessionWorker,
    SignalState,
    Snapshot,
    __version__,
    advice,
    build_diagnostics,
    calculate_overall_health,
    configure_library_logging,
    current_language,
    demo_angle_hint,
    demo_factory,
    diagnostics_json,
    discover_router,
    evaluate_signal,
    format_bytes_mb,
    format_mimo,
    format_modulation,
    format_rate_mbps,
    humanize_error,
    is_valid_ip,
    library_version,
    lock_warnings,
    lockable_bands,
    lte_band_label,
    mimo_status,
    parse_antenna_value,
    run_game_connection_test,
    set_language,
    t as _translate,
    uplink_status,
)

APP_NAME = "HATIM5G"


def Window_width() -> int:
    from kivy.core.window import Window
    return int(Window.width - dp(20))


def _make_widget(name: str, props: dict[str, Any]) -> Any:
    """Create a KV-defined widget, then assign its KV-declared properties.

    Setting them after creation (the same pattern as MetricCard.m_value)
    avoids depending on how constructor kwargs interact with KV rules."""
    widget = getattr(Factory, name)()
    for key, value in props.items():
        setattr(widget, key, value)
    return widget


def _to_float(value: Any) -> float | None:
    try:
        return float(str(value).replace('dBm', '').replace('dB', '').strip())
    except (TypeError, ValueError):
        return None


class _LocalizedText(str):
    """Text translated for the UI; format placeholders before Arabic shaping."""
    def format(self, *args: Any, **kwargs: Any) -> str:
        return _shape_arabic(super().format(*args, **kwargs))


def _shape_arabic(value: str) -> str:
    """Shape Arabic glyphs and apply Unicode bidi for Kivy's SDL text renderer."""
    if current_language() != 'ar' or not any('\u0600' <= ch <= '\u06ff' for ch in value):
        return value
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(value))
    except Exception:
        # Keep the app usable if a platform build lacks optional shaping modules.
        logger.exception("Arabic text shaping unavailable")
        return value


def _shape_arabic_display(value: str) -> str:
    """Shape Arabic display names even when the selected UI language is English."""
    if not any('\u0600' <= ch <= '\u06ff' for ch in value):
        return value
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(value))
    except Exception:
        return value


def t(text: str) -> str:
    """Translate UI text and shape Arabic for correct glyph order in Kivy."""
    translated = _translate(text)
    if current_language() == 'ar' and '{' in translated and '}' in translated:
        return _LocalizedText(translated)
    return _shape_arabic(translated)

# Логи видны в logcat (adb logcat | grep python).
logging.basicConfig(level=logging.INFO, format="%(name)s [%(levelname)s] %(message)s")
configure_library_logging()
logger = logging.getLogger(APP_NAME)

LTE_PARAMS = ['sinr', 'rsrp', 'rsrq', 'rssi']
NR_PARAMS = ['nr_sinr', 'nr_rsrp']
PARAM_TITLES = {'rsrp': 'RSRP', 'rssi': 'RSSI', 'sinr': 'SINR', 'rsrq': 'RSRQ',
                'nr_rsrp': 'NR RSRP', 'nr_sinr': 'NR SINR', 'nr_rsrq': 'NR RSRQ'}
TREND_GLYPHS = {TREND_UP: "↑", TREND_DOWN: "↓", TREND_FLAT: "→"}

# Шрифт со стрелками (↑→↓), ⚠, Δ: встроенный Roboto в Kivy их не содержит.
# Kivy не подменяет недостающие символы другим шрифтом, а цветных эмодзи
# (🔊 🧪 ✅ …) в DejaVu Sans нет — они рисуются квадратом. Все подписи
# Android используют только символы этого шрифта; это проверяет
# tests/test_project.py::test_android_text_fits_bundled_font.
_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets')
_FONT_PATH = os.path.join(_ASSETS, 'DejaVuSans.ttf')
_MOHANAD_PATH = os.path.join(_ASSETS, 'AL-Mohanad.ttf')
_ARABIC_READINGS_FONT_PATH = os.path.join(_ASSETS, 'Al-Mohanad-Long-Kaf.ttf')
# Жирное начертание — для крупных значений и заголовков (читаемость на солнце).
_FONT_BOLD_PATH = os.path.join(_ASSETS, 'DejaVuSans-Bold.ttf')
_MOHANAD_BOLD_PATH = os.path.join(_ASSETS, 'Al-Mohanad-Extra-Bold.ttf')

THEMES: dict[str, dict[str, list[float]]] = {
    'dark': {
        'c_bg': [0.07, 0.09, 0.12, 1], 'c_card': [0.12, 0.14, 0.18, 1],
        'c_text': [0.92, 0.94, 0.96, 1], 'c_sub': [0.62, 0.67, 0.72, 1],
        'c_accent': [0.04, 0.47, 0.84, 1], 'c_button2': [0.2, 0.24, 0.3, 1],
        'c_graph_bg': [0.1, 0.12, 0.16, 1], 'c_grid': [0.2, 0.23, 0.27, 1],
    },
    # «Солнце»: максимальный контраст для экрана под прямым солнцем.
    'sun': {
        'c_bg': [1, 1, 1, 1], 'c_card': [0.92, 0.93, 0.94, 1],
        'c_text': [0, 0, 0, 1], 'c_sub': [0.2, 0.2, 0.2, 1],
        'c_accent': [0.0, 0.3, 0.7, 1], 'c_button2': [0.8, 0.82, 0.85, 1],
        'c_graph_bg': [1, 1, 1, 1], 'c_grid': [0.8, 0.8, 0.8, 1],
    },
}


def unit_of(param: str) -> str:
    return "dBm" if param.endswith(('rsrp', 'rssi')) else "dB"


def fmt_num(value: float | None) -> str:
    """Число для подписи: целые — как есть (eNB 1048575, а не 1.04858e+06)."""
    if value is None:
        return "-"
    return str(value) if isinstance(value, int) else f"{value:g}"


def hex_to_rgba(color: str, sun: bool = False) -> list[float]:
    """'#00b894' или 'gray' → RGBA. В режиме «Солнце» цвета темнее."""
    named = {'gray': '#808080', 'green': '#33cc66', 'orange': '#e68033', 'red': '#d93333'}
    h = named.get(color, color).lstrip('#')
    try:
        rgb = [int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)]
    except (ValueError, IndexError):
        rgb = [0.5, 0.5, 0.5]
    if sun:
        rgb = [c * 0.7 for c in rgb]
    return [*rgb, 1.0]


def beep_interval(delta: float | None) -> float:
    """Пауза между сигналами парктроника: у пика — часто, далеко — редко."""
    if delta is None:
        return 1.5
    return 0.12 + min(1.3, abs(delta) * 0.12)


# =========================================================
# Платформенные сервисы Android (pyjnius)
# =========================================================

def set_keep_screen_on(on: bool) -> None:
    """Экран не гаснет, пока идёт мониторинг (FLAG_KEEP_SCREEN_ON).

    Флаг окна не требует разрешения WAKE_LOCK и снимается системой, когда
    приложение уходит в фон. Hardware validation required.
    """
    if platform != 'android':
        return
    try:
        from android.runnable import run_on_ui_thread
        from jnius import autoclass
    except ImportError:
        logger.warning("pyjnius/android недоступны — keep-screen-on пропущен")
        return

    @run_on_ui_thread
    def apply() -> None:
        activity = autoclass('org.kivy.android.PythonActivity').mActivity
        flag = autoclass('android.view.WindowManager$LayoutParams').FLAG_KEEP_SCREEN_ON
        window = activity.getWindow()
        if on:
            window.addFlags(flag)
        else:
            window.clearFlags(flag)
    apply()


class ToneBeeper:
    """Короткие сигналы через android.media.ToneGenerator.

    Hardware validation required: громкость и задержка на устройстве.
    """

    def __init__(self) -> None:
        self._tone: Any = None
        self._tone_id = 0
        if platform != 'android':
            return
        try:
            from jnius import autoclass
            tone_cls = autoclass('android.media.ToneGenerator')
            audio = autoclass('android.media.AudioManager')
            self._tone = tone_cls(audio.STREAM_MUSIC, 80)
            self._tone_id = tone_cls.TONE_PROP_BEEP
        except Exception:
            logger.warning("ToneGenerator недоступен", exc_info=True)

    @property
    def available(self) -> bool:
        return self._tone is not None

    def beep(self, ms: int = 60) -> None:
        if self._tone is not None:
            self._tone.startTone(self._tone_id, ms)

    def release(self) -> None:
        if self._tone is not None:
            self._tone.release()
            self._tone = None


# =========================================================
# График на Kivy canvas
# =========================================================

class SignalGraph(Widget):
    """Линейный график: автомасштаб, линия пика, признак устаревания.

    Размеры — в dp/sp; текстуры подписей кэшируются (подписи оси почти
    не меняются, а создание текстуры — самая дорогая часть отрисовки).
    """

    _TEX_CACHE_MAX = 96

    def __init__(self, **kw: Any) -> None:
        super().__init__(**kw)
        self._values: list[float] = []
        self._peak: float | None = None
        self._param = 'sinr'
        self._stale = False
        self._tex: dict[tuple, Any] = {}
        self.bind(pos=lambda *a: self._redraw(), size=lambda *a: self._redraw())

    def set_data(self, values: list[float], param: str, peak: float | None,
                 stale: bool) -> None:
        self._values = list(values)
        self._param = param
        self._peak = peak
        self._stale = stale
        self._redraw()

    def _texture(self, text: str, size: float, color: tuple, bold: bool = False) -> Any:
        key = (text, size, color, bold)
        tex = self._tex.get(key)
        if tex is None:
            from kivy.core.text import Label as CoreLabel
            lbl = CoreLabel(text=text, font_size=size, bold=bold, color=color)
            lbl.refresh()
            tex = lbl.texture
            if len(self._tex) >= self._TEX_CACHE_MAX:
                self._tex.clear()
            self._tex[key] = tex
        return tex

    def _y_range(self) -> tuple[float, float]:
        base = self._param.replace('nr_', '')
        lo_lim, hi_lim = PARAM_RANGES.get(base, (-140, 40))
        pts = self._values + ([self._peak] if self._peak is not None else [])
        if not pts:
            return float(lo_lim), float(hi_lim)
        lo, hi = min(pts), max(pts)
        span = GRAPH_MIN_SPAN.get(base, 10.0)
        if hi - lo < span:
            mid = (hi + lo) / 2
            lo, hi = mid - span / 2, mid + span / 2
        lo = max(lo_lim, 5 * ((lo - 1) // 5))
        hi = min(hi_lim, 5 * -((-(hi + 1)) // 5))
        return float(lo), float(max(hi, lo + 1))

    def _redraw(self) -> None:
        from kivy.graphics import Color, Ellipse, Line, Rectangle
        app = App.get_running_app()
        theme = THEMES[app.theme_name] if app else THEMES['dark']
        text_col = tuple(theme['c_sub'])
        self.canvas.clear()
        w, h = self.width, self.height
        pl, pr, pt, pb = dp(44), dp(10), dp(22), dp(20)
        plot_w, plot_h = w - pl - pr, h - pt - pb
        if plot_w <= dp(20) or plot_h <= dp(20):
            return
        x0, y0 = self.x + pl, self.y + pb
        y_min, y_max = self._y_range()
        rng = y_max - y_min

        def y_of(v: float) -> float:
            return y0 + plot_h * (max(y_min, min(y_max, v)) - y_min) / rng

        with self.canvas:
            Color(*theme['c_graph_bg'])
            Rectangle(pos=self.pos, size=self.size)
            for i in range(5):
                gy = y0 + plot_h * i / 4
                Color(*theme['c_grid'])
                Line(points=[x0, gy, x0 + plot_w, gy], width=1)
                tex = self._texture(f"{y_min + rng * i / 4:.0f}", sp(11), text_col)
                Color(1, 1, 1, 1)
                Rectangle(texture=tex, pos=(x0 - tex.width - dp(4), gy - tex.height / 2),
                          size=tex.size)
            title = PARAM_TITLES.get(self._param, self._param.upper())
            tex = self._texture(f"{title} ({unit_of(self._param)})", sp(13),
                                tuple(theme['c_text']), True)
            Color(1, 1, 1, 1)
            Rectangle(texture=tex, pos=(x0, self.y + h - pt + dp(3)), size=tex.size)
            tex = self._texture(t("последние {n} точек").format(n=GRAPH_HISTORY),
                                sp(10), text_col)
            Rectangle(texture=tex, pos=(x0 + (plot_w - tex.width) / 2, self.y + dp(3)),
                      size=tex.size)

            if self._peak is not None:
                py = y_of(self._peak)
                Color(0.0, 0.72, 0.58, 1)
                Line(points=[x0, py, x0 + plot_w, py], width=1, dash_length=dp(4),
                     dash_offset=dp(3))
            if len(self._values) < 2:
                return
            span = max(GRAPH_HISTORY - 1, 1)
            pts: list[float] = []
            for i, v in enumerate(self._values[-GRAPH_HISTORY:]):
                pts.extend([x0 + plot_w * i / span, y_of(v)])
            line_col = (0.6, 0.6, 0.6, 1) if self._stale else (0.0, 0.62, 0.9, 1)
            Color(*line_col)
            Line(points=pts, width=dp(1.5))
            lx, ly = pts[-2], pts[-1]
            r = dp(4)
            Ellipse(pos=(lx - r, ly - r), size=(2 * r, 2 * r))
            label = t("нет свежих данных") if self._stale else \
                f"{fmt_num(self._values[-1])} {unit_of(self._param)}"
            tex = self._texture(label, sp(13), line_col, True)
            Color(1, 1, 1, 1)
            Rectangle(texture=tex, pos=(self.x + w - pr - tex.width, self.y + h - pt + dp(3)),
                      size=tex.size)


class RotatedBox(Widget):
    """Показывает вложенный layout повёрнутым на 90° (альбомно).

    Scatter, а не голый Rotate по canvas: Scatter применяет ту же
    трансформацию к касаниям, поэтому кнопка внутри остаётся кликабельной.
    """

    def __init__(self, inner: Widget, **kw: Any) -> None:
        super().__init__(**kw)
        from kivy.uix.scatter import Scatter
        self._inner = inner
        inner.size_hint = (None, None)
        self._scatter = Scatter(do_rotation=False, do_scale=False,
                                do_translation=False, size_hint=(None, None))
        self._scatter.add_widget(inner)
        self.add_widget(self._scatter)
        self.bind(pos=self._sync, size=self._sync)

    def _sync(self, *a: Any) -> None:
        land = (self.height, self.width)
        self._scatter.size = land
        self._inner.size = land
        self._scatter.rotation = 90
        self._scatter.center = self.center


# =========================================================
# KV-разметка
# =========================================================

KV = """
#:import dp kivy.metrics.dp
#:import sp kivy.metrics.sp

<ActionButton@Button>:
    background_normal: ''
    background_down: ''
    background_color: (0, 0, 0, 0)
    color: 1, 1, 1, 1
    font_size: sp(16)
    bold: True
    size_hint_y: None
    height: dp(54)
    canvas.before:
        Color:
            rgba: app.c_accent if self.state == 'normal' else (app.c_accent[0]*0.82, app.c_accent[1]*0.82, app.c_accent[2]*0.82, 1)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(15)]

<FlatButton@Button>:
    background_normal: ''
    background_down: ''
    background_color: (0, 0, 0, 0)
    color: app.c_text
    font_size: sp(15)
    canvas.before:
        Color:
            rgba: app.c_button2 if self.state == 'normal' else app.c_accent
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(14)]

<SectionCard@BoxLayout>:
    orientation: 'vertical'
    size_hint_y: None
    height: self.minimum_height
    padding: dp(12)
    spacing: dp(8)
    canvas.before:
        Color:
            rgba: app.c_card
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(12)]

<SectionTitle@Label>:
    font_size: sp(19)
    bold: True
    color: app.c_text
    size_hint_y: None
    height: dp(34)
    text_size: self.width, None
    halign: app.text_align
    valign: 'middle'

<AutoLabel@Label>:
    font_size: sp(15)
    color: app.c_text
    size_hint_y: None
    height: self.texture_size[1] + dp(6)
    text_size: self.width, None
    halign: app.text_align
    valign: 'top'

<HintLabel@AutoLabel>:
    font_size: sp(13)
    color: app.c_sub

<InfoLabel@AutoLabel>:
    font_size: sp(16)
    line_height: 1.3
    markup: True

<MetricCard@BoxLayout>:
    orientation: 'vertical'
    m_name: ''
    m_value: '-'
    m_status: ''
    m_peak: ''
    m_color: 0.5, 0.5, 0.5, 1
    glow: 0, 0, 0, 0
    glow_fill: 0, 0, 0, 0
    glow_soft: 0, 0, 0, 0
    value_size: sp(22)
    padding: dp(6)
    spacing: dp(1)
    canvas.before:
        Color:
            rgba: app.c_card
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]
        Color:
            rgba: root.glow_fill
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]
        Color:
            rgba: root.glow_soft
        Line:
            rounded_rectangle: (self.x - dp(2), self.y - dp(2), self.width + dp(4), self.height + dp(4), dp(12))
            width: dp(3)
        Color:
            rgba: root.glow
        Line:
            rounded_rectangle: (self.x, self.y, self.width, self.height, dp(10))
            width: dp(1.6)
    Label:
        text: root.m_name
        font_size: sp(14)
        color: app.c_sub
        size_hint_y: None
        height: dp(18)
    Label:
        text: root.m_value
        # Fit complete live values in narrow cards without replacing digits with ellipses.
        font_size: min(root.value_size, max(sp(10), (self.width - dp(8)) / max(len(root.m_value), 5) * 1.75))
        bold: True
        color: root.m_color
        halign: 'center'
        valign: 'middle'
        text_size: self.width - dp(4), self.height
        shorten: False
    Label:
        text: root.m_status
        font_size: sp(13)
        color: root.m_color
        size_hint_y: None
        height: dp(18)
    Label:
        text: root.m_peak
        font_size: sp(14)
        color: app.c_sub
        size_hint_y: None
        height: dp(20) if self.text else 0

<NavButton@ButtonBehavior+BoxLayout>:
    icon: ''
    label: ''
    active: False
    orientation: 'vertical'
    padding: dp(1), dp(8), dp(1), dp(3)
    spacing: dp(2)
    canvas.before:
        Color:
            rgba: (0.10, 0.38, 0.95, 0.30) if self.active else (0.08, 0.12, 0.18, 0.96)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(18)]
        Color:
            rgba: (0.22, 0.52, 1, 1) if self.active else (0.24, 0.29, 0.38, 0.75)
        Line:
            rounded_rectangle: (self.x, self.y, self.width, self.height, dp(18))
            width: dp(1.8) if self.active else dp(0.8)
    Image:
        source: root.icon
        size_hint: None, None
        size: dp(26), dp(26)
        pos_hint: {'center_x': 0.5}
        color: (0.38, 0.66, 1, 1) if root.active else app.c_sub
    Label:
        text: root.label
        font_name: 'AlMohanad'
        font_size: sp(10)
        bold: True
        halign: 'center'
        valign: 'top'
        text_size: self.width, self.height
        color: (0.38, 0.66, 1, 1) if root.active else app.c_sub

<ThemeNavButton@ButtonBehavior+BoxLayout>:
    icon: ''
    label: ''
    orientation: 'vertical'
    padding: dp(1), dp(8), dp(1), dp(3)
    spacing: dp(2)
    canvas.before:
        Color:
            rgba: (0.22, 0.19, 0.12, 0.88)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(18)]
        Color:
            rgba: (0.72, 0.48, 0.08, 0.55)
        Line:
            rounded_rectangle: (self.x, self.y, self.width, self.height, dp(18))
            width: dp(1.0)
    Image:
        source: root.icon
        size_hint: None, None
        size: dp(26), dp(26)
        pos_hint: {'center_x': 0.5}
        color: (1, 0.78, 0.32, 1)
    Label:
        text: root.label
        font_name: 'AlMohanad'
        font_size: sp(10)
        bold: True
        halign: 'center'
        valign: 'top'
        text_size: self.width, self.height
        color: (1, 0.78, 0.32, 1)

<Header@BoxLayout>:
    title: ''
    size_hint_y: None
    height: dp(50)
    padding: dp(12), dp(4)
    Label:
        text: root.title
        font_size: sp(19)
        bold: True
        color: app.c_text
        halign: 'center'
        valign: 'middle'

BoxLayout:
    orientation: 'vertical'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    ScreenManager:
        id: main_sm
        ConnectionScreen:
        MonitorScreen:
        InfoScreen:
        ReadingsScreen:
        CellsScreen:
        ToolsScreen:
    BoxLayout:
        size_hint_y: None
        height: dp(90)
        spacing: dp(3)
        padding: dp(12), dp(6)
        canvas.before:
            Color:
                rgba: app.c_card
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20), dp(20), 0, 0]

        # المظهر — أول عنصر ليظهر يسار الشريط في الواجهة العربية
        ThemeNavButton:
            icon: app.nav_icon_dir + ('/moon.png' if app.theme_name == 'sun' else '/sun.png')
            label: app.nav_theme
            on_release: app.apply_theme('sun' if app.theme_name != 'sun' else 'dark')

        NavButton:
            icon: app.nav_icon_dir + '/info.png'
            label: app.nav_info
            active: (app.current_page == 'info')
            on_release: app.go('info')

        NavButton:
            icon: app.nav_icon_dir + '/network.png'
            label: app.nav_network
            active: (app.current_page == 'tools')
            on_release: app.go('tools')

        NavButton:
            icon: app.nav_icon_dir + '/cells.png'
            label: app.nav_cells
            active: (app.current_page == 'cells')
            on_release: app.go('cells')

        NavButton:
            icon: app.nav_icon_dir + '/readings.png'
            label: app.nav_readings
            active: (app.current_page == 'readings')
            on_release: app.go('readings')

        NavButton:
            icon: app.nav_icon_dir + '/antenna.png'
            label: app.nav_antenna
            active: (app.current_page == 'monitor')
            on_release: app.go('monitor')

        NavButton:
            icon: app.nav_icon_dir + '/home.png'
            label: app.nav_home
            active: (app.current_page == 'connection')
            on_release: app.go('connection')

<ConnectionScreen>:
    name: 'connection'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    ScrollView:
        bar_width: dp(5)
        scroll_type: ['bars', 'content']
        BoxLayout:
            orientation: 'vertical'
            size_hint_y: None
            height: self.minimum_height
            padding: dp(18), dp(20)
            spacing: dp(16)
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(142)
                padding: dp(16), dp(12)
                spacing: dp(4)
                canvas.before:
                    Color:
                        rgba: app.c_accent[0], app.c_accent[1], app.c_accent[2], 0.13
                    RoundedRectangle:
                        pos: self.x - dp(2), self.y - dp(2)
                        size: self.width + dp(4), self.height + dp(4)
                        radius: [dp(20)]
                    Color:
                        rgba: app.c_card
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(18)]
                    Color:
                        rgba: app.c_accent[0], app.c_accent[1], app.c_accent[2], 0.75
                    Line:
                        rounded_rectangle: (self.x, self.y, self.width, self.height, dp(18))
                        width: dp(1.2)
                Label:
                    text: 'HATIM5G'
                    font_size: sp(36)
                    bold: True
                    color: (0.35, 0.78, 1, 1)
                    outline_width: dp(1)
                    outline_color: (0.05, 0.35, 0.95, 0.5)
                    size_hint_y: None
                    height: dp(52)
                Label:
                    text: root.subtitle
                    font_size: sp(14)
                    color: app.c_sub
                    size_hint_y: None
                    height: dp(28)
                Label:
                    text: 'ROUTER CONTROL  •  LTE / 5G'
                    font_size: sp(11)
                    color: app.c_sub
                    size_hint_y: None
                    height: dp(20)
            SectionCard:
                AutoLabel:
                    text: root.lbl_ip
                BoxLayout:
                    id: ip_row
                    size_hint_y: None
                    height: dp(50)
                    spacing: dp(8)
                    TextInput:
                        id: ip_input
                        text: '192.168.8.1'
                        multiline: False
                        font_size: sp(17)
                        padding: dp(12), dp(12)
                        background_normal: ''
                        background_active: ''
                        background_color: app.c_bg
                        foreground_color: app.c_text
                        cursor_color: app.c_accent
                    FlatButton:
                        id: find_btn
                        text: root.lbl_find
                        size_hint_x: 0.42
                        font_size: sp(14)
                        on_release: root.on_find()
                AutoLabel:
                    text: root.lbl_pw
                TextInput:
                    id: pw_input
                    password: True
                    multiline: False
                    font_size: sp(17)
                    padding: dp(12), dp(12)
                    size_hint_y: None
                    height: dp(50)
                    background_normal: ''
                    background_active: ''
                    background_color: app.c_bg
                    foreground_color: app.c_text
                    cursor_color: app.c_accent
                    on_text_validate: root.on_connect()
                BoxLayout:
                    id: remember_row
                    size_hint_y: None
                    height: dp(38)
                    spacing: dp(8)
                    CheckBox:
                        id: remember_router
                        active: True
                        size_hint_x: None
                        width: dp(40)
                    AutoLabel:
                        id: remember_lbl
                        text: root.lbl_remember
                Button:
                    text: root.lbl_connect
                    size_hint_y: None
                    height: dp(58)
                    background_normal: ''
                    background_down: ''
                    background_color: 0, 0, 0, 0
                    color: 1, 1, 1, 1
                    font_size: sp(18)
                    bold: True
                    canvas.before:
                        Color:
                            rgba: (0.06, 0.42, 0.98, 0.25)
                        RoundedRectangle:
                            pos: self.x - dp(2), self.y - dp(2)
                            size: self.width + dp(4), self.height + dp(4)
                            radius: [dp(20)]
                        Color:
                            rgba: (0.06, 0.42, 0.98, 1) if self.state == 'normal' else (0.03, 0.32, 0.78, 1)
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [dp(18)]
                    on_release: root.on_connect()
                AutoLabel:
                    id: status_lbl
                    text: ''
                    font_size: sp(14)
                    color: root.status_color
                    halign: 'center'
            BoxLayout:
                size_hint_y: None
                height: dp(50)
                spacing: dp(10)
                FlatButton:
                    text: root.lbl_demo
                    on_release: app.start_demo()
                FlatButton:
                    text: root.lbl_help
                    on_release: root.on_help()
            SectionCard:
                BoxLayout:
                    id: lang_row
                    size_hint_y: None
                    height: dp(46)
                    spacing: dp(8)
                    Label:
                        id: lang_lbl
                        text: root.lbl_lang
                        color: app.c_sub
                        font_size: sp(14)
                        size_hint_x: None
                        width: dp(80)
                    Spinner:
                        id: lang_spinner
                        text: root.lang_name
                        values: root.lang_values
                        background_normal: ''
                        background_down: ''
                        background_color: 0, 0, 0, 0
                        color: app.c_text
                        canvas.before:
                            Color:
                                rgba: app.c_button2
                            RoundedRectangle:
                                pos: self.pos
                                size: self.size
                                radius: [dp(14)]
                        on_text: root.on_language(self.text)

<MonitorScreen>:
    name: 'monitor'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        padding: dp(8)
        spacing: dp(6)
        Label:
            text: root.lbl_title
            font_size: sp(17)
            bold: True
            color: app.c_text
            size_hint_y: None
            height: dp(24)
        Label:
            id: status_lbl
            text: ''
            font_size: sp(15)
            bold: True
            color: root.status_color
            size_hint_y: None
            height: self.texture_size[1] + dp(2)
            text_size: self.width, None
            halign: 'center'
        Label:
            id: tower_lbl
            text: '—'
            font_size: sp(15)
            bold: True
            color: app.c_text
            size_hint_y: None
            height: self.texture_size[1] + dp(2)
            text_size: self.width, None
            halign: 'center'
        Label:
            id: event_lbl
            text: ''
            font_size: sp(13)
            color: app.c_sub
            size_hint_y: None
            height: self.texture_size[1] if self.text else 0
            text_size: self.width, None
            halign: 'center'
        BoxLayout:
            size_hint_y: 0.30
            spacing: dp(6)
            MetricCard:
                id: primary_box
                size_hint_x: 0.66
                value_size: sp(54)
            BoxLayout:
                orientation: 'vertical'
                size_hint_x: 0.34
                canvas.before:
                    Color:
                        rgba: app.c_card
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [dp(10)]
                Label:
                    id: dir_lbl
                    text: '—'
                    font_size: sp(72)
                    bold: True
                    color: 0.5, 0.5, 0.5, 1
                Label:
                    id: dir_text_lbl
                    text: ''
                    font_size: sp(12)
                    color: app.c_sub
                    size_hint_y: None
                    height: dp(44)
                    text_size: self.width - dp(8), None
                    halign: 'center'
                    valign: 'middle'
        GridLayout:
            cols: 3
            spacing: dp(6)
            size_hint_y: 0.17
            MetricCard:
                id: secondary_box
                value_size: sp(30)
            MetricCard:
                id: small1_box
                value_size: sp(24)
            MetricCard:
                id: small2_box
                value_size: sp(24)
        Label:
            id: advice_lbl
            text: ''
            font_size: sp(13)
            color: root.advice_color
            size_hint_y: None
            height: self.texture_size[1] if self.text else 0
            text_size: self.width, None
            halign: 'left'
        BoxLayout:
            size_hint_y: None
            height: dp(42)
            spacing: dp(6)
            Spinner:
                id: graph_param
                text: 'sinr'
                values: root.graph_values
                size_hint_x: 0.5
                font_size: sp(15)
                on_text: app.set_graph_param(self.text)
            FlatButton:
                text: root.lbl_fullscreen
                size_hint_x: 0.5
                font_size: sp(14)
                on_release: app.open_fullscreen_graph()
        SignalGraph:
            id: signal_graph
            size_hint_y: 0.26
        BoxLayout:
            size_hint_y: None
            height: dp(56)
            spacing: dp(6)
            FlatButton:
                text: root.lbl_sound
                background_color: app.c_accent if app.sound_on else app.c_button2
                color: (1, 1, 1, 1) if app.sound_on else app.c_text
                on_release: app.toggle_sound()
            FlatButton:
                text: root.lbl_peaks
                on_release: app.reset_peaks()

<InfoScreen>:
    name: 'info'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        ScrollView:
            bar_width: dp(8)
            scroll_type: ['bars', 'content']
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(10)
                spacing: dp(10)
                SectionCard:
                    SectionTitle:
                        text: root.lbl_tower_title
                    InfoLabel:
                        id: tower_block
                        text: ''
                SectionCard:
                    SectionTitle:
                        text: root.lbl_cells_title
                    InfoLabel:
                        id: cells_block
                        text: ''
                SectionCard:
                    SectionTitle:
                        text: root.lbl_sim_title
                    InfoLabel:
                        id: sim_block
                        text: ''
                SectionCard:
                    SectionTitle:
                        text: root.lbl_status_title
                    InfoLabel:
                        id: status_block
                        text: ''

<CellCard@BoxLayout>:
    orientation: 'vertical'
    size_hint_y: None
    height: self.minimum_height
    padding: dp(12)
    spacing: dp(8)
    band: '—'
    title: ''
    sub: ''
    rsrp: ''
    rsrq: ''
    sinr: ''
    bars: 0
    band_color: 0.28, 0.73, 1, 1
    band_fill: 0.28, 0.73, 1, 0.18
    signal_color: 0.5, 0.5, 0.5, 1
    rsrp_color: 0.7, 0.75, 0.8, 1
    rsrq_color: 0.7, 0.75, 0.8, 1
    status_text: ''
    show_button: False
    cell_index: -1
    canvas.before:
        Color:
            rgba: 0.06, 0.115, 0.125, 1
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(16)]
    BoxLayout:
        size_hint_y: None
        height: dp(52)
        spacing: dp(10)
        Label:
            text: root.band
            size_hint_x: None
            width: dp(70)
            bold: True
            font_size: sp(22)
            color: root.band_color
            canvas.before:
                Color:
                    rgba: root.band_fill
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(12)]
                Color:
                    rgba: root.band_color
                Line:
                    rounded_rectangle: (self.x, self.y, self.width, self.height, dp(12))
                    width: dp(1.5)
        BoxLayout:
            orientation: 'vertical'
            Label:
                text: root.title
                bold: True
                font_size: sp(15)
                color: app.c_text
                halign: 'right'
                valign: 'middle'
                text_size: self.size
            Label:
                text: root.sub
                font_size: sp(13)
                color: app.c_sub
                halign: 'right'
                valign: 'middle'
                text_size: self.size
        Widget:
            size_hint_x: None
            width: dp(34)
            canvas:
                Color:
                    rgba: root.signal_color if root.bars >= 1 else (0.17, 0.21, 0.28, 1)
                RoundedRectangle:
                    pos: self.x, self.y + dp(8)
                    size: dp(6), dp(8)
                    radius: [dp(3)]
                Color:
                    rgba: root.signal_color if root.bars >= 2 else (0.17, 0.21, 0.28, 1)
                RoundedRectangle:
                    pos: self.x + dp(9), self.y + dp(8)
                    size: dp(6), dp(13)
                    radius: [dp(3)]
                Color:
                    rgba: root.signal_color if root.bars >= 3 else (0.17, 0.21, 0.28, 1)
                RoundedRectangle:
                    pos: self.x + dp(18), self.y + dp(8)
                    size: dp(6), dp(19)
                    radius: [dp(3)]
                Color:
                    rgba: root.signal_color if root.bars >= 4 else (0.17, 0.21, 0.28, 1)
                RoundedRectangle:
                    pos: self.x + dp(27), self.y + dp(8)
                    size: dp(6), dp(26)
                    radius: [dp(3)]
    BoxLayout:
        size_hint_y: None
        height: dp(50)
        spacing: dp(6)
        MetricCard:
            m_name: 'RSRP'
            m_value: root.rsrp
            m_color: root.rsrp_color
            value_size: sp(15)
        MetricCard:
            m_name: 'RSRQ'
            m_value: root.rsrq
            m_color: root.rsrq_color
            value_size: sp(15)
        MetricCard:
            m_name: 'SINR'
            m_value: root.sinr
            m_color: 0.62, 0.68, 0.74, 1
            value_size: sp(15)
    Label:
        text: root.status_text
        size_hint_y: None
        height: dp(26) if self.text else 0
        bold: True
        font_size: sp(14)
        color: 0.21, 0.82, 0.50, 1
    ActionButton:
        text: app.lbl_cell_connect
        height: dp(46) if root.show_button else 0
        opacity: 1 if root.show_button else 0
        disabled: not root.show_button
        on_release: app.cell_connect(root.cell_index)

<CellsScreen>:
    name: 'cells'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        BoxLayout:
            size_hint_y: None
            height: dp(50)
            padding: dp(14), dp(4)
            spacing: dp(8)
            FlatButton:
                text: root.lbl_scan
                size_hint_x: None
                width: dp(130)
                on_release: app.refresh_cells_screen(rescan=True)
            Label:
                text: root.scan_info
                font_size: sp(13)
                color: app.c_sub
                halign: 'right'
                valign: 'middle'
                text_size: self.size
        ScrollView:
            bar_width: dp(8)
            scroll_type: ['bars', 'content']
            BoxLayout:
                id: cells_box
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(12)
                spacing: dp(10)

<ToggleArrow@ButtonBehavior+Widget>:
    group: ''
    expanded: False
    on_release: app.toggle_carriers(self.group)
    size_hint_y: None
    height: dp(32)
    canvas:
        Color:
            rgba: 0.16, 0.21, 0.28, 0.9
        RoundedRectangle:
            pos: self.center_x - dp(26), self.center_y - dp(13)
            size: dp(52), dp(26)
            radius: [dp(13)]
        Color:
            rgba: 0.62, 0.70, 0.80, 1
        Line:
            points: (self.center_x - dp(8), self.center_y - dp(3), self.center_x, self.center_y + dp(4), self.center_x + dp(8), self.center_y - dp(3)) if self.expanded else (self.center_x - dp(8), self.center_y + dp(3), self.center_x, self.center_y - dp(4), self.center_x + dp(8), self.center_y + dp(3))
            width: dp(2)
            cap: 'round'
            joint: 'round'

<FactCell@BoxLayout>:
    k: ''
    v: ''
    orientation: 'vertical'
    size_hint_y: None
    height: dp(34)
    Label:
        text: root.k
        font_size: sp(11)
        color: app.c_sub
        size_hint_y: None
        height: dp(15)
    Label:
        text: root.v
        font_size: sp(13)
        bold: True
        color: app.c_text

<ReadingTile@BoxLayout>:
    m_title: ''
    m_num: ''
    m_unit: ''
    m_rate: ''
    tone: 0.7, 0.75, 0.8, 1
    pill_fill: 0.1, 0.14, 0.2, 1
    pill_line: 0.2, 0.25, 0.3, 1
    orientation: 'vertical'
    padding: dp(3), dp(5)
    spacing: dp(1)
    canvas.before:
        Color:
            rgba: app.c_card
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]
    Label:
        text: root.m_title
        font_size: sp(11)
        color: app.c_sub
        size_hint_y: None
        height: dp(14)
    Label:
        text: root.m_num
        font_size: sp(16)
        bold: True
        color: root.tone
    Label:
        text: root.m_unit
        font_size: sp(10)
        color: root.tone
        size_hint_y: None
        height: dp(13)
    BoxLayout:
        size_hint_y: None
        height: dp(20)
        padding: dp(2), dp(1)
        canvas.before:
            Color:
                rgba: root.pill_fill
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(8)]
            Color:
                rgba: root.pill_line
            Line:
                rounded_rectangle: (self.x, self.y, self.width, self.height, dp(8))
                width: dp(1)
        Label:
            text: root.m_rate
            font_size: sp(11)
            bold: True
            color: root.tone

<CarrierCard@BoxLayout>:
    orientation: 'vertical'
    size_hint_y: None
    height: self.minimum_height
    padding: dp(8)
    spacing: dp(6)
    band: '—'
    tech: 'LTE'
    band_label: ''
    band_size: sp(28)
    band_color: 0.28, 0.73, 1, 1
    band_fill: 0.28, 0.73, 1, 0.18
    glow_soft: 0.28, 0.73, 1, 0.3
    role: ''
    role_color: 0.21, 0.82, 0.5, 1
    role_fill: 0.21, 0.82, 0.5, 0.16
    frame: 0.21, 0.82, 0.5, 0.35
    sub: ''
    canvas.before:
        Color:
            rgba: 0.06, 0.10, 0.13, 1
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(14)]
        Color:
            rgba: root.frame
        Line:
            rounded_rectangle: (self.x, self.y, self.width, self.height, dp(14))
            width: dp(1.2)
    BoxLayout:
        size_hint_y: None
        height: dp(24)
        spacing: dp(8)
        Label:
            text: root.role
            size_hint_x: None
            width: dp(64)
            bold: True
            font_size: sp(12)
            color: root.role_color
            canvas.before:
                Color:
                    rgba: root.role_fill
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(14)]
                Color:
                    rgba: root.role_color
                Line:
                    rounded_rectangle: (self.x, self.y, self.width, self.height, dp(14))
                    width: dp(1)
        Label:
            text: root.sub
            font_size: sp(12)
            color: app.c_sub
            halign: 'left'
            valign: 'middle'
            text_size: self.size
    BoxLayout:
        id: tiles
        size_hint_y: None
        height: dp(100)
        spacing: dp(5)
        BoxLayout:
            size_hint_x: 1.15
            orientation: 'vertical'
            padding: dp(4)
            canvas.before:
                Color:
                    rgba: root.glow_soft
                Line:
                    rounded_rectangle: (self.x - dp(2), self.y - dp(2), self.width + dp(4), self.height + dp(4), dp(14))
                    width: dp(3)
                Color:
                    rgba: root.band_fill
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(12)]
                Color:
                    rgba: root.band_color
                Line:
                    rounded_rectangle: (self.x, self.y, self.width, self.height, dp(12))
                    width: dp(1.8)
            Label:
                text: root.band_label
                font_size: sp(11)
                color: app.c_sub
                size_hint_y: None
                height: dp(14)
            Label:
                text: root.band
                font_size: root.band_size
                bold: True
                color: root.band_color
            Label:
                text: root.tech
                font_size: sp(11)
                color: root.band_color
                size_hint_y: None
                height: dp(14)
    GridLayout:
        id: facts_grid
        cols: 3
        size_hint_y: None
        height: self.minimum_height
        spacing: dp(4), dp(2)

<ReadingsScreen>:
    name: 'readings'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        ScrollView:
            bar_width: dp(8)
            scroll_type: ['bars', 'content']
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(12)
                spacing: dp(12)
                SectionCard:
                    canvas.before:
                        Color:
                            rgba: 0.047, 0.11, 0.17, 1
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [dp(14)]
                    SectionTitle:
                        font_name: 'AlMohanadLongKaf'
                        font_size: sp(18)
                        color: 0.28, 0.73, 1, 1
                        text: root.lbl_lte
                    BoxLayout:
                        id: lte_cards
                        orientation: 'vertical'
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(10)
                SectionCard:
                    canvas.before:
                        Color:
                            rgba: 0.025, 0.12, 0.12, 1
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [dp(14)]
                    SectionTitle:
                        font_name: 'AlMohanadLongKaf'
                        font_size: sp(18)
                        color: 0.20, 0.86, 0.79, 1
                        text: root.lbl_nr
                    BoxLayout:
                        id: nr_cards
                        orientation: 'vertical'
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(10)
                BoxLayout:
                    id: agg_wrap
                    orientation: 'vertical'
                    size_hint_y: None
                    height: self.minimum_height
                    SectionCard:
                        id: agg_card
                        SectionTitle:
                            font_name: 'AlMohanadLongKaf'
                            font_size: sp(21)
                            text: root.lbl_aggregation
                        InfoLabel:
                            font_name: 'AlMohanadLongKaf'
                            font_size: sp(17)
                            id: aggregation_readings
                            text: root.aggregation_text
                HintLabel:
                    text: root.lbl_note

<ToolsScreen>:
    name: 'tools'
    canvas.before:
        Color:
            rgba: app.c_bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        Header:
            title: root.lbl_title
        ScrollView:
            id: tools_scroll
            bar_width: dp(8)
            scroll_type: ['bars', 'content']
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(10)
                spacing: dp(12)
                AutoLabel:
                    text: root.net_msg
                    color: root.net_msg_color
                    bold: True
                    height: (self.texture_size[1] + dp(6)) if self.text else 0
                SectionCard:
                    SectionTitle:
                        text: root.lbl_bandlock
                    HintLabel:
                        text: root.hint_bandlock
                    AutoLabel:
                        text: root.lock_state
                        bold: True
                    GridLayout:
                        id: bands_grid
                        cols: 4
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(4)
                    FlatButton:
                        text: root.lbl_mark_current
                        size_hint_y: None
                        height: dp(48)
                        on_release: app.mark_current_bands()
                    ActionButton:
                        text: root.lbl_apply_bands
                        on_release: app.apply_bands()
                    SectionTitle:
                        text: root.lbl_nr_bands
                    HintLabel:
                        text: root.nr_bands_display
                    GridLayout:
                        id: nr_bands_grid
                        cols: 4
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(8)
                    BoxLayout:
                        size_hint_y: None
                        height: dp(52)
                        spacing: dp(8)
                        FlatButton:
                            text: root.lbl_reset_auto
                            on_release: app.reset_bands()
                        FlatButton:
                            text: root.lbl_restore
                            on_release: app.restore_bands()
                SectionCard:
                    id: antenna_card
                    SectionTitle:
                        text: root.lbl_antenna
                    Spinner:
                        id: antenna_spinner
                        text: root.antenna_text
                        values: root.antenna_values
                        font_size: sp(16)
                        size_hint_y: None
                        height: dp(48)
                    ActionButton:
                        text: root.lbl_apply_antenna
                        on_release: app.apply_antenna(antenna_spinner.text)
                SectionCard:
                    SectionTitle:
                        text: root.lbl_router
                    HintLabel:
                        text: root.hint_router
                    FlatButton:
                        text: root.lbl_reattach
                        size_hint_y: None
                        height: dp(52)
                        on_release: app.confirm_reattach()
                    FlatButton:
                        text: root.lbl_reboot
                        size_hint_y: None
                        height: dp(52)
                        on_release: app.confirm_reboot()
                    FlatButton:
                        text: root.lbl_diag
                        size_hint_y: None
                        height: dp(52)
                        on_release: app.copy_diagnostics()
                SectionCard:
                    SectionTitle:
                        text: root.lbl_whitelist
                    HintLabel:
                        text: root.hint_whitelist
                    ActionButton:
                        text: root.lbl_wl_check
                        on_release: app.game_connection_check()
                    AutoLabel:
                        text: root.wl_verdict
                        font_size: sp(16)
                        bold: True
                        color: root.wl_color
                    AutoLabel:
                        text: root.wl_detail
                        font_size: sp(13)
"""


# =========================================================
# ЭКРАНЫ
# =========================================================

class ConnectionScreen(Screen):
    subtitle = StringProperty("")
    lbl_ip = StringProperty("")
    lbl_pw = StringProperty("")
    lbl_remember = StringProperty("")
    lbl_find = StringProperty("")
    lbl_connect = StringProperty("")
    lbl_lang = StringProperty("")
    lbl_demo = StringProperty("")
    lbl_help = StringProperty("")
    lang_name = StringProperty("")
    lang_values = ListProperty([])
    status_color = ListProperty([0.9, 0.5, 0.2, 1])

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()

    def refresh_texts(self) -> None:
        self.subtitle = t("Портативный монитор LTE/5G Huawei")
        self.lbl_ip = t("IP адрес:")
        self.lbl_pw = t("Пароль:")
        self.lbl_remember = t("حفظ بيانات الراوتر على هذا الجهاز")
        self.lbl_find = t("Найти")
        self.lbl_connect = t("Подключиться")
        self.lbl_lang = t("Язык:")
        self.lbl_demo = t("Тестовый режим (без модема)")
        self.lbl_help = t("Подсказка")
        self.lang_values = [_shape_arabic_display(name) for name in LANGUAGES.values()]
        self.lang_name = _shape_arabic_display(LANGUAGES.get(current_language(), "العربية"))
        self._apply_direction()

    def _apply_direction(self) -> None:
        """Mirror the row order for Arabic (RTL): the label sits on the right."""
        rtl = current_language() == 'ar'

        def arrange(row_id: str, ltr_ids: list[str]) -> None:
            row = self.ids.get(row_id)
            widgets = [self.ids.get(i) for i in ltr_ids]
            if row is None or any(w is None for w in widgets):
                return
            order = list(reversed(widgets)) if rtl else widgets
            if list(reversed(row.children)) == order:
                return
            row.clear_widgets()
            for widget in order:
                row.add_widget(widget)

        arrange('ip_row', ['ip_input', 'find_btn'])
        arrange('remember_row', ['remember_router', 'remember_lbl'])
        arrange('lang_row', ['lang_lbl', 'lang_spinner'])

    def set_status(self, text: str, color: list[float]) -> None:
        lbl = self.ids.get('status_lbl')
        if lbl is not None:
            lbl.text = text
        self.status_color = color

    def on_language(self, name: str) -> None:
        code = {_shape_arabic_display(v): k for k, v in LANGUAGES.items()}.get(name)
        if code and code != current_language():
            set_language(code)
            App.get_running_app().refresh_all_texts()

    def on_help(self) -> None:
        App.get_running_app().show_popup(t("Подключение и частые ошибки"), t(
            "IP по умолчанию: 192.168.8.1 (для B315/B525 — 192.168.1.1 или "
            "192.168.3.1) — кнопка «Найти» проверит их сама. Логин: admin, "
            "пароль — на наклейке роутера.\n\n"
            "Частые ошибки и что делать:\n"
            "• 108006 — неверный логин или пароль.\n"
            "• 108007 — слишком много неудачных попыток: роутер временно "
            "заблокировал вход. Подождите несколько минут.\n"
            "• 108003 — уже выполнен вход с другого устройства. Закройте "
            "веб-интерфейс роутера.\n"
            "• 100002 — функция не поддерживается этой моделью или "
            "прошивкой. Часть возможностей будет недоступна — это нормально.\n"
            "• 100003 / 125002 / 125003 — истекла сессия. Программа войдёт "
            "заново сама.\n"
            "• Нет ответа — проверьте, что телефон подключён к Wi-Fi именно "
            "этого роутера и IP введён верно.\n\n"
            "Тестовый режим показывает работу программы без роутера."))

    def on_find(self) -> None:
        ip_input = self.ids.get('ip_input')
        entered = ip_input.text.strip() if ip_input is not None else ''
        App.get_running_app().discover(entered)

    def on_connect(self) -> None:
        ip_input, pw_input = self.ids.get('ip_input'), self.ids.get('pw_input')
        if ip_input is None or pw_input is None:
            return
        ip = ip_input.text.strip()
        if not is_valid_ip(ip):
            self.set_status(t("Неверный IP-адрес: {ip}\nПример: 192.168.8.1").format(ip=ip),
                            [0.9, 0.3, 0.3, 1])
            return
        App.get_running_app().connect(ip, pw_input.text)


class MonitorScreen(Screen):
    lbl_title = StringProperty("")
    lbl_fullscreen = StringProperty("")
    lbl_sound = StringProperty("")
    lbl_peaks = StringProperty("")
    lbl_menu = StringProperty("")
    graph_values = ListProperty(list(LTE_PARAMS))
    status_color = ListProperty([0.2, 0.8, 0.4, 1])
    advice_color = ListProperty([0.95, 0.62, 0.25, 1])

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()

    def refresh_texts(self) -> None:
        self.lbl_title = t("وزن الأنتينا")
        self.lbl_fullscreen = t("Во весь экран")
        self.lbl_sound = t("♪ Звук")
        self.lbl_peaks = t("⟲ Пики")
        self.lbl_menu = t("☰ Меню")


class InfoScreen(Screen):
    lbl_title = StringProperty("")
    lbl_tower_title = StringProperty("")
    lbl_cells_title = StringProperty("")
    lbl_sim_title = StringProperty("")
    lbl_status_title = StringProperty("")

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()
        App.get_running_app().refresh_info_screen()

    def refresh_texts(self) -> None:
        self.lbl_title = t("Информация")
        self.lbl_tower_title = t("Информация о станции")
        self.lbl_cells_title = t("Лучшие соты за сессию")
        self.lbl_sim_title = t("SIM / Устройство")
        self.lbl_status_title = t("Состояние")


class ReadingsScreen(Screen):
    lbl_title = StringProperty("")
    lbl_lte = StringProperty("")
    lbl_nr = StringProperty("")
    lbl_aggregation = StringProperty("")
    lbl_note = StringProperty("")
    lte_text = StringProperty("")
    nr_text = StringProperty("")
    aggregation_text = StringProperty("")

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()
        App.get_running_app().refresh_readings_screen()

    def refresh_texts(self) -> None:
        self.lbl_title = t("القراءات")
        self.lbl_lte = t("قراءات 4G LTE")
        self.lbl_nr = t("قراءات 5G NR")
        self.lbl_aggregation = t("الدمج الفعلي الحالي")
        self.lbl_note = t("تعرض الصفحة القيم التي يوفرها الراوتر فقط. قد لا تتوفر قياسات مستقلة لكل حامل ثانوي.")


class CellsScreen(Screen):
    lbl_title = StringProperty("")
    lbl_scan = StringProperty("")
    scan_info = StringProperty("")

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()
        App.get_running_app().refresh_cells_screen(rescan=True)

    def refresh_texts(self) -> None:
        self.lbl_title = t("الخلايا القريبة")
        self.lbl_scan = t("مسح الآن")


class ToolsScreen(Screen):
    lbl_title = StringProperty("")
    lbl_bandlock = StringProperty("")
    hint_bandlock = StringProperty("")
    lock_state = StringProperty("")
    lbl_mark_current = StringProperty("")
    lbl_apply_bands = StringProperty("")
    nr_lock_note = StringProperty("")
    nr_bands_display = StringProperty("")
    lbl_nr_bands = StringProperty("")
    lbl_nr_lock_check = StringProperty("")
    lbl_reset_auto = StringProperty("")
    lbl_restore = StringProperty("")
    lbl_antenna = StringProperty("")
    lbl_apply_antenna = StringProperty("")
    antenna_text = StringProperty("")
    antenna_values = ListProperty([])
    lbl_router = StringProperty("")
    hint_router = StringProperty("")
    lbl_reattach = StringProperty("")
    lbl_reboot = StringProperty("")
    lbl_diag = StringProperty("")
    lbl_whitelist = StringProperty("")
    hint_whitelist = StringProperty("")
    lbl_wl_check = StringProperty("")
    wl_verdict = StringProperty("")
    wl_detail = StringProperty("")
    wl_color = ListProperty([0.5, 0.5, 0.5, 1])
    net_msg = StringProperty("")
    net_msg_color = ListProperty([0.5, 0.5, 0.5, 1])

    def on_pre_enter(self, *args: Any) -> None:
        self.refresh_texts()
        app = App.get_running_app()
        app.build_band_checkboxes()
        app.build_nr_band_checkboxes()
        app.load_router_config()

    def refresh_texts(self) -> None:
        self.lbl_title = t("Сеть")
        self.lbl_bandlock = t("Фиксация частот (Band Lock)")
        self.hint_bandlock = t(
            "Список взят из модема; замеченные в эфире бэнды — первыми. "
            "Меняются только LTE-бэнды; «Как было» восстановит настройки, "
            "прочитанные при подключении.")
        self.lbl_mark_current = t("Отметить текущие")
        self.lbl_apply_bands = t("Применить Band Lock")
        self.lbl_nr_bands = t("باندات 5G NR")
        self.nr_bands_display = t("حدد باندات 5G المطلوبة؛ خياراتها منفصلة عن LTE")
        self.lbl_reset_auto = t("Все (AUTO)")
        self.lbl_restore = t("↩ Как было")
        self.lbl_antenna = t("إعدادات الأنتينا")
        self.lbl_apply_antenna = t("Применить")
        self.antenna_values = [t(k) for k in ANTENNA_MODES]
        if not self.antenna_text:
            self.antenna_text = t("Авто")
        self.lbl_router = t("Управление роутером")
        self.hint_router = t(
            "«Переподключить связь» заставляет модем заново выбрать лучшую "
            "соту — быстрее перезагрузки. После перезагрузки программа "
            "переподключится сама.")
        self.lbl_reattach = t("Переподключить связь")
        self.lbl_reboot = t("Перезагрузить роутер")
        self.lbl_diag = t("Скопировать диагностику")
        self.lbl_whitelist = t("اختبار الألعاب")
        self.hint_whitelist = t(
            "اختبر اتصال PUBG Mobile وEA SPORTS FC Mobile. القياس إلى خوادم HTTPS عامة وليس Ping خادم المباراة الفعلي.")
        self.lbl_wl_check = t("بدء الاختبار الشامل")


# =========================================================
# ПРИЛОЖЕНИЕ
# =========================================================

class Hua4GMonApp(App):
    sm = ObjectProperty(None, allownone=True)
    current_page = StringProperty('connection')
    text_align = StringProperty('right')
    lbl_cell_connect = StringProperty("")
    lbl_cells_open = StringProperty("")
    nav_icon_dir = StringProperty(os.path.join(_ASSETS, 'nav'))
    nav_home = StringProperty("")
    nav_readings = StringProperty("")
    nav_cells = StringProperty("")
    nav_network = StringProperty("")
    nav_antenna = StringProperty("")
    nav_info = StringProperty("")
    nav_settings = StringProperty("")
    nav_theme = StringProperty("")
    theme_name = StringProperty('dark')
    c_bg = ListProperty(THEMES['dark']['c_bg'])
    c_card = ListProperty(THEMES['dark']['c_card'])
    c_text = ListProperty(THEMES['dark']['c_text'])
    c_sub = ListProperty(THEMES['dark']['c_sub'])
    c_accent = ListProperty(THEMES['dark']['c_accent'])
    c_button2 = ListProperty(THEMES['dark']['c_button2'])
    sound_on = BooleanProperty(False)
    lbl_back = StringProperty("")

    # ---------- запуск и жизненный цикл ----------

    def build(self) -> Any:
        """Safety wrapper: a startup exception is saved and shown on screen
        instead of silently closing the app, so the cause can be read."""
        try:
            return self._build_app()
        except Exception:
            import traceback
            text = traceback.format_exc()
            self._startup_failed = True
            try:
                logger.error("Startup failed:\n%s", text)
                path = os.path.join(self.user_data_dir, 'startup_error.txt')
                with open(path, 'w', encoding='utf-8') as fh:
                    fh.write(text)
            except Exception:
                path = ''
            from kivy.uix.label import Label as _Label
            from kivy.uix.scrollview import ScrollView as _ScrollView
            lbl = _Label(text="HATIM5G startup error\n" + (path + "\n\n" if path else "\n") + text[-3500:],
                         font_name='Roboto', font_size=sp(11), size_hint_y=None,
                         halign='left', valign='top', color=(1, 0.6, 0.6, 1),
                         text_size=(Window_width(), None))
            lbl.bind(texture_size=lambda inst, size: setattr(inst, 'height', size[1]))
            view = _ScrollView()
            view.add_widget(lbl)
            return view

    _startup_failed = False

    def _install_guard(self) -> None:
        """An uncaught error in a UI callback no longer closes the app: it is
        written to crash_log.txt (app data folder) and the app keeps running."""
        from kivy.base import ExceptionHandler, ExceptionManager
        app = self

        class _Guard(ExceptionHandler):
            def handle_exception(self, inst: BaseException) -> Any:
                try:
                    import traceback
                    text = ''.join(traceback.format_exception(type(inst), inst, inst.__traceback__))
                    logger.error("Guarded UI error:\n%s", text)
                    path = os.path.join(app.user_data_dir, 'crash_log.txt')
                    if os.path.exists(path) and os.path.getsize(path) > 200_000:
                        os.remove(path)
                    with open(path, 'a', encoding='utf-8') as fh:
                        fh.write(time.strftime('%Y-%m-%d %H:%M:%S') + '\n' + text + '\n')
                except Exception:
                    pass
                return ExceptionManager.PASS

        ExceptionManager.add_handler(_Guard())

    def _build_app(self) -> ScreenManager:
        self._install_guard()
        from kivy.core.window import Window
        Window.clearcolor = tuple(self.c_bg)
        Window.softinput_mode = 'below_target'
        Window.bind(on_keyboard=self._on_keyboard)
        # Use DejaVu Sans as the app-wide UI font: it has broad Unicode coverage
        # for Arabic, Latin, arrows, and technical glyphs. A display-only Arabic
        # font can omit symbols and turn navigation icons into empty squares.
        if os.path.exists(_FONT_PATH):
            bold = _FONT_BOLD_PATH if os.path.exists(_FONT_BOLD_PATH) else _FONT_PATH
            LabelBase.register(name='DejaVuSans', fn_regular=_FONT_PATH, fn_bold=bold)
            LabelBase.register(name='AlMohanad', fn_regular=_MOHANAD_PATH if os.path.exists(_MOHANAD_PATH) else _FONT_PATH,
                               fn_bold=_MOHANAD_BOLD_PATH if os.path.exists(_MOHANAD_BOLD_PATH) else bold)
            # Kivy widgets default to Roboto; point it to a symbol-complete font
            # instead of Al-Mohanad, whose glyph set may not include nav symbols.
            LabelBase.register(name='Roboto', fn_regular=_FONT_PATH, fn_bold=bold)
        if os.path.exists(_ARABIC_READINGS_FONT_PATH):
            LabelBase.register(name='AlMohanadLongKaf', fn_regular=_ARABIC_READINGS_FONT_PATH,
                               fn_bold=_ARABIC_READINGS_FONT_PATH)
        self.title = f"{APP_NAME} v{__version__}"
        self._router_store = JsonStore(os.path.join(self.user_data_dir, 'router.json'))
        # Журнал сессии нужен только для экспорта CSV, которого на Android нет.
        self.state = SignalState(trend_param='sinr', log_max=GRAPH_HISTORY)
        self.session: RouterSession | None = None
        self.worker: SessionWorker | None = None
        self.demo_modem: DemoModem | None = None
        self.link = 'offline'
        self.interval = 1.0
        self.band_vars: dict[int, Any] = {}
        self.nr_band_vars: dict[int, Any] = {}
        self._nr_bands_shown: list[int] = []
        self.band_role_vars: dict[int, dict[str, Any]] = {}
        self._band_list: list[int] = list(REGION_BANDS)
        self._bands_shown: list[int] = []
        self._busy = False
        self._discovering = False       # идёт автопоиск роутера
        self._wl_running = False        # идёт проверка белых списков
        self._fs_graph: SignalGraph | None = None
        self._last_back = 0.0
        self._beep_ev: Any = None
        self.beeper = ToneBeeper()
        self.lbl_back = t("رجوع")
        self.nav_home = t("الرئيسية")
        self.nav_readings = t("القراءات")
        self.nav_cells = t("الخلايا")
        self.nav_network = t("الشبكة")
        self.nav_antenna = t("وزن الانتينا")
        self.nav_info = t("المعلومات")
        self.nav_settings = t("الإعدادات")
        self.nav_theme = t("المظهر")
        self.lbl_cell_connect = t("اتصال بهذه الخلية")
        self.lbl_cells_open = t("الخلايا القريبة")
        self.text_align = 'right' if current_language() == 'ar' else 'left'
        self._root_widget = Builder.load_string(KV)
        self.sm: ScreenManager = self._root_widget.ids.main_sm
        self.current_page = self.sm.current
        self.sm.bind(current=lambda _inst, value: setattr(self, 'current_page', value))
        Clock.schedule_interval(self._tick, 0.5)
        return self._root_widget

    def on_start(self) -> None:
        if self._startup_failed:
            return
        """Restore router details from the app-private Android data directory."""
        try:
            if self._router_store.exists('router'):
                saved = self._router_store.get('router')
                scr = self._conn_screen()
                if scr.ids.get('ip_input') is not None:
                    scr.ids.ip_input.text = saved.get('ip', '192.168.8.1')
                if scr.ids.get('pw_input') is not None:
                    scr.ids.pw_input.text = saved.get('password', '')
        except Exception:
            logger.exception("Could not restore saved router details")

    def save_router_details(self, ip: str, password: str, remember: bool) -> None:
        try:
            if remember:
                self._router_store.put('router', ip=ip.strip(), password=password)
            elif self._router_store.exists('router'):
                self._router_store.delete('router')
        except Exception:
            logger.exception("Could not save router details")

    def on_pause(self) -> bool:
        if self._startup_failed:
            return True
        """Свернули приложение: опрос на паузу, звук выключаем."""
        if self.worker is not None:
            self.worker.pause()
        self._stop_beeps()
        return True

    def on_resume(self) -> None:
        if self._startup_failed:
            return
        if self.worker is not None:
            self.worker.resume()
        if self.sound_on:
            self._schedule_beep()

    def on_stop(self) -> None:
        if self._startup_failed:
            return
        worker = self.worker
        if worker is not None:
            worker.stop()
            worker.join(timeout=2.0)       # дать отправить logout
        self.beeper.release()
        set_keep_screen_on(False)

    # ---------- тема, тексты, навигация ----------

    def apply_theme(self, name: str) -> None:
        from kivy.core.window import Window
        self.theme_name = name
        for key, value in THEMES[name].items():
            if hasattr(self, key):
                setattr(self, key, value)
        Window.clearcolor = tuple(self.c_bg)
        self._bands_shown = []          # подписи бэндов — заново, в цвете темы
        self.build_band_checkboxes()
        if self.state.last is not None:
            self._render(self.state.last)
        else:
            self.refresh_graph()

    def refresh_all_texts(self) -> None:
        self.text_align = 'right' if current_language() == 'ar' else 'left'
        self.lbl_back = t("رجوع")
        for name in ('connection', 'monitor', 'info', 'readings', 'cells', 'tools'):
            self.sm.get_screen(name).refresh_texts()
        self._render_link_state()
        if self.state.last is not None:
            self._render(self.state.last)

    def go(self, screen: str) -> None:
        self.sm.current = screen

    def open_antenna_tools(self) -> None:
        """Open network tools and scroll directly to antenna controls."""
        self.go('tools')
        try:
            screen = self.sm.get_screen('tools')
            scroll = screen.ids.get('tools_scroll')
            card = screen.ids.get('antenna_card')
            if scroll is not None and card is not None:
                Clock.schedule_once(lambda _dt: scroll.scroll_to(card, padding=dp(12), animate=True), 0.12)
        except Exception:
            logger.exception("Could not focus antenna controls")

    def _on_keyboard(self, window: Any, key: int, *args: Any) -> bool:
        """Системная «Назад» (Esc на десктопе).

        Hardware validation required: жест «Назад» Android 13+ на устройстве.
        """
        if self._startup_failed or key != 27:
            return False
        if any(isinstance(w, ModalView) for w in window.children):
            return False            # открытый диалог закроется сам
        current = self.sm.current
        if current in ('info', 'readings', 'tools', 'cells'):
            self.sm.current = 'monitor'
            return True
        if current == 'monitor':
            now = time.monotonic()
            if now - self._last_back < 2.0:
                self.disconnect()
            else:
                self._last_back = now
                self.toast(t("Нажмите «Назад» ещё раз, чтобы отключиться"))
            return True
        if current == 'connection':
            now = time.monotonic()
            if now - self._last_back < 2.0:
                return False        # second press: leave the app
            self._last_back = now
            self.toast(t("اضغط «رجوع» مرة أخرى للخروج"))
            return True
        return False

    # ---------- подключение ----------

    def _conn_screen(self) -> ConnectionScreen:
        return self.sm.get_screen('connection')

    def discover(self, entered: str) -> None:
        # Повторное нажатие во время поиска игнорируется: иначе результат
        # первого поиска мог бы прийти последним и затереть второй.
        if self._discovering:
            return
        self._discovering = True
        scr = self._conn_screen()
        scr.set_status(t("Ищу роутер…"), [0.3, 0.6, 0.95, 1])
        candidates = ([entered] if is_valid_ip(entered) else []) + list(DISCOVERY_CANDIDATES)

        def done(found: Any) -> None:
            self._discovering = False
            if found is None:
                scr.set_status(t("Роутер не найден. Проверьте подключение к его Wi-Fi/USB."),
                               [0.9, 0.3, 0.3, 1])
                return
            ip_input = scr.ids.get('ip_input')
            if ip_input is not None:
                ip_input.text = found.ip
            scr.set_status(t("Найден роутер {model} на {ip}").format(
                model=found.model or "Huawei", ip=found.ip), [0.2, 0.75, 0.45, 1])
        self._run_bg(lambda: discover_router(candidates), done, lambda e: done(None))

    def connect(self, ip: str, password: str) -> None:
        if self.worker is not None:
            return
        remember_widget = self._conn_screen().ids.get('remember_router')
        remember = bool(remember_widget.active) if remember_widget is not None else False
        self.save_router_details(ip, password, remember)
        self.demo_modem = None
        self._conn_screen().set_status(t("Подключение..."), [0.9, 0.6, 0.2, 1])
        self._start_session(RouterSession(ip, password))

    def start_demo(self) -> None:
        if self.worker is not None:
            return
        self.demo_modem = DemoModem()
        self._start_session(RouterSession("demo", "", factory=demo_factory(self.demo_modem)))

    def _start_session(self, session: RouterSession) -> None:
        self.state.reset()
        self.session = session
        worker: SessionWorker | None = None

        def mine(fn: Callable[..., None]) -> Callable[..., None]:
            """Событие фонового потока → главный поток, только для текущей сессии."""
            def post(*args: Any) -> None:
                def call(_dt: float) -> None:
                    if worker is self.worker:
                        fn(*args)
                Clock.schedule_once(call)
            return post

        worker = SessionWorker(
            session, interval=lambda: self.interval,
            on_connected=mine(self._on_connected), on_snapshot=mine(self._on_snapshot),
            on_status=mine(self._on_status), on_fatal=mine(self._on_fatal))
        self.worker = worker
        self.link = 'connecting'
        worker.start()

    def disconnect(self) -> None:
        """Мгновенно для UI: выход из роутера выполняет фоновый поток."""
        if self.worker is not None:
            self.worker.stop()
        self.worker = None
        self.session = None
        self.demo_modem = None
        self.link = 'offline'
        self._busy = False
        self._stop_beeps()
        set_keep_screen_on(False)
        self._conn_screen().set_status("", [0.5, 0.5, 0.5, 1])
        self.sm.current = 'connection'

    def _on_connected(self, info: dict[str, Any]) -> None:
        self.link = 'online'
        session = self.session
        if session is not None:
            self._band_list = lockable_bands(session.supported_bands, self.state.observed_bands)
        self._conn_screen().set_status("", [0.5, 0.5, 0.5, 1])
        self.sm.current = 'readings'
        set_keep_screen_on(True)
        self._render_link_state()
        self._show_last_event()         # не текст ошибки прошлой сессии
        if self.sound_on:
            self._schedule_beep()

    def _show_last_event(self) -> None:
        ev = self.sm.get_screen('monitor').ids.get('event_lbl')
        if ev is not None:
            ev.text = self._event_text(self.state.events[-1]) if self.state.events else ""

    def _on_status(self, status: str, delay: float | None, exc: BaseException | None) -> None:
        recovered = self.link == 'reconnecting' and status != 'reconnecting'
        self.link = 'reconnecting' if status == 'reconnecting' else 'online'
        self._render_link_state(humanize_error(exc) if exc is not None else "")
        if recovered:
            # Строка событий показывала ошибку связи — возвращаем последнее событие.
            self._show_last_event()

    def _on_fatal(self, exc: BaseException) -> None:
        self.disconnect()
        self._conn_screen().set_status(humanize_error(exc), [0.9, 0.3, 0.3, 1])

    @staticmethod
    def _event_text(change: Any) -> str:
        return t("{at} смена соты: {old} → {new}").format(
            at=change.at, old=change.old_label, new=change.new_label)

    def _render_link_state(self, detail: str = "") -> None:
        scr = self.sm.get_screen('monitor')
        lbl = scr.ids.get('status_lbl')
        if lbl is None:
            return
        sun = self.theme_name == 'sun'
        if self.link == 'reconnecting':
            lbl.text = t("Нет связи с роутером — переподключаюсь…")
            scr.status_color = hex_to_rgba('#e68033', sun)
            ev = scr.ids.get('event_lbl')
            if detail and ev is not None:
                ev.text = detail
        elif self.demo_modem is not None:
            lbl.text = t("Тестовый режим")
            scr.status_color = hex_to_rgba('#e68033', sun)

    # ---------- данные ----------

    def _on_snapshot(self, snap: Snapshot) -> None:
        change = self.state.ingest(snap, time.monotonic())
        scr = self.sm.get_screen('monitor')
        if change is not None:
            ev = scr.ids.get('event_lbl')
            if ev is not None:
                ev.text = self._event_text(change)
        if snap.has_nr and 'nr_sinr' not in scr.graph_values:
            scr.graph_values = LTE_PARAMS + NR_PARAMS
        if any(b not in self._band_list for b in snap.bands) and self.session is not None:
            self._band_list = lockable_bands(self.session.supported_bands,
                                             self.state.observed_bands)
        self._render(snap)
        self.refresh_readings_screen(snap)

    def _tick(self, _dt: float) -> None:
        """Каждые 0.5 с: признак устаревших данных."""
        if self.link not in ('online', 'reconnecting') or self.state.last is None:
            return
        now = time.monotonic()
        if self.state.is_stale(now, self.interval):
            scr = self.sm.get_screen('monitor')
            lbl = scr.ids.get('status_lbl')
            if lbl is not None:
                lbl.text = t("⚠ Данные устарели — нет ответа {s:.0f} с").format(
                    s=self.state.age(now) or 0)
                scr.status_color = hex_to_rgba('#d63031', self.theme_name == 'sun')
            self.refresh_graph(stale=True)

    def _metric_card(self, card: Any, param: str) -> None:
        val = self.state.current(param)
        label, color, _ = evaluate_signal(param.replace('nr_', ''), val)
        card.m_name = PARAM_TITLES.get(param, param.upper())
        card.m_value = fmt_num(val)
        card.m_status = t(label)
        card.m_color = hex_to_rgba(color, self.theme_name == 'sun')
        peak, delta = self.state.peaks.get(param), self.state.delta_to_peak(param)
        card.m_peak = "" if peak is None or delta is None else \
            t("Пик: {v} (Δ {d})").format(v=fmt_num(peak), d=f"{delta:+g}")

    def _layout_params(self) -> list[str]:
        """Крупно — выбранная метрика, рядом RSRP (или SINR), мелко — остальные."""
        primary = self.state.trend_param
        secondary = 'rsrp' if primary not in ('rsrp', 'nr_rsrp') else 'sinr'
        rest = [p for p in LTE_PARAMS if p not in (primary, secondary)][:2]
        return [primary, secondary, *rest]

    def _render(self, snap: Snapshot) -> None:
        scr = self.sm.get_screen('monitor')
        ids = scr.ids
        if not ids:
            return
        sun = self.theme_name == 'sun'
        score, summary, color = calculate_overall_health(snap.rsrp, snap.sinr)
        health = t(summary).format(pct=score)
        if self.demo_modem is not None:
            health = t("ДЕМО · азимут {a}").format(
                a=demo_angle_hint(self.demo_modem)) + " · " + health
        ids.status_lbl.text = health
        scr.status_color = hex_to_rgba(color, sun)
        ids.tower_lbl.text = self._tower_summary(snap)
        cards = (ids.primary_box, ids.secondary_box, ids.small1_box, ids.small2_box)
        for card, param in zip(cards, self._layout_params(), strict=True):
            self._metric_card(card, param)

        glyph = TREND_GLYPHS.get(self.state.trend, "—")
        ids.dir_lbl.text = glyph
        ids.dir_lbl.color = hex_to_rgba(
            {"↑": '#00b894', "↓": '#d63031', "→": '#fdcb6e'}.get(glyph, 'gray'), sun)
        ids.dir_text_lbl.text = {
            "↑": t("Лучше — продолжайте"), "↓": t("Хуже — поверните обратно"),
            "→": t("Стабильно — фиксируйте"),
        }.get(glyph, t("Накапливаю данные..."))

        mimo = mimo_status(snap.cqi0, snap.cqi1)
        up = uplink_status(snap.pusch_dbm)
        tips = advice(rsrp=snap.rsrp, sinr=snap.sinr, rsrq=snap.rsrq,
                      jitter=self.state.jitter(), mimo=mimo, uplink=up)
        if snap.data_enabled is False:
            tips.insert(0, "Мобильные данные на роутере выключены.")
        ids.advice_lbl.text = "\n".join("• " + t(tip) for tip in tips[:2])
        scr.advice_color = hex_to_rgba('#e68033', sun)
        self.refresh_graph()
        if self.sm.current == 'info':
            self.refresh_info_screen()

    def _tower_summary(self, snap: Snapshot) -> str:
        parts = []
        if snap.bands:
            freq = f" · {snap.freq_mhz:g} {t('МГц')}" if snap.freq_mhz else ""
            parts.append(f"B{snap.bands[0]}{freq}")
            if len(snap.bands) > 1:
                parts.append("CA " + "+".join(f"B{b}" for b in snap.bands[1:]))
        if snap.pci is not None:
            parts.append(f"PCI {snap.pci}")
        if snap.rat:
            parts.append(t(RAT_LABELS.get(snap.rat, snap.rat)))
        return " · ".join(parts) if parts else "—"

    def set_graph_param(self, param: str) -> None:
        self.state.set_trend_param(param)
        if self.state.last is not None:
            self._render(self.state.last)
        else:
            self.refresh_graph()

    def refresh_graph(self, stale: bool = False) -> None:
        param = self.state.trend_param
        values = list(self.state.history.get(param, []))
        peak = self.state.peaks.get(param)
        graph = self.sm.get_screen('monitor').ids.get('signal_graph')
        if graph is not None:
            graph.set_data(values, param, peak, stale)
        if self._fs_graph is not None:
            self._fs_graph.set_data(values, param, peak, stale)

    def reset_peaks(self) -> None:
        self.state.reset_peaks()
        if self.state.last is not None:
            self._render(self.state.last)
        self.toast(t("Пики сброшены"))

    # ---------- звук-парктроник ----------

    def toggle_sound(self) -> None:
        if not self.beeper.available:
            self.toast(t("Звук недоступен на этом устройстве"))
            return
        self.sound_on = not self.sound_on
        if self.sound_on:
            self._schedule_beep()
        else:
            self._stop_beeps()

    def _schedule_beep(self) -> None:
        self._stop_beeps()
        delta = self.state.delta_to_peak(self.state.trend_param)
        self._beep_ev = Clock.schedule_once(self._beep_tick, beep_interval(delta))

    def _beep_tick(self, _dt: float) -> None:
        self._beep_ev = None
        if not self.sound_on or self.link == 'offline':
            return
        # Во время переподключения молчим, но цикл не прерываем — иначе звук
        # не вернулся бы после перезагрузки роутера или обрыва Wi-Fi.
        if self.link == 'online' and not self.state.is_stale(time.monotonic(), self.interval):
            self.beeper.beep(50)
        self._schedule_beep()

    def _stop_beeps(self) -> None:
        if self._beep_ev is not None:
            self._beep_ev.cancel()
            self._beep_ev = None

    # ---------- меню и диалоги ----------

    def open_menu(self) -> None:
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.button import Button
        box = BoxLayout(orientation='vertical', spacing=dp(8), padding=dp(8))
        popup = Popup(title=t("Меню"), content=box, size_hint=(0.85, None), height=dp(470))
        sun = self.theme_name == 'sun'
        items = [
            (t("وزن الأنتينا"), lambda: self.go('monitor')),
            (t("القراءات"), lambda: (self.refresh_readings_screen(), self.go('readings'))),
            (t("ℹ Информация"), lambda: self.go('info')),
            (t("⚙ Сеть"), lambda: self.go('tools')),
            (t("☀ Солнце: выкл") if sun else t("☀ Солнце: вкл"),
             lambda: self.apply_theme('dark' if sun else 'sun')),
            (t("⏏ Отключиться"), self.confirm_disconnect),
        ]
        for text, action in items:
            btn = Button(text=text, font_size=sp(17), size_hint_y=None, height=dp(56))
            btn.bind(on_release=lambda _b, a=action: (popup.dismiss(), a()))
            box.add_widget(btn)
        popup.open()

    def confirm(self, title: str, message: str, yes_text: str,
                on_yes: Callable[[], None]) -> None:
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.button import Button
        from kivy.uix.label import Label
        content = BoxLayout(orientation='vertical', spacing=dp(10), padding=dp(10))
        msg = Label(text=message, halign='center', valign='middle', font_size=sp(15))
        msg.bind(size=lambda i, v: setattr(i, 'text_size', v))
        content.add_widget(msg)
        btns = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(10))
        popup = Popup(title=title, content=content, size_hint=(0.92, 0.55))
        no = Button(text=t("← Назад"), font_size=sp(16))
        yes = Button(text=yes_text, font_size=sp(16), background_color=(0.8, 0.4, 0.15, 1))
        no.bind(on_release=lambda *a: popup.dismiss())
        yes.bind(on_release=lambda *a: (popup.dismiss(), on_yes()))
        btns.add_widget(no)
        btns.add_widget(yes)
        content.add_widget(btns)
        popup.open()

    def confirm_disconnect(self) -> None:
        self.confirm(t("Подтверждение"), t("Отключиться от роутера?"),
                     t("Отключиться"), self.disconnect)

    def show_popup(self, title: str, message: str) -> None:
        from kivy.uix.label import Label
        from kivy.uix.scrollview import ScrollView
        lbl = Label(text=message, halign='left', valign='top', size_hint_y=None,
                    font_size=sp(14))
        lbl.bind(width=lambda i, w: setattr(i, 'text_size', (w, None)),
                 texture_size=lambda i, ts: setattr(i, 'height', ts[1]))
        sv = ScrollView()
        sv.add_widget(lbl)
        Popup(title=title, content=sv, size_hint=(0.92, 0.8)).open()

    def toast(self, text: str, seconds: float = 2.0) -> None:
        from kivy.core.window import Window
        from kivy.graphics import Color, RoundedRectangle
        from kivy.uix.label import Label
        lbl = Label(text=text, font_size=sp(15), size_hint=(None, None), color=(1, 1, 1, 1))
        lbl.texture_update()
        lbl.size = (lbl.texture_size[0] + dp(24), lbl.texture_size[1] + dp(16))
        lbl.pos = ((Window.width - lbl.width) / 2, dp(80))
        with lbl.canvas.before:
            Color(0, 0, 0, 0.8)
            RoundedRectangle(pos=lbl.pos, size=lbl.size, radius=[dp(8)])
        Window.add_widget(lbl)
        Clock.schedule_once(lambda dt: Window.remove_widget(lbl), seconds)

    def open_fullscreen_graph(self) -> None:
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.button import Button
        inner = BoxLayout(orientation='vertical', spacing=dp(6), padding=dp(8))
        graph = SignalGraph()
        close = Button(text=t("← Назад"), size_hint_y=None, height=dp(48))
        inner.add_widget(graph)
        inner.add_widget(close)
        self._fs_graph = graph
        popup = Popup(title='', separator_height=0, content=RotatedBox(inner),
                      size_hint=(0.98, 0.96))
        popup.bind(on_dismiss=lambda *a: setattr(self, '_fs_graph', None))
        close.bind(on_release=lambda *a: popup.dismiss())
        popup.open()
        self.refresh_graph()

    # ---------- экран «Информация» ----------

    _carrier_open: dict = {}

    def toggle_carriers(self, group: str) -> None:
        self._carrier_open = {**self._carrier_open, group: not self._carrier_open.get(group)}
        self.refresh_readings_screen()

    def refresh_readings_screen(self, snap: Snapshot | None = None) -> None:
        """Render modem-reported LTE/NR carriers as cards (primary first, then secondary)."""
        if not hasattr(self, 'sm') or 'readings' not in self.sm.screen_names:
            return
        snap = snap or self.state.last
        screen = self.sm.get_screen('readings')
        lte_box = screen.ids.get('lte_cards')
        nr_box = screen.ids.get('nr_cards')
        if lte_box is None or nr_box is None:
            return
        # Rebuild only when something shown actually changed: recreating every
        # card on each poll made scrolling stutter (display-only; no router I/O).
        raw_sig = dict(snap.raw or {}) if snap is not None else {}
        sig = (None if snap is None else tuple(
            getattr(snap, f, None) for f in (
                'rsrp', 'rsrq', 'sinr', 'rssi', 'pci', 'earfcn', 'dl_bandwidth',
                'nr_rsrp', 'nr_rsrq', 'nr_sinr', 'nr_pci', 'nr_arfcn', 'nr_bandwidth',
                'nr_band_label', 'band_label', 'band_raw', 'has_nr')),
            tuple(sorted((k, str(v)) for k, v in raw_sig.items() if k in (
                'cell_id', 'cellId', 'CellID', 'cellid', 'nr_cell_id', 'nrcellid',
                'nrCellId', 'nrpci', 'scc_pci', 'dlbandwidth', 'nrdlbandwidth',
                'bandInfo', 'band', 'lte_band', 'nr_band', 'nrBand'))),
            tuple(sorted(self._carrier_open.items())), t('رئيسي'), self.theme_name)
        if sig == getattr(self, '_readings_sig', None) and lte_box.children:
            return
        self._readings_sig = sig
        lte_box.clear_widgets()
        nr_box.clear_widgets()
        if snap is None:
            lte_box.add_widget(Factory.HintLabel(text=t("لا توجد بيانات بعد. اتصل بالراوتر أولًا.")))
            nr_box.add_widget(Factory.HintLabel(text=t("لا توجد بيانات 5G بعد.")))
            screen.aggregation_text = '—'
            return

        green = (0.21, 0.82, 0.50, 1)
        yellow = (1.0, 0.83, 0.31, 1)
        red = (1.0, 0.36, 0.38, 1)
        grey = (0.48, 0.53, 0.60, 1)
        orange = (1.0, 0.62, 0.26, 1)

        def val(value: Any) -> str:
            return '—' if value is None or value == '' else str(value)

        def fact(label: str, value: Any) -> tuple[str, str]:
            return (label, val(value))

        def rate(metric: str, num: float) -> tuple[str, tuple]:
            good, mid = {'rsrp': (-90, -105), 'rsrq': (-10, -15), 'sinr': (20, 5)}[metric]
            if num >= good:
                return _shape_arabic_display('قوي'), green
            if num >= mid:
                return _shape_arabic_display('متوسط'), yellow
            return _shape_arabic_display('ضعيف'), red

        def tile(metric: str, value: Any, unit: str) -> dict[str, Any]:
            num = _to_float(value)
            if num is None:
                return dict(m_title=metric.upper(), m_num='—', m_unit='', m_rate=t("غير متوفر"),
                            tone=grey, pill_fill=(0.11, 0.14, 0.20, 1), pill_line=(0.16, 0.21, 0.28, 1))
            text, col = rate(metric, num)
            return dict(m_title=metric.upper(), m_num=f"{num:g}", m_unit=unit, m_rate=text,
                        tone=col, pill_fill=col[:3] + (0.16,), pill_line=col[:3] + (0.6,))

        def add_card(box: Any, *, band: str, primary: bool, sub: str,
                     metrics: tuple[Any, Any, Any], facts: list[tuple[str, str]]) -> None:
            is_nr = band.upper().startswith('N')
            bc = (0.20, 0.86, 0.79, 1) if is_nr else (0.28, 0.73, 1, 1)
            rc = green if primary else orange
            card = _make_widget('CarrierCard', dict(
                band=band or '—', tech='NR' if is_nr else 'LTE', band_label=t('الباند'),
                band_size=sp(26 if primary else 22), band_color=bc,
                band_fill=bc[:3] + (0.18,), glow_soft=bc[:3] + ((0.45 if primary else 0.15),),
                role=t('رئيسي' if primary else 'ثانوي'), role_color=rc,
                role_fill=rc[:3] + (0.16,), frame=rc[:3] + (0.35,), sub=sub))
            for label, value in facts:
                card.ids.facts_grid.add_widget(_make_widget('FactCell', dict(k=label, v=value)))
            tiles = card.ids.tiles
            tiles.add_widget(_make_widget('ReadingTile', tile('rsrp', metrics[0], 'dBm')))
            tiles.add_widget(_make_widget('ReadingTile', tile('rsrq', metrics[1], 'dB')))
            tiles.add_widget(_make_widget('ReadingTile', tile('sinr', metrics[2], 'dB')))
            box.add_widget(card)

        def add_group(box: Any, group: str, secondary: list[tuple[str, str, str]],
                      channel_label: str) -> None:
            """Secondary carriers appear only if the router reported them: a small
            arrow under the primary card expands/collapses them."""
            if not secondary:
                return
            expanded = bool(self._carrier_open.get(group))
            box.add_widget(_make_widget('ToggleArrow', dict(group=group, expanded=expanded)))
            if not expanded:
                return
            for n, (width, channel, band) in enumerate(secondary, 1):
                add_card(box, band=band, primary=False, sub=f"{t('حامل ثانوي')} {n}",
                         metrics=(None, None, None),
                         facts=[fact(t('العرض'), width), fact(channel_label, channel)])

        # Band names come from modem data only; never from raw strings with quotes.
        raw = dict(snap.raw or {})
        lte_band = str(snap.band_label or '').strip().upper()
        if not re.fullmatch(r'B\d+', lte_band):
            lte_band = ''
            for candidate in (raw.get('bandInfo'), raw.get('band'), raw.get('lte_band'), snap.band_raw):
                match = re.search(r'(?<![A-Z0-9])B\d+(?![A-Z0-9])', str(candidate or ''), re.IGNORECASE)
                if match:
                    lte_band = match.group(0).upper()
                    break
        if not lte_band and snap.bands:
            lte_band = f'B{snap.bands[0]}'

        nr_band = str(snap.nr_band_label or '').strip().upper()
        if not re.fullmatch(r'N\d+', nr_band):
            nr_band = ''
            for candidate in (raw.get('nr_band'), raw.get('nrBand'), snap.band_raw, raw.get('bandInfo')):
                match = re.search(r'(?<![A-Z0-9])N\d+(?![A-Z0-9])', str(candidate or ''), re.IGNORECASE)
                if match:
                    nr_band = match.group(0).upper()
                    break

        carriers = [(w.strip(), ch, b.upper()) for w, ch, b in re.findall(
            r'([0-9.]+\s*MHz)\s*@\s*(\d+)\s*\((B\d+|N\d+)\)', snap.band_raw or '', re.IGNORECASE)]
        if not carriers:
            carriers = [('', '', b.upper()) for b in re.findall(
                r'\((B\d+|N\d+)\)', snap.band_raw or '', re.IGNORECASE)]

        if not carriers:
            # Some firmwares report aggregation only as a list of band names
            # ("B1+B3", "N78 N41"): take the first reported field that has any.
            for source in (snap.band_raw, raw.get('bandInfo'), raw.get('band')):
                found = re.findall(r'(?<![A-Z0-9])([BN]\d+)(?![A-Z0-9])', str(source or ''), re.IGNORECASE)
                if found:
                    carriers = [('', '', b.upper()) for b in found]
                    break

        def split_secondary(kind: str, primary_band: str) -> list[tuple[str, str, str]]:
            """Carriers of one technology minus ONE occurrence of the primary band
            (duplicate bands are separate component carriers and are kept)."""
            result, skipped = [], False
            for width, channel, band in carriers:
                if not band.startswith(kind):
                    continue
                if not skipped and band == primary_band:
                    skipped = True
                    continue
                result.append((width, channel, band))
            return result

        cell_id = raw.get('cell_id') or raw.get('cellId') or raw.get('CellID') or raw.get('cellid')
        add_card(lte_box, band=lte_band, primary=True, sub=t("الحامل الرئيسي"),
                 metrics=(snap.rsrp, snap.rsrq, snap.sinr),
                 facts=[fact(t('معرّف الخلية'), cell_id), fact('RSSI', snap.rssi),
                        fact('PCI', snap.pci), fact('EARFCN', snap.earfcn),
                        fact(t('العرض'), snap.dl_bandwidth or raw.get('dlbandwidth'))])
        lte_secondary = split_secondary('B', lte_band)
        add_group(lte_box, 'lte', lte_secondary, 'EARFCN')

        nr_pci = snap.nr_pci if snap.nr_pci is not None else raw.get('nrpci', raw.get('scc_pci'))
        nr_cell = raw.get('nr_cell_id') or raw.get('nrcellid') or raw.get('nrCellId')
        nr_active = bool(snap.has_nr or nr_pci is not None or snap.nr_rsrp is not None)
        nr_secondary: list[tuple[str, str, str]] = []
        if nr_active:
            add_card(nr_box, band=nr_band, primary=True, sub=t("الحامل الرئيسي"),
                     metrics=(snap.nr_rsrp, snap.nr_rsrq, snap.nr_sinr),
                     facts=[fact(t('معرّف الخلية'), nr_cell), fact('PCI', nr_pci),
                            fact('NR-ARFCN', snap.nr_arfcn),
                            fact(t('العرض'), snap.nr_bandwidth or raw.get('nrdlbandwidth'))])
            nr_secondary = split_secondary('N', nr_band)
            add_group(nr_box, 'nr', nr_secondary, 'NR-ARFCN')
        else:
            nr_box.add_widget(Factory.HintLabel(text=t("اتصال 5G غير ظاهر حاليًا.")))

        # Aggregation: primary carriers on top, secondary below.
        agg_wrap = screen.ids.get('agg_wrap')
        agg_card = screen.ids.get('agg_card')
        has_aggregation = bool(lte_secondary or nr_secondary)
        if agg_wrap is not None and agg_card is not None:
            if has_aggregation and agg_card.parent is None:
                agg_wrap.add_widget(agg_card)
            elif not has_aggregation and agg_card.parent is not None:
                agg_wrap.remove_widget(agg_card)
        if not has_aggregation:
            screen.aggregation_text = ''
            return
        mains = [b for b in (lte_band, nr_band if nr_active else '') if b]
        subs = [b for _w, _c, b in lte_secondary + nr_secondary]
        subs.sort(key=lambda b: (b.startswith('N'), int(b[1:])))
        lines = []
        if mains:
            lines.append('[b][color=35D07F]' + t('رئيسي') + '[/color][/b]')
            lines.append('[b][size=21sp][color=35D07F]' + '  +  '.join(mains) + '[/color][/size][/b]')
        if subs:
            lines.append('[b][color=FF9F43]' + t('ثانوي') + '[/color][/b]')
            lines.append('[b][size=19sp][color=FF9F43]' + '  +  '.join(subs) + '[/color][/size][/b]')
        screen.aggregation_text = '\n'.join(lines)

    # ---------- экран «Cells» ----------

    _cell_rows: list = []
    _cell_scan_serial = 0

    @staticmethod
    def _signal_rgba(metric: str, value: float | None) -> tuple:
        if value is None:
            return (0.62, 0.68, 0.74, 1)
        good, mid = {'rsrp': (-90, -105), 'rsrq': (-10, -15)}[metric]
        if value >= good:
            return (0.21, 0.82, 0.50, 1)
        return (1.0, 0.83, 0.31, 1) if value >= mid else (1.0, 0.36, 0.38, 1)

    def _cell_card_props(self, *, band: str | None, pci: Any, arfcn: Any, arfcn_name: str,
                         rsrp: float | None, rsrq: float | None, sinr: float | None,
                         tag: str, index: int, current: bool) -> dict[str, Any]:
        na = t("غير متوفر")
        def fmt(v: float | None, unit: str) -> str:
            return na if v is None else f"{v:g} {unit}"
        is_nr = (band or '').upper().startswith('N')
        bars = 0
        if rsrp is not None:
            bars = 4 if rsrp >= -90 else 3 if rsrp >= -100 else 2 if rsrp >= -108 else 1
        return dict(
            band=band or '—',
            title=f"PCI {pci if pci is not None else '—'}  ·  {arfcn_name} {arfcn if arfcn is not None else '—'}",
            sub=tag, rsrp=fmt(rsrp, 'dBm'), rsrq=fmt(rsrq, 'dB'), sinr=fmt(sinr, 'dB'),
            bars=bars, band_color=(0.20, 0.86, 0.79, 1) if is_nr else (0.28, 0.73, 1, 1),
            band_fill=(0.20, 0.86, 0.79, 0.18) if is_nr else (0.28, 0.73, 1, 0.18),
            signal_color=self._signal_rgba('rsrp', rsrp),
            rsrp_color=self._signal_rgba('rsrp', rsrp), rsrq_color=self._signal_rgba('rsrq', rsrq),
            status_text=t("متصل حاليًا بهذه الخلية") if current else '',
            show_button=not current, cell_index=index)

    def refresh_cells_screen(self, rescan: bool = False) -> None:
        if 'cells' not in self.sm.screen_names:
            return
        screen = self.sm.get_screen('cells')
        box = screen.ids.get('cells_box')
        if box is None:
            return
        snap = self.state.last
        session = self.session
        self._cell_scan_serial += 1
        serial = self._cell_scan_serial

        def render(neighbors: list[NeighborCell] | None, note: str) -> None:
            if serial != self._cell_scan_serial:
                return
            box.clear_widgets()
            self._cell_rows = []
            cards: list[dict[str, Any]] = []
            if snap is not None:
                # band_label may be a long text such as "B1 (2100 MHz)": keep only "B1".
                m_band = re.search(r'(?<![A-Z0-9])B\d+(?![A-Z0-9])', str(snap.band_label or ''), re.IGNORECASE)
                lte_band = m_band.group(0).upper() if m_band else (band_from_earfcn(snap.earfcn) or None)
                cards.append(self._cell_card_props(
                    band=lte_band, pci=snap.pci, arfcn=snap.earfcn, arfcn_name='EARFCN',
                    rsrp=_to_float(snap.rsrp), rsrq=_to_float(snap.rsrq), sinr=_to_float(snap.sinr),
                    tag=t("الخلية الحالية"), index=-1, current=True))
                if snap.has_nr:
                    cards.append(self._cell_card_props(
                        band=(snap.nr_band_label or '').upper() or None, pci=snap.nr_pci,
                        arfcn=snap.nr_arfcn, arfcn_name='NR-ARFCN',
                        rsrp=_to_float(snap.nr_rsrp), rsrq=_to_float(snap.nr_rsrq),
                        sinr=_to_float(snap.nr_sinr), tag=t("خلية 5G الحالية"),
                        index=-1, current=True))
            for cell in neighbors or []:
                if snap is not None and cell.pci == snap.pci and cell.arfcn == snap.earfcn:
                    continue                      # already shown as the current cell
                self._cell_rows.append(cell)
                cards.append(self._cell_card_props(
                    band=cell.band, pci=cell.pci, arfcn=cell.arfcn,
                    arfcn_name='NR-ARFCN' if (cell.band or '').startswith('N') else 'EARFCN',
                    rsrp=cell.rsrp, rsrq=cell.rsrq, sinr=cell.sinr,
                    tag=t("خلية مجاورة"), index=len(self._cell_rows) - 1, current=False))
            for props in cards:
                box.add_widget(_make_widget('CellCard', props))
            hint = Factory.HintLabel(text=note)
            box.add_widget(hint)
            screen.scan_info = t("آخر مسح: {time}").format(time=time.strftime('%H:%M:%S')) \
                if neighbors is not None else ''

        if session is None or self.link != 'online':
            render(None, t("اتصل بالراوتر أولًا لقراءة الخلايا."))
            return
        if not rescan and self._cell_rows:
            return
        screen.scan_info = t("جارٍ المسح…")

        def work() -> list[NeighborCell]:
            cells: list[NeighborCell] = []
            try:                                   # router's own cell-info page source
                cells = parse_nbrcell_response(session.read_neighbor_cells_raw())
            except Exception:
                logger.debug("device/nbrcellinfo unavailable", exc_info=True)
            if not cells:
                cells = parse_cell_info(session.read_cell_info())
            return cells

        def done(cells: list[NeighborCell]) -> None:
            note = (t("تعرض الصفحة ما يرجعه الراوتر فقط.") if cells
                    else t("الراوتر لم يعرض خلايا مجاورة (غير متوفر)."))
            render(cells, note)

        def fail(exc: BaseException) -> None:
            render(None, t("الراوتر لم يعرض خلايا مجاورة (غير متوفر)."))

        self._run_bg(work, done, fail)

    def cell_connect(self, index: int) -> None:
        """No documented router API for locking a single cell has been verified,
        so nothing is sent: the app never guesses an undocumented write."""
        self.toast(t("قفل خلية محددة غير مدعوم: لم يُتحقق من واجهة موثقة في هذا الراوتر، ولم يُرسل أي تغيير."), 4.5)

    def refresh_info_screen(self) -> None:
        ids = self.sm.get_screen('info').ids
        if not ids:
            return
        snap = self.state.last or Snapshot()
        nd = t("Нет данных")
        mhz = t('МГц')

        def row(name: str, value: Any) -> str:
            # Строки от роутера — без разметки Kivy: «[» и «]» в них не теги.
            text = escape_markup(str(value)) if value not in (None, '', '-') else nd
            label = t(name)
            if current_language() == 'ar':
                return f"{text} [b]:{label}[/b]"
            return f"[b]{label}:[/b] {text}"

        ca = {True: t("Активна"), False: t("Нет"), None: None}[snap.ca]
        nr = snap.nr_summary() if snap.has_nr else None
        dl, ul = snap.dl_bandwidth, snap.ul_bandwidth
        tower = [
            row('Оператор (PLMN)', f"{snap.plmn} ({snap.operator or t('Неизвестный оператор')})"
                if snap.plmn else None),
            row('Технология', t(RAT_LABELS.get(snap.rat, snap.rat)) if snap.rat else None),
            row('Рабочий Band (LTE)', snap.band_label.replace('МГц', mhz)),
            row('Частота DL', f"{snap.freq_mhz:g} {mhz}" if snap.freq_mhz else None),
            row('EARFCN (канал DL)', snap.earfcn_raw),
            row('Агрегация (CA)', ca),
            row('Ширина канала', f"DL {dl} / UL {ul}" if ul else dl),
            row('Сектор антенны (PCI)', fmt_num(snap.pci)),
            row('eNodeB (Вышка)', fmt_num(snap.enodeb) if snap.enodeb is not None else
                (f"NCI {snap.nci}" if snap.nci else None)),
            row('Cell (Локальный сектор)', fmt_num(snap.sector)),
            row('TAC (зона)', snap.tac),
            row('5G NR', nr),
        ]
        current = snap.cell
        cells = [
            f"{'▶ ' if c.key == current else ''}{c.band_label.replace('МГц', mhz)}"
            f" · PCI {fmt_num(c.key.pci)} · SINR {fmt_num(c.best_sinr)}"
            f" · RSRP {fmt_num(c.best_rsrp)}"
            for c in self.state.top_cells()]
        info = self.session.device_info if self.session is not None else {}
        sim = [row(name, info.get(key)) for key, name in (
            ('Imei', 'IMEI (роутер)'), ('Imsi', 'IMSI (SIM)'), ('Iccid', 'ICCID (SIM-карта)'),
            ('Msisdn', 'Номер телефона'), ('SerialNumber', 'Серийный номер'),
            ('DeviceName', 'Модель'), ('SoftwareVersion', 'Прошивка'))]
        mimo = mimo_status(snap.cqi0, snap.cqi1)
        up = uplink_status(snap.pusch_dbm)
        mods = [f"{d} {m}" for d, m in (("DL", format_modulation(snap.dl_mcs)),
                                        ("UL", format_modulation(snap.ul_mcs, uplink=True))) if m]
        cqi = None
        if snap.cqi0 is not None:
            cqi = f"{snap.cqi0}" + (f" / {snap.cqi1}" if snap.cqi1 is not None else "") + \
                (f" — {t(MIMO_LABELS[mimo])}" if mimo else "")
        tx = (snap.txpower + (f" — {t(UPLINK_LABELS[up])}" if up else "")) or None
        st = self.state

        def minmax(p: str) -> str | None:
            lo, hi = st.session_min.get(p), st.session_max.get(p)
            return None if lo is None else f"{fmt_num(lo)} / {fmt_num(hi)} {unit_of(p)}"

        month = None
        if snap.month_dl is not None or snap.month_ul is not None:
            month = f"{format_bytes_mb(snap.month_dl or 0)} / {format_bytes_mb(snap.month_ul or 0)}"
        status = [
            row('Время сессии', str(datetime.timedelta(seconds=snap.connect_time))
                if snap.connect_time else None),
            row('Температура чипа', snap.temperature),
            row('Мобильные данные', {True: t("включены"), False: t("ВЫКЛЮЧЕНЫ"),
                                     None: None}[snap.data_enabled]),
            row('Скорость (Download)', format_rate_mbps(snap.dl_rate)),
            row('Скорость (Upload)', format_rate_mbps(snap.ul_rate)),
            row('Скачано за сессию', format_bytes_mb(snap.total_dl)),
            row('Отдано за сессию', format_bytes_mb(snap.total_ul)),
            row('Трафик за месяц (↓/↑)', month),
            row('Модуляция DL / UL', " / ".join(mods) if mods else None),
            row('Режим MIMO', format_mimo(snap.transmode) if snap.transmode else None),
            row('CQI (потоки)', cqi),
            row('Мощность передатчика', tx),
            row('RRC', snap.rrc),
            row('RSRP мин / макс', minmax('rsrp')),
            row('SINR мин / макс', minmax('sinr')),
        ]
        for key, lines in (('tower_block', tower), ('cells_block', cells or [nd]),
                           ('sim_block', sim), ('status_block', status)):
            ids[key].text = "\n".join(lines)

    # ---------- экран «Сеть» ----------

    def _tools(self) -> ToolsScreen:
        return self.sm.get_screen('tools')

    def _net_msg(self, text: str, color: str) -> None:
        tools = self._tools()
        tools.net_msg = text
        tools.net_msg_color = hex_to_rgba(color, self.theme_name == 'sun')

    def build_band_checkboxes(self) -> None:
        grid = self._tools().ids.get('bands_grid')
        if grid is None or self._bands_shown == self._band_list:
            return
        from kivy.uix.checkbox import CheckBox
        from kivy.uix.label import Label
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.gridlayout import GridLayout
        from kivy.graphics import Color, RoundedRectangle, Line
        checked = {b for b, cb in self.band_vars.items() if cb.active}
        grid.clear_widgets()
        self.band_vars = {}
        self.band_role_vars = {}
        # Keep four bands per row, but give every band a distinct rounded tile.
        grid.spacing = dp(8)
        for band in self._band_list:
            card = BoxLayout(orientation='vertical', size_hint_y=None,
                             height=dp(104), padding=(dp(5), dp(5)), spacing=dp(3))
            with card.canvas.before:
                Color(*hex_to_rgba('#17283A', self.theme_name == 'sun'))
                card._band_tile_bg = RoundedRectangle(pos=card.pos, size=card.size,
                                                       radius=[dp(12)])
            with card.canvas.after:
                Color(*hex_to_rgba('#29465B', self.theme_name == 'sun'))
                card._band_tile_border = Line(rounded_rectangle=(card.x, card.y,
                    card.width, card.height, dp(12)), width=1.05)
            def _sync_tile(widget, *_):
                widget._band_tile_bg.pos = widget.pos
                widget._band_tile_bg.size = widget.size
                widget._band_tile_border.rounded_rectangle = (widget.x, widget.y,
                    widget.width, widget.height, dp(12))
            card.bind(pos=_sync_tile, size=_sync_tile)
            select = CheckBox(size_hint=(None, None), size=(dp(22), dp(20)),
                              pos_hint={'center_x': .5}, active=band in checked)
            lbl = Label(text=lte_band_label(band, t("МГц")), color=self.c_text,
                        halign='center', valign='middle', size_hint_y=None,
                        height=dp(30), font_size=sp(12), bold=True)
            lbl.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
            roles = GridLayout(cols=2, size_hint_y=None, height=dp(28), spacing=dp(3))
            p_box = BoxLayout(orientation='horizontal', spacing=dp(1))
            p_label = Label(text='P', color=self.c_text, font_size=sp(11))
            p_cb = CheckBox(size_hint=(None, None), size=(dp(18), dp(18)))
            s_box = BoxLayout(orientation='horizontal', spacing=dp(1))
            s_label = Label(text='S', color=self.c_text, font_size=sp(11))
            s_cb = CheckBox(size_hint=(None, None), size=(dp(18), dp(18)))
            p_box.add_widget(p_label); p_box.add_widget(p_cb)
            s_box.add_widget(s_label); s_box.add_widget(s_cb)
            roles.add_widget(p_box); roles.add_widget(s_box)
            card.add_widget(select); card.add_widget(lbl); card.add_widget(roles)
            grid.add_widget(card)
            self.band_vars[band] = select
            self.band_role_vars[band] = {'p': p_cb, 's': s_cb}
            p_cb.bind(active=lambda _cb, active, other=s_cb: setattr(other, 'active', False) if active else None)
            s_cb.bind(active=lambda _cb, active, other=p_cb: setattr(other, 'active', False) if active else None)
        self._bands_shown = list(self._band_list)

    def build_nr_band_checkboxes(self) -> None:
        """Render NR band cards; writing NR locks requires a verified router API."""
        grid = self._tools().ids.get('nr_bands_grid')
        bands = [40, 41, 71, 77, 78, 79]
        if grid is None or self._nr_bands_shown == bands:
            return
        from kivy.uix.checkbox import CheckBox
        from kivy.uix.label import Label
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.gridlayout import GridLayout
        from kivy.graphics import Color, RoundedRectangle, Line
        checked = {b for b, cb in self.nr_band_vars.items() if cb.active}
        grid.clear_widgets(); self.nr_band_vars = {}
        for band in bands:
            card = BoxLayout(orientation='vertical', size_hint_y=None,
                             height=dp(92), padding=(dp(5), dp(5)), spacing=dp(3))
            with card.canvas.before:
                Color(*hex_to_rgba('#0B3028', self.theme_name == 'sun'))
                card._nr_bg = RoundedRectangle(pos=card.pos, size=card.size, radius=[dp(12)])
            with card.canvas.after:
                Color(*hex_to_rgba('#00C982', self.theme_name == 'sun'))
                card._nr_border = Line(rounded_rectangle=(card.x, card.y, card.width, card.height, dp(12)), width=1.1)
            def _sync_nr_tile(widget, *_):
                widget._nr_bg.pos = widget.pos; widget._nr_bg.size = widget.size
                widget._nr_border.rounded_rectangle = (widget.x, widget.y, widget.width, widget.height, dp(12))
            card.bind(pos=_sync_nr_tile, size=_sync_nr_tile)
            select = CheckBox(size_hint=(None, None), size=(dp(22), dp(20)), pos_hint={'center_x': .5}, active=band in checked)
            lbl = Label(text=f'N{band}', color=hex_to_rgba('#37E6A0'), halign='center', valign='middle', size_hint_y=None, height=dp(26), font_size=sp(13), bold=True)
            lbl.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
            roles = GridLayout(cols=2, size_hint_y=None, height=dp(24), spacing=dp(3))
            p_box = BoxLayout(orientation='horizontal', spacing=dp(1)); p_label = Label(text='P', color=self.c_text, font_size=sp(11)); p_cb = CheckBox(size_hint=(None, None), size=(dp(18), dp(18)))
            s_box = BoxLayout(orientation='horizontal', spacing=dp(1)); s_label = Label(text='S', color=self.c_text, font_size=sp(11)); s_cb = CheckBox(size_hint=(None, None), size=(dp(18), dp(18)))
            p_box.add_widget(p_label); p_box.add_widget(p_cb); s_box.add_widget(s_label); s_box.add_widget(s_cb)
            roles.add_widget(p_box); roles.add_widget(s_box)
            card.add_widget(select); card.add_widget(lbl); card.add_widget(roles); grid.add_widget(card)
            self.nr_band_vars[band] = select
            p_cb.bind(active=lambda _cb, active, other=s_cb: setattr(other, 'active', False) if active else None)
            s_cb.bind(active=lambda _cb, active, other=p_cb: setattr(other, 'active', False) if active else None)
        self._nr_bands_shown = list(bands)

    def _run_bg(self, work: Callable[[], Any], done: Callable[[Any], None],
                fail: Callable[[BaseException], None]) -> None:
        """Выполнить work в фоне, результат/ошибку — в главном потоке."""
        def task() -> None:
            try:
                result = work()
            except Exception as exc:
                logger.exception("Background task failed")
                Clock.schedule_once(lambda dt, err=exc: fail(err))
            else:
                Clock.schedule_once(lambda dt: done(result))
        threading.Thread(target=task, daemon=True).start()

    def _net_action(self, work: Callable[[], Any], done: Callable[[Any], None],
                    busy_text: str) -> None:
        """Команда роутеру: повторное нажатие до ответа игнорируется."""
        if self.session is None or self.link != 'online':
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return
        if self._busy:
            return
        self._busy = True
        self._net_msg(busy_text, '#3399ff')
        session = self.session

        def finish(result: Any) -> None:
            if session is not self.session:
                return          # ответ прошлой сессии: её состояние уже сброшено
            self._busy = False
            done(result)

        def failed(exc: BaseException) -> None:
            if session is not self.session:
                return
            self._busy = False
            self._net_msg(t("Команда не выполнена: {err}").format(
                err=humanize_error(exc)), '#d63031')
        self._run_bg(work, finish, failed)

    def load_router_config(self) -> None:
        """Читает текущий Band Lock и антенну (только чтение)."""
        session = self.session
        if session is None:
            return
        unread = t("Сейчас на модеме: не прочитано")
        # Пока не прочитано — не показываем состояние прошлой сессии.
        self._tools().lock_state = unread

        def done(cfg: Any) -> None:
            if session is not self.session:
                return
            tools = self._tools()
            if cfg.locked is None:
                tools.lock_state = t("Сейчас на модеме: не прочитано")
            elif not cfg.locked:
                tools.lock_state = t("Сейчас на модеме: AUTO (все бэнды)")
                for cb in self.band_vars.values():
                    cb.active = False
            else:
                tools.lock_state = t("Сейчас на модеме: {bands}").format(
                    bands=", ".join(f"B{b}" for b in cfg.locked))
                extra = [b for b in cfg.locked if b not in self._band_list]
                if extra:
                    self._band_list += extra
                    self.build_band_checkboxes()
                for b, cb in self.band_vars.items():
                    cb.active = b in cfg.locked
            if cfg.antenna is not None:
                for label, code in ANTENNA_MODES.items():
                    if code == cfg.antenna:
                        tools.antenna_text = t(label)

        def failed(_exc: BaseException) -> None:
            if session is self.session:
                self._tools().lock_state = unread
        self._run_bg(session.read_config, done, failed)

    def mark_current_bands(self) -> None:
        snap = self.state.last
        if snap is None or not snap.bands:
            self._net_msg(t("Текущий бэнд ещё не определён."), '#d63031')
            return
        missing = [b for b in snap.bands if b not in self._band_list]
        if missing:
            self._band_list += missing
        self.build_band_checkboxes()
        for b, cb in self.band_vars.items():
            cb.active = b in snap.bands
        self._net_msg(t("Отмечены текущие бэнды: {bands}").format(
            bands=", ".join(f"B{b}" for b in snap.bands)), '#3399ff')

    def check_nr_band_lock_support(self) -> None:
        """Read-only capability probe; never sends an undocumented NR write."""
        session = self.session
        if session is None or self.link != 'online':
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return

        def inspect() -> tuple[bool, str]:
            dumps, errors = session.collect_diagnostics()
            candidates = (dumps.get('net_net_mode_list'), dumps.get('net_net_mode'))
            # A named NR band field is only a hint, not proof that a write API exists.
            keys = {'NRBand', 'NRBandList', 'NRBandLock', 'NRBandMask',
                    'NRSABand', 'NR5GBand', 'NRBandSelect'}
            found = False
            def walk(value: Any) -> None:
                nonlocal found
                if isinstance(value, dict):
                    for key, child in value.items():
                        if str(key).replace('_', '').lower() in {k.replace('_', '').lower() for k in keys}:
                            found = True
                        walk(child)
                elif isinstance(value, (list, tuple)):
                    for child in value:
                        walk(child)
            for candidate in candidates:
                walk(candidate)
            if found:
                return True, t("ظهرت حقول NR في قراءة الراوتر، لكن وجودها لا يثبت وجود أمر كتابة آمن. أرسل تقرير التشخيص لتحديد طريقة القفل قبل تفعيلها.")
            if errors.get('net_net_mode_list'):
                return False, t("تعذرت قراءة قائمة أوضاع الشبكة؛ لم يتم اختبار دعم قفل 5G بشكل كامل.")
            return False, t("الراوتر لم يعرض حقول قفل NR معروفة في واجهة القراءة. لم يتم إرسال أي أمر تغيير. نحتاج تقرير التشخيص أو توثيق واجهة هذا الإصدار قبل تنفيذ قفل حقيقي.")

        self._net_action(inspect,
                         lambda result: self._net_msg(result[1], '#d6a000' if result[0] else '#d63031'),
                         t("أفحص واجهة الراوتر للقراءة فقط…"))

    def apply_bands(self) -> None:
        session = self.session
        selected = [b for b, cb in self.band_vars.items() if cb.active]
        if session is None or self.link != 'online':
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return
        if not selected:
            self._net_msg(t("Выберите хотя бы один диапазон!"), '#d63031')
            return
        nr_selected = [b for b, cb in self.nr_band_vars.items() if cb.active]
        names = ", ".join(f"B{b}" for b in selected)
        nr_names = ", ".join(f"N{b}" for b in nr_selected)
        # The available Huawei write method accepts LTEBand only. Never invent an NR field.
        def done(ok: Any) -> None:
            self._after_write(ok, t("تم إرسال أمر LTE للباندات: {bands}.").format(bands=names))
            if nr_selected:
                self._net_msg(t("قفل 5G ({bands}) لم يُرسل؛ واجهة الكتابة الحالية لا توفر حقل NR موثقًا.").format(bands=nr_names), '#d6a000')
        self._net_action(lambda: session.apply_plan(session.plan_band_lock(selected)), done,
                         t("جاري إرسال أمر قفل LTE…"))

    def reset_bands(self) -> None:
        session = self.session
        if session is None:
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return
        self._net_action(lambda: session.apply_plan(session.plan_all_bands()),
                         lambda ok: self._after_write(ok, t("Включены все бэнды (AUTO).")),
                         t("Включаю все бэнды…"))

    def restore_bands(self) -> None:
        session = self.session
        if session is None:
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return
        plan = session.plan_restore_original()
        if plan is None:
            self._net_msg(t("Исходные настройки не прочитаны — роутер не отдал net-mode."),
                          '#d63031')
            return
        self._net_action(lambda: session.apply_plan(plan),
                         lambda ok: self._after_write(ok, t(
                             "Восстановлены настройки, прочитанные при подключении.")),
                         t("Восстанавливаю настройки…"))

    def _after_write(self, verified: bool, success_text: str) -> None:
        if verified:
            self._net_msg(success_text + " " + t(
                "Модем перерегистрируется в сети (до ~30 с)."), '#00b894')
        else:
            self._net_msg(t("Команда отправлена, но роутер не подтвердил запись — "
                            "проверьте строку «Сейчас на модеме»."), '#e68033')
        self.load_router_config()

    def apply_antenna(self, label: str) -> None:
        session = self.session
        rev = {t(k): k for k in ANTENNA_MODES}
        code = parse_antenna_value(rev.get(label, label))
        if session is None:
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return
        if code is None:
            self._net_msg(t("Неизвестный режим антенны."), '#d63031')
            return

        def work() -> int | None:
            session.set_antenna(code)
            return session.read_antenna()

        def done(read_back: int | None) -> None:
            if read_back in (code, None):
                self._net_msg(t("Тип антенны изменён: {mode}").format(mode=label), '#00b894')
            else:
                self._net_msg(t("Роутер принял команду, но сообщает другой режим антенны."),
                              '#e68033')
        self._net_action(work, done, t("Переключаю антенну…"))

    def confirm_reattach(self) -> None:
        session = self.session
        if session is None:
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return

        def done(ok: bool) -> None:
            if ok:
                self._net_msg(t("Связь переподключена."), '#00b894')
            else:
                self._net_msg(t("Не удалось включить мобильные данные — включите их в "
                                "веб-интерфейсе роутера."), '#d63031')
        self.confirm(t("Подтверждение"), t(
            "Переподключить мобильную связь?\n\nИнтернет пропадёт примерно "
            "на 5–10 секунд."), t("Переподключить"),
            lambda: self._net_action(session.reattach, done, t("Переподключаю связь…")))

    def confirm_reboot(self) -> None:
        session, worker = self.session, self.worker
        if session is None or worker is None:
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return

        def done(_: Any) -> None:
            self._net_msg(t("Роутер перезагружается — переподключусь автоматически."),
                          '#3399ff')
        self.confirm(t("Подтверждение"), t(
            "Перезагрузить роутер?\n\nСоединение с интернетом прервётся "
            "на 1–2 минуты. Программа переподключится автоматически."),
            t("Перезагрузить роутер"),
            lambda: self._net_action(session.reboot, done, t("Отправляю команду перезагрузки…")))

    def copy_diagnostics(self) -> None:
        """Диагностика (JSON) в буфер обмена: удобно вставить в issue/мессенджер.

        Hardware validation required: вставка из буфера на Android 12+.
        """
        session = self.session
        if session is None:
            self._net_msg(t("Сначала подключитесь к роутеру."), '#d63031')
            return

        def work() -> str:
            dumps, errors = session.collect_diagnostics()
            report = build_diagnostics(
                app_version=__version__, library_version=library_version(),
                platform=f"{platform} / Python {py_platform.python_version()}",
                dumps=dumps, errors=errors)
            return diagnostics_json(report)

        def done(text: str) -> None:
            from kivy.core.clipboard import Clipboard
            Clipboard.copy(text)
            self._net_msg(t("Диагностика скопирована в буфер обмена. Личные номера "
                            "замаскированы."), '#00b894')
        self._net_action(work, done, t("Собираю диагностику…"))

    def game_connection_check(self) -> None:
        if self._wl_running:
            return
        self._wl_running = True
        tools = self._tools()
        tools.wl_verdict = t("Testing game connection…")
        tools.wl_color = hex_to_rgba('#e68033', self.theme_name == 'sun')
        tools.wl_detail = t("Measuring latency, jitter, and failed probes. This may take about 20 seconds.")

        def fmt_probe(label: str, probe: Any) -> list[str]:
            avg = f"{probe.average_ms:.1f} ms" if probe.average_ms is not None else "—"
            jitter = f"{probe.jitter_ms:.1f} ms" if probe.jitter_ms is not None else "—"
            low = f"{probe.min_ms:.1f} ms" if probe.min_ms is not None else "—"
            high = f"{probe.max_ms:.1f} ms" if probe.max_ms is not None else "—"
            return [label, t("Host: {host}").format(host=probe.host),
                    t("Average TCP/TLS latency: {value}").format(value=avg),
                    t("Jitter (successive latency difference): {value}").format(value=jitter),
                    t("Failed connection attempts: {failed}/{attempts} ({loss:.0f}%)").format(
                        failed=probe.failures, attempts=probe.attempts, loss=probe.packet_loss_pct),
                    t("Minimum / maximum: {minimum} / {maximum}").format(minimum=low, maximum=high),
                    (t("Error: {error}").format(error=probe.error) if probe.error else "")]

        def done(report: Any) -> None:
            self._wl_running = False
            all_samples = report.pubg.samples_ms + report.fc_mobile.samples_ms
            all_failures = report.pubg.failures + report.fc_mobile.failures
            if all_samples and all_failures == 0:
                tools.wl_verdict = t("Test complete — no failed probes")
                color = '#00b894'
            elif all_samples:
                tools.wl_verdict = t("Test complete — some probes failed")
                color = '#e6a23c'
            else:
                tools.wl_verdict = t("Could not reach test endpoints")
                color = '#e74c3c'
            tools.wl_color = hex_to_rgba(color, self.theme_name == 'sun')
            lines = fmt_probe(t("PUBG MOBILE"), report.pubg) + [""] + fmt_probe(t("EA SPORTS FC MOBILE"), report.fc_mobile)
            lines += ["", t("Note: these are measurements to public publisher HTTPS endpoints, not the actual game match server ping.")]
            tools.wl_detail = "\n".join(line for line in lines if line)

        def failed(exc: BaseException) -> None:
            self._wl_running = False
            tools.wl_verdict = t("Test error")
            tools.wl_detail = humanize_error(exc)
        self._run_bg(run_game_connection_test, done, failed)


def main() -> None:
    Hua4GMonApp().run()


if __name__ == "__main__":
    main()
