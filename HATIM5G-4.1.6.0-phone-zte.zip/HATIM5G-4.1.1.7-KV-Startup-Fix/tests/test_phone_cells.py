from core.phone_cells import build_cell, clean, nr_band_from_arfcn


def test_unavailable_values_become_none():
    assert clean(2147483647) is None and clean(None) is None and clean('x') is None
    assert clean(-93) == -93.0


def test_build_cell_bands():
    nr = build_cell('NR', pci=313, arfcn=640776, rsrp=-96, rsrq=-9, sinr=2147483647, registered=False)
    assert (nr.band, nr.sinr) == ('N78', None)
    lte = build_cell('LTE', pci=311, arfcn=1450, rsrp=-93, rsrq=-10, sinr=14, registered=True)
    assert lte.band == 'B3' and lte.registered
    assert build_cell('LTE', pci=1, arfcn=1, rsrp=0, rsrq=0, sinr=0, registered=False, bands=[28]).band == 'B28'
    assert nr_band_from_arfcn(462270) == 'N40' and nr_band_from_arfcn(None) is None
