"""Read-only probe for ZTE routers (``/goform/goform_get_cmd_process``).

Only HTTP GET with the commands ZTE's own web UI uses for signal data; no
login is attempted and nothing is written. The result is shown/copied so the
real response format can be reviewed before any ZTE support is built on it.
"""
from __future__ import annotations

import json
from typing import Any

import requests

_GET = '/goform/goform_get_cmd_process'

PROBE_GROUPS: dict[str, list[str]] = {
    'device': ['wa_inner_version', 'cr_version', 'modem_main_state', 'network_type',
               'network_provider', 'ppp_status'],
    'lte': ['lte_rsrp', 'lte_rsrq', 'lte_snr', 'lte_rssi', 'lte_pci', 'lte_band',
            'lte_bandwidth', 'wan_active_band', 'wan_active_channel', 'wan_lte_ca',
            'lte_ca_pcell_band', 'lte_ca_pcell_arfcn', 'lte_ca_pcell_freq',
            'lte_ca_pcell_bandwidth', 'lte_ca_scell_band', 'lte_ca_scell_arfcn',
            'lte_ca_scell_bandwidth', 'lte_ca_scell_info', 'lte_multi_ca_scell_info',
            'lte_multi_ca_scell_sig_info'],
    'nr': ['nr5g_pci', 'nr5g_rsrp', 'nr5g_rsrq', 'nr5g_snr', 'nr5g_cell_id',
           'nr5g_action_band', 'nr5g_action_channel', 'nr5g_bandwidth', 'nr5g_type',
           'nr_ca_state', 'nr_ca_pcell_band', 'nr_ca_pcell_freq', 'nr_ca_pcell_bandwidth',
           'nr_multi_ca_scell_info', 'nr_multi_ca_scell_sig_info'],
    'neighbors': ['ngbr_cell_info'],
    'locks': ['lte_band_lock', 'nr5g_sa_band_lock', 'nr5g_nsa_band_lock'],
}


def probe(ip: str, timeout: float = 5.0) -> dict[str, Any]:
    """GET-only. Returns {group: parsed-or-raw response | 'error: ...'}."""
    base = f'http://{ip}'
    headers = {'Referer': f'{base}/index.html', 'X-Requested-With': 'XMLHttpRequest'}
    result: dict[str, Any] = {'host': ip}
    for group, cmds in PROBE_GROUPS.items():
        url = f"{base}{_GET}?isTest=false&multi_data=1&cmd={','.join(cmds)}"
        try:
            reply = requests.get(url, headers=headers, timeout=timeout)
            text = reply.text
            try:
                result[group] = json.loads(text)
            except ValueError:
                result[group] = text[:2000]
        except Exception as exc:  # network errors are the answer here
            result[group] = f"error: {type(exc).__name__}: {exc}"
    return result


def to_text(data: dict[str, Any]) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2)
