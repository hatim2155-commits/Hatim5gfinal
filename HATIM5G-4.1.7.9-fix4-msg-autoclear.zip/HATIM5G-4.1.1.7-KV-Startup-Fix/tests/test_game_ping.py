"""Ping page logic: quality classes, ordering, summary, parallel suite (no network)."""
from core.game_ping import (GAMES, REGIONS, PingResult, quality, run_ping_suite,
                            sort_by_ping, summarize)
from core.game_test import GameProbe


def _res(key, ping, jitter=None, failures=0, attempts=5):
    return PingResult(key, key, key[0].upper(), f'{key}.example', ping, jitter, failures, attempts)


def test_quality_thresholds():
    assert quality(None) == 'none'
    assert quality(0) == 'excellent' and quality(39.9) == 'excellent'
    assert quality(40) == 'good' and quality(79.9) == 'good'
    assert quality(80) == 'fair' and quality(149.9) == 'fair'
    assert quality(150) == 'poor'


def test_sort_puts_unanswered_last():
    out = sort_by_ping([_res('a', 90), _res('b', None), _res('c', 30)])
    assert [r.key for r in out] == ['c', 'a', 'b']


def test_summary_uses_answering_hosts_only():
    s = summarize([_res('a', 30, 2, 0), _res('b', 50, 4, 1), _res('c', None, None, 5)])
    assert s.ping_ms == 40 and s.jitter_ms == 3 and s.best_ms == 30
    assert abs(s.loss_pct - 6 / 15 * 100) < 1e-9


def test_summary_without_data_is_none():
    s = summarize([_res('a', None, None, 5)])
    assert s.ping_ms is None and s.best_ms is None and s.jitter_ms is None
    assert summarize([]).loss_pct is None


def test_suite_probes_every_host_once_and_splits_results():
    seen = []

    def fake(host, attempts, timeout):
        seen.append(host)
        return GameProbe(host, (50.0, 52.0), 1, attempts, '', (20.0, 22.0))

    games, regions = run_ping_suite(probe=fake)
    assert sorted(seen) == sorted([g[3] for g in GAMES] + [r[3] for r in REGIONS])
    assert [g.key for g in games] == [g[0] for g in GAMES]
    assert [r.key for r in regions] == [r[0] for r in REGIONS]
    assert games[0].ping_ms == 21.0 and games[0].failures == 1


def test_hosts_are_unique_and_plain_hostnames():
    hosts = [g[3] for g in GAMES] + [r[3] for r in REGIONS]
    assert len(hosts) == len(set(hosts))
    assert all('/' not in h and ' ' not in h and '.' in h for h in hosts)
