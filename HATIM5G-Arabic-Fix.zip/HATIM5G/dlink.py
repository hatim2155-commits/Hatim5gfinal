"""D-Link LuCI (OpenWrt) CPE client wrapper.

Built from a Charles capture of a D-Link DWR-2000M ("RG600L-EU" platform) web
backend. The router runs a D-Link branded LuCI with a JSON dispatch under
`/cgi-bin/luci/admin/status/`. The browser flow that was reverse engineered:

    1. GET  /cgi-bin/luci/                       -> login page, seeds SessionID cookie
    2. POST /cgi-bin/luci  luci_username=<u>&luci_password=<p>
                                                 -> 302 -> /cgi-bin/luci/,
                                                    Set-Cookie: sysauth=<token>
    3. GET  /cgi-bin/luci/admin/status/header?status=1&<ts>          -> {"model":..,"project":..}
    4. GET  /cgi-bin/luci/admin/status/home_poll?status=1&<ts>       -> netType, signalStrength,
                                                                         operator, wanStatusInfo(json),
                                                                         systeminfo(json), traffic(counter)
    5. GET  /cgi-bin/luci/admin/status/get_sim_detail?status=1&<ts>  -> iccid, imei, internet_info(json)
    6. GET  /cgi-bin/luci/admin/status/get_band_info?<ts>            -> endc, imsi, dlMcs, ulMcs
    7. GET  /cgi-bin/luci/admin/status/get_eth_detail?status=1&<ts>  -> wanMac, ethType, wanipv6, ethCable,
                                                                        wanStatusInfo(json)

The trailing `<ts>` query parameter is a millisecond timestamp appended by the
LuCI XHR helper. It is a cache-buster (anti-caching), NOT request protection or
throttling: it equals Date.now() at request time, changes on every call, and is
never validated by the server. We reproduce it so each poll is a fresh URL.

Firmware quirks handled here:
  - responses are JSON, but `wanStatusInfo` / `systeminfo` / `internet_info`
    are JSON *strings* that must be decoded again
  - `internet_info` repeats keys (rssi/rsrp/rsrq/snr/pci/sinr) - the first
    values belong to the LTE anchor and the last ones to the 5G NR carrier
  - the modem exposes its OWN signal classification in home_poll.signalStrength
    (GREAT/GOOD/MODERATE/POOR/UNKNOWN); we surface that as signal_quality so the
    UI can prefer the modem's judgement over our own band math
  - the modem runs HTTPS with a self-signed certificate -> verify=False
"""

from __future__ import annotations

import json
import logging
import time
import warnings
from typing import Any, Optional

import requests
import urllib3

from modem import ModemUnavailableError, operator_name
from quality import parse_dbm, parse_int, parse_mhz_bandwidth, parse_number, render_metric

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

log = logging.getLogger(__name__)

BRAND = "D-Link"

# modem signalStrength (home_poll) -> normalized quality + bars
SIGNAL_QUALITY_MAP = {
    "GREAT": "excellent",
    "GOOD": "good",
    "MODERATE": "fair",
    "POOR": "poor",
    "UNKNOWN": None,
}
SIGNAL_BARS = {"GREAT": 4, "GOOD": 3, "MODERATE": 2, "POOR": 1, "UNKNOWN": 0}
QUALITY_LABELS = {"excellent": "Excellent", "good": "Good", "fair": "Fair", "poor": "Poor"}


class _SessionExpired(Exception):
    """Internal: the sysauth cookie is no longer accepted; re-login needed."""


# --------------------------------------------------------------------------
# JSON helpers
# --------------------------------------------------------------------------

def _nested_json(value: Any) -> dict[str, Any]:
    """Decode a JSON-string-inside-JSON field (wanStatusInfo, systeminfo...)."""
    if isinstance(value, dict):
        return value
    if not value:
        return {}
    try:
        obj = json.loads(value)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _collect_pairs(pairs: list) -> dict[str, list[Any]]:
    """object_pairs_hook that keeps EVERY value per key, in order.

    The D-Link `internet_info` JSON repeats metric keys: the first value is the
    LTE anchor reading and the last is the 5G NR reading. A plain json.loads()
    would silently drop the first one.
    """
    out: dict[str, list[Any]] = {}
    for key, value in pairs:
        out.setdefault(key, []).append(value)
    return out


def _dup_json(raw: Any) -> dict[str, list[Any]]:
    """Parse `internet_info` (or any JSON string) keeping duplicate keys."""
    if isinstance(raw, dict):
        return {k: [v] for k, v in raw.items()}
    if not raw:
        return {}
    try:
        obj = json.loads(raw, object_pairs_hook=_collect_pairs)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _val(dup: dict[str, list[Any]], key: str, idx: int = -1) -> Any:
    lst = dup.get(key) or []
    return lst[idx] if lst else None


def _fmt(value: Any) -> Optional[str]:
    if value is None:
        return None
    s = str(value).strip()
    return s or None


def _iccid(value: Any) -> Optional[str]:
    """'ICCID: 8921602080358069378F' -> '8921602080358069378F'."""
    s = _fmt(value)
    if not s or s.upper() == "ERROR":
        return None
    if ":" in s:
        s = s.split(":", 1)[1].strip()
    return s or None


def _imsi(value: Any) -> Optional[str]:
    """'IMSI: 605020835806937\\n' -> '605020835806937'."""
    s = _fmt(value)
    if not s or s.upper() == "ERROR" or s.upper().startswith("IMSI: ERROR"):
        return None
    if ":" in s:
        s = s.split(":", 1)[1].strip()
    return s or None


def _wan_ip(wan_json: dict[str, Any]) -> Optional[str]:
    """Pick the cellular WAN IPv4/IPv6 from netifd-style wanStatusInfo."""
    for iface in wan_json.get("interface") or []:
        if not isinstance(iface, dict):
            continue
        if iface.get("interface") != "wan" or not iface.get("up"):
            continue
        for key in ("ipv4-address", "ipv6-address"):
            addrs = iface.get(key) or []
            if addrs and isinstance(addrs[0], dict) and addrs[0].get("address"):
                return str(addrs[0]["address"])
    return None


def _ca_bandwidth_map(ca_band: Any, ca_bw: Any) -> dict[str, float]:
    """'B3+B1/N78' + '20-10-100' -> {'3': 20.0, '1': 10.0, '78': 100.0}.

    The D-Link combines the LTE CA list and the NR carrier into one string with
    '/'; widths follow the same order dash-separated.
    """
    if not ca_band or not ca_bw:
        return {}
    bands = [b.strip().upper() for b in str(ca_band).replace("/", "+").split("+") if b.strip()]
    widths = [w.strip() for w in str(ca_bw).split("-") if w.strip()]
    out: dict[str, float] = {}
    for band, width in zip(bands, widths):
        digits = "".join(ch for ch in band if ch.isdigit())
        if not digits:
            continue
        n = parse_number(width)
        if n is not None:
            out[digits] = n
    return out


def _mode_from(net_type: Optional[str], radiomode: Optional[str], lte: bool, nr: bool) -> tuple[str, str]:
    rm = (radiomode or "").upper()
    if "NSA" in rm:
        return "5G NSA", "nsa"
    if "SA" in rm:
        return "5G SA", "sa"
    if any(x in rm for x in ("LTE", "4G")):
        return "LTE", "lte"
    if nr and lte:
        return "5G NSA", "nsa"
    if nr:
        return "5G SA", "sa"
    if lte:
        return "LTE", "lte"
    if net_type:
        return str(net_type), str(net_type).lower()
    return "Unknown", "unknown"


def _cell(kind: str, rat: str, title: str, identity: dict[str, Any], metrics: dict[str, Any]) -> dict[str, Any]:
    clean = {k: v for k, v in identity.items() if v is not None and v != ""}
    return {"kind": kind, "rat": rat, "title": title, "identity": clean, "metrics": metrics}


def _metrics(signal: dict[str, Any], keys: tuple[str, ...]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key in keys:
        value = parse_dbm(signal.get(key))
        if value is not None:
            out[key] = render_metric(key, value)
    return out


def _neighbor_cell(internet: dict[str, Any], rat: str, prefix: str) -> Optional[dict[str, Any]]:
    """One neighbour cell from lte_*_nbr / nr_*_nbr fields when present."""
    arfcn = _fmt(internet.get(f"{prefix}_arfcn_nbr"))
    pci = _fmt(internet.get(f"{prefix}_pci_nbr"))
    metrics = _metrics(
        {k: internet.get(f"{prefix}_{k}_nbr") for k in ("rsrp", "rsrq", "sinr")},
        ("rsrp", "rsrq", "sinr"),
    )
    if not arfcn and not pci and not metrics:
        return None
    identity = {"pci": pci, "arfcn": arfcn}
    return _cell("neighbor", rat, f"Neighbour cell ({rat})", identity, metrics)


# --------------------------------------------------------------------------
# Snapshot building (pure functions, testable)
# --------------------------------------------------------------------------

def build_dlink_snapshot(
    header: Optional[dict[str, Any]] = None,
    home: Optional[dict[str, Any]] = None,
    sim: Optional[dict[str, Any]] = None,
    band: Optional[dict[str, Any]] = None,
    eth: Optional[dict[str, Any]] = None,
    source: str = "live",
    raw: Optional[dict[str, Any]] = None,
    dl_mbps: Optional[float] = None,
    ul_mbps: Optional[float] = None,
    ts: Optional[float] = None,
) -> dict[str, Any]:
    """Normalize the D-Link status payloads into the platform snapshot shape.

    Cells:
      - LTE anchor (primary)  - first set of duplicated metrics, arfcn4G, band4G
      - 5G NR carrier (secondary) - last set of duplicated metrics, arfcn5G, band
      - extra LTE CA component carriers parsed from caBand
      - neighbour cells from lte_*_nbr / nr_*_nbr when the modem reports them
    """
    header = header or {}
    home = home or {}
    sim = sim or {}
    band = band or {}
    eth = eth or {}

    model = _fmt(header.get("model")) or "router"
    name = f"{BRAND} {model}".strip()
    net_type = _fmt(home.get("netType"))
    signal_strength = str(home.get("signalStrength") or "").upper()
    signal_quality = SIGNAL_QUALITY_MAP.get(signal_strength)

    sim_info = _dup_json(sim.get("internet_info"))
    internet: dict[str, Any] = {
        k: _val(sim_info, k)
        for k in (
            "mcc", "mnc", "operator", "radiomode", "cid", "tac", "plmn",
            "arfcn4G", "arfcn5G", "band", "band4G", "bandwidth", "cqi",
            "caBand", "caBandwidth", "caDL", "caUL", "endc", "ta",
            "network_type", "noBid4G", "noBid5G", "eNodeB",
            "lte_arfcn_nbr", "lte_pci_nbr", "lte_sinr_nbr", "lte_rsrp_nbr", "lte_rsrq_nbr",
            "nr_arfcn_nbr", "nr_pci_nbr", "nr_sinr_nbr", "nr_rsrp_nbr", "nr_rsrq_nbr",
        )
    }
    # duplicated metric keys: index 0 = LTE anchor, last = NR carrier
    lte_metrics_raw = {k: _val(sim_info, k, 0) for k in ("rsrp", "rsrq", "rssi", "snr", "sinr", "pci")}
    nr_metrics_raw = {k: _val(sim_info, k, -1) for k in ("rsrp", "rsrq", "rssi", "snr", "sinr", "pci")}

    bw_map = _ca_bandwidth_map(internet.get("caBand"), internet.get("caBandwidth"))
    lte_band = _fmt(internet.get("band4G"))
    nr_band_raw = _fmt(internet.get("band"))
    # present 5G band the conventional way ('78' -> 'n78'), like the rest of the app
    nr_band = f"n{nr_band_raw}" if nr_band_raw and nr_band_raw.isdigit() else nr_band_raw
    lte_bw = bw_map.get(lte_band) if lte_band else None
    nr_bw = bw_map.get(nr_band_raw) if nr_band_raw else parse_mhz_bandwidth(internet.get("bandwidth"))

    cells: list[dict[str, Any]] = []

    # -- LTE anchor ----------------------------------------------------------
    lte_metrics = _metrics(
        {k: v for k, v in lte_metrics_raw.items() if k in ("rsrp", "rsrq", "rssi", "sinr")},
        ("rsrp", "rsrq", "sinr", "rssi"),
    )
    if not lte_metrics and "snr" in lte_metrics_raw:
        snr = parse_dbm(lte_metrics_raw["snr"])
        if snr is not None:
            lte_metrics["sinr"] = render_metric("sinr", snr)
    lte_identity = {
        "pci": _fmt(lte_metrics_raw.get("pci")),
        "cell_id": _fmt(internet.get("cid")) or _fmt(internet.get("eNodeB")),
        "band": lte_band,
        "arfcn": _fmt(internet.get("arfcn4G")),
        "dl_bandwidth_mhz": lte_bw,
        "mcs": _fmt(band.get("dlMcs")),
        "ul_mcs": _fmt(band.get("ulMcs")),
    }
    lte_present = bool(lte_metrics) or lte_identity["pci"] or lte_identity["arfcn"]

    # -- 5G NR carrier -------------------------------------------------------
    nr_metrics = _metrics(
        {k: v for k, v in nr_metrics_raw.items() if k in ("rsrp", "rsrq", "sinr")},
        ("rsrp", "rsrq", "sinr"),
    )
    if not nr_metrics and "snr" in nr_metrics_raw:
        snr = parse_dbm(nr_metrics_raw["snr"])
        if snr is not None:
            nr_metrics["sinr"] = render_metric("sinr", snr)
    nr_identity = {
        "pci": _fmt(nr_metrics_raw.get("pci")),
        "band": nr_band,
        "arfcn": _fmt(internet.get("arfcn5G")),
        "dl_bandwidth_mhz": nr_bw,
        "cqi": _fmt(internet.get("cqi")),
        "ta": _fmt(internet.get("ta")),
    }
    nr_present = bool(nr_metrics) or nr_identity["pci"] or nr_identity["arfcn"]

    # In NSA mode LTE anchors and NR is a secondary carrier; SA has NR alone.
    mode_label, mode = _mode_from(net_type, internet.get("radiomode"), lte_present, nr_present)
    if mode == "sa":
        if nr_present:
            cells.append(_cell("primary", "NR", "Primary cell (5G NR)", nr_identity, nr_metrics))
        if lte_present:
            cells.append(_cell("secondary", "LTE", "Secondary cell (LTE)", lte_identity, lte_metrics))
    else:
        if lte_present:
            cells.append(_cell("primary", "LTE", "Primary cell (LTE anchor)", lte_identity, lte_metrics))
        if nr_present:
            cells.append(_cell("secondary", "NR", "Secondary cell (5G NR)", nr_identity, nr_metrics))

    # -- extra LTE CA component carriers (B3+B1/N78 -> the B1 is a CA SCell) --
    for bd, bw in bw_map.items():
        if bd == (lte_band or "") or bd == (nr_band_raw or ""):
            continue
        cells.append(
            _cell(
                "secondary",
                "LTE",
                "LTE carrier aggregation",
                {"band": bd, "dl_bandwidth_mhz": bw},
                {},
            )
        )

    # -- neighbours -----------------------------------------------------------
    for rat, prefix in (("NR", "nr"), ("LTE", "lte")):
        nbr = _neighbor_cell(internet, rat, prefix)
        if nbr is not None:
            cells.append(nbr)

    wan_status = _nested_json(home.get("wanStatusInfo"))
    eth_status = _nested_json(eth.get("wanStatusInfo"))
    system = _nested_json(home.get("systeminfo"))
    plmn = _fmt(internet.get("plmn")) or "---"
    operator = _fmt(home.get("operator")) or operator_name(plmn) or "---"
    # -1 means "no cable detected" on this firmware
    eth_cable = parse_int(eth.get("ethCable"))
    if eth_cable is not None and eth_cable < 0:
        eth_cable = None

    device = {
        "name": name,
        "brand": BRAND,
        "model": model,
        "mode": mode,
        "mode_label": mode_label,
        "bars": SIGNAL_BARS.get(signal_strength),
        "signal_quality": signal_quality,
        "signal_quality_label": QUALITY_LABELS.get(signal_quality) if signal_quality else None,
        "plmn": plmn,
        "operator": operator,
        "dl_mbps": dl_mbps,
        "ul_mbps": ul_mbps,
        "month_gb": None,
        "today_mb": None,
        "uptime_s": parse_int(system.get("uptime")),
        "wan_ip": _wan_ip(wan_status) or _wan_ip(eth_status) or _fmt(home.get("wan_ip")),
        "imei": _fmt(sim.get("imei")),
        "iccid": _iccid(sim.get("iccid")),
        "imsi": _imsi(band.get("imsi")),
        "network_type": net_type,
        "traffic_counter": parse_number(home.get("traffic")),
        "wan_mac": _fmt(eth.get("wanMac")),
        "eth_type": _fmt(eth.get("ethType")),
        "wan_ipv6": _fmt(eth.get("wanipv6")),
        "eth_cable": eth_cable,
    }

    return {
        "ts": ts if ts is not None else time.time(),
        "device": device,
        "cells": cells,
        "source": source,
        "error": None,
        "raw": raw,
    }


# --------------------------------------------------------------------------
# Client
# --------------------------------------------------------------------------

class DlinkClient:
    """Owns an HTTPS session to the D-Link LuCI backend and fetches one
    normalized snapshot. Interface-compatible with modem.HuaweiClient."""

    def __init__(self, host: str, username: str, password: str, timeout: float = 6.0, scheme: str = "https") -> None:
        self.host = host
        self.username = username
        self.password = password
        self.timeout = timeout
        self.scheme = scheme
        self._base = f"{scheme}://{host}"
        self._session = requests.Session()
        self._session.verify = False  # the router's cert is self-signed
        self._session.headers.update(
            {"User-Agent": "Mozilla/5.0 (signal-monitor)", "Accept": "*/*"}
        )
        self._last_traffic: Optional[float] = None
        self._last_ts: Optional[float] = None

    # ------------------------------------------------------------------ login

    def _ensure_logged_in(self) -> None:
        if self._session.cookies.get("sysauth"):
            return
        # First visit seeds the SessionID cookie the login form expects.
        self._session.get(self._base + "/cgi-bin/luci/", timeout=self.timeout)
        resp = self._session.post(
            self._base + "/cgi-bin/luci",
            data={"luci_username": self.username, "luci_password": self.password},
            allow_redirects=True,
            timeout=self.timeout,
        )
        if not self._session.cookies.get("sysauth"):
            raise ModemUnavailableError("login failed: check username/password")

    def _drop_session(self) -> None:
        self._session.cookies.clear()
        self._last_traffic = None
        self._last_ts = None

    def close(self) -> None:
        try:
            self._session.close()
        except Exception:
            pass
        self._last_traffic = None
        self._last_ts = None

    # ------------------------------------------------------------------ fetch

    def _status_get(self, endpoint: str, status: Optional[int] = 1) -> dict[str, Any]:
        # The LuCI XHR helper appends Date.now() as an unnamed query parameter
        # (cache-buster). Mirror it: ?status=1&<ms> (or just ?<ms> for the
        # endpoints that do not take a status flag).
        qs = "status=1&" if status else ""
        qs += str(int(time.time() * 1000))
        url = f"{self._base}/cgi-bin/luci/admin/status/{endpoint}?{qs}"
        resp = self._session.get(url, timeout=self.timeout, allow_redirects=False)
        if resp.status_code in (301, 302, 401, 403):
            raise _SessionExpired(endpoint)
        if resp.status_code != 200:
            raise ModemUnavailableError(f"{endpoint} failed: HTTP {resp.status_code}")
        return resp.json()

    def _fetch_once(self) -> dict[str, Any]:
        header = self._status_get("header", status=1)
        home = self._status_get("home_poll", status=1)
        sim = self._status_get("get_sim_detail", status=1)
        band_info = self._status_get("get_band_info", status=None)
        eth = self._status_get("get_eth_detail", status=1)

        # home_poll.traffic is a cumulative KiB counter that the firmware only
        # advances on a coarse cadence (the device's own UI polls every 5s and
        # divides the delta by 5). So we measure the rate across counter
        # *changes*: when a poll sees the same value we keep the previous
        # timestamp, and the next change is attributed to the full window
        # since that change. This avoids fake 0 readings and spikes.
        traffic = parse_number(home.get("traffic"))
        dl_mbps: Optional[float] = None
        now = time.monotonic()
        if traffic is not None:
            if self._last_traffic is not None and self._last_ts is not None:
                delta = traffic - self._last_traffic
                dt = now - self._last_ts
                if delta > 0 and dt > 0:
                    dl_mbps = round((delta / dt) * 8 / 1000, 2)
            if traffic != self._last_traffic or self._last_ts is None:
                self._last_traffic = traffic
                self._last_ts = now
        else:
            self._last_traffic = None
            self._last_ts = None

        return build_dlink_snapshot(
            header=header,
            home=home,
            sim=sim,
            band=band_info,
            eth=eth,
            source="live",
            raw={"header": header, "home_poll": home, "get_sim_detail": sim,
                 "get_band_info": band_info, "get_eth_detail": eth},
            dl_mbps=dl_mbps,
            ul_mbps=None,
        )

    def fetch(self) -> dict[str, Any]:
        """Poll the modem and return a normalized snapshot dict."""
        self._ensure_logged_in()
        try:
            return self._fetch_once()
        except _SessionExpired:
            # stale auth token -> re-login once and retry
            log.info("dlink session expired, re-logging in")
            self._drop_session()
            self._ensure_logged_in()
            return self._fetch_once()

    def validate(self) -> None:
        """Light check used by the config modal: log in and hit one authorized
        endpoint so wrong credentials / unreachable host fail fast."""
        try:
            self._ensure_logged_in()
            self._status_get("header", status=1)
        except Exception as exc:
            self.close()
            raise ModemUnavailableError(f"login or reachability failed: {exc}") from exc
        finally:
            self.close()
