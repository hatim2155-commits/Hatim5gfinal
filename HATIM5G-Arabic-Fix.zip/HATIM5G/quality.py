"""Metric definitions, quality bands and rendering helpers.

Every metric has:
  - a numeric range (min..max) used to position the progress bar
  - quality bands: value >= threshold -> quality (threshold None catches the rest)

Bands follow the widely used LTE/5G convention (digi.com knowledge base,
same scale 5gtop uses): excellent / good / fair / poor.
All thresholds can be tuned here; the frontend renders whatever the backend sends.
"""

from __future__ import annotations

import re
from typing import Any, Optional

QUALITY_ORDER = ["excellent", "good", "fair", "poor"]

# quality -> (label used on the page)
QUALITY_LABELS = {
    "excellent": "Excellent",
    "good": "Good",
    "fair": "Fair",
    "poor": "Poor",
}

# key -> definition. bands: list of (threshold, quality), checked top-down;
# a None threshold matches everything below the previous boundary.
METRICS: dict[str, dict[str, Any]] = {
    "rsrp": {
        "label": "RSRP",
        "unit": "dBm",
        "min": -140.0,
        "max": -60.0,
        "bands": [(-80.0, "excellent"), (-90.0, "good"), (-100.0, "fair"), (None, "poor")],
        "desc": "Reference Signal Received Power",
    },
    "rsrq": {
        "label": "RSRQ",
        "unit": "dB",
        "min": -34.0,
        "max": -3.0,
        "bands": [(-10.0, "excellent"), (-15.0, "good"), (-20.0, "fair"), (None, "poor")],
        "desc": "Reference Signal Received Quality",
    },
    "sinr": {
        "label": "SINR",
        "unit": "dB",
        "min": -10.0,
        "max": 30.0,
        "bands": [(20.0, "excellent"), (13.0, "good"), (0.0, "fair"), (None, "poor")],
        "desc": "Signal to Interference plus Noise Ratio",
    },
    "rssi": {
        "label": "RSSI",
        "unit": "dBm",
        "min": -110.0,
        "max": -50.0,
        "bands": [(-65.0, "excellent"), (-75.0, "good"), (-85.0, "fair"), (None, "poor")],
        "desc": "Received Signal Strength Indicator",
    },
}

# Order in which metrics are displayed in a cell card
METRIC_ORDER = ["rsrp", "rsrq", "sinr", "rssi"]

_NUM_RE = re.compile(r"(-?[0-9]*\.?[0-9]+)")


# --------------------------------------------------------------------------
# Parsing helpers (defensive against firmware variations)
# --------------------------------------------------------------------------

def parse_number(value: Any) -> Optional[float]:
    """Extract the leading number from strings like '-79dBm', '15dB', '32639'."""
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    m = _NUM_RE.search(str(value))
    if not m:
        return None
    try:
        return float(m.group(1))
    except ValueError:
        return None


def parse_int(value: Any) -> Optional[int]:
    n = parse_number(value)
    return int(n) if n is not None else None


def parse_dbm(value: Any) -> Optional[float]:
    return parse_number(value)


def parse_db(value: Any) -> Optional[float]:
    return parse_number(value)


def parse_mhz(value: Any) -> Optional[float]:
    """'3654900kHz' -> 3654.9 (MHz), '2650000kHz' -> 2650.0, '90MHz' -> 90.0."""
    n = parse_number(value)
    if n is None:
        return None
    s = str(value).lower()
    if "ghz" in s:
        return n * 1000.0
    if "mhz" in s:
        return n
    return n / 1000.0  # assume kHz


def parse_mhz_bandwidth(value: Any) -> Optional[float]:
    """'90MHz' -> 90.0, '20MHz' -> 20.0. Same as parse_mhz but keeps raw unit."""
    n = parse_number(value)
    if n is None:
        return None
    s = str(value).lower()
    if "ghz" in s:
        return n * 1000.0
    return n


# --------------------------------------------------------------------------
# Quality classification + bar math
# --------------------------------------------------------------------------

def classify(key: str, value: float) -> str:
    m = METRICS[key]
    for threshold, quality in m["bands"]:
        if threshold is None:
            return quality
        if value >= threshold:
            return quality
    return "poor"


def pct_for(key: str, value: float) -> float:
    """Position (0..100) of a value on the metric bar."""
    m = METRICS[key]
    lo, hi = m["min"], m["max"]
    if hi <= lo:
        return 0.0
    pct = (value - lo) / (hi - lo) * 100.0
    return max(0.0, min(100.0, pct))


def segments_for(key: str) -> list[dict[str, Any]]:
    """Colored bar segments from min to max, each covering the values between
    consecutive band boundaries. A segment's quality is the quality of the
    values it contains:
      - below the first threshold  -> worst quality (the None fallback band)
      - between threshold[i] and threshold[i+1] -> quality of threshold[i]
      - above the last threshold   -> quality of the last threshold
    """
    m = METRICS[key]
    bands = sorted((t, q) for t, q in m["bands"] if t is not None)
    if not bands:
        return [{"end_pct": 100.0, "quality": "poor"}]
    fallback = next(q for t, q in m["bands"] if t is None)
    segments: list[dict[str, Any]] = []
    prev_quality = fallback
    for threshold, quality in bands:
        segments.append({"end_pct": pct_for(key, threshold), "quality": prev_quality})
        prev_quality = quality
    segments.append({"end_pct": 100.0, "quality": prev_quality})
    # drop empty/overlapping segments and make sure we cover 0..100
    result: list[dict[str, Any]] = []
    prev = 0.0
    for seg in segments:
        if seg["end_pct"] < prev:
            continue
        result.append(seg)
        prev = seg["end_pct"]
    return result


def render_metric(key: str, value: Any) -> dict[str, Any]:
    """Full render payload for the frontend. value None -> no signal present."""
    base = {
        "key": key,
        "label": METRICS[key]["label"],
        "unit": METRICS[key]["unit"],
        "desc": METRICS[key]["desc"],
        "min": METRICS[key]["min"],
        "max": METRICS[key]["max"],
    }
    if value is None:
        base.update({"value": None, "quality": None, "quality_label": None, "pct": None})
        return base
    val = float(value)
    quality = classify(key, val)
    base.update(
        {
            "value": val,
            "quality": quality,
            "quality_label": QUALITY_LABELS[quality],
            "pct": pct_for(key, val),
            "segments": segments_for(key),
        }
    )
    return base
