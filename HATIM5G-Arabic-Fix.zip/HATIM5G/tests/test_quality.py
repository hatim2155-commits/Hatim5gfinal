"""Boundary tests for quality bands and parsing helpers."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from quality import (  # noqa: E402
    METRICS,
    classify,
    parse_db,
    parse_dbm,
    parse_int,
    parse_mhz,
    parse_mhz_bandwidth,
    parse_number,
    pct_for,
    render_metric,
    segments_for,
)


# ------------------------------------------------------------------ parsing

def test_parse_number_variants():
    assert parse_number("-79dBm") == -79.0
    assert parse_number("15dB") == 15.0
    assert parse_number("-10.0dB") == -10.0
    assert parse_number("32639") == 32639.0
    assert parse_number(None) is None
    assert parse_number("") is None
    assert parse_number("none") is None
    assert parse_number(42) == 42.0


def test_parse_dbm_db_int():
    assert parse_dbm("-80dBm") == -80.0
    assert parse_db("-5.0dB") == -5.0
    assert parse_int("0x20") is None or parse_int("427") == 427


def test_parse_mhz():
    assert parse_mhz("3654900kHz") == 3654.9
    assert parse_mhz("2650000kHz") == 2650.0
    assert parse_mhz("90MHz") == 90.0
    assert parse_mhz("3.5GHz") == 3500.0
    assert parse_mhz(None) is None


def test_parse_mhz_bandwidth():
    assert parse_mhz_bandwidth("90MHz") == 90.0
    assert parse_mhz_bandwidth("20MHz") == 20.0


# ------------------------------------------------------------------ bands

def test_classify_rsrp():
    assert classify("rsrp", -79) == "excellent"
    assert classify("rsrp", -80) == "excellent"   # inclusive boundary
    assert classify("rsrp", -81) == "good"
    assert classify("rsrp", -90) == "good"
    assert classify("rsrp", -99) == "fair"
    assert classify("rsrp", -100) == "fair"
    assert classify("rsrp", -101) == "poor"
    assert classify("rsrp", -150) == "poor"


def test_classify_sinr():
    assert classify("sinr", 25) == "excellent"
    assert classify("sinr", 20) == "excellent"
    assert classify("sinr", 19) == "good"
    assert classify("sinr", 13) == "good"
    assert classify("sinr", 5) == "fair"
    assert classify("sinr", -3) == "poor"


def test_pct_for_clamps():
    assert pct_for("rsrp", -140) == 0.0
    assert pct_for("rsrp", -100) == 50.0
    assert pct_for("rsrp", -60) == 100.0
    assert pct_for("rsrp", -200) == 0.0   # below min clamps
    assert pct_for("rsrp", 0) == 100.0    # above max clamps


def test_segments_full_range():
    segs = segments_for("rsrp")
    assert segs[-1]["end_pct"] == 100.0
    # covers from 0 to 100 without gaps
    prev = 0.0
    for s in segs:
        assert s["end_pct"] >= prev
        prev = s["end_pct"]
    assert len(segs) == 4  # poor, fair, good, excellent


def _segment_at(segs, pct):
    """Quality of the segment containing pct."""
    prev = 0.0
    for s in segs:
        if pct <= s["end_pct"] + 1e-9:
            return s["quality"]
        prev = s["end_pct"]
    return segs[-1]["quality"]


def test_segments_colors_match_classification():
    """The colored region at a value's bar position must match its quality.
    Checks values strictly inside each band (exact boundary values sit on the
    junction between two colored regions)."""
    for key in ("rsrp", "rsrq", "sinr", "rssi"):
        segs = segments_for(key)
        assert len(segs) == 4
        lo, hi = METRICS[key]["min"], METRICS[key]["max"]
        thresholds = [t for t, _ in METRICS[key]["bands"] if t is not None]
        values = {lo + 0.5, hi - 0.5}
        for t in thresholds:
            if lo + 0.5 < t - 0.5 < hi - 0.5:
                values.add(t - 0.5)  # just below the boundary -> lower band
            if lo + 0.5 < t + 0.5 < hi - 0.5:
                values.add(t + 0.5)  # just above the boundary -> this band
        for val in values:
            pct = pct_for(key, val)
            assert _segment_at(segs, pct) == classify(key, val), f"{key} @ {val}"


def test_segments_exact_boundaries():
    """Explicit boundary expectations for the default bands."""
    # rsrp min -140 max -60: thresholds -100 (fair), -90 (good), -80 (excellent)
    segs = segments_for("rsrp")
    assert [(round(s["end_pct"], 1), s["quality"]) for s in segs] == [
        (50.0, "poor"),    # -140..-100
        (62.5, "fair"),    # -100..-90
        (75.0, "good"),    # -90..-80
        (100.0, "excellent"),  # -80..-60
    ]
    # sinr min -10 max 30: thresholds 0 (fair), 13 (good), 20 (excellent)
    segs = segments_for("sinr")
    assert [(round(s["end_pct"], 1), s["quality"]) for s in segs] == [
        (25.0, "poor"),        # -10..0
        (57.5, "fair"),        # 0..13
        (75.0, "good"),        # 13..20
        (100.0, "excellent"),  # 20..30
    ]


def test_render_metric_none():
    r = render_metric("rsrp", None)
    assert r["value"] is None
    assert r["quality"] is None


def test_render_metric_value():
    r = render_metric("rsrp", -79)
    assert r["value"] == -79.0
    assert r["quality"] == "excellent"
    assert 0 < r["pct"] <= 100
    assert r["unit"] == "dBm"
