"""Tests for the D-Link LuCI client: pure snapshot building from the captured
payloads, plus integration tests against a mock LuCI backend."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest  # noqa: E402

import dlink  # noqa: E402
from dlink import DlinkClient, build_dlink_snapshot  # noqa: E402
from modem import ModemUnavailableError  # noqa: E402

from mock_dlink import BAND_INFO, ETH_DETAIL, HEADER, HOME_POLL, SIM_DETAIL, MockDlink  # noqa: E402


def _snap(**kw):
    kw.setdefault("eth", ETH_DETAIL)
    params = dict(header=HEADER, home=HOME_POLL, sim=SIM_DETAIL, band=BAND_INFO)
    params.update(kw)
    return build_dlink_snapshot(**params)


def test_build_snapshot_device():
    s = _snap(dl_mbps=12.34)
    d = s["device"]
    assert d["name"] == "D-Link DWR-2000M"
    assert d["brand"] == "D-Link"
    assert d["model"] == "DWR-2000M"
    assert d["mode_label"] == "5G NSA"
    assert d["mode"] == "nsa"
    # modem-provided classification (MODERATE -> fair) is preferred over our own
    assert d["signal_quality"] == "fair"
    assert d["signal_quality_label"] == "Fair"
    assert d["bars"] == 2
    assert d["plmn"] == "60502"
    assert d["operator"] == "TUNISIE TELECOM"
    assert d["uptime_s"] == 721
    assert d["wan_ip"] == "10.77.221.244"
    assert d["imei"] == "351108519562447"
    assert d["iccid"] == "8921602080358069378F"
    assert d["imsi"] == "605020835806937"
    assert d["dl_mbps"] == 12.34
    assert d["ul_mbps"] is None
    assert d["month_gb"] is None
    assert d["wan_mac"] == "A2:9F:7A:76:3E:97"
    assert d["eth_type"] == "DHCP"
    assert d["eth_cable"] is None  # firmware reports -1 for "no cable"
    assert s["error"] is None


def test_eth_wan_status_fallback():
    """When home_poll has no WAN address, get_eth_detail's wanStatusInfo is used."""
    home = dict(HOME_POLL, wanStatusInfo=None)
    s = _snap(home=home)
    assert s["device"]["wan_ip"] == "10.77.221.244"


def test_build_snapshot_cells():
    s = _snap()
    kinds = [(c["kind"], c["rat"]) for c in s["cells"]]
    assert ("primary", "LTE") in kinds
    assert ("secondary", "NR") in kinds
    assert ("secondary", "LTE") in kinds  # B1 CA component carrier
    assert ("neighbor", "NR") in kinds

    lte = next(c for c in s["cells"] if c["kind"] == "primary")
    assert lte["identity"]["pci"] == "76"
    assert lte["identity"]["cell_id"] == "a7b505"
    assert lte["identity"]["band"] == "3"
    assert lte["identity"]["arfcn"] == "1350"
    assert lte["identity"]["dl_bandwidth_mhz"] == 20.0
    assert lte["metrics"]["rsrp"]["value"] == -104.0  # first (LTE) duplicate set
    assert lte["metrics"]["rsrq"]["value"] == -17.0
    assert lte["metrics"]["sinr"]["value"] == 2.0
    assert lte["metrics"]["rssi"]["value"] == -87.0

    nr = next(c for c in s["cells"] if c["kind"] == "secondary" and c["rat"] == "NR")
    assert nr["identity"]["pci"] == "643"
    assert nr["identity"]["band"] == "n78"
    assert nr["identity"]["arfcn"] == "647328"
    assert nr["identity"]["dl_bandwidth_mhz"] == 100.0
    assert nr["identity"]["cqi"] == "15"
    assert nr["metrics"]["rsrp"]["value"] == -103.0  # last (NR) duplicate set
    assert nr["metrics"]["rsrq"]["value"] == -12.0
    assert nr["metrics"]["sinr"]["value"] == 8.0
    assert "rssi" not in nr["metrics"]  # 5G NR has no RSSI

    ca = next(c for c in s["cells"] if c["kind"] == "secondary" and c["rat"] == "LTE")
    assert ca["identity"]["band"] == "1"
    assert ca["identity"]["dl_bandwidth_mhz"] == 10.0
    assert ca["metrics"] == {}

    nbr = next(c for c in s["cells"] if c["kind"] == "neighbor")
    assert nbr["rat"] == "NR"
    assert nbr["identity"]["pci"] == "644"
    assert nbr["metrics"]["rsrp"]["value"] == -107.0
    assert nbr["metrics"]["sinr"]["value"] == -5.0


def test_signal_strength_mapping():
    for raw, quality, bars in (
        ("GREAT", "excellent", 4),
        ("GOOD", "good", 3),
        ("MODERATE", "fair", 2),
        ("POOR", "poor", 1),
        ("UNKNOWN", None, 0),
    ):
        home = dict(HOME_POLL, signalStrength=raw)
        s = build_dlink_snapshot(header=HEADER, home=home, sim=SIM_DETAIL, band=BAND_INFO)
        assert s["device"]["signal_quality"] == quality, raw
        assert s["device"]["bars"] == bars, raw


def test_empty_payloads():
    s = build_dlink_snapshot()
    assert s["device"]["name"] == "D-Link router"
    assert s["device"]["signal_quality"] is None
    assert s["cells"] == []
    assert s["error"] is None


def test_ca_bandwidth_map():
    assert dlink._ca_bandwidth_map("B3+B1/N78", "20-10-100") == {"3": 20.0, "1": 10.0, "78": 100.0}
    assert dlink._ca_bandwidth_map(None, None) == {}


# --------------------------------------------------------------------------
# live path against the mock LuCI backend
# --------------------------------------------------------------------------

def test_live_fetch_against_mock():
    with MockDlink() as mdm:
        client = DlinkClient(mdm.host, "admin", "testpass", timeout=5.0, scheme="http")
        snap = client.fetch()
        client.close()

    assert snap["device"]["name"] == "D-Link DWR-2000M"
    assert snap["device"]["signal_quality"] == "fair"
    assert snap["device"]["bars"] == 2
    kinds = {(c["kind"], c["rat"]) for c in snap["cells"]}
    assert ("primary", "LTE") in kinds
    assert ("secondary", "NR") in kinds
    assert snap["error"] is None


def test_live_fetch_computes_rate_from_traffic_counter():
    import time

    from mock_dlink import MockDlinkHandler

    with MockDlink() as mdm:
        MockDlinkHandler.traffic = "219580"
        client = DlinkClient(mdm.host, "admin", "testpass", timeout=5.0, scheme="http")
        s1 = client.fetch()  # first poll: no previous counter -> no rate
        # advance the cumulative KiB counter, as the modem would between polls
        MockDlinkHandler.traffic = "224780"  # +5200 KiB
        time.sleep(0.05)  # ensure a measurable elapsed window
        s2 = client.fetch()
        client.close()
    assert s1["device"]["dl_mbps"] is None
    assert s2["device"]["dl_mbps"] is not None
    assert s2["device"]["dl_mbps"] > 0


def test_rate_ignores_unchanged_counter():
    """A poll that sees the same counter value keeps the previous timestamp, so
    the next change is measured across the full window (no fake 0/spike)."""
    import time

    from mock_dlink import MockDlinkHandler

    with MockDlink() as mdm:
        MockDlinkHandler.traffic = "1000"
        client = DlinkClient(mdm.host, "admin", "testpass", timeout=5.0, scheme="http")
        s1 = client.fetch()
        # unchanged counter: must NOT produce a 0-rate sample that resets the window
        MockDlinkHandler.traffic = "1000"
        time.sleep(0.05)
        s2 = client.fetch()
        # now it advances: the whole elapsed window since the change is used
        MockDlinkHandler.traffic = "1600"  # +600 KiB
        time.sleep(0.05)
        s3 = client.fetch()
        client.close()
    assert s1["device"]["dl_mbps"] is None
    assert s2["device"]["dl_mbps"] == 0.0 or s2["device"]["dl_mbps"] is None
    assert s3["device"]["dl_mbps"] is not None and s3["device"]["dl_mbps"] > 0


def test_live_fetch_reuses_session():
    with MockDlink() as mdm:
        client = DlinkClient(mdm.host, "admin", "testpass", timeout=5.0, scheme="http")
        s1 = client.fetch()
        s2 = client.fetch()  # reuses the logged-in sysauth cookie
        client.close()
    assert s1["ts"] <= s2["ts"]
    assert s2["device"]["name"] == "D-Link DWR-2000M"


def test_validate_wrong_password_raises():
    with MockDlink() as mdm:
        client = DlinkClient(mdm.host, "admin", "wrongpass", timeout=5.0, scheme="http")
        with pytest.raises(ModemUnavailableError):
            client.validate()


def test_fetch_wrong_password_raises():
    with MockDlink() as mdm:
        client = DlinkClient(mdm.host, "admin", "wrongpass", timeout=5.0, scheme="http")
        with pytest.raises(ModemUnavailableError):
            client.fetch()


def test_validate_good_password_passes():
    with MockDlink() as mdm:
        client = DlinkClient(mdm.host, "admin", "testpass", timeout=5.0, scheme="http")
        client.validate()  # should not raise


def test_status_url_has_cache_buster():
    """The status URLs must carry the millisecond cache-buster like the browser."""
    with MockDlink() as mdm:
        client = DlinkClient(mdm.host, "admin", "testpass", timeout=5.0, scheme="http")
        client._ensure_logged_in()
        assert client._status_get("header", status=1)["model"] == "DWR-2000M"
        # home_poll takes status=1; get_band_info takes none (bare timestamp)
        assert client._status_get("get_band_info", status=None)["endc"] == "1"
        client.close()
