"""Integration tests: exercise the REAL huawei-lte-api login flow and HTTP
parsing against a local mock HiLink modem (tests/mock_modem.py).

This validates the live path (Connection -> Session -> token -> state-login ->
login -> fetch) that pure snapshot tests cannot cover.
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest  # noqa: E402

from modem import HuaweiClient, ModemUnavailableError  # noqa: E402

from mock_modem import MockModem  # noqa: E402


def test_live_fetch_against_mock():
    with MockModem() as mdm:
        client = HuaweiClient(mdm.host, "admin", "testpass", timeout=5.0)
        snap = client.fetch()
        client.close()

    assert snap["device"]["name"] == "H153-381"
    assert snap["device"]["mode_label"] == "LTE + 5G NR (NSA)"
    assert snap["device"]["bars"] == 4
    kinds = {(c["kind"], c["rat"]) for c in snap["cells"]}
    assert ("primary", "LTE") in kinds
    assert ("secondary", "NR") in kinds
    assert ("neighbor", "NR") in kinds
    nr = next(c for c in snap["cells"] if c["rat"] == "NR" and c["kind"] == "secondary")
    assert nr["metrics"]["rsrp"]["value"] == -79.0
    assert nr["identity"]["dl_bandwidth_mhz"] == 90.0
    assert snap["error"] is None


def test_live_fetch_reuses_connection():
    with MockModem() as mdm:
        client = HuaweiClient(mdm.host, "admin", "testpass", timeout=5.0)
        s1 = client.fetch()
        s2 = client.fetch()  # second call reuses the logged-in session
        client.close()
    assert s1["ts"] <= s2["ts"]
    assert s2["device"]["name"] == "H153-381"


def test_validate_wrong_password_raises():
    with MockModem() as mdm:
        client = HuaweiClient(mdm.host, "admin", "wrongpass", timeout=5.0)
        with pytest.raises(ModemUnavailableError):
            client.validate()


def test_fetch_wrong_password_raises():
    with MockModem() as mdm:
        client = HuaweiClient(mdm.host, "admin", "wrongpass", timeout=5.0)
        with pytest.raises(ModemUnavailableError):
            client.fetch()


def test_validate_good_password_passes():
    with MockModem() as mdm:
        client = HuaweiClient(mdm.host, "admin", "testpass", timeout=5.0)
        client.validate()  # should not raise


def test_live_fetch_sa_mode():
    """5G SA (mode 102): NR is the primary cell, no LTE anchor."""
    with MockModem(sa_mode=True) as mdm:
        client = HuaweiClient(mdm.host, "admin", "testpass", timeout=5.0)
        snap = client.fetch()
        client.close()

    assert snap["device"]["mode_label"] == "5G SA"
    kinds = {(c["kind"], c["rat"]) for c in snap["cells"]}
    assert ("primary", "NR") in kinds
    # serving cells are NR; LTE may still appear as neighbor entries
    serving = [c for c in snap["cells"] if c["kind"] in ("primary", "secondary")]
    assert all(c["rat"] == "NR" for c in serving)
    nr = next(c for c in snap["cells"] if c["kind"] == "primary")
    assert nr["metrics"]["rsrp"]["value"] == -72.0
    assert nr["identity"]["dl_bandwidth_mhz"] == 100.0


def test_cell_info_case_insensitive_keys():
    """Real firmware may send 'CellId'/'ARFCN'/'Band' instead of lowercase."""
    from modem import _cells_from_cell_info

    raw = {
        "NrCellInfo": {
            "item": {"Pci": "901", "Arfcn": "643660", "Band": "n78", "RSRP": "-88dBm", "Sinr": "10dB"},
        }
    }
    cells = _cells_from_cell_info(raw, existing=[])
    assert len(cells) == 1
    assert cells[0]["rat"] == "NR"
    assert cells[0]["identity"]["pci"] == "901"
    assert cells[0]["identity"]["band"] == "n78"
    assert cells[0]["identity"]["arfcn"] == "643660"
    assert cells[0]["metrics"]["rsrp"]["value"] == -88.0


def test_full_server_live_mode_e2e_huawei():
    """End-to-end: run the FastAPI server in live mode pointed at the mock,
    then POST config (validates against the mock) and read status."""
    _run_e2e(vendor="huawei")


def test_full_server_live_mode_e2e_dlink():
    """End-to-end with the D-Link LuCI vendor: the config modal POSTs
    vendor=dlink and the poller must build its client from the D-Link SDK."""
    _run_e2e(vendor="dlink")


def _run_e2e(vendor: str) -> None:
    import json
    import os
    import subprocess
    import socket

    # free port for the app
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()

    env = {k: v for k, v in os.environ.items() if k != "SIGNAL_MONITOR_DEMO"}
    root = Path(__file__).resolve().parent.parent

    # The server writes its runtime files into BASE_DIR (the repo root), so the
    # test must snapshot any existing ones and restore them afterwards. We must
    # NEVER delete real user data (config.json/best.json/mp.json/reports.json).
    DATA_FILES = ("config.json", "best.json", "mp.json", "reports.json")
    backups = {}
    for name in DATA_FILES:
        p = root / name
        if p.exists():
            backups[name] = p.read_bytes()
            p.unlink()
        else:
            backups[name] = None

    if vendor == "dlink":
        from mock_dlink import MockDlink

        backend = MockDlink()
        cfg = {
            "host": backend.host,
            "username": "admin",
            "password": "testpass",
            "interval_s": 0.5,
            "vendor": "dlink",
            "scheme": "http",  # the mock runs plain HTTP; the real device is https
        }
    else:
        from mock_modem import MockModem

        backend = MockModem()
        cfg = {
            "host": backend.host,
            "username": "admin",
            "password": "testpass",
            "interval_s": 0.5,
        }

    with backend:
        # Launch the real server in live mode (env var off), fresh process so
        # demo_mode is False and the config file path is the real one.
        proc = subprocess.Popen(
            [sys.executable, "main.py", "--port", str(port)],
            cwd=str(root),
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            base = f"http://127.0.0.1:{port}"
            # wait for startup (up to ~15s)
            import urllib.request

            for _ in range(75):
                try:
                    urllib.request.urlopen(base + "/api/config", timeout=1)
                    break
                except Exception:
                    time.sleep(0.2)
            else:
                raise RuntimeError("server did not start")

            req = urllib.request.Request(
                base + "/api/config",
                data=json.dumps(cfg).encode(),
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=10) as r:
                assert json.loads(r.read()) == {"ok": True}

            # poller should now fetch from the mock (up to ~15s)
            data = None
            for _ in range(50):
                with urllib.request.urlopen(base + "/api/status", timeout=2) as r:
                    data = json.loads(r.read())
                if data["cells"]:
                    break
                time.sleep(0.3)
            assert data is not None and data["cells"], "no cells after config"
            assert data["source"] == "live"
            if vendor == "dlink":
                assert data["device"]["name"] == "D-Link DWR-2000M"
                assert data["device"]["brand"] == "D-Link"
                assert data["device"]["signal_quality"] == "fair"
                rats = {c["rat"] for c in data["cells"]}
                assert rats >= {"LTE", "NR"}
            else:
                assert data["device"]["name"] == "H153-381"
                rats = {c["rat"] for c in data["cells"]}
                assert rats >= {"LTE", "NR"}
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
            # restore the pre-test contents of any real data files, and remove
            # only the files this test created (that did not exist beforehand)
            for name in DATA_FILES:
                p = root / name
                if backups[name] is None:
                    p.unlink(missing_ok=True)
                else:
                    p.write_bytes(backups[name])
