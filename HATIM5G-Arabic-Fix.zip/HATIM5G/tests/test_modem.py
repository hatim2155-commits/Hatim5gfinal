"""Tests for modem snapshot building (NSA/SA/LTE-only/empty)."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modem import build_snapshot  # noqa: E402

STATUS = {"SignalIconNr": "4"}
TRAFFIC = {"CurrentDownloadRate": "443457", "CurrentUploadRate": "76419"}
MONTH = {"CurrentMonthDownload": "1000000000", "CurrentMonthUpload": "200000000", "CurrentDayUsed": "300000000"}
BASIC = {"devicename": "H122-373"}
DEVINFO = {"DeviceName": "H122-373", "UpTime": "5344844", "WanIPAddress": "192.168.0.1"}

NSA_SIGNAL = {
    "mode": "7", "plmn": "26201", "pci": "427", "cell_id": "C1", "band": "7",
    "dlfrequency": "2650000kHz", "ulfrequency": "2530000kHz", "dlbandwidth": "20MHz",
    "rsrp": "-80dBm", "rsrq": "-5.0dB", "sinr": "8dB", "rssi": "-54dBm",
    "scc_pci": "0x20",
    "nrrsrp": "-79dBm", "nrrsrq": "-10.0dB", "nrsinr": "15dB",
    "nrdlfreq": "3654900kHz", "nrdlbandwidth": "90MHz",
}

CELLINFO = {
    "NrCellInfo": [{"pci": "723", "rsrp": "-89dBm", "rsrq": "-11.0dB", "sinr": "9dB"}],
    "LteCellInfo": [{"pci": "77", "rsrp": "-95dBm", "rssi": "-62dBm"}],
}


def _keys(cells):
    return [(c["kind"], c["rat"]) for c in cells]


def test_nsa_primary_and_secondary():
    s = build_snapshot(NSA_SIGNAL, STATUS, TRAFFIC, MONTH, BASIC, DEVINFO, CELLINFO)
    assert s["device"]["name"] == "H122-373"
    assert s["device"]["mode_label"] == "LTE + 5G NR (NSA)"
    assert s["device"]["bars"] == 4
    kinds = _keys(s["cells"])
    assert ("primary", "LTE") in kinds
    assert ("secondary", "NR") in kinds
    assert ("secondary", "LTE") in kinds  # scc_pci CA cell
    assert ("neighbor", "NR") in kinds
    assert ("neighbor", "LTE") in kinds

    nr = [c for c in s["cells"] if c["rat"] == "NR" and c["kind"] == "secondary"][0]
    assert nr["metrics"]["rsrp"]["value"] == -79.0
    assert "rssi" not in nr["metrics"]  # NR has no RSSI


def test_sa_nr_primary():
    signal = {k: v for k, v in NSA_SIGNAL.items() if k.startswith("nr") or k in ("mode", "plmn")}
    signal["mode"] = "102"
    signal["nrpci"] = "723"
    s = build_snapshot(signal, STATUS, TRAFFIC, MONTH, BASIC, DEVINFO, None)
    assert s["device"]["mode_label"] == "5G SA"
    kinds = _keys(s["cells"])
    assert ("primary", "NR") in kinds
    assert not any(c["rat"] == "LTE" for c in s["cells"])


def test_lte_only():
    signal = {k: v for k, v in NSA_SIGNAL.items() if not k.startswith("nr")}
    s = build_snapshot(signal, STATUS, TRAFFIC, MONTH, BASIC, DEVINFO, None)
    kinds = _keys(s["cells"])
    assert ("primary", "LTE") in kinds
    assert not any(c["rat"] == "NR" for c in s["cells"])


def test_empty_signal():
    s = build_snapshot({}, {}, {}, {}, {}, {}, None)
    assert s["cells"] == []
    assert s["error"] is None
    assert s["device"]["dl_mbps"] is None


def test_mode_label_nr_presence():
    """H153-381 quirk (issue #265): mode 7 with NR fields must read as NSA."""
    from modem import mode_label

    assert mode_label("101") == "5G NSA"
    assert mode_label("102") == "5G SA"
    assert mode_label("7", has_nr=True) == "LTE + 5G NR (NSA)"
    assert mode_label("7", has_nr=False) == "LTE"
    assert mode_label("0") == "No service"


PCC_SCC = {
    "PCC": {"EARFCN": "1600", "Band": "B3", "Bandwidth": "20MHz", "PCI": "463",
            "RSRP": "-99dBm", "RSRQ": "-9.0dB", "RSSI": "-67dBm", "SINR": "5dB"},
    "SCC": {"EARFCN": "6300", "Band": "B20", "Bandwidth": "10MHz", "PCI": "463",
            "RSRP": "-89dBm", "RSRQ": "-5dB", "RSSI": "-67dBm", "SINR": "--"},
}


def test_cell_info_pcc_scc_separate():
    """The user's modem reports PCC + SCC with the SAME PCI but different
    EARFCN/band; both must be displayed as separate cells."""
    from modem import _cells_from_cell_info

    cells = _cells_from_cell_info(PCC_SCC, existing=[])
    assert len(cells) == 2
    by_type = {c["identity"]["type"].upper(): c for c in cells}
    pcc, scc = by_type["PCC"], by_type["SCC"]
    assert pcc["kind"] == "primary"
    assert scc["kind"] == "secondary"
    assert pcc["identity"]["arfcn"] == "1600"
    assert scc["identity"]["arfcn"] == "6300"
    assert pcc["identity"]["dl_bandwidth_mhz"] == 20.0
    assert scc["identity"]["dl_bandwidth_mhz"] == 10.0
    assert pcc["metrics"]["sinr"]["value"] == 5.0
    assert "sinr" not in scc["metrics"]  # '--' means no value
    assert scc["metrics"]["rsrp"]["value"] == -89.0


def test_neighbor_cells_classified_as_neighbor():
    """Cells typed NEIGHBOR must be counted as neighbours, not carrier-
    aggregation secondaries, so neighbour tower counts are not 0."""
    from modem import _cells_from_cell_info

    raw = {
        "NrCellInfo": [
            {"type": "NEIGHBOR", "pci": "723", "arfcn": "643660", "band": "n78", "rsrp": "-89dBm"},
            {"type": "NEIGHBOUR", "pci": "556", "arfcn": "640000", "rsrp": "-102dBm"},
        ],
        "LteCellInfo": [
            {"type": "NEIGHBOR", "pci": "77", "arfcn": "3050", "rsrp": "-95dBm"},
        ],
    }
    cells = _cells_from_cell_info(raw, existing=[])
    assert len(cells) == 3
    assert all(c["kind"] == "neighbor" for c in cells)
    pcis = sorted(c["identity"]["pci"] for c in cells if c["rat"] == "NR")
    assert pcis == ["556", "723"]
    lte = next(c for c in cells if c["rat"] == "LTE")
    assert lte["identity"]["pci"] == "77"


def test_cell_info_pcc_deduped_with_primary():
    """A cell-info PCC that matches the serving primary (same PCI+EARFCN) is
    not duplicated; the SCC survives."""
    from modem import _cells_from_cell_info

    existing = [{"kind": "primary", "rat": "LTE",
                 "identity": {"pci": "463", "arfcn": "1600", "band": "B3"}, "metrics": {}}]
    cells = _cells_from_cell_info(PCC_SCC, existing=existing)
    assert len(cells) == 1
    assert cells[0]["identity"]["type"].upper() == "SCC"
    assert cells[0]["kind"] == "secondary"


def test_rates_and_usage():
    s = build_snapshot(NSA_SIGNAL, STATUS, TRAFFIC, MONTH, BASIC, DEVINFO, None)
    # 443457 bytes/s -> 3.55 Mbit/s
    assert abs(s["device"]["dl_mbps"] - 3.55) < 0.01
    assert abs(s["device"]["ul_mbps"] - 0.61) < 0.01
    # 1.2 GB month, 300 MB today (well, CurrentDayUsed bytes -> MB)
    assert abs(s["device"]["month_gb"] - 1.12) < 0.01
    assert abs(s["device"]["today_mb"] - 286.1) < 0.5
