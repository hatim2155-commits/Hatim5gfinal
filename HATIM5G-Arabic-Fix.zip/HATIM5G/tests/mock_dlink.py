"""A minimal mock D-Link LuCI backend for integration tests.

Reproduces the HTTP flow captured from a DWR-2000M:

    GET  /cgi-bin/luci/                                   -> login page + SessionID cookie
    POST /cgi-bin/luci  luci_username=<u>&luci_password=<p>
                                                          -> 302 + sysauth cookie (or 200 login page again)
    GET  /cgi-bin/luci/admin/status/header?status=1&<ts>  -> {"model":..,"project":..}
    GET  /cgi-bin/luci/admin/status/home_poll?status=1&<ts>-> netType, signalStrength, ...
    GET  /cgi-bin/luci/admin/status/get_sim_detail?status=1&<ts>
    GET  /cgi-bin/luci/admin/status/get_band_info?<ts>

Status endpoints require the sysauth cookie (like the real LuCI dispatcher).
"""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Optional

SYS_AUTH = "d6ad45faa9bc28e6b31852a30514f460"
SESSION_ID = "af456a5a9ccac500afb97ba877886d6b8f36f42bdc652b298788835e9a91928d6c4fff3fc0af254684ed3ac60008f28db0e84f1570126aff90a395f5e018bf65"

HEADER = {"model": "DWR-2000M", "project": "RG600L-EU"}

HOME_POLL = {
    "netType": "5G",
    "signalStrength": "MODERATE",
    "wifion": "1",
    "operator": "TUNISIE TELECOM",
    "wanStatusInfo": json.dumps(
        {
            "interface": [
                {
                    "interface": "lan", "up": True, "proto": "static",
                    "ipv4-address": [{"address": "192.168.1.1", "mask": 24}],
                },
                {
                    "interface": "wan", "up": True, "proto": "ql_datacall",
                    "ipv4-address": [{"address": "10.77.221.244", "mask": 29}],
                    "dns-server": ["196.203.82.66", "8.8.4.4"],
                },
            ]
        }
    ),
    "wifion_5g": "1",
    "ssid24G": "MxHTT2G",
    "ssid5G": "MxHTT5G",
    "systeminfo": json.dumps({"localtime": 1786731479, "uptime": 721, "load": [539136, 499616, 302976]}),
    "luciDHCPLeasesInfo": json.dumps({"dhcp_leases": [], "dhcp6_leases": []}),
    "traffic": "219580",
}

def _dup_json_str(*dicts):
    """Build a JSON *string* that keeps duplicate keys, like the real firmware
    emits: the first set of metric keys belongs to the LTE anchor and the
    repeated ones to the 5G NR carrier. A plain dict cannot express this."""
    parts = []
    for d in dicts:
        for k, v in d.items():
            parts.append(json.dumps(k) + ":" + json.dumps(str(v)))
    return "{" + ",".join(parts) + "}"


LTE_READINGS = {
    "rssi": "-87", "rsrp": "-104", "rsrq": "-17", "snr": "2",
    "mcc": "605", "mnc": "02", "operator": "TUNISIE TELECOM",
    "radiomode": "5G(NSA)", "cid": "a7b505", "noBid4G": "a7b50",
    "eNodeB": "a7b5", "plmn": "60502", "tac": "34",
    "pci": "76", "arfcn4G": "1350", "sinr": "2",
}
NR_READINGS = {
    "rssi": "-93", "rsrp": "-103", "rsrq": "-12", "snr": "9",
    "pci": "643", "arfcn5G": "647328", "sinr": "8", "ta": "90",
    "nr_arfcn_nbr": "647328", "nr_sinr_nbr": "-5", "nr_pci_nbr": "644",
    "nr_rsrp_nbr": "-107", "nr_rsrq_nbr": "-17",
    "endc": 1, "network_type": "5G", "band": "78", "bandwidth": "100M",
    "cqi": "15", "band4G": "3", "caBand": "B3+B1/N78",
    "caBandwidth": "20-10-100", "caDL": "QPSK-64QAM-256QAM", "caUL": "64QAM-64QAM-64QAM",
}

SIM_DETAIL = {
    "iccid": "ICCID: 8921602080358069378F",
    "imei": "351108519562447",
    "internet_info": _dup_json_str(LTE_READINGS, NR_READINGS),
}

BAND_INFO = {"endc": "1", "imsi": "IMSI: 605020835806937\n", "dlMcs": "0", "ulMcs": "23"}

ETH_DETAIL = {
    "wanMac": "A2:9F:7A:76:3E:97",
    "wanStatusInfo": json.dumps(
        {
            "interface": [
                {
                    "interface": "lan", "up": True, "proto": "static",
                    "ipv4-address": [{"address": "192.168.1.1", "mask": 24}],
                },
                {
                    "interface": "wan", "up": True, "proto": "ql_datacall",
                    "ipv4-address": [{"address": "10.77.221.244", "mask": 29}],
                    "dns-server": ["196.203.82.66", "8.8.4.4"],
                },
            ]
        }
    ),
    "ethCable": "-1",
    "wanipv6": "",
    "ethType": "DHCP",
}

ENDPOINTS = {
    "header": HEADER,
    "home_poll": HOME_POLL,
    "get_sim_detail": SIM_DETAIL,
    "get_band_info": BAND_INFO,
    "get_eth_detail": ETH_DETAIL,
}


class MockDlinkHandler(BaseHTTPRequestHandler):
    username = "admin"
    password = "testpass"
    traffic = HOME_POLL["traffic"]  # tests can advance the cumulative counter
    _lock = threading.Lock()

    def log_message(self, *args):  # noqa: D102
        pass

    def _send_json(self, body: dict, status: int = 200, extra_headers: Optional[dict[str, str]] = None) -> None:
        data = json.dumps(body).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Content-Length", str(len(data)))
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def _auth_ok(self) -> bool:
        return self.headers.get("Cookie", "").find("sysauth=" + SYS_AUTH) != -1

    def do_GET(self) -> None:  # noqa: N802
        path = self.path.split("?")[0]
        if path == "/cgi-bin/luci/":
            html = "<html><body>D-Link LuCI login page</body></html>"
            data = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Set-Cookie", f"SessionID={SESSION_ID}; Path=/")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if not path.startswith("/cgi-bin/luci/admin/status/"):
            self._send_json({"error": "not found"}, status=404)
            return
        if not self._auth_ok():
            self._send_json({"error": "not authorized"}, status=403)
            return
        endpoint = path.removeprefix("/cgi-bin/luci/admin/status/")
        if endpoint == "home_poll":
            body = dict(HOME_POLL, traffic=MockDlinkHandler.traffic)
        else:
            body = ENDPOINTS.get(endpoint)
        if body is None:
            self._send_json({"error": "no support"}, status=404)
            return
        self._send_json(body)

    def do_POST(self) -> None:  # noqa: N802
        path = self.path.split("?")[0]
        if path != "/cgi-bin/luci":
            self._send_json({"error": "not found"}, status=404)
            return
        length = int(self.headers.get("Content-Length", 0))
        form = self.rfile.read(length).decode("utf-8", "replace")
        import urllib.parse

        params = urllib.parse.parse_qs(form)
        user = (params.get("luci_username") or [""])[0]
        password = (params.get("luci_password") or [""])[0]
        if user == MockDlinkHandler.username and password == MockDlinkHandler.password:
            # LuCI answers the login POST with a 302 to /cgi-bin/luci/ + sysauth
            # cookie. The real device marks it Secure (its LuCI is HTTPS-only);
            # the test mock omits the flag so the cookie is also sent over the
            # plain-HTTP transport the tests use.
            self.send_response(302)
            self.send_header("Location", "/cgi-bin/luci/")
            self.send_header("Set-Cookie", f"sysauth={SYS_AUTH}; path=/cgi-bin/luci/")
            self.send_header("Content-Length", "0")
            self.end_headers()
        else:
            # wrong credentials: login page is served again, no sysauth cookie
            html = "<html><body>login failed</body></html>"
            data = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)


class MockDlink:
    """Context manager that runs the mock D-Link LuCI backend on an ephemeral
    HTTP port (the real device speaks HTTPS; the client is tested with scheme
    http here)."""

    def __init__(self, password: str = "testpass") -> None:
        MockDlinkHandler.password = password
        self._server = ThreadingHTTPServer(("127.0.0.1", 0), MockDlinkHandler)
        self.host = f"127.0.0.1:{self._server.server_address[1]}"
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)

    def __enter__(self) -> "MockDlink":
        self._thread.start()
        return self

    def __exit__(self, *exc) -> None:
        self._server.shutdown()
        self._server.server_close()
        self._thread.join(timeout=3)
