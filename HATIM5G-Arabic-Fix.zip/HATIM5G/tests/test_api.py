"""API tests using FastAPI TestClient in demo mode (no modem needed)."""

import os
import sys
import time
from pathlib import Path

os.environ["SIGNAL_MONITOR_DEMO"] = "1"  # must be set before importing main

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient  # noqa: E402
import pytest  # noqa: E402

import main  # noqa: E402


@pytest.fixture(autouse=True)
def _tmp_data(tmp_path, monkeypatch):
    """Point config + runtime data (best, MP) at temp paths for every test."""
    monkeypatch.setattr(main, "CONFIG_PATH", tmp_path / "config.json")
    monkeypatch.setattr(main, "BEST_PATH", tmp_path / "best.json")
    monkeypatch.setattr(main, "MP_PATH", tmp_path / "mp.json")
    monkeypatch.setattr(main, "REPORTS_PATH", tmp_path / "reports.json")
    # State was constructed at import with the real paths; rebuild against tmp
    main.state = main.State()
    yield


def _client():
    return TestClient(main.app)


def test_status_returns_demo_snapshot():
    with _client() as c:
        # poller is a thread: give it a moment to produce the first snapshot
        data = None
        for _ in range(20):
            r = c.get("/api/status")
            assert r.status_code == 200
            data = r.json()
            if data.get("cells"):
                break
            time.sleep(0.2)
        assert data is not None and data["cells"], "poller never produced a snapshot"
        assert data["source"] == "demo"
        assert data["device"]["name"]
        rats = {c_["rat"] for c_ in data["cells"]}
        assert rats >= {"LTE", "NR"}


def test_status_schema():
    with _client() as c:
        data = c.get("/api/status").json()
        cell = next(x for x in data["cells"] if x["kind"] == "primary")
        m = cell["metrics"]["rsrp"]
        assert m["min"] <= m["max"]
        assert 0 <= m["pct"] <= 100
        assert m["quality"] in ("excellent", "good", "fair", "poor")
        assert m["segments"]  # colored band segments present


def test_config_vendor_and_scheme_roundtrip():
    """vendor + scheme survive a save/load cycle (D-Link deployment path)."""
    main.save_config({
        "host": "192.168.1.1", "username": "admin", "password": "x",
        "interval_s": 1.0, "vendor": "dlink", "scheme": "http",
    })
    cfg = main.load_config()
    assert cfg["vendor"] == "dlink"
    assert cfg["scheme"] == "http"
    assert cfg["host"] == "192.168.1.1"
    assert cfg["interval_s"] == 1.0


def test_config_endpoint_persists_vendor_and_scheme():
    """POST /api/config stores vendor + scheme and GET /api/config returns them."""
    with _client() as c:
        r = c.post("/api/config", json={
            "host": "192.168.1.1", "username": "admin", "password": "x",
            "interval_s": 1.0, "vendor": "dlink", "scheme": "http",
        })
        assert r.status_code == 200
        cfg = c.get("/api/config").json()
        assert cfg["vendor"] == "dlink"
        assert cfg["scheme"] == "http"
        assert cfg["host"] == "192.168.1.1"


def test_history_schema():
    with _client() as c:
        for _ in range(10):
            h = c.get("/api/history?limit=5").json()
            if h:
                break
            time.sleep(0.2)
        assert h, "no history samples yet"
        sample = h[-1]
        assert "ts" in sample and "cells" in sample
        for cell in sample["cells"]:
            assert cell["key"], "history cells must carry a stable key"
            assert "kind" in cell and "rat" in cell


def test_raw_endpoint():
    with _client() as c:
        data = None
        for _ in range(20):
            r = c.get("/api/raw")
            assert r.status_code == 200
            data = r.json()
            if "signal" in data:
                break
            time.sleep(0.2)
        assert data and "signal" in data, "raw endpoint never returned modem data"
        assert data["signal"]["nrrsrp"]  # demo NR field present


def _wait_for_snapshot(c):
    for _ in range(30):
        data = c.get("/api/status").json()
        if data.get("cells"):
            return data
        time.sleep(0.2)
    raise AssertionError("poller never produced a snapshot")


def test_best_tracks_max():
    with _client() as c:
        snap = _wait_for_snapshot(c)
        best = c.get("/api/best").json()
        assert best, "best never populated"
        # for every metric present in the snapshot, best >= any live value
        for cell in snap["cells"]:
            for key, m in cell["metrics"].items():
                if m["value"] is not None:
                    assert best[key]["value"] >= m["value"], f"{key} best below live value"
        assert "rsrp" in best and "ts" in best["rsrp"] and "cell" in best["rsrp"]
        # best provenance now carries serving-cell identity
        assert "band" in best["rsrp"]
        assert "frequency_mhz" in best["rsrp"]
        assert "pci" in best["rsrp"]
        assert "ca" in best["rsrp"]  # carrier aggregation on/off


def test_best_clear():
    with _client() as c:
        _wait_for_snapshot(c)
        assert c.get("/api/best").json()
        r = c.post("/api/best/clear")
        assert r.status_code == 200
        assert c.get("/api/best").json() == {}


def test_mp_capture_list_clear():
    with _client() as c:
        _wait_for_snapshot(c)
        r = c.post("/api/mp", json={"note": "window spot"})
        assert r.status_code == 200
        entry = r.json()
        assert entry["id"] and entry["ts"]
        assert entry["note"] == "window spot"
        assert entry["cells"], "MP should snapshot the current cells"
        assert "best" in entry and entry["best"], "MP should summarize best per metric"
        assert "value" in entry["best"]["rsrp"]
        # serving-cell band/frequency/pci + neighbour tower counts
        assert "summary" in entry
        assert entry["summary"]["neighbor_4g"] >= 0
        assert entry["summary"]["neighbor_5g"] >= 0
        assert entry["summary"]["band"] is not None
        assert entry["summary"]["pci"] is not None
        assert entry["summary"]["frequency_mhz"] is not None
        assert "carrier_aggregations" in entry["summary"]  # CA cells (if reported)

        c.post("/api/mp", json={"note": "garden"})
        lst = c.get("/api/mp").json()
        assert len(lst) == 2
        assert lst[-1]["note"] == "garden"

        r = c.post("/api/mp/clear")
        assert r.status_code == 200
        assert c.get("/api/mp").json() == []


def test_mp_smart_capture_keeps_whole_best_snapshot():
    """Smart capture samples 10x over 10s and stores one self-consistent
    snapshot (marked smart) rather than merging values per metric."""
    with _client() as c:
        _wait_for_snapshot(c)
        r = c.post("/api/mp", json={"note": "smart spot", "smart": True, "smart_samples": 10, "smart_interval_s": 0.1})
        assert r.status_code == 200
        entry = r.json()
        assert entry["smart"] is True
        assert "score" in entry and 0 <= entry["score"] <= 1
        assert entry["cells"], "smart capture must snapshot cells"
        # every metric value in a cell is one reading (no cross-sample merge)
        for cell in entry["cells"]:
            for m in cell["metrics"].values():
                assert "value" in m


def test_smart_capture_ignores_transient_serving_cell():
    """CRITICAL: smart capture must NOT pick a momentary different serving
    cell that scores highest. It must pick the best sample from the dominant
    (stable) serving cell so the point reflects the sustained 10s window."""
    with _client() as c:
        _wait_for_snapshot(c)
        # Build 10 fake snapshots: 8 on the stable cell (mediocre signal),
        # 2 on a transient different cell with a much higher score.
        def mk_snap(pci, band, rsrp):
            from quality import render_metric
            cell = {
                "kind": "primary", "rat": "LTE", "title": "Primary",
                "identity": {"pci": pci, "band": band, "dl_freq_mhz": 2650.0, "cell_id": "C1", "arfcn": "3050"},
                "metrics": {"rsrp": render_metric("rsrp", rsrp)},
            }
            return {"ts": time.time(), "cells": [cell], "device": {}}

        stable = [mk_snap("427", "7", -95.0) for _ in range(8)]   # -95 dBm
        transient = [mk_snap("999", "3", -40.0) for _ in range(2)]  # spikes much higher

        # feed the poller state so get_snapshot() alternates: mostly stable, 2 transient
        class FakeState:
            def __init__(self, seq):
                self.seq = seq
                self.i = 0
            def get_snapshot(self):
                s = self.seq[self.i % len(self.seq)]
                self.i += 1
                return s

        main.state.get_snapshot = FakeState(stable + transient).get_snapshot
        r = c.post("/api/mp", json={"note": "stab", "smart": True, "smart_samples": 10, "smart_interval_s": 0.1})
        entry = r.json()
        assert entry["smart"] is True
        # chosen snapshot must be the stable cell, NOT the transient high one
        chosen_pci = entry["cells"][0]["identity"]["pci"]
        assert chosen_pci == "427", f"picked transient cell {chosen_pci}"
        assert entry["sampling"]["samples"] == 10
        assert entry["sampling"]["stable_samples"] >= 8
        # the chosen value is from the stable cell, not the -40 spike
        assert entry["cells"][0]["metrics"]["rsrp"]["value"] < -80


def test_mp_export_markdown():
    with _client() as c:
        _wait_for_snapshot(c)
        c.post("/api/mp", json={"note": "window"})
        r = c.get("/api/mp/export?fmt=md")
        assert r.status_code == 200
        text = r.text
        assert "Measurement Reports" in text
        assert "window" in text
        assert "Serving cell" in text
        assert "| RSRP |" in text or "RSRP" in text
        r2 = c.get("/api/mp/export?fmt=txt")
        assert r2.status_code == 200
        assert "Measurement Reports" in r2.text


def test_reports_crud():
    """Create/open/clear/delete reports; captures go to the active report."""
    with _client() as c:
        _wait_for_snapshot(c)

        # start with a migrated default report
        reports = c.get("/api/reports").json()
        assert len(reports) == 1
        assert reports[0]["name"] == "Default report"

        # create a new report -> becomes active
        r = c.post("/api/reports", json={"name": "Garden"})
        assert r.status_code == 200
        new_id = r.json()["id"]
        active = c.get("/api/reports/active").json()
        assert active["id"] == new_id

        # capture into the active (Garden) report
        c.post("/api/mp", json={"note": "garden spot"})
        assert len(c.get("/api/mp").json()) == 1

        # open the default report and capture there
        default_id = reports[0]["id"]
        c.post(f"/api/reports/{default_id}/open")
        c.post("/api/mp", json={"note": "default spot"})
        assert [m["note"] for m in c.get("/api/mp").json()] == ["default spot"]

        # export both reports into one markdown doc
        ids = ",".join([default_id, new_id])
        r = c.get(f"/api/mp/export?fmt=md&report_ids={ids}")
        assert r.status_code == 200
        assert "Report 1" in r.text and "Report 2" in r.text
        assert "garden spot" in r.text and "default spot" in r.text

        # clear + delete
        c.post(f"/api/reports/{default_id}/clear")
        assert c.get("/api/reports").json()[0]["mp_count"] == 0
        r = c.delete(f"/api/reports/{new_id}")
        assert r.status_code == 200
        assert len(c.get("/api/reports").json()) == 1


def test_mp_edit_note():
    with _client() as c:
        _wait_for_snapshot(c)
        r = c.post("/api/mp", json={"note": "before"})
        mp_id = r.json()["id"]
        r = c.patch(f"/api/mp/{mp_id}/note", json={"note": "after edit"})
        assert r.status_code == 200
        assert r.json()["note"] == "after edit"
        # persisted in the list
        lst = c.get("/api/mp").json()
        assert lst[-1]["id"] == mp_id
        assert lst[-1]["note"] == "after edit"
        # unknown id -> 404
        r = c.patch("/api/mp/nonexistent/note", json={"note": "x"})
        assert r.status_code == 404


def test_mp_requires_snapshot(monkeypatch):
    """Capture before any data -> 400."""
    monkeypatch.setattr(main.state, "get_snapshot", lambda: None)
    with _client() as c:
        r = c.post("/api/mp", json={"note": "x"})
        assert r.status_code == 400
        assert "nothing to capture" in r.json()["detail"]


def test_config_get_masks_password():
    with _client() as c:
        r = c.get("/api/config")
        assert r.status_code == 200
        body = r.json()
        assert "password" not in body
        assert "host" in body


def test_config_post_requires_host():
    with _client() as c:
        r = c.post("/api/config", json={"host": "", "username": "admin", "password": "", "interval_s": 2})
        assert r.status_code == 400


def test_config_post_saves():
    with _client() as c:
        r = c.post(
            "/api/config",
            json={"host": "192.168.8.1", "username": "admin", "password": "secret", "interval_s": 1.5},
        )
        assert r.status_code == 200
        assert r.json() == {"ok": True}
        body = c.get("/api/config").json()
        assert body["host"] == "192.168.8.1"
        assert body["interval_s"] == 1.5
        assert "password" not in body


def test_index_serves_page():
    with _client() as c:
        r = c.get("/")
        assert r.status_code == 200
        assert "5G Signal Monitor" in r.text
        assert "configModal" in r.text
