"""A minimal mock Huawei HiLink modem server for integration tests.

Implements just enough of the HiLink HTTP+XML protocol for huawei-lte-api's
login flow and the endpoints this app polls:

    GET  /                        -> HTML (no csrf meta; token endpoint fallback)
    GET  /api/webserver/token     -> <response><token>..</token></response>
    GET  /api/user/state-login    -> <response><State>-1|0</State><password_type>0</password_type></response>
    POST /api/user/login          -> <response>OK</response> or <error>...</error>
    POST /api/user/logout         -> <response>OK</response>
    GET  /api/<device|monitoring|net>/... -> <response><fields/></response>

The signal payload mirrors a real 5G CPE (NSA: LTE anchor + NR carrier).
"""

from __future__ import annotations

import base64
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Optional
from xml.sax.saxutils import escape

TOKEN = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"

SIGNAL_XML = """<response>
  <mode>7</mode>
  <plmn>65510</plmn>
  <pci>427</pci>
  <cell_id>0x1F3A92C4</cell_id>
  <band>7</band>
  <earfcn>DL:3050 UL:21050</earfcn>
  <dlfrequency>2650000kHz</dlfrequency>
  <ulfrequency>2530000kHz</ulfrequency>
  <dlbandwidth>20MHz</dlbandwidth>
  <ulbandwidth>20MHz</ulbandwidth>
  <rsrp>-80dBm</rsrp>
  <rsrq>-5.0dB</rsrq>
  <sinr>8dB</sinr>
  <rssi>-54dBm</rssi>
  <cqi0>3</cqi0>
  <txpower>PPusch:0dBm PPucch:0dBm PSrs:0dBm PPrach:0dBm</txpower>
  <dl_mcs>mcsDownCarrier1Code0:29</dl_mcs>
  <scc_pci>0x20</scc_pci>
  <nrrsrp>-79dBm</nrrsrp>
  <nrrsrq>-10.0dB</nrrsrq>
  <nrsinr>15dB</nrsinr>
  <nrearfcn>DL:643660 UL:643660</nrearfcn>
  <nrdlfreq>3654900kHz</nrdlfreq>
  <nrulfreq>3654900kHz</nrulfreq>
  <nrdlbandwidth>90MHz</nrdlbandwidth>
  <nrulbandwidth>90MHz</nrulbandwidth>
  <nrcqi0>32639</nrcqi0>
  <nrdlmcs>NRmcsDownCarrier1Code0:27</nrdlmcs>
  <nrtxpower>PPusch:12dBm PPucch:-4dBm PSrs:0dBm PPrach:-1dBm</nrtxpower>
  <nrrank>4</nrrank>
</response>"""

STATUS_XML = "<response><SignalIconNr>4</SignalIconNr></response>"

SA_SIGNAL_XML = """<response>
  <mode>102</mode>
  <plmn>65510</plmn>
  <nrpci>723</nrpci>
  <nrcellid>0x2F4B81D5</nrcellid>
  <nrband>n78</nrband>
  <nrearfcn>DL:643660 UL:643660</nrearfcn>
  <nrdlfreq>3654900kHz</nrdlfreq>
  <nrulfreq>3654900kHz</nrulfreq>
  <nrdlbandwidth>100MHz</nrdlbandwidth>
  <nrulbandwidth>100MHz</nrulbandwidth>
  <nrrsrp>-72dBm</nrrsrp>
  <nrrsrq>-8.0dB</nrrsrq>
  <nrsinr>22dB</nrsinr>
  <nrcqi0>15</nrcqi0>
  <nrdlmcs>NRmcsDownCarrier1Code0:28</nrdlmcs>
  <nrtxpower>PPusch:11dBm PPucch:-3dBm PSrs:0dBm PPrach:0dBm</nrtxpower>
  <nrrank>4</nrrank>
</response>"""

TRAFFIC_XML = """<response>
  <CurrentDownloadRate>443457</CurrentDownloadRate>
  <CurrentUploadRate>76419</CurrentUploadRate>
</response>"""
MONTH_XML = """<response>
  <CurrentMonthDownload>1000000000</CurrentMonthDownload>
  <CurrentMonthUpload>200000000</CurrentMonthUpload>
  <CurrentDayUsed>300000000</CurrentDayUsed>
</response>"""
BASIC_XML = "<response><devicename>H153-381</devicename></response>"
DEVICE_INFO_XML = """<response>
  <DeviceName>H153-381</DeviceName>
  <UpTime>5344844</UpTime>
  <WanIPAddress>192.168.0.1</WanIPAddress>
</response>"""
CELL_INFO_XML = """<response>
  <NrCellInfo>
    <item><pci>723</pci><arfcn>643660</arfcn><rsrp>-89dBm</rsrp><rsrq>-11.0dB</rsrq><sinr>9dB</sinr></item>
  </NrCellInfo>
  <LteCellInfo>
    <item><pci>77</pci><arfcn>3050</arfcn><rsrp>-95dBm</rsrp><rsrq>-12.0dB</rsrq><sinr>6dB</sinr><rssi>-62dBm</rssi></item>
  </LteCellInfo>
</response>"""

ENDPOINTS = {
    "device/signal": SIGNAL_XML,
    "monitoring/status": STATUS_XML,
    "monitoring/traffic-statistics": TRAFFIC_XML,
    "monitoring/month_statistics": MONTH_XML,
    "device/basic_information": BASIC_XML,
    "device/information": DEVICE_INFO_XML,
    "net/cell-info": CELL_INFO_XML,
}


class MockModemHandler(BaseHTTPRequestHandler):
    username = "admin"
    password = "testpass"
    logged_in = False
    sa_mode = False
    _lock = threading.Lock()

    # silence default logging
    def log_message(self, *args):  # noqa: D102
        pass

    def _csrf_ok(self) -> bool:
        """Real HiLink modems require the request verification token on API
        calls; enforce it so the library's token handling is really tested."""
        return self.headers.get("__RequestVerificationToken") == TOKEN

    def _send_xml(self, body: str, status: int = 200, extra_headers: Optional[dict[str, str]] = None) -> None:
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/xml")
        self.send_header("Content-Length", str(len(data)))
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def _send_error(self, code: int, message: str) -> None:
        self._send_xml(f"<error><code>{code}</code><message>{escape(message)}</message></error>")

    def do_GET(self) -> None:  # noqa: N802
        path = self.path.split("?")[0]
        if path == "/":
            html = "<html><head></head><body>mock modem</body></html>"
            data = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Set-Cookie", "SessionID=mock123; Path=/")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if path == "/api/webserver/token":
            self._send_xml(f"<response><token>{TOKEN}</token></response>")
            return

        if not self._csrf_ok():
            self._send_error(125002, "Session error")
            return

        if path == "/api/user/state-login":
            state = "0" if MockModemHandler.logged_in else "-1"
            self._send_xml(f"<response><State>{state}</State><password_type>0</password_type></response>")
            return

        endpoint = path.removeprefix("/api/")
        body = ENDPOINTS.get(endpoint)
        if endpoint == "device/signal" and MockModemHandler.sa_mode:
            body = SA_SIGNAL_XML
        if body is None:
            self._send_error(100002, "No support")
            return
        if endpoint.startswith(("device/", "monitoring/", "net/")) and not MockModemHandler.logged_in:
            self._send_error(100003, "No rights (needs login)")
            return
        self._send_xml(body)

    def do_POST(self) -> None:  # noqa: N802
        path = self.path.split("?")[0]
        if not self._csrf_ok():
            self._send_error(125002, "Session error")
            return
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8", "replace")

        if path == "/api/user/login":
            # <request><Username>..</Username><Password>base64</Password><password_type>0</password_type></request>
            username = ""
            password = ""
            for tag in ("Username", "Password"):
                marker = f"<{tag}>"
                end = f"</{tag}>"
                start = body.find(marker)
                if start != -1:
                    endi = body.find(end, start)
                    value = body[start + len(marker):endi]
                    if tag == "Username":
                        username = value
                    else:
                        password = base64.b64decode(value).decode("utf-8", "replace")
            with MockModemHandler._lock:
                if username == MockModemHandler.username and password == MockModemHandler.password:
                    MockModemHandler.logged_in = True
                    self._send_xml("<response>OK</response>", extra_headers={"__RequestVerificationToken": TOKEN})
                else:
                    MockModemHandler.logged_in = False
                    self._send_error(108006, "Username or password wrong")
            return

        if path == "/api/user/logout":
            with MockModemHandler._lock:
                MockModemHandler.logged_in = False
            self._send_xml("<response>OK</response>")
            return

        self._send_error(100002, "No support")


class MockModem:
    """Context manager that runs the mock modem on an ephemeral port."""

    def __init__(self, password: str = "testpass", sa_mode: bool = False) -> None:
        MockModemHandler.password = password
        MockModemHandler.logged_in = False
        MockModemHandler.sa_mode = sa_mode
        self._server = ThreadingHTTPServer(("127.0.0.1", 0), MockModemHandler)
        self.host = f"127.0.0.1:{self._server.server_address[1]}"
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)

    def __enter__(self) -> "MockModem":
        self._thread.start()
        return self

    def __exit__(self, *exc) -> None:
        self._server.shutdown()
        self._server.server_close()
        self._thread.join(timeout=3)
