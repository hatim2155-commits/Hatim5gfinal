"""Signal Monitor - FastAPI backend (Huawei HiLink + D-Link LuCI).

Run:
    python main.py                 # live modem, reads/creates config.json
    python main.py --demo          # simulated snapshot, no modem needed
    python main.py --host 0.0.0.0  # expose on LAN (password travels over HTTP!)

Vendor is chosen in config.json / the Configure modal:
    "vendor": "huawei"  (default, uses huawei-lte-api)
    "vendor": "dlink"   (D-Link LuCI JSON backend, see dlink.py)

Endpoints:
    GET  /api/status               cached snapshot (instant)
    GET  /api/history?limit=N      sparkline history (slim, stable cell keys)
    GET  /api/raw                  last raw modem responses (debugging)
    GET  /api/best                 lifetime best value per metric
    POST /api/best/clear           reset the lifetime best
    GET  /api/reports              list of reports (id, name, mp_count)
    POST /api/reports              create a report (and make it active)
    DELETE /api/reports/{id}       delete a report
    POST /api/reports/{id}/clear   clear all MPs in a report
    POST /api/reports/{id}/open    open (make active) a report
    GET  /api/mp                   captured measurement points of the active report
    POST /api/mp                   capture current measurements (with note, optional smart mode)
    POST /api/mp/clear             delete all measurement points of the active report
    GET  /api/mp/export            export one or more reports as a single .md or .txt
    GET  /api/config               current config (no password)
    POST /api/config               validate + save config, restart poller
    GET  /                         the single page
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import os
import random
import threading
import time
from collections import deque
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Deque, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

import modem
from quality import render_metric

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("signal-monitor")

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
CONFIG_PATH = BASE_DIR / "config.json"
BEST_PATH = BASE_DIR / "best.json"
MP_PATH = BASE_DIR / "mp.json"
REPORTS_PATH = BASE_DIR / "reports.json"

DEFAULT_CONFIG = {
    "host": "192.168.1.1",
    "username": "admin",
    "password": "admin",
    "interval_s": 1.0,
    "vendor": "huawei",
    # optional transport override for D-Link ("http"/"https"); "" = vendor default
    "scheme": "",
}

DEFAULT_REPORT_NAME = "Default report"

HISTORY_MAX = 300


# --------------------------------------------------------------------------
# JSON persistence helpers
# --------------------------------------------------------------------------

def _load_json(path: Path, default: Any) -> Any:
    try:
        if path.exists():
            with open(path, "r", encoding="utf-8") as fh:
                return json.load(fh)
    except Exception as exc:
        log.warning("could not read %s: %s", path.name, exc)
    return default


def _save_json(path: Path, data: Any) -> None:
    try:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
    except Exception as exc:
        log.warning("could not write %s: %s", path.name, exc)


# --------------------------------------------------------------------------
# Config persistence
# --------------------------------------------------------------------------

def load_config() -> dict[str, Any]:
    cfg = dict(DEFAULT_CONFIG)
    try:
        if CONFIG_PATH.exists():
            with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
                saved = json.load(fh)
                cfg.update({k: saved[k] for k in cfg if k in saved})
    except Exception as exc:
        log.warning("could not read config: %s", exc)
    return cfg


def save_config(cfg: dict[str, Any]) -> None:
    with open(CONFIG_PATH, "w", encoding="utf-8") as fh:
        json.dump(cfg, fh, indent=2)
    try:
        os.chmod(CONFIG_PATH, 0o600)  # ignore failure on platforms without chmod
    except OSError:
        pass


# --------------------------------------------------------------------------
# Shared state
# --------------------------------------------------------------------------

class State:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.snapshot: Optional[dict[str, Any]] = None
        self.history: Deque[dict[str, Any]] = deque(maxlen=HISTORY_MAX)
        self.last_raw: Optional[dict[str, Any]] = None
        self.last_error: Optional[str] = None
        self.best: dict[str, Any] = _load_json(BEST_PATH, {})
        self.reports: list[dict[str, Any]] = _load_json(REPORTS_PATH, None)
        self.active_report_id: Optional[str] = None
        self._init_reports()

    def publish(self, snapshot: dict[str, Any]) -> None:
        raw = snapshot.pop("raw", None)
        with self.lock:
            self.snapshot = snapshot
            self.last_raw = raw
            self.history.append(slim_snapshot(snapshot))
            self._update_best(snapshot)

    def _update_best(self, snapshot: dict[str, Any]) -> None:
        """Track the best (max) value ever seen for each metric, with provenance."""
        ts = snapshot.get("ts") or time.time()
        changed = False
        ca_active = _ca_active(snapshot)
        for cell in snapshot.get("cells", []):
            label = f"{cell.get('title') or cell.get('rat')} · {cell.get('rat')}"
            ident = cell.get("identity") or {}
            for key, metric in cell.get("metrics", {}).items():
                value = metric.get("value")
                if value is None:
                    continue
                current = self.best.get(key)
                if current is None or value > current.get("value", float("-inf")):
                    self.best[key] = {
                        "value": value,
                        "ts": ts,
                        "cell": label,
                        "unit": metric.get("unit"),
                        "quality": metric.get("quality"),
                        "band": ident.get("band"),
                        "frequency_mhz": ident.get("dl_freq_mhz"),
                        "pci": ident.get("pci"),
                        "ca": ca_active,
                    }
                    changed = True
        if changed:
            _save_json(BEST_PATH, self.best)

    def get_snapshot(self) -> Optional[dict[str, Any]]:
        with self.lock:
            return self.snapshot

    def get_history(self, limit: int) -> list[dict[str, Any]]:
        with self.lock:
            items = list(self.history)
        return items[-limit:]

    def get_best(self) -> dict[str, Any]:
        with self.lock:
            return dict(self.best)

    def clear_best(self) -> None:
        with self.lock:
            self.best = {}
            _save_json(BEST_PATH, self.best)

    # ------------------------------------------------------- reports storage

    def _init_reports(self) -> None:
        """Load reports, migrating the legacy single MP list if needed."""
        if self.reports is None:
            # migrate legacy mp.json into a default report
            legacy = _load_json(MP_PATH, [])
            self.reports = []
            if legacy:
                self.reports.append(_new_report(DEFAULT_REPORT_NAME, mps=legacy))
            if not self.reports:
                self.reports.append(_new_report(DEFAULT_REPORT_NAME))
            self._save_reports()
        if not self.reports:
            self.reports.append(_new_report(DEFAULT_REPORT_NAME))
        # pick a valid active report
        if not any(r.get("id") == self.active_report_id for r in self.reports):
            self.active_report_id = self.reports[0]["id"]

    def _save_reports(self) -> None:
        _save_json(REPORTS_PATH, self.reports)

    def get_reports(self) -> list[dict[str, Any]]:
        """Light list of reports (no measurement points in the payload)."""
        with self.lock:
            return [
                {
                    "id": r["id"],
                    "name": r.get("name", DEFAULT_REPORT_NAME),
                    "created": r.get("created"),
                    "updated": r.get("updated"),
                    "mp_count": len(r.get("mps", [])),
                }
                for r in self.reports
            ]

    def get_active_report_id(self) -> Optional[str]:
        with self.lock:
            return self.active_report_id

    def _find_report(self, report_id: Optional[str]) -> Optional[dict[str, Any]]:
        rid = report_id or self.active_report_id
        for r in self.reports:
            if r.get("id") == rid:
                return r
        return None

    def create_report(self, name: str = "") -> Optional[dict[str, Any]]:
        """Create a new empty report and make it active."""
        import uuid

        name = (name or "").strip() or DEFAULT_REPORT_NAME
        with self.lock:
            report = _new_report(name)
            self.reports.append(report)
            self.active_report_id = report["id"]
            self._save_reports()
            return self._light_report(report)

    def delete_report(self, report_id: str) -> bool:
        with self.lock:
            before = len(self.reports)
            self.reports = [r for r in self.reports if r.get("id") != report_id]
            if len(self.reports) == before:
                return False
            if not self.reports:
                self.reports.append(_new_report(DEFAULT_REPORT_NAME))
            if not any(r.get("id") == self.active_report_id for r in self.reports):
                self.active_report_id = self.reports[0]["id"]
            self._save_reports()
            return True

    def clear_report(self, report_id: str) -> bool:
        with self.lock:
            report = self._find_report(report_id)
            if report is None:
                return False
            report["mps"] = []
            report["updated"] = time.time()
            self._save_reports()
            return True

    def open_report(self, report_id: str) -> bool:
        with self.lock:
            if not any(r.get("id") == report_id for r in self.reports):
                return False
            self.active_report_id = report_id
            return True

    @staticmethod
    def _light_report(report: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": report["id"],
            "name": report.get("name", DEFAULT_REPORT_NAME),
            "created": report.get("created"),
            "updated": report.get("updated"),
            "mp_count": len(report.get("mps", [])),
        }

    # ------------------------------------------------------- measurement points

    def get_mp(self, report_id: Optional[str] = None) -> list[dict[str, Any]]:
        """Measurement points of a report (active by default), newest last."""
        with self.lock:
            report = self._find_report(report_id)
            if report is None:
                return []
            return list(report.get("mps", []))

    def capture_mp(
        self,
        note: str = "",
        smart: bool = False,
        smart_samples: int = 10,
        smart_interval_s: float = 1.0,
        report_id: Optional[str] = None,
    ) -> Optional[dict[str, Any]]:
        """Capture the current measurements into a report (active by default).

        With smart=True the live snapshot is sampled every `smart_interval_s`
        seconds for `smart_samples` samples and the single best snapshot (by
        overall serving-cell signal) is kept. We pick one whole snapshot rather
        than merging the best value from each cell/sample, which would combine
        readings that were never measured together (false data).
        """
        import uuid

        sample_info: dict[str, Any] = {}
        if smart:
            result = self._smart_sample(smart_samples, smart_interval_s)
            snap = result["snapshot"]
            score = result["score"]
            sample_info = {
                "samples": result["samples"],
                "stable_samples": result["stable"],
            }
        else:
            snap = self.get_snapshot()
            score = _mp_score(snap)

        with self.lock:
            report = self._find_report(report_id)
            if report is None:
                return None
            entry: dict[str, Any] = {
                "id": uuid.uuid4().hex[:8],
                "ts": (snap or {}).get("ts") or time.time(),
                "note": (note or "").strip(),
                "device": (snap or {}).get("device", {}),
                "cells": _mp_cells(snap or {}),
                "smart": smart,
                "score": round(score, 4),
            }
            if sample_info:
                entry["sampling"] = sample_info
            entry["summary"] = _mp_summary(entry["cells"])
            entry["best"] = _mp_best(entry["cells"])
            report.setdefault("mps", []).append(entry)
            report["updated"] = time.time()
            self._save_reports()
            return entry

    def _smart_sample(self, samples: int, interval_s: float) -> dict[str, Any]:
        """Sample the live snapshot every `interval_s` seconds over the window
        and return the single best-scoring snapshot that belongs to the
        *dominant* serving cell, plus its score and sampling transparency.

        Picking the absolute best snapshot is not safe: a brief lock onto a
        different serving cell or a transient spike can score highest yet never
        reflect the sustained conditions of the window. So we keep only samples
        whose serving-cell identity (band/PCI/frequency) is the dominant one
        seen across the window, then choose the best within that stable cell.
        """
        scored: list[tuple[float, dict[str, Any]]] = []
        for i in range(samples):
            snap = self.get_snapshot()
            if snap is not None and snap.get("cells"):
                scored.append((_mp_score(snap), snap))
            if i < samples - 1:
                time.sleep(interval_s)

        if not scored:
            return {"snapshot": None, "score": 0.0, "samples": samples, "stable": 0}

        # group samples by serving-cell signature
        groups: dict[str, list[tuple[float, dict[str, Any]]]] = {}
        sig_counts: dict[str, int] = {}
        for score, snap in scored:
            sig = _serving_signature(snap)
            groups.setdefault(sig, []).append((score, snap))
            sig_counts[sig] = sig_counts.get(sig, 0) + 1

        # dominant signature = most samples (tie -> highest summed score)
        def group_score(sig: str) -> float:
            return sum(s for s, _ in groups[sig])

        dominant = max(groups, key=lambda s: (sig_counts[s], group_score(s)))
        best = max(groups[dominant], key=lambda x: x[0])
        return {
            "snapshot": best[1],
            "score": best[0],
            "samples": len(scored),
            "stable": sig_counts[dominant],
        }

    def clear_mp(self, report_id: Optional[str] = None) -> None:
        """Clear the measurement points of a report (active by default)."""
        with self.lock:
            report = self._find_report(report_id)
            if report is None:
                return
            report["mps"] = []
            report["updated"] = time.time()
            self._save_reports()

    def update_mp_note(self, mp_id: str, note: str, report_id: Optional[str] = None) -> Optional[dict[str, Any]]:
        """Update the note/comment on an existing measurement point."""
        note = (note or "").strip()
        with self.lock:
            report = self._find_report(report_id)
            if report is None:
                return None
            for entry in report.get("mps", []):
                if entry.get("id") == mp_id:
                    entry["note"] = note
                    report["updated"] = time.time()
                    self._save_reports()
                    return entry
        return None


def _new_report(name: str, mps: Optional[list[dict[str, Any]]] = None) -> dict[str, Any]:
    """Create a new report dict holding a set of measurement points."""
    import uuid

    now = time.time()
    return {
        "id": uuid.uuid4().hex[:8],
        "name": (name or "").strip() or DEFAULT_REPORT_NAME,
        "created": now,
        "updated": now,
        "mps": list(mps) if mps else [],
    }


def _mp_cells(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    """Compact cell view for a measurement point."""
    out = []
    for cell in snapshot.get("cells", []):
        identity = cell.get("identity") or {}
        metrics = {
            k: {"value": m.get("value"), "unit": m.get("unit"), "quality": m.get("quality")}
            for k, m in (cell.get("metrics") or {}).items()
        }
        out.append(
            {
                "kind": cell.get("kind"),
                "rat": cell.get("rat"),
                "title": cell.get("title"),
                "identity": {k: identity[k] for k in ("pci", "band", "arfcn", "type", "dl_freq_mhz", "dl_bandwidth_mhz") if identity.get(k)},
                "metrics": metrics,
            }
        )
    return out


def _mp_best(cells: list[dict[str, Any]]) -> dict[str, Any]:
    """Best (max) value per metric across a measurement point's cells."""
    best: dict[str, Any] = {}
    for cell in cells:
        for key, metric in cell.get("metrics", {}).items():
            value = metric.get("value")
            if value is None:
                continue
            if key not in best or value > best[key].get("value", float("-inf")):
                best[key] = {
                    "value": value,
                    "unit": metric.get("unit"),
                    "quality": metric.get("quality"),
                    "cell": f"{cell.get('title') or cell.get('rat')} · {cell.get('rat')}",
                }
    return best


def render_mp_markdown(mp_list: list[dict[str, Any]]) -> str:
    """Render the measurement-point report as readable Markdown that is both
    human-friendly and easy for an LLM to parse (deterministic sections)."""
    lines: list[str] = []
    lines.append("# 5G Signal Monitor — Measurement Points Report")
    lines.append("")
    lines.append(f"- Points: **{len(mp_list)}**")
    lines.append("")
    if not mp_list:
        lines.append("_No measurement points captured yet._")
        return "\n".join(lines)

    for i, mp in enumerate(mp_list, 1):
        lines.append("---")
        lines.append("")
        lines.append(f"## Point {i} — {mp.get('note') or '(no note)'}")
        lines.append("")
        ts = mp.get("ts")
        if ts:
            try:
                import datetime as _dt

                lines.append(f"- **Time**: {_dt.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')}")
            except Exception:
                lines.append(f"- **Time**: {ts}")
        lines.append(f"- **Mode**: {mp.get('smart') and 'Smart (best of samples)' or 'Instant'}")
        lines.append(f"- **Score**: {mp.get('score')}")
        sampling = mp.get("sampling")
        if sampling:
            lines.append(
                f"- **Sampling**: {sampling.get('samples')} samples, "
                f"{sampling.get('stable_samples')} on the stable serving cell"
            )
        dev = mp.get("device") or {}
        lines.append(f"- **Device**: {dev.get('name')} · {dev.get('mode_label')} · {dev.get('operator')}")
        lines.append("")

        summary = mp.get("summary") or {}
        lines.append("### Serving cell")
        lines.append("")
        lines.append(
            "| Metric | Value |"
        )
        lines.append("| --- | --- |")
        lines.append(f"| Band | {summary.get('band') or '—'} |")
        lines.append(
            f"| Frequency | {_fmt_mhz(summary.get('frequency_mhz'))} |"
        )
        lines.append(f"| PCI | {summary.get('pci') or '—'} |")
        lines.append(f"| Neighbour 4G towers | {summary.get('neighbor_4g', 0)} |")
        lines.append(f"| Neighbour 5G towers | {summary.get('neighbor_5g', 0)} |")
        lines.append("")

        cags = summary.get("carrier_aggregations") or []
        if cags:
            lines.append("### Carrier aggregation")
            lines.append("")
            lines.append("| RAT | Band | Freq | EARFCN | PCI |")
            lines.append("| --- | --- | --- | --- | --- |")
            for ca in cags:
                lines.append(
                    f"| {ca.get('rat') or '—'} | {ca.get('band') or '—'} | "
                    f"{_fmt_mhz(ca.get('frequency_mhz'))} | {ca.get('arfcn') or '—'} | {ca.get('pci') or '—'} |"
                )
            lines.append("")

        cells = mp.get("cells") or []
        if cells:
            lines.append("### Cells")
            lines.append("")
            lines.append("| Kind | RAT | Cell | PCI | Band | Freq | RSRP | RSRQ | SINR | RSSI |")
            lines.append("| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |")
            for c in cells:
                cid = c.get("identity") or {}
                m = c.get("metrics") or {}
                lines.append(
                    f"| {c.get('kind')} | {c.get('rat')} | {c.get('title') or '—'} | "
                    f"{cid.get('pci') or '—'} | {cid.get('band') or '—'} | "
                    f"{_fmt_mhz(cid.get('dl_freq_mhz'))} | "
                    f"{_fmt_metric(m.get('rsrp'))} | {_fmt_metric(m.get('rsrq'))} | "
                    f"{_fmt_metric(m.get('sinr'))} | {_fmt_metric(m.get('rssi'))} |"
                )
            lines.append("")

        best = mp.get("best") or {}
        if best:
            lines.append("### Best per metric")
            lines.append("")
            lines.append("| Metric | Value | Quality | Cell |")
            lines.append("| --- | --- | --- | --- |")
            for key, b in best.items():
                lines.append(
                    f"| {key.upper()} | {_fmt_metric(b)} | {b.get('quality') or '—'} | {b.get('cell') or '—'} |"
                )
            lines.append("")
    return "\n".join(lines)


def render_reports_markdown(reports: list[dict[str, Any]]) -> str:
    """Render one or more reports into a single Markdown document. Each report
    becomes a top-level section containing its measurement-point tables."""
    if not reports:
        return "# 5G Signal Monitor — Reports\n\n_No reports to export._\n"

    lines: list[str] = []
    lines.append("# 5G Signal Monitor — Measurement Reports")
    lines.append("")
    lines.append(f"- Reports: **{len(reports)}**")
    lines.append(f"- Total points: **{sum(len(r.get('mps', [])) for r in reports)}**")
    lines.append("")

    for ri, report in enumerate(reports, 1):
        mps = report.get("mps", [])
        lines.append("---")
        lines.append("")
        lines.append(f"# Report {ri} — {report.get('name') or DEFAULT_REPORT_NAME}")
        lines.append("")
        lines.append(f"- Points: **{len(mps)}**")
        created = report.get("created")
        if created:
            try:
                import datetime as _dt

                lines.append(
                    f"- Created: {_dt.datetime.fromtimestamp(created).strftime('%Y-%m-%d %H:%M:%S')}"
                )
            except Exception:
                pass
        lines.append("")
        if not mps:
            lines.append("_No measurement points in this report._")
            lines.append("")
            continue
        for i, mp in enumerate(mps, 1):
            lines.append("## Point {0} — {1}".format(i, mp.get("note") or "(no note)"))
            lines.append("")
            ts = mp.get("ts")
            if ts:
                try:
                    import datetime as _dt2

                    lines.append(f"- **Time**: {_dt2.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')}")
                except Exception:
                    lines.append(f"- **Time**: {ts}")
            lines.append(f"- **Mode**: {mp.get('smart') and 'Smart (best of samples)' or 'Instant'}")
            lines.append(f"- **Score**: {mp.get('score')}")
            sampling = mp.get("sampling")
            if sampling:
                lines.append(
                    f"- **Sampling**: {sampling.get('samples')} samples, "
                    f"{sampling.get('stable_samples')} on the stable serving cell"
                )
            dev = mp.get("device") or {}
            lines.append(f"- **Device**: {dev.get('name')} · {dev.get('mode_label')} · {dev.get('operator')}")
            lines.append("")

            summary = mp.get("summary") or {}
            lines.append("### Serving cell")
            lines.append("")
            lines.append("| Metric | Value |")
            lines.append("| --- | --- |")
            lines.append(f"| Band | {summary.get('band') or '—'} |")
            lines.append(f"| Frequency | {_fmt_mhz(summary.get('frequency_mhz'))} |")
            lines.append(f"| PCI | {summary.get('pci') or '—'} |")
            lines.append(f"| Neighbour 4G towers | {summary.get('neighbor_4g', 0)} |")
            lines.append(f"| Neighbour 5G towers | {summary.get('neighbor_5g', 0)} |")
            lines.append("")

            cags = summary.get("carrier_aggregations") or []
            if cags:
                lines.append("### Carrier aggregation")
                lines.append("")
                lines.append("| RAT | Band | Freq | EARFCN | PCI |")
                lines.append("| --- | --- | --- | --- | --- |")
                for ca in cags:
                    lines.append(
                        f"| {ca.get('rat') or '—'} | {ca.get('band') or '—'} | "
                        f"{_fmt_mhz(ca.get('frequency_mhz'))} | {ca.get('arfcn') or '—'} | {ca.get('pci') or '—'} |"
                    )
                lines.append("")

            cells = mp.get("cells") or []
            if cells:
                lines.append("### Cells")
                lines.append("")
                lines.append("| Kind | RAT | Cell | PCI | Band | Freq | RSRP | RSRQ | SINR | RSSI |")
                lines.append("| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |")
                for c in cells:
                    cid = c.get("identity") or {}
                    m = c.get("metrics") or {}
                    lines.append(
                        f"| {c.get('kind')} | {c.get('rat')} | {c.get('title') or '—'} | "
                        f"{cid.get('pci') or '—'} | {cid.get('band') or '—'} | "
                        f"{_fmt_mhz(cid.get('dl_freq_mhz'))} | "
                        f"{_fmt_metric(m.get('rsrp'))} | {_fmt_metric(m.get('rsrq'))} | "
                        f"{_fmt_metric(m.get('sinr'))} | {_fmt_metric(m.get('rssi'))} |"
                    )
                lines.append("")

            best = mp.get("best") or {}
            if best:
                lines.append("### Best per metric")
                lines.append("")
                lines.append("| Metric | Value | Quality | Cell |")
                lines.append("| --- | --- | --- | --- |")
                for key, b in best.items():
                    lines.append(
                        f"| {key.upper()} | {_fmt_metric(b)} | {b.get('quality') or '—'} | {b.get('cell') or '—'} |"
                    )
                lines.append("")
    return "\n".join(lines)


def _fmt_metric(m: Optional[dict[str, Any]]) -> str:
    if not m or m.get("value") is None:
        return "—"
    return f"{m.get('value')} {m.get('unit') or ''}".strip()


def _fmt_mhz(v: Optional[float]) -> str:
    if v is None:
        return "—"
    return f"{v:.1f} MHz"


def _serving_signature(snapshot: Optional[dict[str, Any]]) -> str:
    """Stable identity of a snapshot's serving cell: (band, pci, freq, cell_id).

    Used by smart capture to detect when the modem switched serving cells
    during the sampling window, so we never blend or pick a transient cell.
    """
    if not snapshot:
        return ""
    cells = snapshot.get("cells") or []
    serving = next((c for c in cells if c.get("kind") == "primary"), cells[0] if cells else {})
    ident = serving.get("identity") or {}
    return "|".join(
        str(ident.get(k) or "")
        for k in ("band", "pci", "dl_freq_mhz", "cell_id", "arfcn")
    )


def _mp_score(snapshot: Optional[dict[str, Any]]) -> float:
    """Overall signal-quality score for a snapshot (0..1, higher is better).

    Ranks a whole snapshot using the serving (primary) cell's metrics, each
    normalized to 0..1. Smart capture uses this to pick one self-consistent
    snapshot instead of combining the best value from each metric/cell across
    different samples, which would pair readings never measured together.
    """
    if not snapshot:
        return 0.0
    cells = snapshot.get("cells") or []
    serving = next((c for c in cells if c.get("kind") == "primary"), cells[0] if cells else {})
    metrics = serving.get("metrics") or {}
    total = 0.0
    count = 0
    for m in metrics.values():
        value = m.get("value")
        lo, hi = m.get("min"), m.get("max")
        if value is None or lo is None or hi is None or hi <= lo:
            continue
        total += max(0.0, min(1.0, (value - lo) / (hi - lo)))
        count += 1
    return total / count if count else 0.0


def _mp_summary(cells: list[dict[str, Any]]) -> dict[str, Any]:
    """Compact serving-cell identity (band/frequency/pci) plus neighbour counts
    and any carrier-aggregation secondary cells.

    The serving cell is the primary one when present (fall back to the first
    cell otherwise). Neighbour towers are counted from cells whose kind is
    'neighbor', split by RAT (LTE -> 4G, NR -> 5G). Carrier aggregations are
    the secondary component-carrier cells (LTE CA / SCC / NR secondary) with
    their band, frequency and PCI when the modem reports them.
    """
    serving = next((c for c in cells if c.get("kind") == "primary"), cells[0] if cells else {})
    sid = serving.get("identity") or {}
    neighbor_4g = sum(1 for c in cells if c.get("kind") == "neighbor" and c.get("rat") == "LTE")
    neighbor_5g = sum(1 for c in cells if c.get("kind") == "neighbor" and c.get("rat") == "NR")
    carrier_aggs = []
    for c in cells:
        if c.get("kind") != "secondary":
            continue
        cid = c.get("identity") or {}
        carrier_aggs.append(
            {
                "rat": c.get("rat"),
                "pci": cid.get("pci"),
                "band": cid.get("band"),
                "frequency_mhz": cid.get("dl_freq_mhz"),
                "arfcn": cid.get("arfcn"),
            }
        )
    return {
        "pci": sid.get("pci"),
        "band": sid.get("band"),
        "frequency_mhz": sid.get("dl_freq_mhz"),
        "neighbor_4g": neighbor_4g,
        "neighbor_5g": neighbor_5g,
        "carrier_aggregations": carrier_aggs,
    }


def _ca_active(snapshot: Optional[dict[str, Any]]) -> bool:
    """True when carrier aggregation is active: any secondary component-carrier
    cell (LTE CA / SCC / NR secondary) is present alongside the primary."""
    for cell in (snapshot or {}).get("cells", []):
        if cell.get("kind") == "secondary":
            return True
    return False


def slim_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Compact snapshot for the history ring: stable cell key + metric values."""
    cells = [
        {
            "kind": c["kind"],
            "rat": c["rat"],
            "key": cell_key(c),
            "metrics": {k: m["value"] for k, m in c["metrics"].items()},
        }
        for c in snapshot.get("cells", [])
    ]
    return {"ts": snapshot["ts"], "cells": cells}


def cell_key(cell: dict[str, Any]) -> str:
    """Stable identity for sparkline matching across polls."""
    pci = (cell.get("identity") or {}).get("pci") or ""
    return f"{cell.get('kind')}:{cell.get('rat')}:{pci}"


# --------------------------------------------------------------------------
# Poller
# --------------------------------------------------------------------------

class Poller(threading.Thread):
    """Periodically fetches a snapshot from the modem (or a demo source)."""

    def __init__(self, state: State, config: dict[str, Any], demo: bool = False) -> None:
        super().__init__(daemon=True, name="modem-poller")
        self.state = state
        self.config = config
        self.demo = demo
        self._stop_event = threading.Event()
        self._demo_gen = DemoGenerator() if demo else None
        self._client: Optional[modem.HuaweiClient] = None
        self._backoff = 1.0

    def _drop_client(self) -> None:
        if self._client is not None:
            try:
                self._client.close()
            except Exception:
                pass
        self._client = None

    def stop(self) -> None:
        self._stop_event.set()

    def run(self) -> None:
        log.info("poller started (demo=%s)", self.demo)
        while not self._stop_event.is_set():
            started = time.monotonic()
            try:
                if self.demo:
                    snapshot = self._demo_gen.next()
                else:
                    if not self.config.get("host") or not self.config.get("password"):
                        self.state.last_error = "Not configured - open the Configure modal."
                        time.sleep(1.0)
                        continue
                    if self._client is None:
                        self._client = make_client(self.config)
                    snapshot = self._client.fetch()
                self._backoff = 1.0
                self.state.publish(snapshot)
                self.state.last_error = None
            except modem.ModemUnavailableError as exc:
                self._drop_client()
                self.state.last_error = str(exc)
                log.warning("poll error: %s", exc)
                time.sleep(self._backoff)
                self._backoff = min(self._backoff * 2, 30.0)
                continue
            except Exception as exc:  # defensive: never kill the poller
                self._drop_client()
                self.state.last_error = f"unexpected error: {exc}"
                log.exception("unexpected poll error")
                time.sleep(self._backoff)
                self._backoff = min(self._backoff * 2, 30.0)
                continue

            interval = max(0.5, float(self.config.get("interval_s") or 2.0))
            elapsed = time.monotonic() - started
            sleep = max(0.1, interval - elapsed)
            self._stop_event.wait(sleep)
        log.info("poller stopped")


# --------------------------------------------------------------------------
# Demo data (realistic, based on a real H122-373 NSA dump, adapted for a 5G CPE)
# --------------------------------------------------------------------------

class DemoGenerator:
    def __init__(self) -> None:
        self.t0 = time.time()
        self.phase = random.random() * math.tau

    def next(self) -> dict[str, Any]:
        t = time.time() - self.t0
        wobble = lambda amp, period: amp * math.sin(self.phase + t / period)  # noqa: E731

        lte_rsrp = -78 + wobble(6, 25)
        nr_rsrp = -75 + wobble(7, 20)
        nr_sinr = 17 + wobble(4, 30)
        lte_sinr = 11 + wobble(5, 35)
        dl = max(0, 410 + wobble(120, 12))
        ul = max(0, 63 + wobble(22, 18))

        signal = {
            "mode": "101",
            "plmn": "65510",
            "pci": "427",
            "cell_id": "0x1F3A92C4",
            "band": "7",
            "earfcn": "DL:3050 UL:21050",
            "dlfrequency": "2650000kHz",
            "ulfrequency": "2530000kHz",
            "dlbandwidth": "20MHz",
            "ulbandwidth": "20MHz",
            "rsrp": f"{lte_rsrp:.0f}dBm",
            "rsrq": f"{-6 - wobble(2, 40):.1f}dB",
            "sinr": f"{lte_sinr:.0f}dB",
            "rssi": f"{-53 - wobble(3, 30):.0f}dBm",
            "cqi0": "8",
            "txpower": "PPusch:0dBm PPucch:0dBm PSrs:0dBm PPrach:0dBm",
            "dl_mcs": "mcsDownCarrier1Code0:29",
            "scc_pci": "0x20",
            # NR carrier (NSA secondary)
            "nrrsrp": f"{nr_rsrp:.0f}dBm",
            "nrrsrq": f"{-9 - wobble(2, 35):.1f}dB",
            "nrsinr": f"{nr_sinr:.0f}dB",
            "nrearfcn": "DL:643660 UL:643660",
            "nrdlfreq": "3654900kHz",
            "nrulfreq": "3654900kHz",
            "nrdlbandwidth": "90MHz",
            "nrulbandwidth": "90MHz",
            "nrcqi0": "32639",
            "nrdlmcs": "NRmcsDownCarrier1Code0:27",
            "nrtxpower": "PPusch:12dBm PPucch:-4dBm PSrs:0dBm PPrach:-1dBm",
            "nrrank": "4",
        }
        status = {"SignalIconNr": str(4 + int(wobble(1, 60) > 0.6))}
        traffic = {
            "CurrentDownloadRate": str(int(dl * 1_000_000 / 8)),
            "CurrentUploadRate": str(int(ul * 1_000_000 / 8)),
        }
        month = {
            "CurrentMonthDownload": str(int(1.2 * 1024 ** 3)),
            "CurrentMonthUpload": str(int(0.15 * 1024 ** 3)),
            "CurrentDayUsed": str(int(320 * 1024 * 1024)),
        }
        basic = {"devicename": "H153-381"}
        device_info = {"DeviceName": "H153-381", "WanIPAddress": "192.168.0.100", "UpTime": "18640"}
        cell_info = {
            "NrCellInfo": [
                {"pci": "723", "arfcn": "643660", "band": "n78", "rsrp": "-89dBm", "rsrq": "-11.0dB", "sinr": "9dB"},
                {"pci": "556", "arfcn": "640000", "band": "n78", "rsrp": "-102dBm", "rsrq": "-13.5dB", "sinr": "4dB"},
            ],
            "LteCellInfo": [
                {"pci": "77", "arfcn": "3050", "band": "7", "rsrp": "-95dBm", "rsrq": "-12.0dB", "sinr": "6dB", "rssi": "-62dBm"},
            ],
        }
        snap = modem.build_snapshot(signal, status, traffic, month, basic, device_info, cell_info, source="demo")
        snap["demo"] = True
        snap["raw"] = {"signal": signal, "cell_info": cell_info}
        return snap


# --------------------------------------------------------------------------
# API
# --------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(_app: FastAPI):
    _restart_poller(load_config(), demo=demo_mode)
    yield
    if poller is not None:
        poller.stop()


app = FastAPI(title="5G Signal Monitor", lifespan=lifespan)
state = State()
poller: Optional[Poller] = None

# Set to True when the app is started with --demo (also via SIGNAL_MONITOR_DEMO=1)
demo_mode = os.environ.get("SIGNAL_MONITOR_DEMO") == "1"


class ConfigIn(BaseModel):
    host: str = Field(default=DEFAULT_CONFIG["host"], max_length=255)
    username: str = Field(default=DEFAULT_CONFIG["username"], max_length=64)
    password: str = Field(default="", max_length=255)
    interval_s: float = Field(default=DEFAULT_CONFIG["interval_s"], ge=0.5, le=60.0)
    vendor: str = Field(default=DEFAULT_CONFIG["vendor"], max_length=32)
    # optional transport override: "" = vendor default (D-Link LuCI is https)
    scheme: str = Field(default="", max_length=8)


class MpIn(BaseModel):
    note: str = Field(default="", max_length=200)
    smart: bool = Field(default=False)
    smart_samples: int = Field(default=10, ge=1, le=120)
    smart_interval_s: float = Field(default=1.0, ge=0.1, le=10.0)


VENDOR_LABELS = {
    "huawei": "Huawei HiLink",
    "dlink": "D-Link LuCI",
}


def make_client(config: dict[str, Any]) -> Any:
    """Build the modem client for the configured vendor.

    Every vendor client exposes the same interface as modem.HuaweiClient:
    fetch() -> normalized snapshot, validate(), close().
    """
    vendor = str(config.get("vendor") or "huawei").lower()
    if vendor == "dlink":
        import dlink

        scheme = str(config.get("scheme") or "").lower() or "https"
        return dlink.DlinkClient(
            config["host"],
            config["username"],
            config["password"],
            scheme=scheme,
        )
    return modem.HuaweiClient(config["host"], config["username"], config["password"])


def _restart_poller(config: dict[str, Any], demo: bool) -> None:
    global poller
    if poller is not None:
        poller.stop()
        poller = None
    poller = Poller(state, config, demo=demo)
    poller.start()


@app.get("/api/status")
def api_status() -> dict[str, Any]:
    snapshot = state.get_snapshot()
    if snapshot is None:
        return {
            "ts": time.time(),
            "device": {"name": "---", "brand": None, "model": None, "mode_label": "---",
                       "bars": None, "signal_quality": None, "signal_quality_label": None,
                       "plmn": "---", "operator": "---", "dl_mbps": None, "ul_mbps": None,
                       "month_gb": None, "today_mb": None, "uptime_s": None, "wan_ip": None},
            "cells": [],
            "source": "none",
            "error": state.last_error or "No data yet - configure the modem.",
        }
    return snapshot


@app.get("/api/history")
def api_history(limit: int = 300) -> list[dict[str, Any]]:
    return state.get_history(max(1, min(limit, HISTORY_MAX)))


@app.get("/api/raw")
def api_raw() -> dict[str, Any]:
    """Last raw modem responses (device/signal, net/cell-info) for debugging."""
    if state.last_raw is None:
        return {"error": "no data yet"}
    return state.last_raw


@app.get("/api/best")
def api_best() -> dict[str, Any]:
    """Lifetime best (max) value ever seen per metric."""
    return state.get_best()


@app.post("/api/best/clear")
def api_best_clear() -> dict[str, Any]:
    state.clear_best()
    return {"ok": True}


@app.get("/api/reports")
def api_reports() -> list[dict[str, Any]]:
    """List of measurement reports (light: id, name, created, mp_count)."""
    return state.get_reports()


@app.get("/api/reports/active")
def api_reports_active() -> dict[str, Any]:
    return {"id": state.get_active_report_id()}


class ReportIn(BaseModel):
    name: str = Field(default="", max_length=120)


@app.post("/api/reports")
def api_reports_create(body: ReportIn) -> dict[str, Any]:
    """Create a new empty report and make it active."""
    report = state.create_report(body.name)
    return report or {}


@app.delete("/api/reports/{report_id}")
def api_reports_delete(report_id: str) -> dict[str, Any]:
    if not state.delete_report(report_id):
        raise HTTPException(status_code=404, detail="Report not found")
    return {"ok": True}


@app.post("/api/reports/{report_id}/clear")
def api_reports_clear(report_id: str) -> dict[str, Any]:
    if not state.clear_report(report_id):
        raise HTTPException(status_code=404, detail="Report not found")
    return {"ok": True}


@app.post("/api/reports/{report_id}/open")
def api_reports_open(report_id: str) -> dict[str, Any]:
    if not state.open_report(report_id):
        raise HTTPException(status_code=404, detail="Report not found")
    return {"ok": True, "id": report_id}


@app.get("/api/mp")
def api_mp(report_id: Optional[str] = None) -> list[dict[str, Any]]:
    """List of captured measurement points of a report (active by default)."""
    return state.get_mp(report_id=report_id)


@app.post("/api/mp")
def api_mp_create(body: MpIn, report_id: Optional[str] = None) -> dict[str, Any]:
    """Capture the current measurements into a report (active by default)."""
    if state.get_snapshot() is None:
        raise HTTPException(status_code=400, detail="No measurements yet - nothing to capture")
    entry = state.capture_mp(
        note=body.note,
        smart=body.smart,
        smart_samples=body.smart_samples,
        smart_interval_s=body.smart_interval_s,
        report_id=report_id,
    )
    if entry is None:
        raise HTTPException(status_code=404, detail="Report not found")
    return entry


@app.post("/api/mp/clear")
def api_mp_clear(report_id: Optional[str] = None) -> dict[str, Any]:
    state.clear_mp(report_id=report_id)
    return {"ok": True}


@app.get("/api/mp/export")
def api_mp_export(fmt: str = "md", report_ids: Optional[str] = None) -> Any:
    """Export one or more reports as a single Markdown (.md) or text (.txt)
    file. `report_ids` is a comma-separated list; defaults to the active report."""
    if report_ids:
        wanted = {rid.strip() for rid in report_ids.split(",") if rid.strip()}
        reports = [r for r in state.reports if r.get("id") in wanted]
    else:
        reports = [r for r in state.reports if r.get("id") == state.get_active_report_id()]
    md = render_reports_markdown(reports)
    if fmt == "txt":
        return PlainTextResponse(md, media_type="text/plain; charset=utf-8")
    return PlainTextResponse(md, media_type="text/markdown; charset=utf-8")


class MpNoteIn(BaseModel):
    note: str = Field(default="", max_length=200)


@app.patch("/api/mp/{mp_id}/note")
def api_mp_update_note(mp_id: str, body: MpNoteIn, report_id: Optional[str] = None) -> dict[str, Any]:
    """Edit the note/comment on a captured measurement point."""
    entry = state.update_mp_note(mp_id, body.note, report_id=report_id)
    if entry is None:
        raise HTTPException(status_code=404, detail="Measurement point not found")
    return entry


@app.get("/api/config")
def api_config() -> dict[str, Any]:
    cfg = load_config()
    out = {k: cfg[k] for k in cfg if k != "password"}
    out.setdefault("vendor", DEFAULT_CONFIG["vendor"])
    return out


@app.post("/api/config")
def api_config_save(body: ConfigIn) -> dict[str, Any]:
    host = (body.host or "").strip().rstrip("/")
    if not host:
        raise HTTPException(status_code=400, detail="Modem IP is required")

    # Keep the stored password when the field is left blank (not retyped)
    if not body.password:
        body.password = load_config().get("password", "")

    vendor = (body.vendor or DEFAULT_CONFIG["vendor"]).strip().lower() or "huawei"
    if vendor not in VENDOR_LABELS:
        raise HTTPException(status_code=400, detail=f"Unknown modem vendor: {vendor}")

    candidate = {
        "host": host,
        "username": body.username.strip() or "admin",
        "password": body.password,
        "interval_s": body.interval_s,
        "vendor": vendor,
    }
    scheme = (body.scheme or "").strip().lower()
    if scheme in ("http", "https"):
        candidate["scheme"] = scheme

    # Validate against the modem (or accept in demo mode)
    if not demo_mode:
        try:
            client = make_client(candidate)
            client.validate()
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Could not reach the modem: {exc}")

    save_config(candidate)
    _restart_poller(candidate, demo=demo_mode)
    return {"ok": True}


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Signal Monitor for Huawei / D-Link CPE")
    parser.add_argument("--demo", action="store_true", help="run with simulated data (no modem)")
    parser.add_argument("--host", default="0.0.0.0", help="bind address (default 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8000, help="port (default 8000)")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.demo:
        os.environ["SIGNAL_MONITOR_DEMO"] = "1"
        global demo_mode
        demo_mode = True
    import uvicorn

    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
