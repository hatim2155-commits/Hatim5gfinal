"""Huawei CPE client wrapper.

Uses huawei-lte-api to poll the modem and produces a normalized snapshot:

    {
      "ts": <unix seconds>,
      "device": {name, mode, mode_label, bars, plmn, operator,
                 dl_mbps, ul_mbps, month_gb, today_mb, uptime_s, wan_ip},
      "cells": [ {kind, rat, title, identity, metrics}, ... ],
      "source": "live" | "demo",
      "error": null | "message"
    }

Cells are built defensively so firmware variations (H153-381, H122-373,
N5368X ...) never crash the app:
  - device/signal returns a flat dict. In NSA mode it carries BOTH the LTE
    anchor (rsrp/rsrq/sinr/rssi/pci/cell_id/band/freqs) and the 5G NR carrier
    (nrrsrp/nrrsrq/nrsinr/nrdlfreq/...). In SA mode only the NR fields apply.
  - net/cell-info (best effort) may expose neighbour/secondary cells with a
    firmware-specific schema; entries are normalized generically and de-duped
    by (rat, pci).
"""

from __future__ import annotations

import logging
import re
import time
from typing import Any, Optional

from huawei_lte_api.Client import Client
from huawei_lte_api.Connection import Connection

from quality import (
    METRIC_ORDER,
    QUALITY_LABELS,
    parse_db,
    parse_dbm,
    parse_int,
    parse_mhz,
    parse_mhz_bandwidth,
    render_metric,
)

log = logging.getLogger(__name__)

MODE_LABELS = {
    "0": "No service",
    "1": "2G",
    "2": "3G",
    "3": "2G+3G",
    "7": "LTE",
    "8": "LTE+2G",
    "9": "LTE+3G",
    "10": "2G+3G+LTE",
    "101": "5G NSA",
    "102": "5G SA",
}

# signal dict keys that indicate a field exists but holds no useful value
_EMPTY_VALUES = {None, "", "0", "00000", "null"}


class ModemUnavailableError(Exception):
    """Raised when the modem cannot be reached / answered."""


def _has(value: Any) -> bool:
    return value is not None and str(value).strip() not in _EMPTY_VALUES


def _fmt(value: Any) -> Optional[str]:
    if not _has(value):
        return None
    return str(value)


def operator_name(plmn: Any) -> Optional[str]:
    """Look up operator by PLMN code using the plmn.py table."""
    n = parse_int(plmn)
    if n is None:
        return None
    try:
        from plmn import plmn_dict

        return plmn_dict.get(n)
    except Exception:
        return None


def mode_label(mode: Any, has_nr: bool = False) -> str:
    """Human label for the modem's mode field.

    Some 5G CPEs (H153-381 included, see huawei-lte-api issue #265) report
    mode 7 (LTE) while actually carrying a 5G NR carrier; when NR fields are
    present we surface that instead of a bare 'LTE'."""
    m = str(mode)
    if m == "101":
        return "5G NSA"
    if m == "102":
        return "5G SA"
    if m in ("7", "8", "9", "10") and has_nr:
        return "LTE + 5G NR (NSA)"
    return MODE_LABELS.get(m, f"Mode {mode}")


def _is_nr(mode: Any) -> bool:
    return str(mode) in ("101", "102")


def _is_sa(mode: Any) -> bool:
    return str(mode) == "102"


def _build_metric(key: str, raw: Any) -> Optional[dict[str, Any]]:
    if key not in METRIC_ORDER:
        return None
    value = parse_number_for(key, raw)
    return render_metric(key, value)


def parse_number_for(key: str, raw: Any) -> Optional[float]:
    if not _has(raw):
        return None
    if key == "rsrp" or key == "rssi":
        return parse_dbm(raw)
    if key == "rsrq":
        return parse_db(raw)
    if key == "sinr":
        return parse_db(raw)
    return parse_dbm(raw)


class HuaweiClient:
    """Owns a Connection to the modem and fetches one normalized snapshot."""

    def __init__(self, host: str, username: str, password: str, timeout: float = 6.0) -> None:
        self.host = host
        self.username = username
        self.password = password
        self.timeout = timeout
        self._conn: Optional[Connection] = None
        self._client: Optional[Client] = None
        self.last_error: Optional[str] = None

    # ------------------------------------------------------------------ connect

    def _ensure_connected(self) -> None:
        if self._client is not None:
            return
        url = f"http://{self.host}/"
        conn = None
        try:
            conn = Connection(url, username=self.username, password=self.password, timeout=self.timeout)
            self._conn = conn
            self._client = Client(conn)
        except Exception as exc:
            # never leave a half-open connection behind
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
            self._conn = None
            self._client = None
            if isinstance(exc, ModemUnavailableError):
                raise
            raise ModemUnavailableError(f"connect/login failed: {exc}") from exc

    def close(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                pass
        self._conn = None
        self._client = None

    # ------------------------------------------------------------------ fetch

    def validate(self) -> None:
        """Light check used by the config modal: connect and hit one authorized
        endpoint so wrong credentials / unreachable host fail fast."""
        self._ensure_connected()
        try:
            self._client.device.basic_information()
        except Exception as exc:
            self.close()
            raise ModemUnavailableError(f"login or reachability failed: {exc}") from exc
        finally:
            self.close()

    def fetch(self) -> dict[str, Any]:
        """Poll the modem and return a normalized snapshot dict."""
        self._ensure_connected()
        try:
            signal = self._client.device.signal()
            status = self._client.monitoring.status()
            traffic = self._client.monitoring.traffic_statistics()
            month = self._client.monitoring.month_statistics()
            basic = self._client.device.basic_information()
        except Exception as exc:
            # Session can go stale (login required / system busy) - drop it so
            # the next poll re-authenticates cleanly.
            log.warning("modem request failed: %s", exc)
            self.close()
            raise ModemUnavailableError(f"modem request failed: {exc}") from exc

        device_info: dict[str, Any] = {}
        cell_info_raw: Any = None
        for name, fn in (
            ("device_info", lambda: self._client.device.information()),
            ("cell_info", lambda: self._client.net.cell_info()),
        ):
            try:
                data = fn()
                if name == "device_info":
                    device_info = data if isinstance(data, dict) else {}
                else:
                    cell_info_raw = data
            except Exception as exc:
                log.info("%s unavailable: %s", name, exc)

        return build_snapshot(
            signal=signal,
            status=status,
            traffic=traffic,
            month=month,
            basic=basic,
            device_info=device_info,
            cell_info_raw=cell_info_raw,
            raw={"signal": signal, "cell_info": cell_info_raw},
        )


# --------------------------------------------------------------------------
# Snapshot building (pure functions, testable)
# --------------------------------------------------------------------------

def build_snapshot(
    signal: dict[str, Any],
    status: dict[str, Any],
    traffic: dict[str, Any],
    month: dict[str, Any],
    basic: dict[str, Any],
    device_info: Optional[dict[str, Any]] = None,
    cell_info_raw: Any = None,
    source: str = "live",
    raw: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    device_info = device_info or {}

    mode = str(signal.get("mode") or "7")
    sa = _is_sa(mode)
    has_nr = any(_has(signal.get(k)) for k in ("nrrsrp", "nrsinr", "nrdlfreq", "nrdlbandwidth"))

    cells: list[dict[str, Any]] = []

    # -- LTE anchor / primary ------------------------------------------------
    lte_metrics = _metrics_from(signal, {"rsrp": "rsrp", "rsrq": "rsrq", "sinr": "sinr", "rssi": "rssi"})
    lte_identity = {
        "pci": _fmt(signal.get("pci")),
        "cell_id": _fmt(signal.get("cell_id")),
        "band": _fmt(signal.get("band")),
        "earfcn": _fmt(signal.get("earfcn")),
        "dl_freq_mhz": parse_mhz(signal.get("dlfrequency")),
        "ul_freq_mhz": parse_mhz(signal.get("ulfrequency")),
        "dl_bandwidth_mhz": parse_mhz_bandwidth(signal.get("dlbandwidth")),
        "ul_bandwidth_mhz": parse_mhz_bandwidth(signal.get("ulbandwidth")),
        "tx_power": _fmt(signal.get("txpower")),
        "mcs": _fmt(signal.get("dl_mcs")),
        "cqi": _fmt(signal.get("cqi0")),
    }
    lte_present = bool(lte_metrics) or lte_identity["pci"] or lte_identity["cell_id"]

    # -- NR secondary / primary -----------------------------------------------
    # NR has no RSSI field (RSSI is a 2G/3G/LTE metric); only rsrp/rsrq/sinr apply.
    nr_metrics = _metrics_from(
        signal,
        {"rsrp": "nrrsrp", "rsrq": "nrrsrq", "sinr": "nrsinr"},
    )
    nr_identity = {
        "pci": _fmt(signal.get("nrpci")),
        "cell_id": _fmt(signal.get("nrcellid")),
        "band": _fmt(signal.get("nrband")),
        "arfcn": _fmt(signal.get("nrearfcn")),
        "dl_freq_mhz": parse_mhz(signal.get("nrdlfreq")),
        "ul_freq_mhz": parse_mhz(signal.get("nrulfreq")),
        "dl_bandwidth_mhz": parse_mhz_bandwidth(signal.get("nrdlbandwidth")),
        "ul_bandwidth_mhz": parse_mhz_bandwidth(signal.get("nrulbandwidth")),
        "tx_power": _fmt(signal.get("nrtxpower")),
        "mcs": _fmt(signal.get("nrdlmcs")),
        "cqi": _fmt(signal.get("nrcqi0")),
        "rank": _fmt(signal.get("nrrank")),
        "bler": _fmt(signal.get("nrbler")),
    }
    nr_present = bool(nr_metrics) or nr_identity["pci"] or nr_identity["cell_id"] or _has(signal.get("nrdlfreq"))

    # In SA mode NR is the primary; in NSA mode LTE is primary and NR secondary.
    if sa or (has_nr and not lte_present):
        if nr_present:
            cells.append(_cell("primary", "NR", "Primary cell (5G NR)", nr_identity, nr_metrics))
        if lte_present:
            cells.append(_cell("secondary", "LTE", "Secondary cell (LTE anchor)", lte_identity, lte_metrics))
    else:
        if lte_present:
            cells.append(_cell("primary", "LTE", "Primary cell (LTE anchor)", lte_identity, lte_metrics))
        if nr_present:
            cells.append(_cell("secondary", "NR", "Secondary cell (5G NR)", nr_identity, nr_metrics))

    # LTE carrier-aggregation secondary (scc_pci) shown as extra cell
    scc = signal.get("scc_pci")
    if _has(scc):
        cells.append(
            _cell(
                "secondary",
                "LTE",
                "LTE carrier aggregation",
                {"pci": str(scc), "band": _fmt(signal.get("scc_band"))},
                {},
            )
        )

    # Neighbour cells from net/cell-info (best effort, de-duped by rat+pci)
    cells += _cells_from_cell_info(cell_info_raw, existing=cells)

    device_name = _fmt(basic.get("devicename")) or _fmt(device_info.get("DeviceName")) or "Huawei CPE"
    signal_quality, signal_quality_label = _overall_quality(cells)
    device = {
        "name": device_name,
        "brand": "Huawei",
        "model": device_name if device_name != "Huawei CPE" else None,
        "mode": mode,
        "mode_label": mode_label(mode, has_nr=has_nr),
        "bars": _parse_bars(status),
        "signal_quality": signal_quality,
        "signal_quality_label": signal_quality_label,
        "plmn": _fmt(signal.get("plmn")) or "---",
        "operator": operator_name(signal.get("plmn")) or "---",
        "dl_mbps": _rate_mbps(traffic.get("CurrentDownloadRate")),
        "ul_mbps": _rate_mbps(traffic.get("CurrentUploadRate")),
        "month_gb": _month_gb(month),
        "today_mb": _today_mb(month),
        "uptime_s": parse_int(device_info.get("UpTime")),
        "wan_ip": _fmt(device_info.get("WanIPAddress")) or _fmt(device_info.get("wan_ip_address")),
    }

    return {
        "ts": time.time(),
        "device": device,
        "cells": cells,
        "source": source,
        "error": None,
        "raw": raw,
    }


def _cell(kind: str, rat: str, title: str, identity: dict[str, Any], metrics: dict[str, Any]) -> dict[str, Any]:
    # keep only non-empty identity entries for compactness
    clean_identity = {k: v for k, v in identity.items() if v is not None and v != ""}
    return {"kind": kind, "rat": rat, "title": title, "identity": clean_identity, "metrics": metrics}


def _metrics_from(signal: dict[str, Any], mapping: dict[str, str]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, raw_key in mapping.items():
        raw = signal.get(raw_key)
        value = parse_number_for(key, raw)
        if value is not None:
            out[key] = render_metric(key, value)
    return out


_QUALITY_RANK = {"excellent": 0, "good": 1, "fair": 2, "poor": 3}


def _overall_quality(cells: list[dict[str, Any]]) -> tuple[Optional[str], Optional[str]]:
    """Overall signal classification from the serving (primary) cell's metrics.

    We take the WORST metric quality as the conservative overall level. When the
    modem provides its own classification (D-Link signalStrength), clients use
    that instead; this is the fallback for vendors that only expose raw metrics.
    """
    serving = next((c for c in cells if c.get("kind") == "primary"), cells[0] if cells else {})
    worst: Optional[str] = None
    worst_rank = -1
    for metric in (serving.get("metrics") or {}).values():
        quality = metric.get("quality")
        if not quality:
            continue
        rank = _QUALITY_RANK.get(quality, 4)
        if rank > worst_rank:
            worst_rank, worst = rank, quality
    if not worst:
        return None, None
    return worst, QUALITY_LABELS.get(worst)


def _parse_bars(status: dict[str, Any]) -> Optional[int]:
    for k in ("SignalIconNr", "SignalIcon"):
        v = status.get(k)
        n = parse_int(v)
        if n is not None and n > 0:
            return min(n, 5)
    return None


def _rate_mbps(raw: Any) -> Optional[float]:
    """CurrentDownloadRate is bytes/sec -> Mbit/s."""
    n = parse_dbm(raw)
    if n is None:
        return None
    return round(n * 8 / 1_000_000, 2)


def _month_gb(month: dict[str, Any]) -> Optional[float]:
    dl = parse_dbm(month.get("CurrentMonthDownload"))
    ul = parse_dbm(month.get("CurrentMonthUpload"))
    if dl is None and ul is None:
        return None
    return round(((dl or 0) + (ul or 0)) / (1024 ** 3), 2)


def _today_mb(month: dict[str, Any]) -> Optional[float]:
    n = parse_dbm(month.get("CurrentDayUsed"))
    if n is None:
        n = parse_dbm(month.get("CurrentDayDownload"))
    if n is None:
        return None
    return round(n / (1024 ** 2), 1)


# --------------------------------------------------------------------------
# net/cell-info normalization
# --------------------------------------------------------------------------

def _cells_from_cell_info(data: Any, existing: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if data is None:
        return []
    seen = {_cell_dedupe_key(c["rat"], c["identity"]) for c in existing}
    out: list[dict[str, Any]] = []
    for parent_key, entry in _iter_cell_dicts(data):
        identity, metrics = _normalize_cell_entry(entry)
        if identity.get("type") is None and parent_key:
            identity["type"] = parent_key
        if not metrics:
            continue
        rat = _rat_for_cell_entry(parent_key, entry)
        kind = _kind_for_cell_info(identity.get("type") or parent_key)
        title = f"{identity.get('type') or 'Neighbour cell'} ({rat})"
        key = _cell_dedupe_key(rat, identity)
        if key in seen:
            continue
        seen.add(key)
        out.append(_cell(kind, rat, title, identity, metrics))
    return out


def _cell_dedupe_key(rat: str, identity: dict[str, Any]) -> tuple:
    """Identity key used to avoid duplicate cells. PCC and SCC can share a PCI
    (the user's modem reports PCI 463 on both), so EARFCN/band disambiguates."""
    return (rat, identity.get("pci"), _normalize_arfcn(identity.get("arfcn")), identity.get("band"))


def _normalize_arfcn(value: Any) -> Optional[str]:
    """'DL:3050 UL:21050' -> '3050', '1600' -> '1600', None -> None."""
    s = str(value) if value is not None else ""
    m = re.search(r"\d+", s)
    return m.group(0) if m else None


def _kind_for_cell_info(type_hint: Optional[str]) -> str:
    t = (type_hint or "").upper()
    if t in ("PCC", "PCC_CELL", "PRIMARY", "SERVING"):
        return "primary"
    if t in ("SCC", "SCC_CELL", "SECONDARY"):
        return "secondary"
    if t in ("NEIGHBOUR", "NEIGHBOR", "NEIGHBOUR_CELL", "NEIGHBOR_CELL", "MEASUREMENT"):
        return "neighbor"
    return "neighbor"


def _rat_for_cell_entry(parent_key: Optional[str], entry: dict[str, Any]) -> str:
    """NR/LTE heuristic: wrapper key ('NrCellInfo') or entry Rat field, else
    keys starting with 'nr' (nrrsrp, nrpci, ...)."""
    context = (parent_key or "") + " " + str(_entry_get(entry, "Rat") or "")
    if "nr" in context.lower():
        return "NR"
    if "lte" in context.lower():
        return "LTE"
    # NR fields are prefixed 'nr' (nrrsrp, nrsinr, nrpci ...)
    if any(k.lower().startswith("nr") for k in entry):
        return "NR"
    return "LTE"


# Generic XML list-item wrappers that do not carry RAT information
_GENERIC_CONTAINER_KEYS = {"item", "items", "row", "rows", "entry", "entries", "cell", "cells"}


def _iter_cell_dicts(node: Any, parent_key: Optional[str] = None):
    """Yield (wrapper_key, dict) for dicts that look like individual cell
    entries. The wrapper key survives generic container nesting (item/row)."""
    if isinstance(node, dict):
        if _looks_like_cell(node):
            yield parent_key, node
        for key, value in node.items():
            next_key = parent_key if key.lower() in _GENERIC_CONTAINER_KEYS else key
            yield from _iter_cell_dicts(value, next_key)
    elif isinstance(node, (list, tuple)):
        for value in node:
            yield from _iter_cell_dicts(value, parent_key)


def _looks_like_cell(d: dict[str, Any]) -> bool:
    keys = {k.lower() for k in d.keys()}
    return bool(keys & {"pci", "arfcn", "earfcn", "cellid", "cell_id", "band", "eci"})


def _entry_get(entry: dict[str, Any], key: str) -> Any:
    """Case-insensitive lookup for cell-info entry keys (real firmware may
    return 'CellId', 'ARFCN', 'Band', 'Rat' with various casings)."""
    if key in entry:
        return entry[key]
    lowered = key.lower()
    for k, v in entry.items():
        if k.lower() == lowered:
            return v
    return None


def _normalize_cell_entry(entry: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    identity = {
        "pci": _fmt(_entry_get(entry, "pci")),
        "cell_id": _fmt(_entry_get(entry, "cellid") or _entry_get(entry, "cell_id") or _entry_get(entry, "eci")),
        "band": _fmt(_entry_get(entry, "band")),
        "arfcn": _fmt(_entry_get(entry, "arfcn") or _entry_get(entry, "earfcn")),
        "type": _fmt(_entry_get(entry, "type")),
        "dl_freq_mhz": parse_mhz(_entry_get(entry, "dlfreq") or _entry_get(entry, "freq")),
        "dl_bandwidth_mhz": parse_mhz_bandwidth(_entry_get(entry, "bandwidth")),
    }
    metrics: dict[str, Any] = {}
    for key, raw_key in (
        ("rsrp", "rsrp"),
        ("rsrq", "rsrq"),
        ("sinr", "sinr"),
        ("rssi", "rssi"),
    ):
        raw = _entry_get(entry, raw_key)
        value = parse_number_for(key, raw)
        if value is not None:
            metrics[key] = render_metric(key, value)
    return identity, metrics
