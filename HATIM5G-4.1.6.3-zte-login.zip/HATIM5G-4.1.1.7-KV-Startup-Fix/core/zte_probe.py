"""Read-only probe for ZTE routers (``/goform/goform_get_cmd_process``).

HTTP GET with the commands ZTE's own web UI uses for signal data. When a
password is given, ONE login request (the same one the router's web page sends)
is made first, because many ZTE models return empty signal fields to anonymous
requests. No setting is written and no lock command is sent. The password is
never included in the output. The result is shown/copied so the real response
format can be reviewed before any ZTE support is built on it.
"""
from __future__ import annotations

import base64
import hashlib
import json
from typing import Any

import requests

_GET = '/goform/goform_get_cmd_process'

PROBE_GROUPS: dict[str, list[str]] = {
    'device': ['wa_inner_version', 'cr_version', 'modem_main_state', 'network_type',
               'network_provider', 'ppp_status'],
    'lte': ['lte_rsrp', 'lte_rsrq', 'lte_snr', 'lte_rssi', 'lte_pci', 'lte_band',
            'lte_bandwidth', 'wan_active_band', 'wan_active_channel', 'wan_lte_ca',
            'lte_ca_pcell_band', 'lte_ca_pcell_arfcn', 'lte_ca_pcell_freq',
            'lte_ca_pcell_bandwidth', 'lte_ca_scell_band', 'lte_ca_scell_arfcn',
            'lte_ca_scell_bandwidth', 'lte_ca_scell_info', 'lte_multi_ca_scell_info',
            'lte_multi_ca_scell_sig_info'],
    'nr': ['nr5g_pci', 'nr5g_rsrp', 'nr5g_rsrq', 'nr5g_snr', 'nr5g_cell_id',
           'nr5g_action_band', 'nr5g_action_channel', 'nr5g_bandwidth', 'nr5g_type',
           'nr_ca_state', 'nr_ca_pcell_band', 'nr_ca_pcell_freq', 'nr_ca_pcell_bandwidth',
           'nr_multi_ca_scell_info', 'nr_multi_ca_scell_sig_info'],
    'neighbors': ['ngbr_cell_info'],
    'locks': ['lte_band_lock', 'nr5g_sa_band_lock', 'nr5g_nsa_band_lock'],
}


_SET = '/goform/goform_set_cmd_process'


def _login(session: requests.Session, base: str, password: str, headers: dict,
           timeout: float) -> str:
    """One login request. Returns a short status text (never the password)."""
    ld = ''
    try:
        reply = session.get(f"{base}{_GET}?isTest=false&cmd=LD", headers=headers, timeout=timeout)
        ld = str(reply.json().get('LD', '') or '')
    except Exception:
        ld = ''
    if ld:
        inner = hashlib.sha256(password.encode()).hexdigest().upper()
        secret = hashlib.sha256((inner + ld).encode()).hexdigest().upper()
        scheme = 'sha256+LD'
    else:
        secret = base64.b64encode(password.encode()).decode()
        scheme = 'base64'
    try:
        reply = session.post(f"{base}{_SET}", headers=headers, timeout=timeout,
                             data={'isTest': 'false', 'goformId': 'LOGIN', 'password': secret})
        return f"{scheme}: HTTP {reply.status_code} {reply.text[:120]}"
    except Exception as exc:
        return f"{scheme}: error {type(exc).__name__}: {exc}"


def probe(ip: str, password: str = '', timeout: float = 5.0) -> dict[str, Any]:
    """Returns {group: parsed-or-raw response | 'error: ...'} (plus login status)."""
    base = f'http://{ip}'
    headers = {'Referer': f'{base}/index.html', 'X-Requested-With': 'XMLHttpRequest'}
    session = requests.Session()
    result: dict[str, Any] = {'host': ip}
    if password:
        result['login'] = _login(session, base, password, headers, timeout)
    for group, cmds in PROBE_GROUPS.items():
        url = f"{base}{_GET}?isTest=false&multi_data=1&cmd={','.join(cmds)}"
        try:
            reply = session.get(url, headers=headers, timeout=timeout)
            text = reply.text
            try:
                result[group] = json.loads(text)
            except ValueError:
                result[group] = text[:2000]
        except Exception as exc:  # network errors are the answer here
            result[group] = f"error: {type(exc).__name__}: {exc}"
    return result


def to_text(data: dict[str, Any]) -> str:
    """Compact: fields with values first, empty field names listed in one line."""
    out: dict[str, Any] = {}
    for key, value in data.items():
        if isinstance(value, dict):
            filled = {k: v for k, v in value.items() if v not in ('', None)}
            empty = [k for k, v in value.items() if v in ('', None)]
            out[key] = {**filled, '_empty': ' '.join(empty)} if empty else filled
        else:
            out[key] = value
    return json.dumps(out, ensure_ascii=False, indent=1)
