from core.neighbor_cells import band_from_earfcn, parse_cell_info


def test_parses_only_entries_with_pci():
    data = {'CellInfo': {'Cell': [
        {'PCI': '301', 'EARFCN': '1300', 'RSRP': '-89dBm', 'RSRQ': '-11dB', 'SINR': '9dB'},
        {'phy_cell_id': 112, 'dlearfcn': 100, 'rsrp': '-97'},
    ]}}
    cells = parse_cell_info(data)
    assert len(cells) == 2
    assert (cells[0].band, cells[0].pci, cells[0].rsrp) == ('B3', 301, -89.0)
    assert cells[1].band == 'B1' and cells[1].rsrq is None


def test_unrecognised_or_empty_response_gives_no_cells():
    assert parse_cell_info({'a': 1}) == []
    assert parse_cell_info(None) == []
    assert band_from_earfcn(9999) is None
