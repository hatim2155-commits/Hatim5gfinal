"""Read-only parsing of neighbouring-cell data reported by the router.

Nothing here is invented: a cell is returned only when the router's own
response contains a physical-cell-id field. Missing fields stay ``None`` and
the UI shows them as unavailable. The router response layout differs between
models/firmwares, so field names are matched loosely (case/underscore
insensitive) and an unrecognised response simply yields an empty list.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

# 3GPP TS 36.101 downlink EARFCN ranges (inclusive) for common LTE bands.
_LTE_EARFCN_BANDS: tuple[tuple[int, int, int], ...] = (
    (0, 599, 1), (600, 1199, 2), (1200, 1949, 3), (1950, 2399, 4),
    (2400, 2649, 5), (2750, 3449, 7), (3450, 3799, 8), (6150, 6449, 20),
    (9210, 9659, 28), (37750, 38249, 38), (38650, 39649, 40), (39650, 41589, 41),
)

_PCI = {'pci', 'phycellid', 'physcellid', 'physicalcellid', 'physicalcellidentity'}
_EARFCN = {'earfcn', 'dlearfcn', 'arfcn', 'nrarfcn', 'channel'}
_BAND = {'band', 'lteband', 'bandinfo', 'nrband'}
_RSRP = {'rsrp'}
_RSRQ = {'rsrq'}
_SINR = {'sinr', 'snr'}


@dataclass(frozen=True)
class NeighborCell:
    band: str | None
    pci: int | None
    arfcn: int | None
    rsrp: float | None
    rsrq: float | None
    sinr: float | None


def band_from_earfcn(earfcn: int | None) -> str | None:
    if earfcn is None:
        return None
    for low, high, band in _LTE_EARFCN_BANDS:
        if low <= earfcn <= high:
            return f'B{band}'
    return None


def _norm(key: Any) -> str:
    return str(key).replace('_', '').replace('-', '').lower()


def _num(value: Any) -> float | None:
    if value is None:
        return None
    text = str(value).lower().replace('dbm', '').replace('db', '').strip()
    try:
        return float(text)
    except ValueError:
        return None


def _pick(entry: dict[str, Any], names: set[str]) -> Any:
    for key, value in entry.items():
        if _norm(key) in names and not isinstance(value, (dict, list)):
            return value
    return None


def _band_text(value: Any) -> str | None:
    text = str(value or '').strip().upper()
    if not text:
        return None
    digits = ''.join(ch for ch in text if ch.isdigit())
    if text.startswith('N') and digits:
        return f'N{digits}'
    if digits:
        return f'B{digits}'
    return None


def parse_cell_info(data: Any) -> list[NeighborCell]:
    """Return every dict in ``data`` that carries a PCI, as a NeighborCell."""
    found: list[NeighborCell] = []

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            pci_raw = _pick(node, _PCI)
            if pci_raw is not None and _num(pci_raw) is not None:
                earfcn_raw = _num(_pick(node, _EARFCN))
                earfcn = int(earfcn_raw) if earfcn_raw is not None else None
                band = _band_text(_pick(node, _BAND)) or band_from_earfcn(earfcn)
                found.append(NeighborCell(
                    band=band, pci=int(_num(pci_raw)), arfcn=earfcn,
                    rsrp=_num(_pick(node, _RSRP)), rsrq=_num(_pick(node, _RSRQ)),
                    sinr=_num(_pick(node, _SINR))))
                return
            for child in node.values():
                walk(child)
        elif isinstance(node, list):
            for child in node:
                walk(child)

    walk(data)
    return found
