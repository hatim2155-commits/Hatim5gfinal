"""Second login (``loginflag`` 2) the router's own developer page performs before it allows
``net/lock-freq``. Observed in the page's requests::

    POST user/challenge_login      <username><firstnonce><mode>1</mode><loginflag>2</loginflag>
      -> <newType><iterations><salt><servernonce><modeselected>
    POST user/authentication_login <clientproof><finalnonce><loginflag>2</loginflag>

SCRAM-SHA-256 as used by Huawei web UIs: salted = PBKDF2-HMAC-SHA256(password, bytes.fromhex(salt),
iterations); clientKey = HMAC(salted, "Client Key"); proof = clientKey XOR HMAC(SHA256(clientKey),
"first,server,final"), final nonce = server nonce. The algorithm is checked only for internal
consistency here (no router available): the router's own ``serversignature`` is verified when it
returns one. ONE attempt only, never retried (a wrong proof counts as a failed login).
"""
from __future__ import annotations

import hashlib
import hmac
import secrets
from typing import Any, Mapping


def _hmac(key: bytes, msg: bytes) -> bytes:
    return hmac.new(key, msg, hashlib.sha256).digest()


def scram_values(password: str, salt_hex: str, iterations: int,
                 first_nonce: str, server_nonce: str) -> tuple[str, str]:
    """-> (client proof hex, expected server signature hex)."""
    salted = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'),
                                 bytes.fromhex(salt_hex), int(iterations), 32)
    client_key = _hmac(salted, b'Client Key')
    stored_key = hashlib.sha256(client_key).digest()
    auth_msg = f'{first_nonce},{server_nonce},{server_nonce}'.encode()
    signature = _hmac(stored_key, auth_msg)
    proof = bytes(a ^ b for a, b in zip(client_key, signature)).hex()
    server_key = _hmac(salted, b'Server Key')
    return proof, _hmac(server_key, auth_msg).hex()


class DeveloperLoginError(Exception):
    pass


def developer_login(session: Any, username: str, password: str) -> bool:
    """Run the two requests on an already logged-in ``huawei_lte_api`` Session.
    Returns True when the router accepted the proof."""
    first = secrets.token_hex(32)
    challenge = session.post_get('user/challenge_login', {
        'username': username, 'firstnonce': first, 'mode': 1, 'loginflag': 2})
    if not isinstance(challenge, Mapping):
        raise DeveloperLoginError('رد غير مفهوم من الراوتر (challenge).')
    try:
        salt = str(challenge['salt'])
        iterations = int(challenge['iterations'])
        server_nonce = str(challenge['servernonce'])
    except (KeyError, ValueError, TypeError) as exc:
        raise DeveloperLoginError('الراوتر لم يعطِ بيانات التحدي المتوقعة.') from exc
    if not server_nonce.startswith(first):
        raise DeveloperLoginError('رد تحدٍ غير متطابق؛ لم يُرسل الإثبات.')
    proof, expected = scram_values(password, salt, iterations, first, server_nonce)
    reply = session.post_get('user/authentication_login', {
        'clientproof': proof, 'finalnonce': server_nonce, 'loginflag': 2})
    if isinstance(reply, Mapping):
        sig = str(reply.get('serversignature') or '')
        if sig and sig.lower() != expected.lower():
            raise DeveloperLoginError('توقيع الراوتر لا يطابق الحساب المتوقع.')
    return True
