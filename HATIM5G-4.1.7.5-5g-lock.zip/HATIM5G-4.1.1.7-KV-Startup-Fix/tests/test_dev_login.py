import hashlib
import hmac

from core.dev_login import developer_login, scram_values


def test_scram_internal_consistency():
    pw, salt = 'pass', 'ab' * 32
    first, server = 'a' * 64, 'a' * 64 + 'XYZ'
    proof, sig = scram_values(pw, salt, 1000, first, server)
    salted = hashlib.pbkdf2_hmac('sha256', pw.encode(), bytes.fromhex(salt), 1000, 32)
    ck = hmac.new(salted, b'Client Key', hashlib.sha256).digest()
    sg = hmac.new(hashlib.sha256(ck).digest(), f'{first},{server},{server}'.encode(), hashlib.sha256).digest()
    assert bytes(a ^ b for a, b in zip(bytes.fromhex(proof), sg)) == ck and len(sig) == 64
