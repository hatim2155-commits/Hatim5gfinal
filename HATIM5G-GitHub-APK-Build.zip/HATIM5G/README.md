# HATIM5G Android wrapper (early build scaffold)

This repository combines the original 5G CPE Signal Monitor web backend/UI with an Android WebView wrapper and a GitHub Actions workflow that produces a debug APK.

**Important limitation:** The Android APK currently bundles the HTML UI only. The original UI expects the FastAPI server in `main.py` to provide `/api/*` endpoints. That Python backend is not yet hosted inside the Android process, so this APK is a build scaffold and is not yet a standalone live-router app. H155-383 compatibility has not been verified. See [README_AR.md](README_AR.md) for GitHub build instructions and limitations.

Original upstream project/license are retained in the source tree. Please review `LICENSE` before redistributing.
